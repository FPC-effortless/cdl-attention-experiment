"""Post-development, fixed-grid VAR/Kalman diagnostic on identical causal forecast panels."""
import argparse,json,math,pathlib
import numpy as np
import edge

def fit_var(tr,alpha):
 x=np.concatenate([z[:-1] for z in tr]).astype(np.float64);y=np.concatenate([z[1:] for z in tr]).astype(np.float64);X=np.c_[x,np.ones(len(x))];w=np.linalg.solve(X.T@X+np.diag([alpha,alpha,1e-8]),X.T@y);A=w[:2].T;b=w[2];rho=max(abs(np.linalg.eigvals(A)))
 if rho>.999:A=A*(.999/rho)
 b=y.mean(0)-A@x.mean(0);res=y-x@A.T-b;Q=np.cov(res.T)+np.eye(2)*1e-6;return A,b,Q

def predict(ps,A,b,Q,R):
 result=[];eye=np.eye(2);trans=[];Ap=eye.copy();bp=np.zeros(2);Qp=np.zeros((2,2))
 for h in range(16):
  if h in edge.H:trans.append((Ap.copy(),bp.copy(),Qp.copy()))
  bp=A@bp+b;Qp=A@Qp@A.T+Q;Ap=A@Ap
 for name,reg,x,t,s in ps:
  xx=x.numpy();mu=np.zeros((1,t.shape[1],3));sig=np.zeros_like(mu);z=np.zeros(2);P=2*eye
  for j in range(t.shape[1]):
   z=A@z+b;P=A@P@A.T+Q;idx=np.flatnonzero(xx[0,j,2:4]);
   if len(idx):
    K=np.linalg.solve(P[np.ix_(idx,idx)]+R*np.eye(len(idx)),P[idx,:]).T;z=z+K@(xx[0,j,idx]-z[idx]);M=eye.copy();M[:,idx]-=K;P=M@P@M.T+R*K@K.T
   P=(P+P.T)/2
   for k,(Ah,bh,Qh) in enumerate(trans):
    mu[0,j,k]=(Ah@z+bh)[0];sig[0,j,k]=math.sqrt(max((Ah@P@Ah.T+Qh)[0,0],1e-9))
  result.append((name,reg,mu,sig,t.numpy(),s.numpy()))
 return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--dataset',required=True);p.add_argument('--out',required=True);args=p.parse_args();path=pathlib.Path(args.dataset);D=np.load(path,allow_pickle=False);meta=json.loads(path.with_suffix('.json').read_text());result={'scope':'post-development fixed-grid diagnostic; no new qualification','folds':{}}
 for g in 'YRG':
  s=meta['splits'][g];raw=[D[k] for k in s['train']];z=np.concatenate(raw);mean=z.mean(0);std=z.std(0);tr=[(v-mean)/std for v in raw];dev=edge.panels([(D[k]-mean)/std for k in s['dev']],s['dev'],'dev-v1');test=edge.panels([(D[k]-mean)/std for k in s['test']],s['test'],'test-v1');best=None;grid=[]
  for alpha in (.1,1.,10.):
   A,b,Q=fit_var(tr,alpha)
   for q in (.25,1.,4.):
    for r in (.001,.01,.1):
     cfg=(A,b,Q*q,r);v=edge.val(predict(dev,*cfg),std[0]);grid.append({'alpha':alpha,'q':q,'r':r,'val':v})
     if best is None or v<best[0]:best=(v,cfg,alpha,q,r)
  v,cfg,alpha,q,r=best;cal=edge.calibrate(predict(dev,*cfg));sm,rows=edge.metrics(predict(test,*cfg),std[0],cal);result['folds'][g]={'grid':grid,'selected':{'alpha':alpha,'q':q,'r':r,'A':cfg[0].tolist(),'b':cfg[1].tolist(),'Q':cfg[2].tolist(),'R':cfg[3],'val':v},'calibration':cal,'test':sm,'flight_metrics':rows};print(g,sm['0.15-1/15'])
 pathlib.Path(args.out).write_text(json.dumps(result,indent=2)+'\n')
 print('equal-fold RMSE',[(h,float(np.mean([v['test'][f'0.15-1/{h}']['rmse_v'] for v in result['folds'].values()]))) for h in edge.H])
if __name__=='__main__':main()
