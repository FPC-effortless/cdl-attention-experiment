from run import *
def extend(p):
 torch.set_num_threads(1);c=torch.load(p,weights_only=True);task,arm,seed=c['task'],c['arm'],c['seed'];m=Net(task,arm,c['ff']);m.load_state_dict(c['weights']);opt=torch.optim.AdamW(m.parameters(),lr=.003);opt.load_state_dict(c['optimizer']);torch.set_rng_state(c['rng']);start=time.perf_counter();curve=[]
 for i in range(c['steps'],1600):
  k,v,ix,q,y=batch(100000+seed*1000+i,BATCH,6,task);z,_=m(k,v,q);loss=F.cross_entropy(z.flatten(0,1),y.flatten());opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1);opt.step();assert torch.isfinite(loss)
  if (i+1)%200==0:curve.append(dict(step=i+1,loss=float(loss.detach()),individual=float((z.argmax(-1)==y).float().mean())))
 sec=time.perf_counter()-start;name=P/'fits'/f'extension_{arm}_{seed}.pt';torch.save(dict(weights=m.state_dict(),optimizer=opt.state_dict(),rng=torch.get_rng_state(),task=task,arm=arm,seed=seed,ff=m.ff,steps=1600,parent_sha=hashlib.sha256(p.read_bytes()).hexdigest()),name);out=dict(task='extension',arm=arm,seed=seed,ff=m.ff,params=count(m),steps=1600,new_steps=1200,history_exposures=38400,seconds=sec,curve=curve,eval=evaluate(m,seed,fresh=9000000),stream=verify(m,seed),sha256=hashlib.sha256(name.read_bytes()).hexdigest());name.with_suffix('.json').write_text(json.dumps(out,indent=2));print('DONE',arm,seed,out['eval']['6'],flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);jobs=sorted((P/'fits').glob('induction_*.pt'));random.Random(19003).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as ex:
  fs=[ex.submit(extend,p) for p in jobs]
  for f in concurrent.futures.as_completed(fs):f.result()
