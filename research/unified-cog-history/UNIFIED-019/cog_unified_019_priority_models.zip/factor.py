import run as r
from run import *
class FactorMatrix(r.Matrix):
 def forward_pair(self,h,mask,qkeys,ab=None):
  # Only records are fed to the history update; learned query gates evaluated through normal forward for auto mode.
  b,t,d=h.shape;u=self.norm(h);z,a=self.inp(u).chunk(2,-1);a=.5+.49*a.sigmoid();a=a.unflatten(-1,(d//2,2)).mean(-1,keepdim=True).expand(*a.shape[:-1],d//2,2).flatten(-2)
  if self.gate=='hold':a=torch.where(mask[...,None],a,torch.ones_like(a))
  rr,rs=assoc(z.tanh(),a);c=u+rr;k=F.normalize(self.address(u),dim=-1);v=self.payload(u).tanh();g=self.write(u).sigmoid()
  if self.gate=='hold':g=g*mask[...,None]
  s=torch.zeros(b,self.kd,self.vd,device=h.device,dtype=h.dtype)
  if self.mode=='add':s=((g*k).unsqueeze(-1)*v.unsqueeze(-2)).sum(1)
  else:
   for i in range(t):
    ki=k[:,i];err=v[:,i]-torch.einsum('bk,bkv->bv',ki,s);s=s+(g[:,i]*ki).unsqueeze(-1)*err.unsqueeze(-2)
  query=self.address(self.norm(qkeys)) if self.reads==2 else self.address(u[:,-1:]);q=F.normalize(query,dim=-1)
  if ab=='uniform':q=torch.ones_like(q)/math.sqrt(self.kd)
  if ab=='same' and self.reads>1:q=q[:,:1].expand_as(q)
  if ab=='swap' and self.reads>1:q=q.flip(1)
  m=torch.einsum('brk,bkv->brv',q,s)
  if ab=='zero':m=torch.zeros_like(m)
  x=h[:,-1]+self.out(rr[:,-1]+self.combine(c[:,-1]).sigmoid()*self.direct(m.flatten(-2)));return x+self.ff(self.norm2(x))
class FactorAttn(r.Attention):
 def forward_pair(self,h,mask,qkeys,ab=None):
  b,t,d=h.shape;u=self.norm(h);q,k,v=self.qkv(u).reshape(b,t,3,self.heads,self.kd//self.heads).permute(2,0,3,1,4).unbind(0);x=self.qkv(self.norm(qkeys)).reshape(b,2,3,self.heads,self.kd//self.heads)[:,:,0];q=torch.stack([x[:,0,0],x[:,1,1]],1)[:,:,None];z=F.scaled_dot_product_attention(q,k,v).transpose(1,2).reshape(b,self.kd);h=h[:,-1]+self.out(z);return h+self.ff(self.norm2(h))
class Model(nn.Module):
 def __init__(self,arm,ff):
  super().__init__();self.arm=arm;self.ff=ff;self.task='multi';self.key=nn.Embedding(16,D);self.val=nn.Embedding(8,D);self.typ=nn.Embedding(3,D);self.pair=nn.Linear(2*D,D);self.norm=nn.LayerNorm(D);self.read=nn.Linear(D,16);self.agg=nn.Linear(D,8)
  self.block=FactorAttn(D,ff,10,2) if arm=='factor_attn' else FactorMatrix(D,ff,16,8,reads=1 if arm=='factor_one' else 2,mode='delta' if 'delta' in arm else 'add',gate='auto' if arm.endswith('auto') else 'hold',tied=False)
  # Delete unused projection: factorized read ties to write address; parameter counts include only active modules.
  if isinstance(self.block,FactorMatrix):self.block.readaddr=None
  with torch.no_grad():
   for m in self.modules():
    if isinstance(m,nn.Linear):m.weight.normal_(0,1/math.sqrt(m.in_features));m.bias.zero_() if m.bias is not None else None
    elif isinstance(m,nn.Embedding):m.weight.normal_(0,.1)
 def forward(self,k,v,q,ab=None):
  rec=self.key(k)+self.val(v)+self.typ.weight[0];qkeys=self.key(q)+self.typ.weight[1];que=self.pair(self.key(q).flatten(-2))[:,None]+self.typ.weight[1];h=torch.cat([rec,que],1);mask=(torch.arange(h.shape[1])[None,:]<k.shape[1]).expand(k.shape[0],-1);z=self.norm(self.block.forward_pair(h,mask,qkeys,ab));return self.read(z).reshape(-1,2,8),self.agg(z)
ARMS=['factor_attn','factor_one','factor_add','factor_add_auto','factor_delta','factor_delta_auto'];SEEDS=[8209,8231,8279]
def run(arm,seed):
 torch.set_num_threads(1);base=count(Model(arm,1));s=count(Model(arm,2))-base;ff=max(4,round(1+(12000-base)/s));torch.manual_seed(seed);m=Model(arm,ff);opt=torch.optim.AdamW(m.parameters(),lr=.003);curve=[];start=time.perf_counter()
 for i in range(600):
  k,v,ix,q,y=batch(300000+seed*1000+i,32,8,'multi');z,a=m(k,v,q);loss=F.cross_entropy(z.flatten(0,1),y.flatten())+F.cross_entropy(a,y.sum(-1)%8);opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1);opt.step();assert torch.isfinite(loss)
  if (i+1)%100==0:curve.append({'step':i+1,'loss':float(loss.detach()),'individual':float((z.argmax(-1)==y).float().mean())})
 sec=time.perf_counter()-start;p=P/'fits'/f'factor_{arm}_{seed}.pt';torch.save(dict(weights=m.state_dict(),optimizer=opt.state_dict(),rng=torch.get_rng_state(),task='factor',arm=arm,seed=seed,ff=ff,steps=600),p);e=evaluate(m,seed,fresh=8000000);ab={}
 if arm!='factor_attn':ab={a:evaluate(m,seed,fresh=8500000,ab=a)['8'] for a in ['uniform','same','swap','zero'] if not(arm=='factor_one' and a in ['same','swap'])};ab['control']=evaluate(m,seed,fresh=8500000)['8']
 out=dict(task='factor',arm=arm,seed=seed,ff=ff,params=count(m),steps=600,history_exposures=19200,seconds=sec,curve=curve,eval=e,ab=ab,sha256=hashlib.sha256(p.read_bytes()).hexdigest());p.with_suffix('.json').write_text(json.dumps(out,indent=2));print('DONE',arm,seed,e['8'],flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);jobs=[(a,s) for a in ARMS for s in SEEDS];random.Random(19002).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as ex:
  fs=[ex.submit(run,*j) for j in jobs]
  for f in concurrent.futures.as_completed(fs):f.result()
