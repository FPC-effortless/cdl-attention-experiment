import torch,time,json,math
from pathlib import Path
P=Path(__file__).parent;torch.set_num_threads(1)
def seq(k,v,g,s):
 out=[]
 for i in range(k.shape[1]):
  a=k[:,i];b=v[:,i]-torch.einsum('bk,bkv->bv',a,s);s=s+(g[:,i]*a).unsqueeze(-1)*b.unsqueeze(-2);out.append(s)
 return torch.stack(out,1)
def scan(k,v,g,s):
 a=torch.eye(k.shape[-1],dtype=k.dtype,device=k.device)-(g*k).unsqueeze(-1)*k.unsqueeze(-2);b=(g*k).unsqueeze(-1)*v.unsqueeze(-2);d=1
 while d<k.shape[1]:
  aa=a[:,d:]@a[:,:-d];bb=a[:,d:]@b[:,:-d]+b[:,d:];a=torch.cat([a[:,:d],aa],1);b=torch.cat([b[:,:d],bb],1);d*=2
 return a@s[:,None]+b

def test(kd,vd,t,batch):
 torch.manual_seed(kd*100000+t*10+batch);k=torch.nn.functional.normalize(torch.randn(batch,t,kd),dim=-1);v=torch.randn(batch,t,vd);g=torch.sigmoid(torch.randn(batch,t,1));s=torch.randn(batch,kd,vd)*.1;ref=seq(k.double(),v.double(),g.double(),s.double());a=seq(k,v,g,s);b=scan(k,v,g,s)
 grads=[]
 for f in [seq,scan]:
  inputs=[x.clone().requires_grad_(True) for x in [k,v,g,s]];o=f(*inputs);o.square().mean().backward();grads.append([x.grad for x in inputs]);
 # Warm, counterbalanced; medians from 5 timings, each 3 repeats.
 with torch.no_grad():
  for f in [seq,scan]:f(k,v,g,s)
  timings={'seq':[],'scan':[]}
  for i in range(5):
   for name,f in ([('seq',seq),('scan',scan)] if i%2==0 else [('scan',scan),('seq',seq)]):
    st=time.perf_counter()
    for _ in range(3):f(k,v,g,s)
    timings[name].append((time.perf_counter()-st)/3*1000)
 return dict(kd=kd,vd=vd,steps=t,batch=batch,seq_error=float((a-ref).abs().max()),scan_error=float((b-ref).abs().max()),difference=float((b-a).abs().max()),gradient_max=max(float((x-y).abs().max()) for x,y in zip(*grads)),seq_ms=sorted(timings['seq'])[2],scan_ms=sorted(timings['scan'])[2],transition_tensor_bytes=batch*t*kd*kd*4)
if __name__=='__main__':
 results=[test(k,8,t,b) for k in [16,32] for t in [32,128,512] for b in [1,8]];(P/'execution.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
