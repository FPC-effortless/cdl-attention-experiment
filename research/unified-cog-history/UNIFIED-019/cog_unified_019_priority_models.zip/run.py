import sys,math,json,time,hashlib,random,concurrent.futures,io
from pathlib import Path
import torch
from torch import nn
import torch.nn.functional as F
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P/'prior'))
from scan_check import assoc
import lm
lm.scan=assoc
from lm import Block
D=32; SEEDS=[8101,8123,8161]; BATCH=32; STEPS=400

def batch(seed,b,n=8,task='compact'):
 g=torch.Generator().manual_seed(seed);k=torch.rand(b,16,generator=g).argsort(-1)[:,:n];v=torch.randint(8,(b,n),generator=g);ix=torch.rand(b,n,generator=g).argsort(-1)[:,:2 if task=='multi' else min(4,n)];return k,v,ix,k.gather(1,ix),v.gather(1,ix)
def pos(t,d,device):
 f=torch.exp(-math.log(10000)*torch.arange(d//2,device=device)/(d//2));x=torch.arange(t,device=device)[:,None]*f;return torch.stack([x.sin(),x.cos()],-1).flatten(-2)*.1
class Attention(nn.Module):
 def __init__(self,d,ff,kd,heads):
  super().__init__();self.kd=kd;self.heads=heads;self.norm=nn.LayerNorm(d);self.qkv=nn.Linear(d,3*kd);self.out=nn.Linear(kd,d);self.norm2=nn.LayerNorm(d);self.ff=nn.Sequential(nn.Linear(d,ff),nn.GELU(),nn.Linear(ff,d))
 def forward(self,x,mask=None,state=None,ab=None):
  b,t,d=x.shape;q,k,v=self.qkv(self.norm(x)).reshape(b,t,3,self.heads,self.kd//self.heads).permute(2,0,3,1,4).unbind(0);z=F.scaled_dot_product_attention(q,k,v,is_causal=True).transpose(1,2).reshape(b,t,self.kd);h=x+self.out(z);return h+self.ff(self.norm2(h)),None
class Matrix(nn.Module):
 def __init__(self,d,ff,kd,vd,reads=1,mode='delta',gate='auto',tied=True):
  super().__init__();self.d=d;self.kd=kd;self.vd=vd;self.reads=reads;self.mode=mode;self.gate=gate;self.tied=tied;self.norm=nn.LayerNorm(d);self.inp=nn.Linear(d,2*d);self.address=nn.Linear(d,kd);self.payload=nn.Linear(d,vd);self.write=nn.Linear(d,1);self.readaddr=nn.Linear(d,reads*kd) if not tied else None;self.direct=nn.Linear(vd*reads,d);self.combine=nn.Linear(d,d);self.out=nn.Linear(d,d);self.norm2=nn.LayerNorm(d);self.ff=nn.Sequential(nn.Linear(d,ff),nn.GELU(),nn.Linear(ff,d))
 def forward(self,h,mask=None,state=None,ab=None,collect=False):
  b,t,d=h.shape;u=self.norm(h);z,a=self.inp(u).chunk(2,-1);a=.5+.49*a.sigmoid();a=a.unflatten(-1,(d//2,2)).mean(-1,keepdim=True).expand(*a.shape[:-1],d//2,2).flatten(-2)
  if self.gate=='hold':a=torch.where(mask[...,None],a,torch.ones_like(a))
  r,rs=assoc(z.tanh(),a,None if state is None else state[0]);q=u+r;k=F.normalize(self.address(u),dim=-1);v=self.payload(u).tanh();g=self.write(u).sigmoid()
  if self.gate=='hold':g=g*mask[...,None]
  if self.gate=='square':g=g.square()
  if self.gate=='binary':g=(g>.5).to(g)+g-g.detach()
  read=k.unsqueeze(-2) if self.tied else F.normalize(self.readaddr(u).unflatten(-1,(self.reads,self.kd)),dim=-1)
  if ab=='uniform':read=torch.ones_like(read)/math.sqrt(self.kd)
  if ab=='same' and self.reads>1:read=read[...,:1,:].expand_as(read)
  if ab=='swap' and self.reads>1:read=read.flip(-2)
  s=torch.zeros(b,self.kd,self.vd,device=h.device,dtype=h.dtype) if state is None else state[1]
  if self.mode=='add':
   seq=((g*k).unsqueeze(-1)*v.unsqueeze(-2)).cumsum(1)+s[:,None];s=seq[:,-1];m=torch.einsum('btrk,btkv->btrv',read,seq)
  else:
   ys=[]
   for i in range(t):
    ki=k[:,i];err=v[:,i]-torch.einsum('bk,bkv->bv',ki,s);s=s+(g[:,i]*ki).unsqueeze(-1)*err.unsqueeze(-2);ys.append(torch.einsum('brk,bkv->brv',read[:,i],s))
   m=torch.stack(ys,1)
  if ab=='zero':m=torch.zeros_like(m)
  msg=self.direct(m.flatten(-2));h=h+self.out(r+self.combine(q).sigmoid()*msg);h=h+self.ff(self.norm2(h))
  if collect:return h,(rs,s),g,k,read
  return h,(rs,s)
ARMS={'compact':['attn4','native','delta_hold','delta_auto','delta_square','delta_binary'],'multi':['attn10_1','attn10_2','attn32_4','matrix1','matrix2','matrix2_auto'],'induction':['attn32_4','native','matrix_add','matrix_delta']}
class Net(nn.Module):
 def __init__(self,task,arm,ff):
  super().__init__();self.task=task;self.arm=arm;self.ff=ff;self.key=nn.Embedding(16,D);self.val=nn.Embedding(8,D);self.typ=nn.Embedding(3,D);self.norm=nn.LayerNorm(D);self.read=nn.Linear(D,8*(2 if task=='multi' else 1));self.agg=nn.Linear(D,8) if task=='multi' else None;self.pair=nn.Linear(2*D,D) if task=='multi' else None
  blocks=[]
  for _ in range(2 if task=='induction' else 1):
   if arm.startswith('attn'):
    p=arm[4:].split('_');blocks.append(Attention(D,ff,int(p[0]),int(p[1]) if len(p)>1 else 1))
   elif arm=='native':blocks.append(Block(4,8,1.,False,D,ff))
   elif task=='compact':blocks.append(Matrix(D,ff,16,2,gate=arm.split('_')[1]))
   elif task=='multi':blocks.append(Matrix(D,ff,16,8,reads=1 if arm=='matrix1' else 2,mode='add',gate='auto' if arm.endswith('auto') else 'hold',tied=False))
   else:blocks.append(Matrix(D,ff,16,8,mode='add' if arm.endswith('add') else 'delta',gate='auto',tied=False))
  self.blocks=nn.ModuleList(blocks)
  with torch.no_grad():
   for m in self.modules():
    if isinstance(m,nn.Linear):m.weight.normal_(0,1/math.sqrt(m.in_features));m.bias.zero_() if m.bias is not None else None
    elif isinstance(m,nn.Embedding):m.weight.normal_(0,.1)
    if isinstance(m,Block):m.ow.normal_(0,1/math.sqrt(m.h))
 def inputs(self,k,v,q):
  b,n=k.shape
  if self.task=='induction':
   rec=torch.stack([self.key(k)+self.typ.weight[0],self.val(v)+self.typ.weight[1]],2).flatten(1,2);h=torch.cat([rec,self.key(q)+self.typ.weight[2]],1);h=h+pos(h.shape[1],D,h.device);n=2*n
  else:
   rec=self.key(k)+self.val(v)+self.typ.weight[0];que=self.pair(self.key(q).flatten(-2))[:,None]+self.typ.weight[1] if self.task=='multi' else self.key(q)+self.typ.weight[1];h=torch.cat([rec,que],1)
  mask=(torch.arange(h.shape[1],device=h.device)[None,:]<n).expand(b,-1);return h,mask
 def apply(self,h,mask,states=None,ab=None):
  out=[]
  for i,l in enumerate(self.blocks):
   st=None if states is None else states[i];h,s=l(h,st) if isinstance(l,Block) else l(h,mask,st,ab);out.append(s)
  return h,out
 def forward(self,k,v,q,ab=None):
  h,mask=self.inputs(k,v,q);z,_=self.apply(h,mask,ab=ab)
  if self.task=='multi':
   z=self.norm(z[:,-1]);return self.read(z).reshape(-1,2,8),self.agg(z)
  return self.read(self.norm(z[:,-q.shape[1]:])),None

def count(m):return sum(p.numel() for p in m.parameters())
def make(task,arm,seed):
 target=24000 if task=='induction' else 12000;b=count(Net(task,arm,1));s=count(Net(task,arm,2))-b;ff=max(4,round(1+(target-b)/s));torch.manual_seed(seed);return Net(task,arm,ff)
def score(m,k,v,q,y,ab=None):
 z,a=m(k,v,q,ab);ok=z.argmax(-1)==y;g=None if a is None else a.argmax(-1)==y.sum(-1)%8;return ok,g
@torch.no_grad()
def evaluate(m,seed,fresh=0,ab=None):
 m.eval();res={}
 for n in [4,8,16] if m.task!='induction' else [6,12]:
  r={k:0 for k in ['individual','answers','complete','histories','aggregate','both_and_aggregate','mutation','nuisance','order']}
  for i in range(8):
   k,v,ix,q,y=batch(91000000+seed*1000+n*20+i+fresh,32,n,m.task);ok,g=score(m,k,v,q,y,ab);r['individual']+=int(ok.sum());r['answers']+=y.numel();r['complete']+=int(ok.all(-1).sum());r['histories']+=len(y)
   if g is not None:r['aggregate']+=int(g.sum());r['both_and_aggregate']+=int((g&ok.all(-1)).sum())
   if n==(6 if m.task=='induction' else 8):
    ii=torch.arange(len(v));vv=v.clone();vv[ii,ix[:,0]]=(vv[ii,ix[:,0]]+1)%8;yy=vv.gather(1,ix);o,_=score(m,k,vv,q,yy,ab);r['mutation']+=int((ok.all(-1)&o.all(-1)).sum());mask=torch.ones_like(v,dtype=torch.bool);mask.scatter_(1,ix,False);di=mask.long().argmax(-1);vv=v.clone();vv[ii,di]=(vv[ii,di]+1)%8;o,_=score(m,k,vv,q,y,ab);r['nuisance']+=int((ok.all(-1)&o.all(-1)).sum());o,_=score(m,k,v,q.flip(1),y.flip(1),ab);r['order']+=int((ok.all(-1)&o.all(-1)).sum())
  res[str(n)]=r
 return res
@torch.no_grad()
def verify(m,seed):
 k,v,ix,q,y=batch(92000000+seed,8,6 if m.task=='induction' else 8,m.task);h,mask=m.inputs(k,v,q);z,ss=m.apply(h,mask);n=k.shape[1]*(2 if m.task=='induction' else 1);h2=h.clone();h2[:,n:]+=torch.randn_like(h2[:,n:]);zz,_=m.apply(h2,mask);r={'prefix_max':float((zz[:,:n]-z[:,:n]).abs().max())}
 if ss[0] is not None:
  a,s=m.apply(h[:,:n],mask[:,:n]);b,s2=m.apply(h[:,n:],mask[:,n:],s);alt=torch.cat([a,b],1);r['split_max']=float((alt-z).abs().max());r['disagree']=int((m.read(m.norm(alt)).argmax(-1)!=m.read(m.norm(z)).argmax(-1)).sum());r['state_bytes']=sum(x[0].numel()*x.element_size() for p in s for x in p);r['hold_exact']=all(torch.equal(x,y) for p,q in zip(s,s2) for x,y in zip(p,q));f=io.BytesIO();torch.save([[x.clone() for x in p] for p in s],f);f.seek(0);b2,_=m.apply(h[:,n:],mask[:,n:],torch.load(f,weights_only=True));r['restart_max']=float((b2-b).abs().max())
 else:r['state_bytes']=sum(n*2*l.kd*4 for l in m.blocks)
 return r

def run(task,arm,seed):
 torch.set_num_threads(1);m=make(task,arm,seed);opt=torch.optim.AdamW(m.parameters(),lr=.003);steps=STEPS;n=6 if task=='induction' else 8;curve=[];t=time.perf_counter()
 for i in range(steps):
  k,v,ix,q,y=batch(100000+seed*1000+i,BATCH,n,task);p,a=m(k,v,q);loss=F.cross_entropy(p.flatten(0,1),y.flatten());loss=loss if a is None else loss+F.cross_entropy(a,y.sum(-1)%8);opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1);opt.step();assert torch.isfinite(loss)
  if (i+1)%100==0:curve.append({'step':i+1,'loss':float(loss.detach()),'individual':float((p.argmax(-1)==y).float().mean())})
 sec=time.perf_counter()-t;path=P/'fits'/f'{task}_{arm}_{seed}.pt';torch.save({'weights':m.state_dict(),'optimizer':opt.state_dict(),'rng':torch.get_rng_state(),'task':task,'arm':arm,'ff':m.ff,'seed':seed,'steps':steps},path);r={'task':task,'arm':arm,'seed':seed,'ff':m.ff,'params':count(m),'steps':steps,'history_exposures':steps*BATCH,'seconds':sec,'curve':curve,'eval':evaluate(m,seed),'stream':verify(m,seed),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()};path.with_suffix('.json').write_text(json.dumps(r,indent=2));print('DONE',task,arm,seed,r['params'],r['eval'][str(n)],flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);(P/'fits').mkdir(exist_ok=True);jobs=[(t,a,s) for t,arms in ARMS.items() for a in arms for s in SEEDS];random.Random(19001).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as ex:
  fs=[ex.submit(run,*j) for j in jobs]
  for f in concurrent.futures.as_completed(fs):f.result()
