from pathlib import Path
import json,hashlib,csv,collections,statistics,zipfile,torch,os,base64,textwrap
from safetensors.torch import save_file,load_file
P=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
r=[json.load(open(p)) for p in sorted((P/'fits').glob('*.json'))];v=json.load(open(P/'verification.json'));exe=json.load(open(P/'execution.json'));assert len(r)==105 and all(a['hash_ok'] and a['eval_match'] for a in v)
G=collections.defaultdict(list)
for a in r:G[a['task'],a['arm']].append(a)
rows=[]
for (task,arm),xs in sorted(G.items()):
 row={'task':task,'arm':arm,'n':len(xs),'params':xs[0]['params'],'steps':xs[0]['steps'],'seed_ids':'|'.join(str(x['seed']) for x in xs)}
 if task=='language':
  for p in ['dev','test']:row[p+'_bpb']=statistics.mean(x[p]['bpb'] for x in xs)
  for i,c in enumerate([32,128,256]):row[f'history_{c}_bpb']=statistics.mean(x['history']['bpb'][i] for x in xs)
  row['state_bytes']=xs[0]['stream']['state_bytes'] if arm!='attn' else ''
 else:
  for n in xs[0]['eval']:
   for name in ['individual','complete','aggregate','both_and_aggregate','mutation','nuisance','order']:
    row[f'{n}_{name}_count']=sum(x['eval'][n][name] for x in xs);den=sum(x['eval'][n]['answers' if name=='individual' else 'histories'] for x in xs);row[f'{n}_{name}_pct']=100*row[f'{n}_{name}_count']/den
 rows.append(row)
fields=list(dict.fromkeys(k for a in rows for k in a));
with open(P/'summary.csv','w') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
summary={'cycle':'UNIFIED-019','training_executions':105,'independent_lineages':93,'continuations':12,'optimizer_updates_including_only_new_steps':sum(x.get('new_steps',x['steps']) for x in r),'structured_histories':sum(x.get('history_exposures',0) for x in r),'language_bytes':sum(x.get('byte_exposures',0) for x in r),'checkpoint_replays':sum(x['hash_ok'] and x['eval_match'] for x in v),'rows':rows,'source_corpus_sha256':sha((P/'corpus.json').read_bytes()),'cpu_only':True,'official_campaign_credit':0}
(P/'aggregate.json').write_text(json.dumps(summary,indent=2))
(P/'registry_delta.json').write_text(json.dumps({'cycle':'UNIFIED-019','scientific_findings':['Compact delta with learned sigmoid and squared sigmoid solves fresh 8-record retrieval at original 256B state capacity; no explicit HOLD in those arms.','Factorized two-query addressing with a learned delta state solves simultaneous retrieval at 640B; both read paths necessary on tested panels. Explicit query decomposition supplied.','Unpacked induction failed competent-baseline gate at 400 and 1600 updates. Shared local-context module restores attention competence; COG associative candidates improve but miss near-attention criterion.','Delta LM comparable to state-matched native; additive LM degrades with extended context.','Dense affine matrix scan is correct within tolerance but has substantial shape/batch-dependent overhead.'],'candidate_dispositions':{'compact_delta_auto':'retain bounded diagnostic','compact_delta_square':'retain bounded diagnostic','factor_delta_auto':'retain bounded diagnostic','native_induction':'inconclusive','local_induction':'partial','language_delta':'no promotion','matrix_scan':'numerical candidate only'},'canonical_promotions':[],'official_campaign_credit':0},indent=2))
(P/'README.md').write_text('''# COG-UNIFIED-019 — developmental research
Run `python run.py`, `python factor.py`, `python extend.py`, `python language.py`, `python local_induction.py`, `python execution.py`, `python verify.py`, then `python package.py`. Run in the study directory with Python/PyTorch CPU and `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1`. Each stage creates unique fit filenames. `extend.py` resumes induction optimizer/RNG checkpoints. `language.py` requires exact prior development corpus (`corpus.json` in local evidence ZIP; not in public release), SHA256 in aggregate.json. `prior/` contains source recovered from UNIFIED-018. All results are developmental, no canonical promotion. Original protocols plus sequential supplemental protocols preserved. Weights are exact FP32 model state exported as Safetensors, with tensor-by-tensor equality to originals; optimizer and RNG are in `fits/*.pt` (local evidence). No arbitrary untrusted checkpoint loading; use Safetensors for inference. Results: 105 executions including 12 continuations; 93 independent lineages. No protected data or paid compute. Full language-model source is experimental direct readout, not exact previous language-model implementation. `verify.py` replays all evaluation counts and BPB, tests factor/local continuation separately. For local-context streaming the position counter is excluded from reported logical state; input positional encoding must resume at the correct offset. Raw corpus remains private/local.\n''')
# Model custody: safe tensor files, byte hashes, exact original training checkpoint SHA, equality.
(P/'weights').mkdir(exist_ok=True);inv=[]
for f in sorted((P/'fits').glob('*.pt')):
 c=torch.load(f,weights_only=True,map_location='cpu');weights={k:x.detach().cpu().contiguous().clone() for k,x in c['weights'].items()};o=P/'weights'/f'{f.stem}.safetensors';save_file(weights,str(o),metadata={k:str(c[k]) for k in ['task','arm','seed','ff','steps']});w=load_file(str(o));assert set(w)==set(weights) and all(torch.equal(w[k],weights[k]) for k in w)
 inv.append({'fit':f.stem,'training_checkpoint':str(f.relative_to(P)),'training_sha256':sha(f.read_bytes()),'inference_path':str(o.relative_to(P)),'inference_bytes':o.stat().st_size,'inference_sha256':sha(o.read_bytes()),'tensor_equal':True,'task':c['task'],'arm':c['arm'],'seed':c['seed'],'ff':c['ff'],'steps':c['steps']})
(P/'checkpoint_inventory.json').write_text(json.dumps(inv,indent=2))
# Include only new authored source, prior code used, raw results, protocols, reports, exact weights, not raw corpus in release.
source=[p for p in P.glob('*.py')]+[p for p in P.glob('*.md') if not p.name.startswith('TRANSPORT')]+[P/x for x in ['summary.csv','aggregate.json','verification.json','execution.json','registry_delta.json','checkpoint_inventory.json']]+[P/'prior'/x for x in ['lm.py','scan_check.py','scan_reference.py','run.py','supplement.py','final_controls.py','audit_reference.py']]
source=[p for p in source if p.exists()];result_files=list((P/'fits').glob('*.json'));weights=list((P/'weights').glob('*.safetensors'));train=list((P/'fits').glob('*.pt'))
def archive(out,files):
 files=sorted(set(files));manifest=''.join(f'{sha(p.read_bytes())}  {p.relative_to(P).as_posix()}\n' for p in files)
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=5) as z:
  for p in files:z.write(p,p.relative_to(P).as_posix())
  z.writestr('SHA256SUMS.txt',manifest)
 with zipfile.ZipFile(out) as z:
  assert z.testzip() is None
  for line in z.read('SHA256SUMS.txt').decode().splitlines():
   h,name=line.split('  ',1);assert sha(z.read(name))==h
 return {'name':out.name,'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'members':len(files)+1}
base=P.parent
full=archive(base/'cog_unified_019_evidence.zip',source+result_files+weights+train+[P/'corpus.json'])
release=archive(base/'cog_unified_019_inference_release.zip',source+result_files+weights)
# Smaller exact source and report ZIP, plus standalone primary winning compact and factorized model exports for priority remote publication.
priority=[p for p in weights if p.name.startswith(('compact_delta_auto_','compact_delta_square_','factor_factor_delta_auto_'))];small=archive(base/'cog_unified_019_priority_models.zip',source+result_files+priority)
print(json.dumps({'full':full,'release':release,'priority':small,'weights':len(inv)},indent=2))
(P/'archive_receipts.json').write_text(json.dumps({'full':full,'release':release,'priority':small,'weights':len(inv)},indent=2))
# Base64 transport for exact published inference bundle; raw corpus/optimizer files omitted from remote archive.
# Chunk each archive into 384 KiB so connector limits can be respected; reconstruct original archive by concatenation.
tr=P/'transport';tr.mkdir(exist_ok=True);items=[]
for name in [release['name'],small['name']]:
 raw=(base/name).read_bytes();size=384*1024;pieces=[]
 for j,i in enumerate(range(0,len(raw),size)):
  chunk=raw[i:i+size];path=f'{name}.part{j:03d}';f=tr/(path+'.md');enc=base64.b64encode(chunk).decode();f.write_text('\n'.join(textwrap.wrap(enc,480))+'\n');git=hashlib.sha1(f'blob {len(chunk)}\0'.encode()+chunk).hexdigest();pieces.append({'path':path,'transport_filename':f.name,'bytes':len(chunk),'base64_length':len(enc),'lines':len(enc)//480+bool(len(enc)%480),'sha256':sha(chunk),'git_sha':git})
 items.append({'name':name,'sha256':sha(raw),'bytes':len(raw),'pieces':pieces})
(P/'transport_manifest.json').write_text(json.dumps(items,indent=2));print('parts',[(x['name'],len(x['pieces'])) for x in items])
