import run as r, factor, language, local_induction
import torch,json,hashlib,concurrent.futures,math,io
from pathlib import Path
import torch.nn.functional as F
P=Path(__file__).parent
@torch.no_grad()
def factor_stream(m,seed):
 if m.arm=='factor_attn':return {'state_bytes_after_8_records':640,'kind':'cache_size_only'}
 k,v,ix,q,y=r.batch(seed+98800000,32,8,'multi');rec=m.key(k)+m.val(v)+m.typ.weight[0];qkeys=m.key(q)+m.typ.weight[1];que=m.pair(m.key(q).flatten(-2))[:,None]+m.typ.weight[1];h=torch.cat([rec,que],1);mask=(torch.arange(h.shape[1])[None,:]<8).expand(len(k),-1);l=m.block;old=m(k,v,q);u=l.norm(h);z,a=l.inp(u).chunk(2,-1);a=.5+.49*a.sigmoid();a=a.unflatten(-1,(16,2)).mean(-1,keepdim=True).expand(*a.shape[:-1],16,2).flatten(-2)
 if l.gate=='hold':a=torch.where(mask[...,None],a,torch.ones_like(a))
 kk=F.normalize(l.address(u),dim=-1);vv=l.payload(u).tanh();g=l.write(u).sigmoid()
 if l.gate=='hold':g=g*mask[...,None]
 s=torch.zeros(len(k),l.kd,l.vd);working=torch.zeros(len(k),32)
 for i in range(h.shape[1]):
  working=a[:,i]*working+(1-a[:,i])*z[:,i].tanh();ki=kk[:,i];vi=vv[:,i];err=vi if l.mode=='add' else vi-torch.einsum('bk,bkv->bv',ki,s);s=s+(g[:,i]*ki).unsqueeze(-1)*err.unsqueeze(-2)
  if i==7:
   b=io.BytesIO();torch.save((working.clone(),s.clone()),b);b.seek(0);working,s=torch.load(b,weights_only=True)
 q2=F.normalize(l.address(l.norm(qkeys)) if l.reads==2 else l.address(u[:,-1:]),dim=-1);msg=torch.einsum('brk,bkv->brv',q2,s);out=h[:,-1]+l.out(working+l.combine(u[:,-1]+working).sigmoid()*l.direct(msg.flatten(-2)));out=m.norm(out+l.ff(l.norm2(out)));new=m.read(out).reshape(-1,2,8),m.agg(out);return {'state_bytes_after_8_records':(32+l.kd*l.vd)*4,'logit_max':max(float((x-y).abs().max()) for x,y in zip(old,new)),'prediction_disagreements':sum(int((x.argmax(-1)!=y.argmax(-1)).sum()) for x,y in zip(old,new)),'n_predictions':len(k)*3}
@torch.no_grad()
def local_stream(m,seed):
 if m.arm.startswith('attn'):return {'kind':'attention_state_not_tested'}
 k,v,ix,q,y=r.batch(seed+99100000,32,6,'induction');h,mask=m.inputs(k,v,q);full,_=m.apply(h,mask);l=m.blocks[0];prior=torch.cat([torch.zeros_like(h[:,:1]),h[:,:-1]],1);ctx=h+m.mix(torch.cat([m.lnorm(h),m.lnorm(prior)],-1));a,b=ctx[:,:12],ctx[:,12:];st=None
 if isinstance(l,r.Block):za,st=l(a);zb,_=l(b,st)
 else:za,st=l(a,mask[:,:12]);zb,_=l(b,mask[:,12:],st)
 # Actual streaming requires one previous raw token vector. Recompute suffix mixing from carried previous token.
 p=h[:,11:12].clone();suf=h[:,12:];pr=torch.cat([p,suf[:,:-1]],1);bb=suf+m.mix(torch.cat([m.lnorm(suf),m.lnorm(pr)],-1));bio=io.BytesIO();torch.save((tuple(x.clone() for x in st),p),bio);bio.seek(0);rest,p=torch.load(bio,weights_only=True)
 if isinstance(l,r.Block):zc,_=l(bb,rest)
 else:zc,_=l(bb,mask[:,12:],rest)
 z=m.read(m.norm(full[:,12:]));z2=m.read(m.norm(zc));return {'state_bytes':sum(x[0].numel()*x.element_size() for x in st)+32*4,'logit_max':float((z-z2).abs().max()),'prediction_disagreements':int((z.argmax(-1)!=z2.argmax(-1)).sum()),'n_predictions':z.shape[0]*z.shape[1],'position_counter_bytes_excluded':True}
@torch.no_grad()
def geometry(m,seed):
 k=torch.arange(16)[:,None].expand(-1,8);v=torch.arange(8)[None].expand(16,-1);l=m.blocks[0];e=m.key(k)+m.val(v)+m.typ.weight[0];q=m.key(torch.arange(16))+m.typ.weight[1];u=l.norm(e);qu=l.norm(q);wr=F.normalize(l.address(u),dim=-1);rd=F.normalize(l.address(qu),dim=-1);means=F.normalize(wr.mean(1),dim=-1);c=means@means.T;mask=~torch.eye(16,dtype=torch.bool);rg=l.write(u).sigmoid();qg=l.write(qu).sigmoid()
 if l.gate=='square':rg=rg.square();qg=qg.square()
 if l.gate=='binary':rg=(rg>.5).float();qg=(qg>.5).float()
 if l.gate=='hold':qg=qg*0
 sim=torch.einsum('qk,ivk->qiv',rd,wr);pred=sim.permute(0,2,1).argmax(-1);target=torch.arange(16)[:,None].expand(-1,8);return {'cross_identity_cosine_rms':float(c[mask].square().mean().sqrt()),'nearest_key_correct':int((pred==target).sum()),'nearest_key_total':128,'record_gate_mean':float(rg.mean()),'query_gate_mean':float(qg.mean()),'query_gate_max':float(qg.max())}
def replay(path):
 torch.set_num_threads(1);a=json.load(open(path.with_suffix('.json')));c=torch.load(path,weights_only=True);t=a['task'];arm=a['arm'];seed=a['seed'];ff=a['ff'];out={'fit':path.stem,'task':t,'arm':arm,'seed':seed,'hash_ok':hashlib.sha256(path.read_bytes()).hexdigest()==a['sha256']}
 if t=='language':
  m=language.LM(arm,ff);m.load_state_dict(c['weights']);docs,tr,starts,rows,ex=language.data();d=language.ev(m,rows['dev']);e=language.ev(m,rows['test']);out.update(eval_match=d==a['dev'] and e==a['test'],stream=language.verify_lm(m,max(docs['test'],key=len)))
 else:
  m=factor.Model(arm,ff) if t=='factor' else local_induction.LocalNet(arm,ff) if t=='local' else r.Net(c['task'],arm,ff);m.load_state_dict(c['weights']);m.eval();fresh={'factor':8000000,'extension':9000000,'local':11000000}.get(t,0);out['eval_match']=r.evaluate(m,seed,fresh=fresh)==a['eval'];
  if t=='factor':out['stream']=factor_stream(m,seed)
  elif t=='local':out['stream']=local_stream(m,seed)
  else:out['stream']=a.get('stream',{})
  if t=='compact' and arm.startswith('delta'):out['geometry']=geometry(m,seed)
 return out
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);paths=sorted((P/'fits').glob('*.pt'))
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as ex:out=list(ex.map(replay,paths))
 (P/'verification.json').write_text(json.dumps(out,indent=2));print('replays',len(out),sum(a['hash_ok'] and a['eval_match'] for a in out),flush=True)
