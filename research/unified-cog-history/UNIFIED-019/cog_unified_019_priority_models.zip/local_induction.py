from run import *
class LocalNet(Net):
 def __init__(self,arm,ff):
  # Use inherited unpacked token construction; one downstream retrieval block.
  super().__init__('induction',arm,ff);self.blocks=nn.ModuleList([self.blocks[0]]);self.mix=nn.Linear(2*D,D);self.lnorm=nn.LayerNorm(D);self.mix.weight.data.normal_(0,1/math.sqrt(2*D));self.mix.bias.data.zero_()
 def apply(self,h,mask,states=None,ab=None):
  prior=torch.cat([torch.zeros_like(h[:,:1]),h[:,:-1]],1);h=h+self.mix(torch.cat([self.lnorm(h),self.lnorm(prior)],-1));return super().apply(h,mask,states,ab)
 def forward(self,k,v,q,ab=None):
  h,mask=self.inputs(k,v,q);z,_=self.apply(h,mask,ab=ab);return self.read(self.norm(z[:,-q.shape[1]:])),None
SEEDS=[8401,8423,8461];ARMS=['attn32_4','native','matrix_add','matrix_delta']
def run(arm,seed):
 torch.set_num_threads(1);base=count(LocalNet(arm,1));s=count(LocalNet(arm,2))-base;ff=max(4,round(1+(12000-base)/s));torch.manual_seed(seed);m=LocalNet(arm,ff);opt=torch.optim.AdamW(m.parameters(),lr=.003);start=time.perf_counter();curve=[]
 for i in range(600):
  k,v,ix,q,y=batch(500000+seed*1000+i,32,6,'induction');z,_=m(k,v,q);loss=F.cross_entropy(z.flatten(0,1),y.flatten());opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1);opt.step();assert torch.isfinite(loss)
  if (i+1)%100==0:curve.append(dict(step=i+1,loss=float(loss.detach()),individual=float((z.argmax(-1)==y).float().mean())))
 sec=time.perf_counter()-start;p=P/'fits'/f'local_{arm}_{seed}.pt';torch.save(dict(weights=m.state_dict(),optimizer=opt.state_dict(),rng=torch.get_rng_state(),task='local',arm=arm,seed=seed,ff=ff,steps=600),p);out=dict(task='local',arm=arm,seed=seed,ff=ff,params=count(m),steps=600,history_exposures=19200,seconds=sec,curve=curve,eval=evaluate(m,seed,fresh=11000000),sha256=hashlib.sha256(p.read_bytes()).hexdigest());p.with_suffix('.json').write_text(json.dumps(out,indent=2));print('DONE',arm,seed,out['eval']['6'],flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);jobs=[(a,s) for a in ARMS for s in SEEDS];random.Random(19005).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as ex:
  fs=[ex.submit(run,*j) for j in jobs]
  for f in concurrent.futures.as_completed(fs):f.result()
