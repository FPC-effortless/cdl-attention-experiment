from run import *
LD=64; SEEDS=[8303,8329,8363]; ARMS=['native64','native128','add','delta','attn']; STEPS=400;BATCH=8;T=32
class RopeAttention(Attention):
 def forward(self,x,mask=None,state=None,ab=None):
  b,t,d=x.shape;q,k,v=self.qkv(self.norm(x)).reshape(b,t,3,self.heads,self.kd//self.heads).permute(2,0,3,1,4).unbind(0);hd=q.shape[-1];f=torch.exp(-math.log(10000)*torch.arange(hd//2,device=x.device)/(hd//2));theta=torch.arange(t,device=x.device)[:,None]*f;co,si=theta.cos(),theta.sin()
  def rot(w):
   a,b=w.unflatten(-1,(-1,2)).unbind(-1);return torch.stack((a*co-b*si,a*si+b*co),-1).flatten(-2)
  q,k=rot(q),rot(k);y=F.scaled_dot_product_attention(q,k,v,is_causal=True).transpose(1,2).reshape(b,t,d);h=x+self.out(y);return h+self.ff(self.norm2(h)),None
class LM(nn.Module):
 def __init__(self,arm,ff):
  super().__init__();self.arm=arm;self.ff=ff;self.emb=nn.Embedding(256,LD);self.norm=nn.LayerNorm(LD);self.blocks=nn.ModuleList([RopeAttention(LD,ff,LD,4) if arm=='attn' else Block(4,16 if arm=='native64' else 32,1.,False,LD,ff) if arm.startswith('native') else Matrix(LD,ff,16,8,mode=arm,gate='auto',tied=False) for _ in range(2)])
  with torch.no_grad():
   for m in self.modules():
    if isinstance(m,nn.Linear):m.weight.normal_(0,1/math.sqrt(m.in_features));m.bias.zero_() if m.bias is not None else None
    elif isinstance(m,nn.Embedding):m.weight.normal_(0,.02)
    if isinstance(m,Block):m.ow.normal_(0,1/math.sqrt(m.h))
 def forward(self,x,state=None,return_state=False,ab=None):
  h=self.emb(x);ss=[]
  for i,l in enumerate(self.blocks):
   s=None if state is None else state[i];h,s=l(h,s,ab='drop' if ab=='zero' else None) if isinstance(l,Block) else l(h,None,s,ab);ss.append(s)
  z=F.linear(self.norm(h),self.emb.weight);return (z,ss) if return_state else z

def data():
 d=json.load(open(P/'corpus.json'));docs={k:[a['text'].encode() for a in v] for k,v in d.items()};train=docs['train'];tr=torch.cat([torch.tensor(list(a)) for a in train]);off=0;starts=[]
 for a in train:
  starts.append(torch.arange(off,off+max(0,len(a)-T)));off+=len(a)
 rows={};excluded={}
 for k in ['dev','test']:
  res=[];exc=0
  for a in docs[k]:
   if len(a)<T+1:continue
   for j in torch.linspace(0,len(a)-T-1,min(8,max(1,len(a)//T))).long().unique().tolist():
    q=a[j:j+T+1]
    if any(q in trd for trd in train):exc+=1;continue
    res.append(torch.tensor(list(q)))
  rows[k]=torch.stack(res);excluded[k]=exc
 return docs,tr,torch.cat(starts),rows,excluded
@torch.no_grad()
def ev(m,rows,ab=None):
 m.eval();total=n=correct=0
 for x in rows.split(16):
  z=m(x[:,:-1],ab=ab);y=x[:,1:];total+=float(F.cross_entropy(z.flatten(0,1),y.flatten(),reduction='sum'));n+=y.numel();correct+=int((z.argmax(-1)==y).sum())
 return dict(bpb=total/n/math.log(2),n=n,correct=correct)
@torch.no_grad()
def hist(m,docs):
 m.eval();losses=[0.]*3;n=0
 for a in docs:
  if len(a)<257:continue
  x=torch.tensor(list(a[:257]))[None];y=x[:,-32:]
  for i,c in enumerate([32,128,256]):
   z=m(x[:,-c-1:-1])[:,-32:];losses[i]+=float(F.cross_entropy(z.flatten(0,1),y.flatten(),reduction='sum'))
  n+=32
 return {'n':n,'bpb':[l/max(1,n)/math.log(2) for l in losses]}
@torch.no_grad()
def verify_lm(m,doc):
 m.eval();x=torch.tensor(list(doc[:128]))[None];z,s=m(x,return_state=True);xx=x.clone();xx[:,64:]=(xx[:,64:]+1)%256;q=m(xx);r={'causal_max':float((q[:,:64]-z[:,:64]).abs().max())}
 if m.arm!='attn':
  a,st=m(x[:,:61],return_state=True);b,st2=m(x[:,61:],state=st,return_state=True);alt=torch.cat([a,b],1);r.update(split_max=float((alt-z).abs().max()),disagree=int((alt.argmax(-1)!=z.argmax(-1)).sum()),state_bytes=sum(x.numel()*x.element_size() for p in st for x in p));buf=io.BytesIO();torch.save([[x.clone() for x in p] for p in st],buf);buf.seek(0);bb,_=m(x[:,61:],state=torch.load(buf,weights_only=True),return_state=True);r['resume_max']=float((bb-b).abs().max())
 else:r['state_bytes']=128*2*LD*4*2
 return r

def run(arm,seed):
 torch.set_num_threads(1);base=count(LM(arm,1));s=count(LM(arm,2))-base;ff=max(4,round(1+(150000-base)/s));torch.manual_seed(seed);m=LM(arm,ff);opt=torch.optim.AdamW(m.parameters(),lr=.002);docs,tr,starts,rows,excluded=data();g=torch.Generator().manual_seed(seed+1000000);curve=[];t=time.perf_counter()
 for i in range(STEPS):
  m.train();a=tr[starts[torch.randint(len(starts),(BATCH,),generator=g)][:,None]+torch.arange(T+1)];z=m(a[:,:-1]);y=a[:,1:];loss=F.cross_entropy(z.flatten(0,1),y.flatten());opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1);opt.step();assert torch.isfinite(loss)
  if (i+1)%100==0:curve.append({'step':i+1,'dev':ev(m,rows['dev'])})
 sec=time.perf_counter()-t;p=P/'fits'/f'language_{arm}_{seed}.pt';torch.save(dict(weights=m.state_dict(),optimizer=opt.state_dict(),rng=torch.get_rng_state(),data_rng=g.get_state(),task='language',arm=arm,seed=seed,ff=ff,steps=STEPS),p);out=dict(task='language',arm=arm,seed=seed,ff=ff,params=count(m),steps=STEPS,byte_exposures=STEPS*BATCH*T,seconds=sec,curve=curve,dev=ev(m,rows['dev']),test=ev(m,rows['test']),history=hist(m,docs['test']),stream=verify_lm(m,max(docs['test'],key=len)),excluded=excluded,sha256=hashlib.sha256(p.read_bytes()).hexdigest());p.with_suffix('.json').write_text(json.dumps(out,indent=2));print('DONE',arm,seed,out['params'],out['dev'],out['test'],flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);jobs=[(a,s) for a in ARMS for s in SEEDS];random.Random(19004).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as ex:
  fs=[ex.submit(run,*j) for j in jobs]
  for f in concurrent.futures.as_completed(fs):f.result()
