import torch, torch.nn as nn, torch.nn.functional as F, math,json,time,pathlib,concurrent.futures,random,hashlib,io
import lm
from lm import Block
from scan_check import assoc
from audit_reference import batch
lm.scan=assoc
P=pathlib.Path(__file__).parent
SEEDS=[7103,7121,7151];D=32;STEPS=500;BATCH=24;TARGET=24000
class HoldBlock(Block):
 def forward(self,h,state=None,mask=None,ab=None):
  k,d=self.k,self.d;u=self.norm(h);z,a=self.inp(u).chunk(2,-1);a=.5+.49*a.sigmoid();a=a.unflatten(-1,(d//2,2)).mean(-1,keepdim=True).expand(*a.shape[:-1],d//2,2).flatten(-2);a=torch.where(mask[...,None],a,torch.ones_like(a));r,rs=assoc(z.tanh(),a,None if state is None else state[0]);q=r+u
  v=self.pub(q).tanh().unflatten(-1,(k,self.h));w,rp,g=self.route(q).split([k,k,1],-1);gate=.4*g.sigmoid()*w.sigmoid()*mask[...,None];ms,last=assoc(v,1-gate[...,None],None if state is None else state[1]);m=ms*rp.sigmoid()[...,None]*2
  if ab=='zero_memory':m=torch.zeros_like(m)
  p1,p2=(self.select(q).unflatten(-1,(2,k,4))/self.tau).softmax(-1).unbind(-3);y1=self.op(m,p1);y2=self.op(y1,p2);msg=self.recv(self.msgnorm(torch.cat([y1.flatten(-2),y2.flatten(-2)],-1)));h=h+self.out(r+self.combine(q).sigmoid()*msg);h=h+self.ff(self.norm2(h));return h,(rs,last)
class AssocBlock(nn.Module):
 def __init__(self,mode,cap,ff):
  super().__init__();self.mode=mode;self.cap=cap;self.k=4 if cap==32 else 16;self.vd=8 if mode=='slot' or cap==128 else 4;self.kd=8 if cap==32 else 16;self.units=self.k if mode=='slot' else 4;self.h=self.vd if mode=='slot' else self.vd//4;m=self.units*self.h
  self.norm=nn.LayerNorm(D);self.inp=nn.Linear(D,2*D);self.address=nn.Linear(D,self.k if mode=='slot' else self.kd);self.payload=nn.Linear(D,self.vd);self.write=nn.Linear(D,1);self.select=nn.Linear(D,2*self.units*4);self.ow=nn.Parameter(torch.empty(4,self.h,self.h));self.ob=nn.Parameter(torch.zeros(4,self.h));self.msgnorm=nn.LayerNorm(2*m);self.recv=nn.Linear(2*m,D);self.combine=nn.Linear(D,D);self.out=nn.Linear(D,D);self.norm2=nn.LayerNorm(D);self.ff=nn.Sequential(nn.Linear(D,ff),nn.GELU(),nn.Linear(ff,D));nn.init.normal_(self.ow,std=1/math.sqrt(self.h))
 def op(self,x,p):return ((torch.einsum('...gh,koh->...gko',x,self.ow)+self.ob).tanh()*p[...,None]).sum(-2)
 def forward(self,h,state=None,mask=None,ab=None):
  b,t,d=h.shape;u=self.norm(h);z,a=self.inp(u).chunk(2,-1);a=.5+.49*a.sigmoid();a=a.unflatten(-1,(d//2,2)).mean(-1,keepdim=True).expand(*a.shape[:-1],d//2,2).flatten(-2);a=torch.where(mask[...,None],a,torch.ones_like(a));r,rs=assoc(z.tanh(),a,None if state is None else state[0]);q=u+r;addr=self.address(u);v=self.payload(u).tanh();g=self.write(u).sigmoid()*mask[...,None]
  if self.mode=='slot':
   p=(addr/.5).softmax(-1)
   if ab=='hard':p=F.one_hot(p.argmax(-1),self.k).to(p);g=mask[...,None].to(g)
   s,last=assoc(v.unsqueeze(-2).expand(b,t,self.k,self.vd),1-g[...,None]*p[...,None],None if state is None else state[1]);read=torch.full_like(p,1/self.k) if ab=='uniform_read' else p.roll(1,-1) if ab=='wrong_read' else p;m=s*read[...,None]*self.k
  else:
   k=F.normalize(addr,dim=-1);read=torch.ones_like(k)/math.sqrt(self.kd) if ab=='uniform_read' else k.roll(1,-1) if ab=='wrong_read' else k;s=torch.zeros(b,self.kd,self.vd,device=h.device,dtype=h.dtype) if state is None else state[1]
   if self.mode=='add':
    delta=(g*k).unsqueeze(-1)*v.unsqueeze(-2);seq=delta.cumsum(1)+s[:,None];last=seq[:,-1];m=torch.einsum('btk,btkv->btv',read,seq)
   else:
    out=[]
    for i in range(t):
     ki=k[:,i];vi=v[:,i];err=vi-torch.einsum('bk,bkv->bv',ki,s);s=s+(g[:,i]*ki).unsqueeze(-1)*err.unsqueeze(-2);out.append(torch.einsum('bk,bkv->bv',read[:,i],s))
    m=torch.stack(out,1);last=s
   m=m.unflatten(-1,(self.units,self.h))
  if ab=='zero_memory':m=torch.zeros_like(m)
  p1,p2=self.select(q).unflatten(-1,(2,self.units,4)).softmax(-1).unbind(-3);y1=self.op(m,p1);y2=self.op(y1,p2);msg=self.recv(self.msgnorm(torch.cat([y1.flatten(-2),y2.flatten(-2)],-1)));h=h+self.out(r+self.combine(q).sigmoid()*msg);h=h+self.ff(self.norm2(h));return h,(rs,last)
class Attn(nn.Module):
 def __init__(self,kd,heads,ff):
  super().__init__();self.kd=kd;self.heads=heads;self.norm=nn.LayerNorm(D);self.qkv=nn.Linear(D,3*kd);self.out=nn.Linear(kd,D);self.norm2=nn.LayerNorm(D);self.ff=nn.Sequential(nn.Linear(D,ff),nn.GELU(),nn.Linear(ff,D))
 def forward(self,h):
  b,t,d=h.shape;q,k,v=self.qkv(self.norm(h)).reshape(b,t,3,self.heads,self.kd//self.heads).permute(2,0,3,1,4).unbind(0);y=F.scaled_dot_product_attention(q,k,v,is_causal=True).transpose(1,2).reshape(b,t,self.kd);h=h+self.out(y);return h+self.ff(self.norm2(h))
ARMS=['native32','hold32','slot32','add32','delta32','native128','hold128','slot128','add128','delta128','attn4','attn10','attnfull']
class Net(nn.Module):
 def __init__(self,arm,ff):
  super().__init__();self.arm=arm;self.ff=ff;self.key=nn.Embedding(16,D);self.val=nn.Embedding(8,D);self.typ=nn.Embedding(2,D);self.norm=nn.LayerNorm(D);self.read=nn.Linear(D,8);self.cap=128 if arm.endswith('128') else 32
  if arm.startswith('attn'):self.block=Attn(32 if arm=='attnfull' else int(arm[4:]),4 if arm=='attnfull' else 1,ff)
  elif arm.startswith(('native','hold')):self.block=(Block if arm.startswith('native') else HoldBlock)(4 if self.cap==32 else 16,8,1.,False,D,ff)
  else:self.block=AssocBlock(arm.rstrip('0123456789'),self.cap,ff)
  with torch.no_grad():
   for m in self.modules():
    if isinstance(m,nn.Linear):m.weight.normal_(0,1/math.sqrt(m.in_features));m.bias.zero_() if m.bias is not None else None
    elif isinstance(m,nn.Embedding):m.weight.normal_(0,.1)
   if not arm.startswith('attn'):self.block.ow.normal_(0,1/math.sqrt(self.block.h))
 def inputs(self,k,v,q):return torch.cat([self.key(k)+self.val(v)+self.typ.weight[0],self.key(q)+self.typ.weight[1]],1)
 def apply(self,h,mask,state=None,ab=None):
  if self.arm.startswith('attn'):return self.block(h),None
  if self.arm.startswith('native'):return self.block(h,state,ab='drop' if ab=='zero_memory' else None)
  return self.block(h,state,mask,ab)
 def forward(self,k,v,q,ab=None):
  h=self.inputs(k,v,q);mask=torch.arange(h.shape[1],device=h.device)[None,:]<k.shape[1];z,_=self.apply(h,mask,ab=ab);return self.read(self.norm(z[:,-q.shape[1]:]))
def params(m):return sum(p.numel() for p in m.parameters())
def ff(arm):
 base=params(Net(arm,1));s=params(Net(arm,2))-base;return max(4,round(1+(TARGET-base)/s))
@torch.no_grad()
def evaluate(m,seed,ab=None,panels=(2,4,8,12,16),fresh=0):
 m.eval();res={}
 for n in panels:
  c=answers=complete=hist=mut=nuis=order=dis=0;loss=0.
  for i in range(16):
   k,v,ix,q,y=batch(19000000+fresh+seed*1000+n*20+i,32,n);p=m(k,v,q,ab);z=p.argmax(-1);ok=z==y;c+=int(ok.sum());answers+=y.numel();complete+=int(ok.all(-1).sum());hist+=len(y);loss+=float(F.cross_entropy(p.flatten(0,1),y.flatten(),reduction='sum'))
   if n==8:
    vv=v.clone();ii=torch.arange(len(v));vv[ii,ix[:,0]]=(vv[ii,ix[:,0]]+1)%8;yy=vv.gather(1,ix);zz=m(k,vv,q,ab).argmax(-1);mut+=int((ok.all(-1)&(zz==yy).all(-1)).sum());mask=torch.ones_like(v,dtype=torch.bool);mask.scatter_(1,ix,False);di=mask.long().argmax(-1);vv=v.clone();vv[ii,di]=(vv[ii,di]+1)%8;zz=m(k,vv,q,ab).argmax(-1);nuis+=int((ok.all(-1)&(zz==y).all(-1)).sum());rev=m(k,v,q.flip(1),ab).argmax(-1).flip(1);order+=int((ok.all(-1)&(rev==y).all(-1)).sum());dis+=int((rev!=z).sum())
  res[str(n)]=dict(correct=c,answers=answers,complete=complete,histories=hist,mutation_pairs=mut if n==8 else None,nuisance_pairs=nuis if n==8 else None,order_pairs=order if n==8 else None,order_disagree=dis if n==8 else None,nll=loss/answers)
 return res
@torch.no_grad()
def verify(m,seed):
 m.eval();k,v,ix,q,y=batch(28000000+seed,8,8);h=m.inputs(k,v,q);mask=torch.arange(h.shape[1])[None,:]<8;z,s=m.apply(h,mask);h2=h.clone();h2[:,8:]+=torch.randn_like(h2[:,8:]);zz,_=m.apply(h2,mask);st={'causal_prefix_max':float((z[:,:8]-zz[:,:8]).abs().max())}
 if s is not None:
  z1,pre=m.apply(h[:,:8],mask[:,:8]);z2,end=m.apply(h[:,8:],mask[:,8:],pre);both=torch.cat([z1,z2],1);st.update(state_bytes=sum(x[0].numel()*x.element_size() for x in pre),split_max=float((z-both).abs().max()),pred_disagree=int((m.read(m.norm(z)).argmax(-1)!=m.read(m.norm(both)).argmax(-1)).sum()),hold_exact=all(torch.equal(a,b) for a,b in zip(pre,end)));buf=io.BytesIO();torch.save(tuple(x.clone() for x in pre),buf);buf.seek(0);restored=torch.load(buf,weights_only=True);p,_=m.apply(h[:,8:],mask[:,8:],restored);st['restart_disagree']=int((m.read(m.norm(p)).argmax(-1)!=m.read(m.norm(z2)).argmax(-1)).sum())
 else:st['state_bytes']=8*2*m.block.kd*4
 return st
@torch.no_grad()
def revision(m,seed):
 c=answers=complete=hist=0;m.eval()
 for i in range(16):
  k,v,ix,q,y=batch(31000000+seed*1000+i,32,8);vnew=(y+1+torch.randint(7,y.shape,generator=torch.Generator().manual_seed(32000000+seed*1000+i)))%8;k2=torch.cat([k,q],1);v2=torch.cat([v,vnew],1);z=m(k2,v2,q).argmax(-1);c+=int((z==vnew).sum());answers+=vnew.numel();complete+=int((z==vnew).all(1).sum());hist+=len(y)
 return dict(correct=c,answers=answers,complete=complete,histories=hist)
def run(arm,seed):
 torch.set_num_threads(1);torch.manual_seed(seed);f=ff(arm);torch.manual_seed(seed);m=Net(arm,f);opt=torch.optim.AdamW(m.parameters(),lr=.003);curve=[];start=time.perf_counter()
 for i in range(STEPS):
  k,v,ix,q,y=batch(210000+seed*1000+i,BATCH);p=m(k,v,q);loss=F.cross_entropy(p.flatten(0,1),y.flatten());opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1);opt.step();assert torch.isfinite(loss)
  if (i+1)%100==0:curve.append(dict(step=i+1,loss=float(loss.detach()),accuracy=float((p.argmax(-1)==y).float().mean())))
 elapsed=time.perf_counter()-start;path=P/'fits'/f'{arm}_{seed}.pt';torch.save(dict(weights=m.state_dict(),optimizer=opt.state_dict(),rng=torch.get_rng_state(),arm=arm,seed=seed,ff=f,steps=STEPS),path);ev=evaluate(m,seed);st=verify(m,seed);r=dict(arm=arm,seed=seed,params=params(m),ff=f,steps=STEPS,train_seconds=elapsed,curve=curve,eval=ev,stream=st,revision=revision(m,seed),sha256=hashlib.sha256(path.read_bytes()).hexdigest());path.with_suffix('.json').write_text(json.dumps(r,indent=2));print(arm,seed,params(m),ev['8']['correct'],ev['8']['complete'],ev['8']['mutation_pairs'],st,flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);(P/'fits').mkdir(exist_ok=True);jobs=[(a,s) for a in ARMS for s in SEEDS];random.Random(18002).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
  fs=[pool.submit(run,*j) for j in jobs]
  for f in concurrent.futures.as_completed(fs):f.result()
