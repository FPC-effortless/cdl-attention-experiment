import torch, torch.nn as nn, torch.nn.functional as F, math,json,time,pathlib,concurrent.futures,random,hashlib
import lm
from lm import Block
from scan_check import assoc
lm.scan=assoc
P=pathlib.Path(__file__).parent
SEEDS=[6101,6121,6131];D=32;STEPS=500;BATCH=24

def batch(seed,b,n=8):
 g=torch.Generator().manual_seed(seed);k=torch.rand(b,16,generator=g).argsort(-1)[:,:n];v=torch.randint(8,(b,n),generator=g);ix=torch.rand(b,n,generator=g).argsort(-1)[:,:min(4,n)];return k,v,ix,k.gather(1,ix),v.gather(1,ix)
class Attn(nn.Module):
 def __init__(self,heads,ff):
  super().__init__();self.heads=heads;self.norm=nn.LayerNorm(D);self.qkv=nn.Linear(D,3*D);self.out=nn.Linear(D,D);self.norm2=nn.LayerNorm(D);self.ff=nn.Sequential(nn.Linear(D,ff),nn.GELU(),nn.Linear(ff,D))
 def forward(self,h):
  b,t,d=h.shape;q,k,v=self.qkv(self.norm(h)).reshape(b,t,3,self.heads,d//self.heads).permute(2,0,3,1,4).unbind(0);y=F.scaled_dot_product_attention(q,k,v,is_causal=True).transpose(1,2).reshape(b,t,d);h=h+self.out(y);return h+self.ff(self.norm2(h))
class Net(nn.Module):
 def __init__(self,arm,ff):
  super().__init__();self.arm=arm;self.ff=ff;self.key=nn.Embedding(16,D);self.val=nn.Embedding(8,D);self.typ=nn.Embedding(2,D);self.norm=nn.LayerNorm(D);self.read=nn.Linear(D,8);self.block=Block(4,D//4,1.,False,D,ff) if arm=='cog' else Attn(int(arm[-1]),ff)
  with torch.no_grad():
   for m in self.modules():
    if isinstance(m,nn.Linear):m.weight.normal_(0,1/math.sqrt(m.in_features));m.bias.zero_() if m.bias is not None else None
    elif isinstance(m,nn.Embedding):m.weight.normal_(0,.1)
   if arm=='cog':self.block.ow.normal_(0,1/math.sqrt(self.block.h))
 def inputs(self,k,v,q):return torch.cat([self.key(k)+self.val(v)+self.typ.weight[0],self.key(q)+self.typ.weight[1]],1)
 def forward(self,k,v,q):
  h=self.inputs(k,v,q);z=self.block(h)[0] if self.arm=='cog' else self.block(h);return self.read(self.norm(z[:,-q.shape[1]:]))
def params(m):return sum(p.numel() for p in m.parameters())
def ff(arm):
 base=params(Net(arm,1));s=params(Net(arm,2))-base;return max(4,round(1+(12000-base)/s))
@torch.no_grad()
def evaluate(m,seed):
 m.eval();res={}
 for n in [2,4,8,12,16]:
  totals=[0,0,0,0,0,0];loss=0.
  for i in range(16):
   k,v,ix,q,y=batch(9000000+seed*1000+n*20+i,32,n);p=m(k,v,q);z=p.argmax(-1);ok=z==y;totals[0]+=int(ok.sum());totals[1]+=y.numel();totals[2]+=int(ok.all(-1).sum());totals[3]+=len(y);loss+=float(F.cross_entropy(p.flatten(0,1),y.flatten(),reduction='sum'))
   if n==8:
    vv=v.clone();ii=torch.arange(len(v));vv[ii,ix[:,0]]=(vv[ii,ix[:,0]]+1)%8;yy=vv.gather(1,ix);zz=m(k,vv,q).argmax(-1);totals[4]+=int((ok.all(-1)&(zz==yy).all(-1)).sum());mask=torch.ones_like(v,dtype=torch.bool);mask.scatter_(1,ix,False);di=mask.long().argmax(-1);vv=v.clone();vv[ii,di]=(vv[ii,di]+1)%8;zz=m(k,vv,q).argmax(-1);totals[5]+=int((ok.all(-1)&(zz==y).all(-1)).sum())
  res[str(n)]=dict(correct=totals[0],answers=totals[1],complete=totals[2],histories=totals[3],mutation_pairs=totals[4] if n==8 else None,nuisance_pairs=totals[5] if n==8 else None,nll=loss/totals[1])
 k,v,ix,q,y=batch(7000000+seed,8,8);h=m.inputs(k,v,q);h2=h.clone();h2[:,8:]+=torch.randn_like(h2[:,8:]);st={}
 if m.arm=='cog':
  z,s=m.block(h);z1,x=m.block(h[:,:8]);z2,_=m.block(h[:,8:],x);alt=torch.cat([z1,z2],1);st=dict(state_bytes_per_sample=sum(x[0].numel()*x.element_size() for x in s),split_max=float((z-alt).abs().max()),prediction_disagreement=int((m.read(m.norm(z)).argmax(-1)!=m.read(m.norm(alt)).argmax(-1)).sum()));zz=m.block(h2)[0]
 else:z=m.block(h);zz=m.block(h2)
 st['causal_prefix_max']=float((z[:,:8]-zz[:,:8]).abs().max());return res,st

def run(arm,seed):
 torch.set_num_threads(1);torch.manual_seed(seed);f=ff(arm);torch.manual_seed(seed);m=Net(arm,f);opt=torch.optim.AdamW(m.parameters(),lr=.003);curve=[];start=time.perf_counter()
 for i in range(STEPS):
  k,v,ix,q,y=batch(100000+seed*1000+i,BATCH);p=m(k,v,q);loss=F.cross_entropy(p.flatten(0,1),y.flatten());opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1);opt.step()
  if (i+1)%100==0:curve.append(dict(step=i+1,loss=float(loss.detach()),accuracy=float((p.argmax(-1)==y).float().mean())))
 elapsed=time.perf_counter()-start;path=P/f'{arm}_{seed}.pt';torch.save(dict(weights=m.state_dict(),optimizer=opt.state_dict(),rng=torch.get_rng_state(),arm=arm,seed=seed,ff=f,steps=STEPS),path);ev,st=evaluate(m,seed);r=dict(arm=arm,seed=seed,params=params(m),ff=f,steps=STEPS,train_seconds=elapsed,curve=curve,eval=ev,stream=st,sha256=hashlib.sha256(path.read_bytes()).hexdigest());path.with_suffix('.json').write_text(json.dumps(r,indent=2));print(arm,seed,ev['8'],flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);jobs=[(a,s) for a in ['cog','attn1','attn4'] for s in SEEDS];random.Random(17018).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
  fs=[pool.submit(run,*j) for j in jobs]
  for f in concurrent.futures.as_completed(fs):f.result()
