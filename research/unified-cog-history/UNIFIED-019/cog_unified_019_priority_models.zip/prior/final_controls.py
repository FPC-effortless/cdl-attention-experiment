import run as r
import supplement as s
from run import *
class Plain(AssocBlock):
 def __init__(self,mode,ff):
  cap=128 if '128' in mode else 32;typ=mode.split('_')[0].rstrip('0123456789');super().__init__(typ,cap,ff)
  self.kd=16;self.vd=8 if cap==128 else 2
  self.address=nn.Linear(D,self.kd);self.payload=nn.Linear(D,self.vd)
  del self.select,self.ow,self.ob,self.msgnorm,self.recv
  self.direct=nn.Linear(self.vd,D)
 def forward(self,h,state=None,mask=None,ab=None):
  b,t,d=h.shape;u=self.norm(h);z,a=self.inp(u).chunk(2,-1);a=.5+.49*a.sigmoid();a=a.unflatten(-1,(d//2,2)).mean(-1,keepdim=True).expand(*a.shape[:-1],d//2,2).flatten(-2);a=torch.where(mask[...,None],a,torch.ones_like(a));r,rs=assoc(z.tanh(),a,None if state is None else state[0]);q=u+r;k=F.normalize(self.address(u),dim=-1);v=self.payload(u).tanh();g=self.write(u).sigmoid()*mask[...,None];read=torch.ones_like(k)/math.sqrt(self.kd) if ab=='uniform_read' else k.roll(1,-1) if ab=='wrong_read' else k;st=torch.zeros(b,self.kd,self.vd,device=h.device,dtype=h.dtype) if state is None else state[1]
  if self.mode=='add':
   seq=((g*k).unsqueeze(-1)*v.unsqueeze(-2)).cumsum(1)+st[:,None];last=seq[:,-1];m=torch.einsum('btk,btkv->btv',read,seq)
  else:
   out=[]
   for i in range(t):
    ki=k[:,i];vi=v[:,i];err=vi-torch.einsum('bk,bkv->bv',ki,st);st=st+(g[:,i]*ki).unsqueeze(-1)*err.unsqueeze(-2);out.append(torch.einsum('bk,bkv->bv',read[:,i],st))
   m=torch.stack(out,1);last=st
  if ab=='zero_memory':m=torch.zeros_like(m)
  msg=self.direct(m);h=h+self.out(r+self.combine(q).sigmoid()*msg);h=h+self.ff(self.norm2(h));return h,(rs,last)
class Net3(s.Net2):
 def __init__(self,arm,ff):
  if arm=='hold32':s.Net.__init__(self,arm,ff);return
  if 'plain' not in arm:super().__init__(arm,ff);return
  nn.Module.__init__(self);self.arm=arm;self.ff=ff;self.key=nn.Embedding(16,D);self.val=nn.Embedding(8,D);self.typ=nn.Embedding(2,D);self.norm=nn.LayerNorm(D);self.read=nn.Linear(D,8);self.block=Plain(arm,ff)
  with torch.no_grad():
   for m in self.modules():
    if isinstance(m,nn.Linear):m.weight.normal_(0,1/math.sqrt(m.in_features));m.bias.zero_() if m.bias is not None else None
    elif isinstance(m,nn.Embedding):m.weight.normal_(0,.1)
 def apply(self,h,mask,state=None,ab=None):
  if self.arm=='hold32':return s.Net.apply(self,h,mask,state,ab)
  return super().apply(h,mask,state,ab)
ARMS3=['hold32','add32_shape_auto','delta32_shape_auto','delta32_plain','add128_plain','delta128_plain']
r.Net=Net3;r.TARGET=12000
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);jobs=[(a,seed) for a in ARMS3 for seed in s.S];random.Random(18004).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
  fs=[pool.submit(r.run,*j) for j in jobs]
  for f in concurrent.futures.as_completed(fs):f.result()
