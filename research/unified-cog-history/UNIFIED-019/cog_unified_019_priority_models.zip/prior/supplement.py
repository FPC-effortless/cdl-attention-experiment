import run as r
from run import *
import run
S=r.SEEDS=[7193,7211,7243]; r.TARGET=12000
class Flex(AssocBlock):
 def __init__(self,mode,ff):
  cap=128 if '128' in mode else 32
  typ=mode.split('_')[0].rstrip('0123456789')
  super().__init__(typ,cap,ff)
  if 'shape' in mode:
   self.k=16; self.kd=16; self.vd=2; self.units=16 if typ=='slot' else 2; self.h=self.vd if typ=='slot' else 1;m=self.units*self.h
   self.address=nn.Linear(D,self.k if typ=='slot' else self.kd);self.payload=nn.Linear(D,self.vd);self.select=nn.Linear(D,2*self.units*4);self.ow=nn.Parameter(torch.empty(4,self.h,self.h));self.ob=nn.Parameter(torch.zeros(4,self.h));nn.init.normal_(self.ow,std=1/math.sqrt(self.h));self.msgnorm=nn.LayerNorm(2*m);self.recv=nn.Linear(2*m,D)
class Net2(Net):
 def __init__(self,arm,ff):
  if arm in ['native32','attn4','attnfull']:
   super().__init__(arm,ff);return
  # Initialise exactly one alternative block; other pieces same distribution as primary.
  nn.Module.__init__(self);self.arm=arm;self.ff=ff;self.key=nn.Embedding(16,D);self.val=nn.Embedding(8,D);self.typ=nn.Embedding(2,D);self.norm=nn.LayerNorm(D);self.read=nn.Linear(D,8);self.block=Flex(arm,ff)
  with torch.no_grad():
   for m in self.modules():
    if isinstance(m,nn.Linear):m.weight.normal_(0,1/math.sqrt(m.in_features));m.bias.zero_() if m.bias is not None else None
    elif isinstance(m,nn.Embedding):m.weight.normal_(0,.1)
   self.block.ow.normal_(0,1/math.sqrt(self.block.h))
 def apply(self,h,mask,state=None,ab=None):
  if self.arm in ['native32','attn4','attnfull']:return super().apply(h,mask,state,ab)
  if 'auto' in self.arm:mask=torch.ones_like(mask)
  if 'uniform' in self.arm:ab='uniform_read'
  return self.block(h,state,mask,ab)
ARMS2=['native32','attn4','attnfull','add32','add32_shape','delta32_shape','slot32_shape','add128','delta128','add128_auto','delta128_auto','add128_uniform','delta128_uniform']
# Use the same harness, but preserve independent output IDs/seeds and distinct configuration.
r.Net=Net2
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);jobs=[(a,s) for a in ARMS2 for s in S];random.Random(18003).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
  fs=[pool.submit(r.run,*j) for j in jobs]
  for f in concurrent.futures.as_completed(fs):f.result()
