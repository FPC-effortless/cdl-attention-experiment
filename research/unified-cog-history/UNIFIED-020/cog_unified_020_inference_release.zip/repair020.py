import torch, math, json, time, hashlib, random, concurrent.futures, inspect
from torch import nn
import torch.nn.functional as F
import run020 as base
from recovered019 import FactorMatrix,FactorAttn,D,assoc
from pathlib import Path
P=Path(__file__).parent
SEEDS=[9413,9437,9473]; ARMS=['factor_delta','unified_attn','direct_delta','direct_aligned','direct_split']
STEPS=900; BATCH=32
# The exact old method, with a single change in how query addresses are produced.
src=inspect.getsource(FactorMatrix.forward_pair).replace(' def forward_pair(', 'def forward_pair(').replace('query=self.address(self.norm(qkeys)) if self.reads==2 else self.address(u[:,-1:]);q=F.normalize(query,dim=-1)','query=self.readaddr(self.norm(qkeys[:,0])).reshape(b,2,self.kd);q=F.normalize(query,dim=-1)')
exec(src,globals());DirectMatrix=type('DirectMatrix',(FactorMatrix,),{'forward_pair':forward_pair})
class SplitMatrix(FactorMatrix):
 def __init__(self,ff):
  super().__init__(D,ff,16,8,reads=2,mode='delta',gate='auto',tied=False)
  self.address=nn.Linear(D,32);self.payload=nn.Linear(D,8);self.write=nn.Linear(D,2);self.direct=nn.Linear(8,D)
 def forward_pair(self,h,mask,qkeys,ab=None):
  b,t,d=h.shape;u=self.norm(h);z,a=self.inp(u).chunk(2,-1);a=.5+.49*a.sigmoid();a=a.unflatten(-1,(d//2,2)).mean(-1,keepdim=True).expand(*a.shape[:-1],d//2,2).flatten(-2)
  rr,rs=assoc(z.tanh(),a);c=u+rr;k=F.normalize(self.address(u).reshape(b,t,2,16),dim=-1);v=self.payload(u).tanh().reshape(b,t,2,4);g=self.write(u).sigmoid();s=torch.zeros(b,2,16,4,device=h.device,dtype=h.dtype)
  for i in range(t):
   ki=k[:,i];err=v[:,i]-torch.einsum('brk,brkv->brv',ki,s);s=s+(g[:,i,:,None]*ki).unsqueeze(-1)*err.unsqueeze(-2)
  q=F.normalize(self.readaddr(self.norm(qkeys[:,0])).reshape(b,2,16),dim=-1)
  if ab=='uniform':q=torch.ones_like(q)/math.sqrt(16)
  if ab=='same':q=q[:,:1].expand_as(q)
  if ab=='swap':q=q.flip(1)
  m=torch.einsum('brk,brkv->brv',q,s)
  if ab=='zero':m=torch.zeros_like(m)
  x=h[:,-1]+self.out(rr[:,-1]+self.combine(c[:,-1]).sigmoid()*self.direct(m.flatten(-2)));return x+self.ff(self.norm2(x))
class Model(base.Model):
 def __init__(self,arm,ff):
  super().__init__(arm,ff)
  if arm.startswith('direct'):
   self.block=SplitMatrix(ff) if arm=='direct_split' else DirectMatrix(D,ff,16,8,reads=2,mode='delta',gate='auto',tied=False)
   with torch.no_grad():
    for m in self.block.modules():
     if isinstance(m,nn.Linear):m.weight.normal_(0,1/math.sqrt(m.in_features));m.bias.zero_() if m.bias is not None else None
 def align(self,k,v,q,ix):
  rec=self.key(k)+self.val(v)+self.typ.weight[0];que=self.pair(self.key(q).flatten(-2))+self.typ.weight[1];b=self.block
  keys=F.normalize(b.address(b.norm(rec)),dim=-1);reads=F.normalize(b.readaddr(b.norm(que)).reshape(-1,2,16),dim=-1)
  # Additional explicit contributor supervision, never used at inference. No detached keys.
  sim=torch.einsum('brk,btk->brt',reads,keys)*10
  return F.cross_entropy(sim.flatten(0,1),ix.flatten())
def make(arm,seed):
 b=base.count(Model(arm,1));s=base.count(Model(arm,2))-b;ff=max(4,round(1+(12000-b)/s));torch.manual_seed(seed);return Model(arm,ff)
def run(arm,seed):
 torch.set_num_threads(1);m=make(arm,seed);opt=torch.optim.AdamW(m.parameters(),lr=.003);curve=[];t=time.perf_counter()
 for i in range(STEPS):
  m.train();k,v,q,y,ix=base.batch(600000+seed*10000+i,BATCH);z,a=m(k,v,q);loss=F.cross_entropy(z.flatten(0,1),y.flatten())+F.cross_entropy(a,y.sum(-1)%8);loss=loss+0.5*m.align(k,v,q,ix) if arm=='direct_aligned' else loss;opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1);opt.step();assert torch.isfinite(loss)
  if (i+1)%150==0:curve.append(dict(step=i+1,loss=float(loss.detach()),individual=float((z.argmax(-1)==y).float().mean())))
 sec=time.perf_counter()-t;path=P/'fits'/f'repair_{arm}_{seed}.pt';torch.save(dict(weights=m.state_dict(),optimizer=opt.state_dict(),rng=torch.get_rng_state(),arm=arm,seed=seed,ff=m.ff,steps=STEPS),path)
 ev=base.evaluate(m,seed);ab={a:base.evaluate(m,seed,a) for a in ['same','swap','uniform','zero']} if 'delta' in arm or arm.startswith('direct') else {};control=base.evaluate(m,seed,intervene=True)
 restored=Model(arm,m.ff);restored.load_state_dict(torch.load(path,weights_only=True)['weights']);rep=base.evaluate(restored,seed);assert rep==ev
 result=dict(phase='repair',arm=arm,seed=seed,params=base.count(m),ff=m.ff,steps=STEPS,history_exposures=STEPS*BATCH,seconds=sec,curve=curve,eval=ev,intervention_control=control,ab=ab,replay_exact=True,sha256=hashlib.sha256(path.read_bytes()).hexdigest());path.with_suffix('.json').write_text(json.dumps(result,indent=2));print('DONE',arm,seed,ev['8_seen']['complete'],ev['8_heldout']['complete'],ev['16_heldout']['complete'],flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);jobs=[(a,s) for a in ARMS for s in SEEDS];random.Random(20002).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as ex:
  for f in concurrent.futures.as_completed([ex.submit(run,*j) for j in jobs]):f.result()
