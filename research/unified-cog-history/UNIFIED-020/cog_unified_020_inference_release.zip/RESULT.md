# COG-UNIFIED-020 — developmental query decomposition and execution gate
Date: 2026-11-26. Parent: UNIFIED-019 GitHub commit 04cfd10f81b98eeb4f39782acbb5d2aacfc358da, priority archive. Recovered relevant methods from factor.py/run.py/prior/scan_check.py; copied only the active mechanism methods, not a full source-tree or pretrained-weight replay. All new fits start from fresh seeds. No canonical architecture change.

## Accounting
33 independent training fits (18 initial, 15 repair); 29,700 optimizer updates; 950,400 training history exposures; 33/33 checkpoint reloads reproduce every evaluation count. CPU only. No official campaign credit claimed. Six reduced-grid numerical kernel diagnostics are distinct from training fits. Full kernel grid timed out.

## Initial gate: held-out ordered query pairs, 8 records
Three seeds, 900 updates, batch32, ~12K parameters, except MLP 12,981. Each panel is 768 histories. Ordered query pairs matching (q0+3*q1)%5==0 excluded entirely from training. Shared pair projection creates one 32D query vector; factorized reference additionally receives separate embeddings; all non-factorized arms receive only the combined vector at the read interface. Both narrow and wide attention are competent. 640 B COG carried state (512 B matrix +128 B working state); narrow attention prefix cache 640 B at 8 records; wide 2,048 B. State counts exclude temporary activations/current query. Factorized delta reference passes at 8 and 16 records. Linear and nonlinear learned decomposition do not pass.

| Arm | Both correct | Aggregate | Both correct at 16 |
|---|---:|---:|---:|
| Factorized attention | 100.00% | 100.00% | 100.00% |
| Factorized delta | 100.00% | 100.00% | 100.00% |
| Narrow unified attention | 100.00% | 100.00% | 100.00% |
| Wide unified attention | 100.00% | 100.00% | 100.00% |
| Unified linear delta | 59.64% | 46.35% | 40.76% |
| Unified MLP delta | 15.23% | 28.91% | 11.07% |

## Fresh-seed repair phase
Same budget and data protocol; independent direct address heads replace tied query decomposition, separate banks retain the same 640 B carried-state budget. An explicit contributor CE auxiliary with weight 0.5 (cosine logits ×10) is a diagnostic, not autonomous supervision. It passes the held-out 8-record near-attention threshold in each seed for individual and complete accuracy, with >90% aggregation each seed. It does NOT pass the complete seen-pair gate in two seeds (250/256 each, below 98%). It degrades at 16 records. Inference receives no explicit contributor labels. Direct-address heads without auxiliary and split banks remain poor. The ablation confirms independent reads contribute causally. No autonomous query decomposition qualified.

| Arm | Both correct | Aggregate | Both correct at 16 |
|---|---:|---:|---:|
| Factorized delta | 100.00% | 100.00% | 100.00% |
| Narrow unified attention | 100.00% | 100.00% | 100.00% |
| Direct shared delta | 19.40% | 69.40% | 15.23% |
| Direct separate banks | 19.01% | 77.99% | 14.97% |
| Direct + contributor supervision | 98.96% | 93.62% | 81.38% |

Supervised arm held-out 8-record complete counts: 255,252,253 /256. Independent ablation panel: control 750/768, same head 88, swapped 81, uniform 25, zero 21. Exact success at 16 records is 625/768. No evidence the extra bank separation alone solves learning.

## Execution diagnostic
Blockwise low-rank recurrence: delta_i = beta_i(v_i-k_i^T S0 - sum_{j<i}(k_i^T k_j)delta_j). Solve unit lower triangular system (I+tril(beta Gram,-1)) delta = beta(V-KS0); recover states from cumulative rank-one updates. Six completed CPU cases, block=16, widths 16/32/64, histories 128/512, batches 1/4; max FP32 absolute error against FP64 sequential 4.663e-7; max gradient deviation 7.451e-9; segmented continuation max error 7.153e-7. Measured forward-only speedup vs Python-loop sequential approximately 4.57–7.60x, not fused-GPU or full-model speed. Full grid timed out; no claims on unmeasured cases.

## Verdict and limitations
Controlled retrieval capacity is present. Autonomous acquisition of stable query addresses remains the confirmed weakness. Supervised geometry is promising but requires held-out and seen-seed qualification, longer contexts, label-efficiency and removal of contributor supervision. Input still consists of explicitly known ordered identity embeddings before fusion; this is not raw-language query parsing. Record key/value packing remains engineered, no new native-induction or LM integration fits performed. Not FLOP-matched, no GPU, no lifecycle economics, no exact weight replay of UNIFIED-019, no canonical integration. Retain factorized learned-write delta as the qualified structured reference; do not promote direct-address repair. Complete checkpoints/optimizer state/source/results included in local evidence archive. GitHub binary publication not yet verified. Historical binary backfill remains open.
