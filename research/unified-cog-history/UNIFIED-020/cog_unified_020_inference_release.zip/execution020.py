import torch, time, json, statistics
from pathlib import Path
import torch.nn.functional as F
P=Path(__file__).parent
torch.set_num_threads(1)
def sequential(k,v,g,s):
 out=[]
 for i in range(k.shape[1]):
  a=k[:,i];e=v[:,i]-torch.einsum('bk,bkv->bv',a,s);s=s+(g[:,i]*a).unsqueeze(-1)*e.unsqueeze(-2);out.append(s)
 return torch.stack(out,1)
def block_scan(k,v,g,s,block=32):
 out=[]
 for kk,vv,gg in zip(k.split(block,1),v.split(block,1),g.split(block,1)):
  t=kk.shape[1];gram=kk@kk.transpose(-1,-2);L=torch.tril(gg*gram,diagonal=-1)+torch.eye(t,device=k.device,dtype=k.dtype);rhs=gg*(vv-kk@s);delta=torch.linalg.solve_triangular(L,rhs,upper=False,unitriangular=True);states=s[:,None]+(kk.unsqueeze(-1)*delta.unsqueeze(-2)).cumsum(1);out.append(states);s=states[:,-1]
 return torch.cat(out,1)
def dense_scan(k,v,g,s):
 a=torch.eye(k.shape[-1],dtype=k.dtype,device=k.device)-(g*k).unsqueeze(-1)*k.unsqueeze(-2);b=(g*k).unsqueeze(-1)*v.unsqueeze(-2);d=1
 while d<k.shape[1]:
  aa=a[:,d:]@a[:,:-d];bb=a[:,d:]@b[:,:-d]+b[:,d:];a=torch.cat([a[:,:d],aa],1);b=torch.cat([b[:,:d],bb],1);d*=2
 return a@s[:,None]+b

def trial(kd,t,b,seed,block):
 torch.manual_seed(seed);k=F.normalize(torch.randn(b,t,kd),dim=-1);v=torch.randn(b,t,8);g=torch.sigmoid(torch.randn(b,t,1));s=torch.randn(b,kd,8)*.1;ref=sequential(*[x.double() for x in [k,v,g,s]]);a=sequential(k,v,g,s);z=block_scan(k,v,g,s,block);d=dense_scan(k,v,g,s);gs=[]
 for f in [sequential,lambda *x:block_scan(*x,block)]:
  xs=[x.clone().requires_grad_(True) for x in [k,v,g,s]];o=f(*xs);gs.append(torch.autograd.grad(o.square().mean(),xs))
 # Uneven segmentation, with restored prefix state.
 cut=t//3;zz=block_scan(k[:,:cut],v[:,:cut],g[:,:cut],s,block);st=zz[:,-1].clone();rest=block_scan(k[:,cut:],v[:,cut:],g[:,cut:],st,block);split=torch.cat([zz,rest],1)
 times={}
 with torch.no_grad():
  funcs=[('sequential',sequential),('dense',dense_scan),('block',lambda *x:block_scan(*x,block))];raw={n:[] for n,f in funcs}
  for n,f in funcs:f(k,v,g,s)
  for i in range(5):
   for n,f in funcs[::(-1 if i%2 else 1)]:
    st=time.perf_counter()
    for _ in range(3):f(k,v,g,s)
    raw[n].append((time.perf_counter()-st)*1000/3)
  times={n:statistics.median(x) for n,x in raw.items()}
 return dict(kd=kd,t=t,batch=b,block=block,seed=seed,seq_error=float((a-ref).abs().max()),dense_error=float((d-ref).abs().max()),block_error=float((z-ref).abs().max()),split_error=float((split-z).abs().max()),grad_error=max(float((x-y).abs().max()) for x,y in zip(*gs)),times_ms=times)
if __name__=='__main__':
 rows=[trial(k,t,b,200040+k*100+t*10+b,block) for k in [16,32,64] for t in [128,512] for b in [1,4] for block in [16,32]]
 (P/'execution020.json').write_text(json.dumps(rows,indent=2));print('rows',len(rows),'max block error',max(x['block_error'] for x in rows),'max grad',max(x['grad_error'] for x in rows),'max split',max(x['split_error'] for x in rows))
 for x in rows:
  if x['block']==32: print(x['kd'],x['t'],x['batch'],x['times_ms'], 'speed',x['times_ms']['sequential']/x['times_ms']['block'])
