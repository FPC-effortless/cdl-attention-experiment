# Relevant mechanism excerpts recovered from UNIFIED-019/run.py, factor.py, prior/scan_check.py.
# Archived at commit 04cfd10f81b98eeb4f39782acbb5d2aacfc358da.
import math
import torch
from torch import nn
import torch.nn.functional as F
D=32

def assoc(z,a,s=None):
 if s is None:s=torch.zeros_like(z[:,0])
 yy=[]
 for zc,ac in zip(z.split(16,1),a.split(16,1)):
  A=ac; B=(1-ac)*zc
  offset=1
  while offset<zc.shape[1]:
   A,B=torch.cat((A[:,:offset],A[:,offset:]*A[:,:-offset]),1),torch.cat((B[:,:offset],B[:,offset:]+A[:,offset:]*B[:,:-offset]),1)
   offset*=2
  y=A*s[:,None]+B;s=y[:,-1];yy.append(y)
 return torch.cat(yy,1),s
class Attention(nn.Module):
 def __init__(self,d,ff,kd,heads):
  super().__init__();self.kd=kd;self.heads=heads;self.norm=nn.LayerNorm(d);self.qkv=nn.Linear(d,3*kd);self.out=nn.Linear(kd,d);self.norm2=nn.LayerNorm(d);self.ff=nn.Sequential(nn.Linear(d,ff),nn.GELU(),nn.Linear(ff,d))
class Matrix(nn.Module):
 def __init__(self,d,ff,kd,vd,reads=1,mode='delta',gate='auto',tied=True):
  super().__init__();self.d=d;self.kd=kd;self.vd=vd;self.reads=reads;self.mode=mode;self.gate=gate;self.tied=tied;self.norm=nn.LayerNorm(d);self.inp=nn.Linear(d,2*d);self.address=nn.Linear(d,kd);self.payload=nn.Linear(d,vd);self.write=nn.Linear(d,1);self.readaddr=nn.Linear(d,reads*kd) if not tied else None;self.direct=nn.Linear(vd*reads,d);self.combine=nn.Linear(d,d);self.out=nn.Linear(d,d);self.norm2=nn.LayerNorm(d);self.ff=nn.Sequential(nn.Linear(d,ff),nn.GELU(),nn.Linear(ff,d))
class FactorMatrix(Matrix):
 def forward_pair(self,h,mask,qkeys,ab=None):
  # Only records are fed to the history update; learned query gates evaluated through normal forward for auto mode.
  b,t,d=h.shape;u=self.norm(h);z,a=self.inp(u).chunk(2,-1);a=.5+.49*a.sigmoid();a=a.unflatten(-1,(d//2,2)).mean(-1,keepdim=True).expand(*a.shape[:-1],d//2,2).flatten(-2)
  if self.gate=='hold':a=torch.where(mask[...,None],a,torch.ones_like(a))
  rr,rs=assoc(z.tanh(),a);c=u+rr;k=F.normalize(self.address(u),dim=-1);v=self.payload(u).tanh();g=self.write(u).sigmoid()
  if self.gate=='hold':g=g*mask[...,None]
  s=torch.zeros(b,self.kd,self.vd,device=h.device,dtype=h.dtype)
  if self.mode=='add':s=((g*k).unsqueeze(-1)*v.unsqueeze(-2)).sum(1)
  else:
   for i in range(t):
    ki=k[:,i];err=v[:,i]-torch.einsum('bk,bkv->bv',ki,s);s=s+(g[:,i]*ki).unsqueeze(-1)*err.unsqueeze(-2)
  query=self.address(self.norm(qkeys)) if self.reads==2 else self.address(u[:,-1:]);q=F.normalize(query,dim=-1)
  if ab=='uniform':q=torch.ones_like(q)/math.sqrt(self.kd)
  if ab=='same' and self.reads>1:q=q[:,:1].expand_as(q)
  if ab=='swap' and self.reads>1:q=q.flip(1)
  m=torch.einsum('brk,bkv->brv',q,s)
  if ab=='zero':m=torch.zeros_like(m)
  x=h[:,-1]+self.out(rr[:,-1]+self.combine(c[:,-1]).sigmoid()*self.direct(m.flatten(-2)));return x+self.ff(self.norm2(x))
class FactorAttn(Attention):
 def forward_pair(self,h,mask,qkeys,ab=None):
  b,t,d=h.shape;u=self.norm(h);q,k,v=self.qkv(u).reshape(b,t,3,self.heads,self.kd//self.heads).permute(2,0,3,1,4).unbind(0);x=self.qkv(self.norm(qkeys)).reshape(b,2,3,self.heads,self.kd//self.heads)[:,:,0];q=torch.stack([x[:,0,0],x[:,1,1]],1)[:,:,None];z=F.scaled_dot_product_attention(q,k,v).transpose(1,2).reshape(b,self.kd);h=h[:,-1]+self.out(z);return h+self.ff(self.norm2(h))
