import torch, math, json, time, hashlib, random, concurrent.futures
from torch import nn
import torch.nn.functional as F
from pathlib import Path
from recovered019 import D, FactorMatrix, FactorAttn
P=Path(__file__).parent
SEEDS=[9209,9239,9281]
ARMS=['factor_delta','factor_attn','unified_delta_linear','unified_delta_mlp','unified_attn','unified_attn_wide']
STEPS=900; BATCH=32
# Hold out ordered pairs entirely during training.
def batch(seed,b,n=8,split='train'):
 g=torch.Generator().manual_seed(seed);ls=[[] for _ in range(5)]
 while sum(len(x) for x in ls[0])<b:
  k=torch.rand(b*2,16,generator=g).argsort(-1)[:,:n];v=torch.randint(8,(b*2,n),generator=g);ix=torch.rand(b*2,n,generator=g).argsort(-1)[:,:2];q=k.gather(1,ix);y=v.gather(1,ix)
  hold=(q[:,0]+3*q[:,1])%5==0;mask=hold if split=='heldout' else ~hold
  for l,x in zip(ls,[k,v,q,y,ix]):l.append(x[mask])
 return tuple(torch.cat(x)[:b] for x in ls)
class Model(nn.Module):
 def __init__(self,arm,ff):
  super().__init__();self.arm=arm;self.ff=ff;self.key=nn.Embedding(16,D);self.val=nn.Embedding(8,D);self.typ=nn.Embedding(3,D);self.pair=nn.Linear(2*D,D);self.norm=nn.LayerNorm(D);self.read=nn.Linear(D,16);self.agg=nn.Linear(D,8)
  self.block=FactorAttn(D,ff,32 if arm.endswith('wide') else 10,2) if 'attn' in arm else FactorMatrix(D,ff,16,8,reads=2,mode='delta',gate='auto',tied=False)
  if isinstance(self.block,FactorMatrix):self.block.readaddr=None
  self.decompose=nn.Linear(D,2*D) if arm.endswith('linear') else nn.Sequential(nn.Linear(D,D),nn.GELU(),nn.Linear(D,2*D)) if arm.endswith('mlp') else None
  with torch.no_grad():
   for m in self.modules():
    if isinstance(m,nn.Linear):m.weight.normal_(0,1/math.sqrt(m.in_features));m.bias.zero_() if m.bias is not None else None
    elif isinstance(m,nn.Embedding):m.weight.normal_(0,.1)
 def forward(self,k,v,q,ab=None):
  rec=self.key(k)+self.val(v)+self.typ.weight[0];que=self.pair(self.key(q).flatten(-2))[:,None]+self.typ.weight[1];h=torch.cat([rec,que],1);mask=(torch.arange(h.shape[1])[None,:]<k.shape[1]).expand(k.shape[0],-1)
  if self.arm.startswith('factor'):qkeys=self.key(q)+self.typ.weight[1]
  elif self.decompose is not None:qkeys=self.decompose(que[:,0]).reshape(-1,2,D)
  else:qkeys=que.expand(-1,2,-1)
  z=self.norm(self.block.forward_pair(h,mask,qkeys,ab));return self.read(z).reshape(-1,2,8),self.agg(z)
def count(m):return sum(p.numel() for p in m.parameters())
def make(arm,seed):
 b=count(Model(arm,1));s=count(Model(arm,2))-b;ff=max(4,round(1+(12000-b)/s));torch.manual_seed(seed);return Model(arm,ff)
@torch.no_grad()
def evaluate(m,seed,ab=None,intervene=False):
 m.eval();res={}
 for n in ([8] if ab or intervene else [4,8,12,16]):
  for split in (['heldout'] if ab else ['seen','heldout']):
   a=c=g=j=mut=nuis=order=0
   for i in range(8):
    k,v,q,y,ix=batch(120000000+seed*10000+n*100+i+(1000000 if ab or intervene else 0),32,n,split);p,s=m(k,v,q,ab);ok=p.argmax(-1)==y;ag=s.argmax(-1)==y.sum(-1)%8;a+=int(ok.sum());c+=int(ok.all(-1).sum());g+=int(ag.sum());j+=int((ok.all(-1)&ag).sum())
    if not ab:
     vv=v.clone();ii=torch.arange(len(v));vv[ii,ix[:,0]]=(vv[ii,ix[:,0]]+1)%8;pred,_=m(k,vv,q);mut+=int((ok.all(-1)&(pred.argmax(-1)==vv.gather(1,ix)).all(-1)).sum());vv=v.clone();mask=torch.ones_like(v,dtype=torch.bool);mask.scatter_(1,ix,False);di=mask.long().argmax(-1);vv[ii,di]=(vv[ii,di]+1)%8;pred,_=m(k,vv,q);nuis+=int((ok.all(-1)&(pred.argmax(-1)==y).all(-1)).sum());pred,_=m(k,v,q.flip(1));order+=int((ok.all(-1)&(pred.argmax(-1)==y.flip(1)).all(-1)).sum())
   res[f'{n}_{split}']=dict(individual=a,answers=512,complete=c,histories=256,aggregate=g,joint=j,mutation=mut,nuisance=nuis,order=order)
 return res
def run(arm,seed):
 torch.set_num_threads(1);m=make(arm,seed);opt=torch.optim.AdamW(m.parameters(),lr=.003);curve=[];t=time.perf_counter()
 for i in range(STEPS):
  m.train();k,v,q,y,ix=batch(400000+seed*10000+i,BATCH);z,a=m(k,v,q);loss=F.cross_entropy(z.flatten(0,1),y.flatten())+F.cross_entropy(a,y.sum(-1)%8);opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1);opt.step();assert torch.isfinite(loss)
  if (i+1)%150==0:curve.append(dict(step=i+1,loss=float(loss.detach()),individual=float((z.argmax(-1)==y).float().mean())))
 sec=time.perf_counter()-t;path=P/'fits'/f'{arm}_{seed}.pt';torch.save(dict(weights=m.state_dict(),optimizer=opt.state_dict(),rng=torch.get_rng_state(),arm=arm,seed=seed,ff=m.ff,steps=STEPS),path)
 ev=evaluate(m,seed);ab={a:evaluate(m,seed,a) for a in ['same','swap','uniform','zero']} if 'delta' in arm else {};control=evaluate(m,seed,intervene=True)
 restored=Model(arm,m.ff);restored.load_state_dict(torch.load(path,weights_only=True)['weights']);rep=evaluate(restored,seed);assert rep==ev
 result=dict(arm=arm,seed=seed,params=count(m),ff=m.ff,steps=STEPS,history_exposures=STEPS*BATCH,seconds=sec,curve=curve,eval=ev,intervention_control=control,ab=ab,replay_exact=True,sha256=hashlib.sha256(path.read_bytes()).hexdigest());path.with_suffix('.json').write_text(json.dumps(result,indent=2));print('DONE',arm,seed,ev['8_seen']['complete'],ev['8_heldout']['complete'],ev['16_heldout']['complete'],flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);jobs=[(a,s) for a in ARMS for s in SEEDS];random.Random(20001).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as ex:
  for f in concurrent.futures.as_completed([ex.submit(run,*j) for j in jobs]):f.result()
