import torch,json,math,itertools,hashlib
import custody014 as c, curriculum as cur, presence as pre
from custody014 import P,NAME,TRAIN,HELD,TT,HH,K,H,SEEDS,W,MAX,V
@torch.no_grad()
def check(m,arm,seed):
 m.eval();records=[];tokens=[];action=[];address=[];values=[]
 for tab,temps in [(TT,TRAIN),(HH,HELD)]:
  for a in range(3):
   for j in range(len(temps[a])):
    for k,v,alias in itertools.product(range(16),range(8),range(2)):
     tokens.append(tab[a,j,k,v,alias]);action.append(a);address.append(k);values.append(v)
 x=torch.stack(tokens);a,k,v=map(torch.tensor,(action,address,values));n=len(x);out=dict(n=n,action_correct=0,address_correct=0,write_correct=0,write_n=int((a==1).sum()),min_action_margin=1e9,min_address_margin=1e9,min_write_margin=1e9)
 for i in range(0,n,128):
  xx=x[i:i+128,None,:];aa=a[i:i+128];kk=k[i:i+128];vv=v[i:i+128];p,al,kl,vl=m.enc(xx,NAME[None].expand(len(xx),16,2));al,kl,vl=al[:,0],kl[:,0],vl[:,0];mask=aa==1
  if arm.startswith('presence'):
   read=m.read(m.proj(p[:,0]).tanh());target=vv
  else:read=m.read(m.value[vl.argmax(-1)]);target=vv+1
  out['action_correct']+=int((al.argmax(-1)==aa).sum());out['address_correct']+=int((kl.argmax(-1)==kk).sum());out['write_correct']+=int((read.argmax(-1)[mask]==target[mask]).sum())
  for name,z,y in [('action',al,aa),('address',kl,kk),('write',read[mask],target[mask])]:
   if len(z)==0:continue
   selected=z.gather(-1,y[:,None]).squeeze(-1);other=z.masked_fill(torch.nn.functional.one_hot(y,z.shape[-1]).bool(),-float('inf')).max(-1).values;out[f'min_{name}_margin']=min(out[f'min_{name}_margin'],float((selected-other).min()))
 out['exact_policy']=out['action_correct']==n and out['address_correct']==n and out['write_correct']==out['write_n']
 # Construct two-name distractor statements at fixed length; both names supplied as candidates.
 g=torch.Generator().manual_seed(1449000+seed);count=addrn=complete=bits=0
 for _ in range(8):
  n=16;L=64;_,names,act,addr,val,y,_=c.gen(g,n,L);other=(addr+torch.randint(1,K,(n,L),generator=g))%K;tar=names.gather(1,addr[...,None].expand(n,L,2));dis=names.gather(1,other[...,None].expand(n,L,2));vv=c.VALUES[val];
  words=torch.zeros(n,L,MAX,dtype=torch.long)
  # 7-word HOLD; 8-word WRITE and RESET. Target explicitly designated by first named recipient.
  hold=torch.stack([tar[...,0],tar[...,1],torch.full_like(vv,W['mentioned']),vv,torch.full_like(vv,W['near']),dis[...,0],dis[...,1],torch.zeros_like(vv)],-1)
  write=torch.stack([torch.full_like(vv,W['record']),vv,torch.full_like(vv,W['for']),tar[...,0],tar[...,1],torch.full_like(vv,W['near']),dis[...,0],dis[...,1]],-1)
  reset=torch.stack([torch.full_like(vv,W['clear']),tar[...,0],tar[...,1],torch.full_like(vv,W['not']),vv,torch.full_like(vv,W['near']),dis[...,0],dis[...,1]],-1)
  words=torch.where((act==0)[...,None],hold,torch.where((act==1)[...,None],write,reset));z,s,ls,_=m(words,names,mode='hard');complete+=int((z.argmax(-1)==y).all(1).sum());addrn+=int((ls[1].argmax(-1)==addr).sum());count+=act.numel()
 out['two_entity_stress']={'n':128,'complete':complete,'address_correct':addrn,'event_n':count};return out
if __name__=='__main__':
 torch.set_num_threads(1);rows=[]
 for arm in ('factor_aux','presence','presence_curriculum'):
  for seed in SEEDS:
   ck=torch.load(P/'fits'/f'{arm}_{seed}.pt',weights_only=True);m=pre.Model(arm) if arm.startswith('presence') else cur.Model(arm);m.load_state_dict(ck['weights']);r=check(m,arm,seed);rows.append({'arm':arm,'seed':seed,**r});print(rows[-1],flush=True)
 (P/'closure.json').write_text(json.dumps(rows,indent=2))
