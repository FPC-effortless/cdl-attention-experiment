import json,csv,pathlib,hashlib,statistics,platform,torch
P=pathlib.Path(__file__).parent
r=[json.loads(f.read_text()) for f in sorted((P/'fits').glob('*.json'))];v=json.loads((P/'verification.json').read_text());assert len(r)==42==len(v) and all(x['pass'] for x in v)
rows=[];groups={}
for p,x in zip(sorted((P/'fits').glob('*.json')),r):
 pt=p.with_suffix('.pt');assert hashlib.sha256(pt.read_bytes()).hexdigest()==x['checkpoint_sha256'];row=dict(run=p.stem,arm=x['arm'],seed=x['seed'],steps=x['steps'],parameters=x['params'],train_histories=x['examples'],event_exposures=x.get('event_exposures',x['examples']*16),checkpoint_path=str(pt.relative_to(P)),checkpoint_bytes=pt.stat().st_size,sha256=x['checkpoint_sha256']);rows.append(row)
 k=('integration_' if p.stem.startswith('integration_') else '')+x['arm'];groups.setdefault(k,[]).append(x)
with (P/'checkpoint_manifest.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
res={'new_training_fits':len(r),'optimizer_updates':sum(x['steps'] for x in r),'training_histories':sum(x['examples'] for x in r),'event_exposures':sum(x['event_exposures'] for x in rows),'checkpoint_replays':len(v),'verified_replays':sum(x['pass'] for x in v),'groups':{},'closure':json.loads((P/'closure.json').read_text()),'official_campaign_credit_added':0}
for k,xs in groups.items():
 d={};modes=['panels'] if k.startswith('integration_') else [m for m in ['native','hardened','fresh_hardened'] if all(m in x for x in xs)]
 for m in modes:
  d[m]={}
  for p,z in xs[0][m].items():
   d[m][p]={q:sum(x[m][p][q] for x in xs) for q in ['n','complete','slots','cf_both','bitwise','split','action','address','value','event_n','write_n','ablate_complete'] if q in z and z[q] is not None}
 d['params']=xs[0]['params'];d['fits']=len(xs);res['groups'][k]=d
(P/'aggregate.json').write_text(json.dumps(res,indent=2));print({k:v for k,v in res.items() if k not in ['groups','closure']});(P/'environment.json').write_text(json.dumps(dict(python=platform.python_version(),torch=torch.__version__,cuda=torch.cuda.is_available(),cpu_workers=4),indent=2))
(P/'registry_delta.json').write_text(json.dumps({'cycle':'COG-UNIFIED-014','new_fits':42,'checkpoint_replays':42,'developmental_findings':['Initial answer-only action/address/value learning failed.','Factorized lexical matching plus presence coordinate and continuous value proposal learns exact finite-template custody from final-map supervision; six checkpoints pass exhaustive policy and fresh panels.','Two-entity stress fails all six presence models; relational entity binding remains unresolved.','Frozen-supervised protected state enables controlled COG backbone retrieval; protected-only equals hybrid, no added COG benefit demonstrated.'],'canonical_architecture_promotion':'denied','official_campaign_credit_added':0,'remote_archive':'All 42 current weights and 18 Gate0C custody weights uploaded with exact retrieval; larger historical binaries pending.','limits':['Controlled English templates','supplied roster and boundaries','small CPU models','frozen supervised encoder in integration','no natural-language LM qualification','no GPU','no matched-quality lifecycle claims']},indent=2))
