import sys,math,time,json,hashlib,torch,random,concurrent.futures
from torch import nn
import torch.nn.functional as F
import custody014 as c
import curriculum as cur
from hold_reset import exact_hold_reset
from custody014 import P,K,V,H,D,MAX,SEEDS
sys.path.insert(0,str(P/'reference'))
from calibration import Block
ARMS=('continuous','protected','hybrid');DD=48
class Model(nn.Module):
 def __init__(self,arm,seed):
  super().__init__();self.arm=arm;self.seed=seed;self.parser=cur.Model('factor_aux');ck=torch.load(P/'fits'/f'factor_aux_{seed}.pt',weights_only=True);self.parser.load_state_dict(ck['weights']);self.parser.requires_grad_(False);self.parser.eval()
  if arm!='protected':
   self.emb=nn.Embedding(len(c.WORDS),DD);self.inject=nn.Linear(D+3+K+V,DD);self.layers=nn.ModuleList([Block(DD,4,12,96,2,'init_only') for _ in range(2)]);self.norm=nn.LayerNorm(DD);self.head=nn.Linear(DD,K*H)
  self.read=nn.Sequential(nn.Linear(H*(2 if arm=='hybrid' else 1),32),nn.GELU(),nn.Linear(32,V+1))
 def forward(self,w,names,state=None,ablate=False):
  cs,ps=(None,None) if state is None else state;self.parser.eval()
  with torch.no_grad():p,al,kl,vl=self.parser.enc(w,names);a,k,v=al.softmax(-1),kl.softmax(-1),vl.softmax(-1)
  if self.arm!='protected':
   z=self.emb(w);e=self.inject(torch.cat([p,a,k,v],-1));z=torch.cat([z[:,:,:-1],z[:,:,-1:]+e[:,:,None]],2).flatten(1,2);ls=[]
   for i,l in enumerate(self.layers):z,s=l(z,None if cs is None else cs[i]);ls.append(s)
   h=self.head(self.norm(z[:,-1])).reshape(-1,K,H)
  else:ls=None;h=None
  if self.arm!='continuous':
   with torch.no_grad():
    pa,pk,pv=map(lambda x:F.one_hot(x.argmax(-1),x.shape[-1]).float(),(a,k,v));mass=pa[...,1:2]+pa[...,2:3];ret=1-pk*mass;val=pv@self.parser.value;proposal=torch.where((pa[...,1:2]>0),val,torch.zeros_like(val))[...,None,:].expand(-1,-1,K,-1);_,ps=exact_hold_reset(proposal,ret[...,None],torch.zeros_like(proposal[:,0]) if ps is None else ps)
   if ablate:feature=torch.zeros_like(ps)
   else:feature=ps
  else:feature=None
  x=feature if self.arm=='protected' else h if self.arm=='continuous' else torch.cat([h,feature],-1);return self.read(x),(ls,ps)
@torch.no_grad()
def ev(m,seed,n=64):
 m.eval();rows={}
 for kind,L in [('mixed',16),('mixed',64),('mixed',256),('mixed',1024),('retention',1024),('reset',1024),('unknown',64),('paraphrase',64)]:
  g=torch.Generator().manual_seed(1439000+seed+L*37+['mixed','retention','reset','unknown','paraphrase'].index(kind));ok=slot=abl=0;secs=0.;bytesn=0
  for _ in range(n//8):
   w,names,a,k,v,y,cf=c.gen(g,8,L,kind);s=None;start=time.perf_counter()
   for z in w.split(32,1):out,s=m(z,names,s)
   secs+=time.perf_counter()-start;pr=out.argmax(-1);ok+=int((pr==y).all(1).sum());slot+=int((pr==y).sum());ls,ps=s;bytesn=(sum(q[0].numel()*q.element_size() for l in ls for q in l) if ls else 0)+(ps[0].numel()*ps.element_size() if ps is not None else 0)
   if m.arm=='hybrid':
    # use exactly same final feature path but zero memory in final chunk, carry from prior chunks
    st=None
    for j,z in enumerate(w.split(32,1)):o,st=m(z,names,st,ablate=True)
    abl+=int((o.argmax(-1)==y).all(1).sum())
  rows[f'{kind}_{L}']=dict(n=n,complete=ok,slots=slot,state_bytes=bytesn,ablate_complete=abl if m.arm=='hybrid' else None,seconds=secs)
 return rows

def run(arm,seed):
 torch.set_num_threads(1);torch.manual_seed(seed);m=Model(arm,seed);opt=torch.optim.AdamW([p for p in m.parameters() if p.requires_grad],lr=.003);g=torch.Generator().manual_seed(1431000+seed);t=time.perf_counter();curve=[]
 for i in range(1,251):
  w,n,a,k,v,y,_=c.gen(g,16,16);m.train();z,_=m(w,n);loss=F.cross_entropy(z.flatten(0,1),y.flatten());opt.zero_grad();loss.backward();gn=nn.utils.clip_grad_norm_([p for p in m.parameters() if p.requires_grad],1);assert torch.isfinite(gn);opt.step()
  if i in (1,100,250):curve.append(dict(step=i,loss=float(loss.detach()),complete=float((z.argmax(-1)==y).all(1).float().mean())))
 key=f'integration_{arm}_{seed}';path=P/'fits'/f'{key}.pt';torch.save(dict(weights=m.state_dict(),arm=arm,seed=seed,steps=250,vocabulary=c.WORDS),path);r=dict(arm=arm,seed=seed,steps=250,examples=4000,event_exposures=64000,params=sum(p.numel() for p in m.parameters()),trainable_params=sum(p.numel() for p in m.parameters() if p.requires_grad),seconds=time.perf_counter()-t,curve=curve,checkpoint_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),panels=ev(m,seed));(P/'fits'/f'{key}.json').write_text(json.dumps(r,indent=2));print('DONE',key,[(k,v['complete'],v['ablate_complete']) for k,v in r['panels'].items()],flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);jobs=[(a,s) for a in ARMS for s in SEEDS];random.Random(14006).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as p:
  for f in concurrent.futures.as_completed([p.submit(run,*j) for j in jobs]):f.result()
