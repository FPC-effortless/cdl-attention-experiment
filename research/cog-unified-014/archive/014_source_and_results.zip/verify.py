import json,pathlib,torch,hashlib,concurrent.futures
import custody014 as c, curriculum as cur, presence as pre, integrate as it
P=pathlib.Path(__file__).parent
@torch.no_grad()
def check(p):
 torch.set_num_threads(1);r=json.loads(p.read_text());ckpath=p.with_suffix('.pt');ck=torch.load(ckpath,weights_only=True);arm=r['arm'];seed=r['seed'];h=hashlib.sha256(ckpath.read_bytes()).hexdigest();assert h==r['checkpoint_sha256'];out={'run':p.stem,'checkpoint_sha256':h,'hash_match':True}
 if p.name.startswith('integration_'):
  m=it.Model(arm,seed);m.load_state_dict(ck['weights']);a=it.ev(m,seed);out['replay_equal']=all(all(v==a[k][q] for q,v in z.items() if q!='seconds') for k,z in r['panels'].items())
 else:
  m=pre.Model(arm) if arm.startswith('presence') else cur.Model(arm) if arm in cur.ARMS else c.Model(arm);m.load_state_dict(ck['weights']);out['replay_equal']=c.evaluate(m,seed)==r['native'];
  if 'hardened' in r:out['hardened_equal']=c.evaluate(m,seed,'hard')==r['hardened']
  if 'fresh_hardened' in r:out['fresh_equal']=c.evaluate(m,seed+10000,'hard',panels=[('mixed',1024),('retention',1024),('reset',1024),('unknown',64),('paraphrase',64),('alias',64)])==r['fresh_hardened']
 out['pass']=all(v for k,v in out.items() if k in ('hash_match','replay_equal','hardened_equal','fresh_equal'));print(out,flush=True);return out
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);paths=sorted((P/'fits').glob('*.json'));out=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
  for f in concurrent.futures.as_completed([pool.submit(check,p) for p in paths]):
   out.append(f.result());(P/'verification.json').write_text(json.dumps(out,indent=2))
 print('verified',len(out),sum(x['pass'] for x in out),flush=True)
