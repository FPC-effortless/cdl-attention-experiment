"""Publish large, already-completed research artifacts through an authenticated gh CLI.
Never creates training receipts. No --clobber: existing assets are downloaded and hash-checked.
Requires explicit --execute; uses a DRAFT release unless already created. No public release promotion.
"""
import argparse, hashlib, json, pathlib, subprocess, tempfile

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def gh(*args,check=True):return subprocess.run(['gh',*args],check=check,text=True,capture_output=True)
def main():
 p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--tag',required=True);p.add_argument('--target',required=True);p.add_argument('--execute',action='store_true');p.add_argument('archives',nargs='+',type=pathlib.Path);a=p.parse_args();rows=[{'name':x.name,'bytes':x.stat().st_size,'sha256':sha(x)} for x in a.archives];print(json.dumps(rows,indent=2));
 if not a.execute:return
 gh('auth','status');r=gh('release','view',a.tag,'--repo',a.repo,'--json','assets,isDraft',check=False)
 if r.returncode:gh('release','create',a.tag,'--repo',a.repo,'--target',a.target,'--draft','--title',a.tag,'--notes','Research evidence; no architecture promotion.');existing=set()
 else:existing={x['name'] for x in json.loads(r.stdout)['assets']}
 for x,row in zip(a.archives,rows):
  if x.name not in existing:gh('release','upload',a.tag,str(x),'--repo',a.repo)
  with tempfile.TemporaryDirectory() as d:
   gh('release','download',a.tag,'--repo',a.repo,'--pattern',x.name,'--dir',d);remote=pathlib.Path(d)/x.name
   if remote.stat().st_size!=row['bytes'] or sha(remote)!=row['sha256']:raise RuntimeError(f'Integrity failure: {x.name}')
   print('remote bytes verified:',x.name,row['sha256'])
if __name__=='__main__':main()
