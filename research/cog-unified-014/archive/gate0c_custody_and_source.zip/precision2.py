import torch,math,json,pathlib,contextlib,types,hashlib,time,statistics
from torch import nn
import torch.nn.functional as F
import calibration as C
from scan import sequential
from hierarchical import hierarchical
from precision import metrics
P=pathlib.Path(__file__).parent; INPUT=P.parent/'cog_sparse_013'/'inputs'
INPUT_NAMES={'inp','pub','route','select'}; INTEGRATE={'recv','combine','out'}; FF={'ff.0','ff.2'}
CONFIG={'readout':set(),'input':INPUT_NAMES,'input_op':INPUT_NAMES|{'op'},'input_integrate':INPUT_NAMES|INTEGRATE,'input_ff0':INPUT_NAMES|{'ff.0'},'input_ff2':INPUT_NAMES|{'ff.2'},'input_norm':INPUT_NAMES|{'norm'},'input_op_integrate':INPUT_NAMES|{'op'}|INTEGRATE,'all':INPUT_NAMES|INTEGRATE|FF|{'op','norm'}}
@contextlib.contextmanager
def patch(m,names):
 saved=[]
 def put(obj,fn):saved.append((obj,obj.forward));obj.forward=types.MethodType(fn,obj)
 def lin(mod,x):
  with torch.autocast('cpu',enabled=False):return F.linear(x.float(),mod.weight.float(),mod.bias.float() if mod.bias is not None else None)
 def norm(mod,x):
  with torch.autocast('cpu',enabled=False):return F.layer_norm(x.float(),mod.normalized_shape,mod.weight.float(),mod.bias.float(),mod.eps)
 def op(l,x,p):
  with torch.autocast('cpu',enabled=False):return ((torch.einsum('...gh,koh->...gko',x.float(),l.ow.float())+l.ob.float()).tanh()*p.float()[...,None]).sum(-2)
 oldops=[]
 for l in m.layers:
  for name,mod in l.named_modules():
   if isinstance(mod,nn.Linear) and name in names:put(mod,lin)
   if isinstance(mod,nn.LayerNorm) and 'norm' in names:put(mod,norm)
  if 'op' in names:oldops.append((l,l.op));l.op=types.MethodType(op,l)
 try:yield
 finally:
  for mod,old in saved:mod.forward=old
  for l,old in oldops:l.op=old
@torch.no_grad()
def logits(m,x,mode,names,method='hier'):
 C.associative=lambda z,a,s=None:(hierarchical if method=='hier' else sequential)(z.float(),a.float(),None if s is None else s.float());m.eval();out=[]
 with patch(m,names),torch.autocast('cpu',dtype=torch.bfloat16,enabled=mode=='bf16'):
  for a in x.split(16):
   h=m.emb(a)
   for l in m.layers:h,_=l(h)
   with torch.autocast('cpu',enabled=False):z=F.linear(m.norm(h.float()),m.emb.weight.float())
   if m.policy in ('scaled','readout_only'):z=z*math.sqrt(192/m.d)
   out.append(z.float())
 return torch.cat(out)
def mac_fraction(m,names):
 allm=256*m.d;fp=allm
 for l in m.layers:
  for name,mod in l.named_modules():
   if isinstance(mod,nn.Linear):
    x=mod.in_features*mod.out_features;allm+=x;fp+=x if name in names else 0
  x=2*l.k*4*l.h*l.h;allm+=x;fp+=x if 'op' in names else 0
 return fp/allm
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);ds,_,_,rows,_=C.getdata();out=[]
 for receipt in json.load(open(INPUT/'receipts.json')):
  p=INPUT/(receipt['key']+'.pt');sha=hashlib.sha256(p.read_bytes()).hexdigest();assert sha==receipt['checkpoint_sha256'];ck=torch.load(p,weights_only=True);m=C.Model(ck['size'],ck['policy'],ck['L'],ck.get('fixed_ff'));m.load_state_dict(ck['weights']);r={'key':receipt['key'],'sha256':sha,'panels':{},'fp32_mac_fraction':{k:mac_fraction(m,v) for k,v in CONFIG.items()}}
  for name in ('dev','test'):
   x=rows[name][0][:,:-1];y=rows[name][0][:,1:];ref=logits(m,x,'fp32',set(),'serial');d={'fp32_hier':metrics(logits(m,x,'fp32',set()),ref,y)}
   for k,v in CONFIG.items():d[k]=metrics(logits(m,x,'bf16',v),ref,y)
   r['panels'][name]=d
  out.append(r);(P/'precision2.json').write_text(json.dumps(out,indent=2));print('DONE',receipt['key'],{k:(v['flips'],v['mean_kl']) for k,v in r['panels']['dev'].items()},flush=True)
