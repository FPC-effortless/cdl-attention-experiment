import pathlib,json,csv,statistics as S,hashlib
P=pathlib.Path(__file__).parent;mean=S.mean
lm=[json.loads(f.read_text()) for f in sorted((P/'fits').glob('*.json'))];st=[json.loads(f.read_text()) for f in sorted((P/'state_fits').glob('*.json'))];v=json.loads((P/'verification.json').read_text());pr=json.loads((P/'precision2.json').read_text());h=json.loads((P/'hardened.json').read_text());cl=json.loads((P/'closure.json').read_text());d=json.loads((P/'dispatch_check.json').read_text());t=json.loads((P/'timing.json').read_text());pt=json.loads((P/'precision_timing.json').read_text());assert len(lm)==30 and len(st)==18 and len(v)==48 and len(pr)==6 and len(h)==6 and len(cl)==36
assert len(set(r['checkpoint_sha256'] for r in lm+st))==48;assert all(x['hash_ok'] and (abs(x['dev_delta'])<=1e-9 and abs(x['test_delta'])<=1e-9 and x['accuracy_match'] if x['kind']=='language' else all(x['panel_match'].values())) for x in v)
base=7*320*320+320*(2*4+1+2*4*4)+2*4*4*80*80;mac={'dense':2*(base+2*320*1089)+320*256,'narrow':2*(base+2*320*136)+320*256,'group':2*(base+2*320*136+320*16)+320*256}
res={'accounting':{'language_fits':len(lm),'state_fits':len(st),'total_fits':len(lm)+len(st),'distinct_hashes':len(set(r['checkpoint_sha256'] for r in lm+st)),'language_updates':sum(x['steps'] for x in lm),'state_updates':sum(x['steps'] for x in st),'total_updates':sum(x['steps'] for x in lm+st),'byte_exposures':sum(x['byte_exposures'] for x in lm),'structured_history_exposures':sum(x['examples'] for x in st),'checkpoint_replays':len(v),'prior_precision_checkpoints':len(pr),'hardening_interventions':len(h),'official_campaign_new_credit':0},'language':{},'custody':{},'hardened':{},'closure':{},'precision':{},'timing':{},'dispatch':{'panels':len(d),'output_max':max(x['output_max'] for x in d),'gradient_max':max(max(x['gradient_max']) for x in d),'max_gradient_relative_l2':max(max(x['gradient_relative_l2']) for x in d),'inactive_groups_total':sum(x['unused_groups'] for x in d),'inactive_weight_nonzero_grad':sum(x['inactive_weight_nonzero_grad'] for x in d)},'verification':{'replays_pass':len(v),'stream_n':sum(x['stream']['n'] for x in lm),'stream_flips':sum(x['stream']['flips'] for x in lm),'restart_n':sum(x.get('restart_n',0) for x in v),'restart_flips':sum(x.get('restart_flips',0) for x in v),'restart_max':max(x.get('restart_max',0) for x in v)}}
rows=[]
for step in (150,1000):
 res['language'][str(step)]={};basefit={x['seed']:x['dev']['bpb'] for x in lm if x['arm']=='dense' and x['steps']==step}
 for a in sorted(set(x['arm'] for x in lm if x['steps']==step)):
  z=[x for x in lm if x['arm']==a and x['steps']==step];r={'arm':a,'steps':step,'fits':len(z),'params':z[0]['params'],'trainable_params':z[0]['trainable_params'],'dev_bpb':mean(x['dev']['bpb'] for x in z),'test_bpb':mean(x['test']['bpb'] for x in z),'dev_acc':mean(x['dev']['accuracy'] for x in z),'test_acc':mean(x['test']['accuracy'] for x in z),'seed_gains_pct':{str(x['seed']):100*(basefit[x['seed']]-x['dev']['bpb'])/basefit[x['seed']] for x in z},'rank':[mean(x['layers'][i]['effective_rank'] for x in z) for i in range(2)],'zero_fraction':[mean(x['layers'][i]['zeros']/x['layers'][i]['total'] for x in z) for i in range(2)],'never_active_fraction':[mean(x['layers'][i]['never_active']/x['layers'][i]['ff'] for x in z) for i in range(2)],'train_sec_mean':mean(x['train_seconds'] for x in z),'forward_matrix_MACs':mac['narrow' if a=='narrow' else 'dense' if a in ('dense','dense_diverse') else 'group'],'history_bpb':[mean(x['history']['bpb'][i] for x in z) for i in range(3)],'history_targets':z[0]['history']['n'],'state_bytes':z[0]['stream']['state_bytes'],'clip_fraction':mean(x['clip_fraction'] for x in z)};res['language'][str(step)][a]=r;rows.append(r)
for key,allr in [('custody',st),('hardened',h)]:
 for a in sorted(set(x['arm'] for x in allr)):
  z=[x for x in allr if x['arm']==a];res[key][a]={'panels':{k:{metric:sum(x['panels'][k][metric] for x in z) for metric in z[0]['panels'][k]} for k in z[0]['panels']},'distinct_destinations':[len(set(max(range(len(p)),key=p.__getitem__) for p in x['address'])) for x in z]}
for a in sorted(set(x['arm'] for x in cl)):
 z=[x for x in cl if x['arm']==a];res['closure'][a]={m:{'passes':sum(x['finite_closure'] for x in z if x['mode']==m),'fits':sum(x['mode']==m for x in z),'actions':sum(x['action_correct'] for x in z if x['mode']==m),'action_n':sum(x['action_n'] for x in z if x['mode']==m),'transitions':sum(x['transition_correct'] for x in z if x['mode']==m),'transition_value_correct':sum(x['transition_value_correct'] for x in z if x['mode']==m),'transition_n':sum(x['transition_n'] for x in z if x['mode']==m)} for m in sorted(set(x['mode'] for x in z))}
for a in pr[0]['panels']['dev']:
 z=[x['panels'][p][a] for x in pr for p in ('dev','test')];res['precision'][a]={'n':sum(x['n'] for x in z),'flips':sum(x['flips'] for x in z),'worst_mean_kl':max(x['mean_kl'] for x in z),'worst_max_token_kl':max(x['max_kl'] for x in z),'worst_relative_l2':max(x['relative_l2'] for x in z),'worst_peak':max(x['relative_peak'] for x in z),'fp32_affine_mac_fraction':pr[0]['fp32_mac_fraction'].get(a,1.),'all_panel_pass':all(x['flips']==0 and x['mean_kl']<1e-5 and x['relative_l2']<1e-3 and x['relative_peak']<1e-3 for x in z)}
for a in ('dense','narrow','diverse'):
 z=[x for x in t['lm'] if x['arm']==a];res['timing'][a]={k:mean(x['panels'][k]['tokens_per_second'] for x in z) for k in z[0]['panels']}
res['timing']['precision_ms']={k:mean(x['ms'][k] for x in pt) for k in pt[0]['ms']}
for a in ('fixed_soft','learn_soft'):
 res['timing'][a]={}
 for mode in ('native','hardened'):
  z=[x for x in t['state'] if x['arm']==a and x['mode']==mode];m={}
  for L in ('32','128','1024'):
   q=[x['panels'][L] for x in z];nr=sum(x['resume_correct'] for x in q);nc=sum(x['replay_correct'] for x in q);m[L]={'n':sum(x['n'] for x in q),'resume_correct':nr,'replay_correct':nc,'parity':sum(x['parity'] for x in q),'resume_ms_per_correct':1000*sum(x['resume_s'] for x in q)/nr if nr else None,'replay_ms_per_correct':1000*sum(x['replay_s'] for x in q)/nc if nc else None,'state_bytes':q[0]['state_bytes']}
  res['timing'][a][mode]=m
(P/'aggregate.json').write_text(json.dumps(res,indent=2))
with (P/'summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with (P/'checkpoint_manifest.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['relative_path','bytes','sha256','training_steps','seed','arm']);
 for r,folder in [(x,'fits') for x in lm]+[(x,'state_fits') for x in st]:
  name=f"{r['arm']}_{r['seed']}"+(f"_{r['steps']}" if folder=='fits' else '')+'.pt';p=P/folder/name;w.writerow([str(p.relative_to(P)),p.stat().st_size,r['checkpoint_sha256'],r['steps'],r['seed'],r['arm']])
print(json.dumps({'accounting':res['accounting'],'verification':res['verification'],'dispatch':res['dispatch'],'precision':res['precision'],'timing':res['timing']},indent=2))
