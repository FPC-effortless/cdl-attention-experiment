import torch,math,json,pathlib,contextlib,types
from torch import nn
import torch.nn.functional as F
import calibration as C
from scan import sequential
from hierarchical import hierarchical
P=pathlib.Path(__file__).parent
METHODS={'serial':sequential,'hier':hierarchical}
@contextlib.contextmanager
def interventions(m,stage):
 saved=[]
 def patch(obj,name,fn):
  old=getattr(obj,name);saved.append((obj,name,old));setattr(obj,name,types.MethodType(fn,obj))
 def lin(mod,x):
  with torch.autocast('cpu',enabled=False):return F.linear(x.float(),mod.weight.float(),None if mod.bias is None else mod.bias.float())
 def norm(mod,x):
  with torch.autocast('cpu',enabled=False):return F.layer_norm(x.float(),mod.normalized_shape,mod.weight.float(),mod.bias.float(),mod.eps)
 def op(l,x,p):
  with torch.autocast('cpu',enabled=False):return ((torch.einsum('...gh,koh->...gko',x.float(),l.ow.float())+l.ob.float()).tanh()*p.float()[...,None]).sum(-2)
 for l in m.layers:
  for name,mod in l.named_modules():
   if isinstance(mod,nn.Linear) and (stage=='all_linear' or (stage=='input' and name in ('inp','pub','route','select')) or (stage=='output' and name in ('recv','combine','out','ff.0','ff.2'))):patch(mod,'forward',lin)
   if stage=='norm' and isinstance(mod,nn.LayerNorm):patch(mod,'forward',norm)
  if stage in ('operator','all_linear'):patch(l,'op',op)
 try:yield
 finally:
  for obj,name,old in reversed(saved):setattr(obj,name,old)
@torch.no_grad()
def logits(m,x,method,mode,readout,stage='none'):
 C.associative=lambda z,a,s=None:METHODS[method](z.float(),a.float(),None if s is None else s.float());m.eval();out=[]
 with interventions(m,stage),torch.autocast('cpu',dtype=torch.bfloat16,enabled=(mode=='bf16')):
  for a in x.split(16):
   h=m.emb(a)
   for l in m.layers:h,_=l(h)
   if readout:
    with torch.autocast('cpu',enabled=False):z=F.linear(m.norm(h.float()),m.emb.weight.float())
   else:z=F.linear(m.norm(h),m.emb.weight)
   if m.policy in ('scaled','readout_only'):z=z*math.sqrt(192/m.d)
   out.append(z.float())
 return torch.cat(out)
def metrics(z,r,y=None):
 z=z.double();r=r.double();d=z-r;pp=r.log_softmax(-1);qq=z.log_softmax(-1);kl=(pp.exp()*(pp-qq)).sum(-1).clamp_min(0);result=dict(n=z.numel()//z.shape[-1],mean_kl=float(kl.mean()),max_kl=float(kl.max()),relative_l2=float(d.norm()/r.norm().clamp_min(1e-8)),max_token_relative_l2=float((d.norm(dim=-1)/r.norm(dim=-1).clamp_min(1e-8)).max()),relative_peak=float(d.abs().max()/r.abs().max().clamp_min(1e-8)),max_abs=float(d.abs().max()),flips=int((z.argmax(-1)!=r.argmax(-1)).sum()),finite=bool(z.isfinite().all()))
 if y is not None:result.update(bpb=float(F.cross_entropy(z.flatten(0,1),y.flatten())/math.log(2)),target_correct=int((z.argmax(-1)==y).sum()))
 return result
if __name__=='__main__':
 torch.set_num_threads(1);ds,_,_,rows,_=C.getdata();panels={'original':(ds['dev'][0][:128][None],None),'validation':(rows['dev'][0][:,:-1],rows['dev'][0][:,1:])};out=[]
 for receipt in json.loads((P/'inputs/receipts.json').read_text()):
  ck=torch.load(P/'inputs'/f"{receipt['key']}.pt",weights_only=True);m=C.Model(ck['size'],ck['policy'],ck['L'],ck.get('fixed_ff'));m.load_state_dict(ck['weights']);r={'key':receipt['key'],'panels':{}}
  for panel,(x,y) in panels.items():
   ref=logits(m,x,'serial','fp32',False);p={};zs={}
   configs=[('fp32_serial','serial','fp32',False,'none'),('fp32_hier','hier','fp32',False,'none'),('bf16_serial','serial','bf16',False,'none'),('bf16_hier','hier','bf16',False,'none'),('bf16_readout_serial','serial','bf16',True,'none'),('bf16_readout_hier','hier','bf16',True,'none')]
   if panel=='original':configs += [('fp32_'+stage,'hier','bf16',True,stage) for stage in ('input','output','norm','operator','all_linear')]
   for name,method,mode,ro,stage in configs:
    z=logits(m,x,method,mode,ro,stage);zs[name]=z;p[name]=metrics(z,ref,y)
   p['bf16_scan_only']=metrics(zs['bf16_hier'],zs['bf16_serial']);p['bf16_readout_scan_only']=metrics(zs['bf16_readout_hier'],zs['bf16_readout_serial']);r['panels'][panel]=p
  out.append(r);(P/'precision.json').write_text(json.dumps(out,indent=2));print(r['key'],{k:(round(v['mean_kl'],8),round(v['relative_l2'],6),v['flips']) for k,v in r['panels']['original'].items()},flush=True)
