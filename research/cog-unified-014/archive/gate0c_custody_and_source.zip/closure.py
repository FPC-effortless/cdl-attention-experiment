import torch,pathlib,json,itertools
import torch.nn.functional as F
import custody
from hold_reset import exact_hold_reset
P=pathlib.Path(__file__).parent
class CanonicalModel(custody.Model):
 # Inference-only direct zero proposal for non-WRITE cues; no arithmetic signed-zero leakage.
 def encode(self,c,k,v,s=None):
  value=self.value(v);log=self.action(torch.cat([self.cue(c),self.key(k),value],-1));prob=log.softmax(-1);p=F.one_hot(custody.REV[c] if self.arm=='oracle' else prob.argmax(-1),3).float();addr=self.address(k);a=(1-addr*(p[...,1:2]+p[...,2:3]))[...,None];proposal=torch.where(p[...,1:2]==1,value,torch.zeros_like(value))[...,None,:].expand(-1,-1,8,-1)
  if s is None:s=torch.zeros_like(proposal[:,0])
  yy,last=exact_hold_reset(proposal,a,s);return last,log,p,addr,yy,proposal,a
@torch.no_grad()
def audit(m):
 event=torch.tensor(list(itertools.product(range(6),range(8),range(8))));c,k,v=event.T;a=custody.REV[c];c,k,v=c[:,None],k[:,None],v[:,None];m.eval();prototypes=torch.cat([torch.zeros(1,custody.H),m.value.weight.detach()],0);addr=m.address(torch.arange(8));dest=addr.argmax(-1);distinct=int(dest.unique().numel());log=m.action(torch.cat([m.cue(c),m.key(k),m.value(v)],-1));pred=log.argmax(-1)[:,0];action=384 if m.arm=='oracle' else int((pred==a).sum());margin=(log.topk(2,dim=-1).values[...,0]-log.topk(2,dim=-1).values[...,1]).min().item();rr=m.read(prototypes);read=int((rr.argmax(-1)==torch.arange(9)).sum());read_margin=(rr.topk(2,dim=-1).values[:,0]-rr.topk(2,dim=-1).values[:,1]).min().item();n=ok=coordinates=bitcorrect=valok=0
 for j in range(9):
  old=prototypes[j][None,None,:].expand(384,8,-1).clone();out=m.encode(c,k,v,old)[0];expect=old.clone();ii=torch.arange(384);ww=a==1;reset=a==2;expect[ii[ww],dest[k[:,0]][ww]]=prototypes[v[:,0][ww]+1];expect[ii[reset],dest[k[:,0]][reset]]=0.;eq=(out.contiguous().view(torch.int32)==expect.contiguous().view(torch.int32));n+=len(out);ok+=int(eq.reshape(len(out),-1).all(1).sum());coordinates+=eq.numel();bitcorrect+=int(eq.sum());valok+=int((out==expect).reshape(len(out),-1).all(1).sum())
 return dict(action_correct=action,action_n=384,action_logit_margin=margin,distinct_destinations=distinct,readout_correct=read,readout_n=9,readout_margin=read_margin,transition_correct=ok,transition_value_correct=valok,transition_n=n,coordinate_correct=bitcorrect,coordinate_n=coordinates,finite_closure=(action==384 and distinct==8 and read==9 and ok==n))
if __name__=='__main__':
 torch.set_num_threads(1);out=[]
 for f in sorted((P/'state_fits').glob('*.json')):
  r=json.loads(f.read_text());arm=r['arm'];m=custody.Model(arm.replace('soft','hard'));m.load_state_dict(torch.load(f.with_suffix('.pt'),weights_only=True)['weights']);z=dict(arm=arm,seed=r['seed'],mode='hardened' if 'soft' in arm else 'native',**audit(m));out.append(z);print(z,flush=True)
  c=CanonicalModel(m.arm);c.load_state_dict(m.state_dict());c.eval();z=dict(arm=arm,seed=r['seed'],mode='canonical_zero',**audit(c));out.append(z);print(z,flush=True)
 (P/'closure.json').write_text(json.dumps(out,indent=2))
