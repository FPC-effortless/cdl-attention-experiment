import torch,json,pathlib,math
import torch.nn.functional as F
import group,calibration as C
P=pathlib.Path(__file__).parent;G=group.G;W=group.W;TOP=group.TOP

def test(l,x,force=False):
 v=x.detach().clone().requires_grad_();params=[l.ff[0].weight,l.ff[0].bias,l.ff[2].weight,l.ff[2].bias,l.group_router.weight,l.group_router.bias];p=[q.detach().clone().requires_grad_() for q in params];w1,b1,w2,b2,wr,br=p
 def calc(dense):
  log=F.linear(v,wr,br);vals,idx=log.topk(2,dim=-1)
  if force:idx=torch.arange(2)[None].expand(v.size(0),-1);vals=log.gather(-1,idx)
  weight=2*vals.softmax(-1)
  if dense:
   mask=torch.zeros_like(log).scatter(-1,idx,weight).repeat_interleave(W,dim=-1);out=F.linear(F.gelu(F.linear(v,w1,b1))*mask,w2,b2)
  else:
   out=b2[None,:].expand(v.size(0),-1)
   for j in range(G):
    ii,jj=(idx==j).nonzero(as_tuple=True)
    if len(ii)==0:continue
    sl=slice(j*W,(j+1)*W);act=F.gelu(F.linear(v[ii],w1[sl],b1[sl]));y=F.linear(act,w2[:,sl]);out=out.index_add(0,ii,y*weight[ii,jj,None])
  return out,idx
 a,idx=calc(False);b,_=calc(True);g=torch.Generator().manual_seed(130140);q=torch.randn(a.shape,generator=g)/a.numel();ga=torch.autograd.grad((a*q).sum(),[v]+p);gb=torch.autograd.grad((b*q).sum(),[v]+p);inactive=torch.bincount(idx.flatten(),minlength=G)==0;rows=inactive.repeat_interleave(W)
 return dict(force=force,n=v.size(0),unused_groups=int(inactive.sum()),output_max=float((a-b).abs().max()),output_relative_l2=float((a-b).norm()/b.norm().clamp_min(1e-12)),gradient_max=[float((x-y).abs().max()) for x,y in zip(ga,gb)],gradient_relative_l2=[float((x-y).norm()/y.norm().clamp_min(1e-12)) for x,y in zip(ga,gb)],inactive_weight_nonzero_grad=int((ga[1][rows]!=0).sum()+(ga[2][rows]!=0).sum()+(ga[3][:,rows]!=0).sum()))
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);_,_,_,rows,_=C.getdata();out=[]
 for f in sorted((P/'fits').glob('*.json')):
  r=json.loads(f.read_text());arm=r['arm'];
  if arm not in ('learned','diverse'):continue
  m=group.Model(arm);m.load_state_dict(torch.load(f.with_suffix('.pt'),weights_only=True)['weights']);m.eval();xs=[];hooks=[l.norm2.register_forward_hook(lambda mod,args,out:xs.append(out.detach().reshape(-1,out.size(-1)))) for l in m.layers]
  with torch.no_grad():m(rows['dev'][0][:16,:-1])
  for h in hooks:h.remove()
  for i,l in enumerate(m.layers):
   for force in (False,True):out.append(dict(key=f.stem,layer=i,**test(l,xs[i],force)))
 (P/'dispatch_check.json').write_text(json.dumps(out,indent=2));print('panels',len(out),'max output',max(x['output_max'] for x in out),'max grad',max(max(x['gradient_max']) for x in out),'unused group nonzero grad',sum(x['inactive_weight_nonzero_grad'] for x in out))
