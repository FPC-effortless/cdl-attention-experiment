import pathlib,json,hashlib,torch,io,concurrent.futures
import group,custody,calibration as C
P=pathlib.Path(__file__).parent
@torch.no_grad()
def lmcheck(f):
 torch.set_num_threads(1);r=json.loads(f.read_text());p=f.with_suffix('.pt');ck=torch.load(p,weights_only=True);m=group.Model(r['arm']);m.load_state_dict(ck['weights']);m.eval();ds,_,_,rows,_=C.getdata();d=C.evaluate(m,rows['dev']);t=C.evaluate(m,rows['test']);x=ds['test'][0][:96][None];z=m(x);a,s=m(x[:,:37],with_state=True);b=io.BytesIO();torch.save([[v.clone().contiguous() for v in q] for q in s],b);n=b.tell();b.seek(0);st=torch.load(b,weights_only=True);m2=group.Model(r['arm']);m2.load_state_dict(ck['weights']);m2.eval();c=m2(x[:,37:],state=st);y=torch.cat([a,c],1);return dict(key=f.stem,kind='language',hash_ok=hashlib.sha256(p.read_bytes()).hexdigest()==r['checkpoint_sha256'],dev_delta=d['bpb']-r['dev']['bpb'],test_delta=t['bpb']-r['test']['bpb'],accuracy_match=d['accuracy']==r['dev']['accuracy'] and t['accuracy']==r['test']['accuracy'],restart_flips=int((z.argmax(-1)!=y.argmax(-1)).sum()),restart_n=x.numel(),restart_max=float((z-y).abs().max()),state_file_bytes=n)
@torch.no_grad()
def statecheck(f):
 torch.set_num_threads(1);r=json.loads(f.read_text());p=f.with_suffix('.pt');ck=torch.load(p,weights_only=True);m=custody.Model(r['arm']);m.load_state_dict(ck['weights']);m.eval();v={k:custody.ev(m,r['seed'],int(k.split('_')[-1]),k.split('_')[0]) for k in r['panels']};return dict(key=f.stem,kind='state',hash_ok=hashlib.sha256(p.read_bytes()).hexdigest()==r['checkpoint_sha256'],panel_match={k:v[k]==r['panels'][k] for k in v})
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);jobs=[(lmcheck,f) for f in sorted((P/'fits').glob('*.json'))]+[(statecheck,f) for f in sorted((P/'state_fits').glob('*.json'))];out=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
  fs={pool.submit(fn,f):f for fn,f in jobs}
  for f in concurrent.futures.as_completed(fs):
   try:r=f.result();out.append(r);print(r,flush=True)
   except Exception as e:print('FAIL',fs[f],repr(e),flush=True)
   (P/'verification.json').write_text(json.dumps(out,indent=2))
