import torch,pathlib,statistics,json,time,math,random
import calibration as C
from precision2 import INPUT,CONFIG,logits
P=pathlib.Path(__file__).parent
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);ds,_,_,_,_=C.getdata();x=ds['dev'][0][:128][None];out=[]
 for rec in json.load(open(INPUT/'receipts.json')):
  ck=torch.load(INPUT/(rec['key']+'.pt'),weights_only=True);m=C.Model(ck['size'],ck['policy'],ck['L'],ck.get('fixed_ff'));m.load_state_dict(ck['weights']);m.eval();names={'fp32_hier':set(),**CONFIG};times={k:[] for k in names};rng=random.Random(131430)
  for k,v in names.items():logits(m,x,'fp32' if k=='fp32_hier' else 'bf16',v)
  for rep in range(9):
   order=list(names);rng.shuffle(order)
   for k in order:
    t=time.perf_counter();logits(m,x,'fp32' if k=='fp32_hier' else 'bf16',names[k]);times[k].append(time.perf_counter()-t)
  out.append(dict(key=rec['key'],n=x.numel(),ms={k:1000*statistics.median(v) for k,v in times.items()}));print(out[-1],flush=True)
 (P/'precision_timing.json').write_text(json.dumps(out,indent=2))
