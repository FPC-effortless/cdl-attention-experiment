import torch,json,pathlib
from custody import Model,ev
P=pathlib.Path(__file__).parent
if __name__=='__main__':
 torch.set_num_threads(1);out=[]
 for f in sorted((P/'state_fits').glob('*_soft_*.json')):
  r=json.loads(f.read_text());arm=r['arm'];m=Model(arm.replace('soft','hard'));m.load_state_dict(torch.load(f.with_suffix('.pt'),weights_only=True)['weights']);m.eval();x=dict(arm=arm,seed=r['seed'],address=m.address(torch.arange(8)).tolist(),panels={f'{k}_{L}':ev(m,r['seed'],L,k) for k in ('mixed','retention','reset') for L in (32,128,1024)});out.append(x);print(arm,r['seed'],[(k,v['complete'],v['semantic_ignore_final_state_bitwise']) for k,v in x['panels'].items() if k.endswith('1024')],flush=True)
 (P/'hardened.json').write_text(json.dumps(out,indent=2))
