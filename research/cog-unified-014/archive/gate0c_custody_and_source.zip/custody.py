import torch, math, time, pathlib, json, statistics, hashlib, random, concurrent.futures
from torch import nn
import torch.nn.functional as F
from hierarchical import hierarchical
from hold_reset import exact_hold_reset
P=pathlib.Path(__file__).parent;K=8;H=16;SEEDS=[173,271,907];ARMS=['fixed_soft','fixed_hard','learn_soft','learn_hard','fixed_supervised','oracle'];CUES=torch.tensor([4,1,0,5,2,3]);REV=torch.empty(6,dtype=torch.long);REV[CUES]=torch.arange(6)//2

def gen(g,n,L,kind='mixed'):
 if kind=='mixed':
  key=torch.randint(K,(n,L),generator=g);v=torch.randint(8,(n,L),generator=g);u=torch.rand(n,L,generator=g);a=torch.where(u<.6,0,torch.where(u<.9,1,2))
 else:
  # write every key once, then reset a random four keys for reset panel, then all distractors.
  key=torch.cat([torch.rand(n,K,generator=g).argsort(1),torch.randint(K,(n,L),generator=g)],1);v=torch.randint(8,key.shape,generator=g);a=torch.zeros_like(key);a[:,:K]=1
  if kind=='reset':
   key[:,K:K+4]=torch.rand(n,K,generator=g).argsort(1)[:,:4];a[:,K:K+4]=2
 cue=CUES[a*2+torch.randint(2,a.shape,generator=g)];y=torch.zeros(n,K,dtype=torch.long);j=torch.arange(n)
 for t in range(key.shape[1]):
  k=key[:,t];y[j,k]=torch.where(a[:,t]==1,v[:,t]+1,torch.where(a[:,t]==2,0,y[j,k]))
 return cue,key,v,a,y
class Model(nn.Module):
 def __init__(self,arm):
  super().__init__();self.arm=arm;self.hard=arm in ('fixed_hard','learn_hard','fixed_supervised','oracle');self.learn=arm.startswith('learn');self.cue=nn.Embedding(6,16);self.key=nn.Embedding(K,8);self.value=nn.Embedding(8,H);self.action=nn.Sequential(nn.Linear(24+H,32),nn.GELU(),nn.Linear(32,3));self.addr=nn.Parameter(torch.randn(K,K)*.1,requires_grad=self.learn);self.read=nn.Sequential(nn.Linear(H,32),nn.GELU(),nn.Linear(32,9));
  nn.init.normal_(self.value.weight,std=.4);nn.init.zeros_(self.action[-1].bias)
 def address(self,key):
  if not self.learn:return F.one_hot(key,K).float()
  p=self.addr[key].softmax(-1)
  if self.hard:return F.one_hot(p.argmax(-1),K).float()+(p-p.detach()) if self.training else F.one_hot(p.argmax(-1),K).float()
  return p
 def encode(self,c,k,v,s=None):
  value=self.value(v);log=self.action(torch.cat([self.cue(c),self.key(k),value],-1));prob=log.softmax(-1)
  if self.arm=='oracle':p=F.one_hot(REV[c],3).float()
  elif self.hard:p=F.one_hot(prob.argmax(-1),3).float()+(prob-prob.detach()) if self.training else F.one_hot(prob.argmax(-1),3).float()
  else:p=prob
  addr=self.address(k);hold=1-addr*(p[...,1:2]+p[...,2:3]);proposal=(value*p[...,1:2])[...,None,:].expand(-1,-1,K,-1);a=hold[...,None]
  if s is None:s=torch.zeros_like(proposal[:,0])
  yy,last=exact_hold_reset(proposal,a,s) if self.hard else hierarchical(proposal,a,s,accum=torch.float32)
  return last,log,p,addr,yy,proposal,a
 def decode(self,s):
  r=self.address(torch.arange(K));return self.read(torch.einsum('ij,bjh->bih',r,s))
 def forward(self,c,k,v,s=None):
  r=self.encode(c,k,v,s);return self.decode(r[0]),r
@torch.no_grad()
def ev(m,seed,L,kind):
 m.eval();g=torch.Generator().manual_seed(3139000+seed+L*37+{'mixed':1,'retention':2,'reset':3}[kind]);n=256;whole=slots=cf=bits=action=actionn=hn=he=rn=re=semhn=semhe=0;split=0
 for _ in range(n//16):
  c,k,v,a,y=gen(g,16,L,kind);z,r=m(c,k,v);pred=z.argmax(-1);ok=(pred==y).all(-1);whole+=int(ok.sum());slots+=int((pred==y).sum());s,log,p,addr,yy,proposal,aa=r;pa=p.argmax(-1);action+=int((pa==a).sum());actionn+=a.numel();prev=torch.cat([torch.zeros_like(yy[:,:1]),yy[:,:-1]],1);hm=(aa==1).expand_as(yy);rm=(aa==0).expand_as(yy);eq=(yy.contiguous().view(torch.int32)==prev.contiguous().view(torch.int32));hn+=int(hm.sum());he+=int((eq&hm).sum());rn+=int(rm.sum());re+=int(((yy.contiguous().view(torch.int32)==proposal.contiguous().view(torch.int32))&rm).sum());sm=(a==0)[...,None,None].expand_as(yy);semhn+=int(sm.sum());semhe+=int((eq&sm).sum());v2=torch.where(a==0,(v+1)%8,v);zz,rr=m(c,k,v2);cf+=int((ok&(zz.argmax(-1)==y).all(-1)).sum());bits+=int((s.contiguous().view(torch.int32)==rr[0].contiguous().view(torch.int32)).reshape(len(c),-1).all(1).sum());mid=c.shape[1]//2;st=m.encode(c[:,:mid],k[:,:mid],v[:,:mid])[0];end=m.encode(c[:,mid:],k[:,mid:],v[:,mid:],st)[0];split+=int((m.decode(end).argmax(-1)==pred).all(-1).sum())
 return dict(n=n,complete=whole,slots=slots,slot_n=n*K,counterfactual_both=cf,semantic_ignore_final_state_bitwise=bits,action_correct=action,action_n=actionn,hold_n=hn,hold_exact=he,reset_n=rn,reset_exact=re,semantic_hold_n=semhn,semantic_hold_exact=semhe,split_parity=split)
def run(arm,seed):
 torch.set_num_threads(1);torch.manual_seed(seed);m=Model(arm);g=torch.Generator().manual_seed(3131000+seed);opt=torch.optim.AdamW([p for p in m.parameters() if p.requires_grad],lr=.004);start=time.perf_counter();curve=[]
 for i in range(1,601):
  c,k,v,a,y=gen(g,64,32);m.train();z,r=m(c,k,v);loss=F.cross_entropy(z.flatten(0,1),y.flatten());loss=loss+.5*F.cross_entropy(r[1].flatten(0,1),a.flatten()) if arm=='fixed_supervised' else loss;opt.zero_grad(set_to_none=True);loss.backward();gn=float(nn.utils.clip_grad_norm_(m.parameters(),1));assert math.isfinite(gn) and bool(loss.isfinite());opt.step()
  if i in (1,100,300,600):curve.append(dict(step=i,loss=float(loss.detach()),complete=float((z.argmax(-1)==y).all(-1).float().mean())));print(arm,seed,i,curve[-1],flush=True)
 sec=time.perf_counter()-start;key=f'{arm}_{seed}';path=P/'state_fits'/f'{key}.pt';torch.save(dict(weights=m.state_dict(),arm=arm,seed=seed),path);m.eval();r=dict(arm=arm,seed=seed,steps=600,examples=38400,params=sum(p.numel() for p in m.parameters() if p.requires_grad),train_seconds=sec,curve=curve,address=m.address(torch.arange(K)).detach().tolist(),panels={f'{kind}_{L}':ev(m,seed,L,kind) for kind in ('mixed','retention','reset') for L in (32,128,1024)},checkpoint_sha256=hashlib.sha256(path.read_bytes()).hexdigest());(P/'state_fits'/f'{key}.json').write_text(json.dumps(r));print('DONE',key,[(k,v['complete']) for k,v in r['panels'].items()],flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);jobs=[(a,s) for a in ARMS for s in SEEDS];random.Random(313003).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=1) as pool:
  fs={pool.submit(run,*j):j for j in jobs}
  for f in concurrent.futures.as_completed(fs):
   try:f.result()
   except Exception as e:print('FAIL',fs[f],repr(e),flush=True)
