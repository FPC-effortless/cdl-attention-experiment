import torch, math,time,statistics,json,pathlib,hashlib,random,argparse,concurrent.futures
from torch import nn
import torch.nn.functional as F
import calibration as C
from hierarchical import hierarchical
P=pathlib.Path(__file__).parent; C.associative=lambda z,a,s=None:hierarchical(z,a,s,accum=torch.float32)
ARMS=['dense','narrow','fixed','learned','balanced','diverse','dense_diverse']; SEEDS=C.SEEDS; G=16; W=68; TOP=2; D=320
class GroupBlock(C.Block):
 def forward(self,h,state=None):
  k,d=self.k,self.d;u=self.norm(h);z,a=self.inp(u).chunk(2,-1);a=.5+.49*a.sigmoid();a=a.unflatten(-1,(d//2,2)).mean(-1,keepdim=True).expand(*a.shape[:-1],d//2,2).flatten(-2);r,rs=C.associative(z.tanh(),a,None if state is None else state[0]);q=r+u
  v=self.pub(q).tanh().unflatten(-1,(k,self.h));w,rp,g=self.route(q).split([k,k,1],-1);gate=.4*g.sigmoid()*w.sigmoid();ms,last=C.associative(v,1-gate[...,None],None if state is None else state[1]);m=ms*rp.sigmoid()[...,None]*2
  p1,p2=self.select(q).unflatten(-1,(2,k,4)).softmax(-1).unbind(-3);y1=self.op(m,p1);y2=self.op(y1,p2);msg=self.recv(self.msgnorm(torch.cat([y1.flatten(-2),y2.flatten(-2)],-1)));h=h+self.out(r+self.combine(q).sigmoid()*msg);q2=self.norm2(h);self.aux=q2.new_zeros(())
  if self.arm in ('dense','narrow','dense_diverse'):
   act=F.gelu(self.ff[0](q2));h=h+self.ff[2](act);selected=None
  else:
   flat=q2.reshape(-1,d); logits=self.group_router(flat); prob=logits.softmax(-1)
   if self.arm=='fixed':
    idx=self.byte_ids.reshape(-1)%G;selected=torch.stack((idx,(idx+8)%G),-1);weight=torch.ones_like(selected,dtype=flat.dtype)
   else:
    vv,selected=logits.topk(TOP,dim=-1);weight=TOP*vv.softmax(-1)
   out=self.ff[2].bias[None,:].expand(len(flat),-1);act=flat.new_zeros((len(flat),G*W)) if self.collect else None
   if self.arm in ('balanced','diverse'):
    load=F.one_hot(selected,G).float().mean((0,1)).detach();self.aux=.02*(G*(prob.mean(0)*load).sum()-1)
   # Physically evaluate only chosen groups for the tokens assigned to each group.
   for j in range(G):
    ii,jj=(selected==j).nonzero(as_tuple=True)
    if len(ii)==0:continue
    sl=slice(j*W,(j+1)*W);v=F.gelu(F.linear(flat[ii],self.ff[0].weight[sl],self.ff[0].bias[sl]));y=F.linear(v,self.ff[2].weight[:,sl]);out=out.index_add(0,ii,y*weight[ii,jj,None])
    if self.collect:act[ii,sl]=v.detach()
   h=h+out.reshape_as(h)
  if self.arm in ('diverse','dense_diverse') and self.training:
   f=h.reshape(-1,d);f=F.normalize(f-f.mean(0),dim=-1);cov=f@f.T;self.aux=self.aux+.05*(cov.square().sum()-cov.diag().square().sum())/max(1,len(f)*(len(f)-1))
  if self.collect:self.records.append((act.detach().reshape(-1,act.shape[-1]),h.detach().reshape(-1,d),None if selected is None else selected.detach(),None if selected is None else prob.detach()))
  return h,(rs,last)
class Model(C.Model):
 def __init__(self,arm):
  super().__init__(3,'init_only',2,1089);self.arm=arm
  for l in self.layers:
   l.__class__=GroupBlock;l.arm=arm;l.collect=False;l.records=[]
   if arm=='narrow' or arm not in ('dense','dense_diverse'):
    n=136 if arm=='narrow' else G*W;old=l.ff;lin1=nn.Linear(D,n);lin2=nn.Linear(n,D)
    with torch.no_grad():lin1.weight.copy_(old[0].weight[:n]);lin1.bias.copy_(old[0].bias[:n]);lin2.weight.copy_(old[2].weight[:,:n]);lin2.bias.copy_(old[2].bias)
    l.ff=nn.Sequential(lin1,nn.GELU(),lin2)
    if arm!='narrow':
     l.group_router=nn.Linear(D,G);nn.init.normal_(l.group_router.weight,std=.01/math.sqrt(D));nn.init.zeros_(l.group_router.bias)
     if arm=='fixed':l.group_router.requires_grad_(False)
  self.ff=1089 if arm in ('dense','dense_diverse') else 136 if arm=='narrow' else G*W
 def forward(self,x,state=None,with_state=False):
  for l in self.layers:l.byte_ids=x
  return super().forward(x,state,with_state)
 def auxloss(self):return sum(l.aux for l in self.layers)
@torch.no_grad()
def stats(m,rows):
 for l in m.layers:l.collect=True;l.records=[]
 m.eval();m(rows[0][:16,:-1]);out=[]
 for l in m.layers:
  f,z,sel,p=l.records[0];l.collect=False;l.records=[];s=torch.linalg.svdvals(z-z.mean(0));q=s.square()/s.square().sum().clamp_min(1e-12);rank=float((-(q*q.clamp_min(1e-12).log()).sum()).exp());hist=torch.bincount(sel.flatten(),minlength=G).tolist() if sel is not None else None
  out.append(dict(tokens=len(f),ff=f.shape[-1],zeros=int((f==0).sum()),total=f.numel(),never_active=int((~(f!=0).any(0)).sum()),effective_rank=rank,group_hist=hist,group_entropy=float(-(p*p.clamp_min(1e-12).log()).sum(-1).mean()) if p is not None else None))
 return out
@torch.no_grad()
def stream(m,ds):
 m.eval();x=ds['test'][0][:96][None];z,s=m(x,with_state=True);a,st=m(x[:,:37],with_state=True);b,_=m(x[:,37:],state=st,with_state=True);return dict(n=x.numel(),flips=int((z.argmax(-1)!=torch.cat([a,b],1).argmax(-1)).sum()),max_abs=float((z-torch.cat([a,b],1)).abs().max()),state_bytes=sum(t.numel()*t.element_size() for l in s for t in l))
@torch.no_grad()
def history(m,ds):
 m.eval();loss=[0.,0.,0.];n=0
 for d in ds['test']:
  if len(d)<257:continue
  x=d[-257:][None];y=x[:,-32:]
  for j,L in enumerate([32,128,256]):loss[j]+=float(F.cross_entropy(m(x[:,-L-1:-1])[:,-32:].flatten(0,1),y.flatten(),reduction='sum'))
  n+=32
 return dict(n=n,bpb=[v/max(1,n)/math.log(2) for v in loss])
def run(arm,seed,steps):
 torch.set_num_threads(1);torch.manual_seed(seed);m=Model(arm);ds,t,starts,rows,excluded=C.getdata();opt=m.optimizer(.002);g=torch.Generator().manual_seed(813000+seed);curve=[];gns=[];secs=0.;key=f'{arm}_{seed}_{steps}'
 for i in range(1,steps+1):
  m.train();x=t[starts[torch.randint(len(starts),(4,),generator=g)][:,None]+torch.arange(33)];factor=min(1,i/10)*(.2+.8*.5*(1+math.cos(math.pi*i/steps)))
  for pg in opt.param_groups:pg['lr']=pg['base_lr']*factor
  start=time.perf_counter();opt.zero_grad(set_to_none=True);z=m(x[:,:-1]);ce=F.cross_entropy(z.flatten(0,1),x[:,1:].flatten());loss=ce+m.auxloss();assert bool(loss.isfinite());loss.backward();gn=float(nn.utils.clip_grad_norm_(m.parameters(),1));assert math.isfinite(gn);gns.append(gn);opt.step();secs+=time.perf_counter()-start
  if i in (steps//2,steps) or i in (100,250,500,750):
   b=C.evaluate(m,rows['dev'])['bpb'];curve.append(dict(step=i,dev_bpb=b));print('STEP',key,i,b,flush=True)
 path=P/'fits'/f'{key}.pt';torch.save(dict(arm=arm,seed=seed,steps=steps,weights=m.state_dict()),path);r=dict(arm=arm,seed=seed,steps=steps,params=sum(p.numel() for p in m.parameters()),trainable_params=sum(p.numel() for p in m.parameters() if p.requires_grad),byte_exposures=steps*128,train_seconds=secs,curve=curve,dev=C.evaluate(m,rows['dev']),test=C.evaluate(m,rows['test']),excluded=excluded,layers=stats(m,rows['dev']),stream=stream(m,ds),history=history(m,ds),mean_grad_norm=statistics.mean(gns),clip_fraction=sum(v>1 for v in gns)/len(gns),checkpoint_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
 (P/'fits'/f'{key}.json').write_text(json.dumps(r));print('DONE',key,r['dev']['bpb'],flush=True)
def jobs(jobs,workers=3):
 with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:
  fs={pool.submit(run,*j):j for j in jobs}
  for f in concurrent.futures.as_completed(fs):
   try:f.result()
   except Exception as e:print('FAIL',fs[f],repr(e),flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);p=argparse.ArgumentParser();p.add_argument('mode',choices=['screen','long']);p.add_argument('--candidate');a=p.parse_args();js=[(x,s,150) for x in ARMS for s in SEEDS] if a.mode=='screen' else [(x,s,1000) for x in ['dense','narrow',a.candidate] for s in SEEDS];random.Random(130301).shuffle(js);jobs(js)
