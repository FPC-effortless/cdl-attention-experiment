import torch,json,math,pathlib,time,statistics,numpy as np
import group,custody,calibration as C
P=pathlib.Path(__file__).parent
@torch.no_grad()
def bench_lm():
 ds,_,_,_,_=C.getdata();d=max(ds['test'],key=len);out=[]
 for f in sorted((P/'fits').glob('*_1000.json')):
  r=json.loads(f.read_text());m=group.Model(r['arm']);m.load_state_dict(torch.load(f.with_suffix('.pt'),weights_only=True)['weights']);m.eval();_,s=m(d[:128][None],with_state=True);panels={}
  for label,L,st in [('full1',1,None),('full32',32,None),('full128',128,None),('full256',256,None),('continuation1',1,s)]:
   x=d[128:128+L][None];fn=lambda:m(x,state=st);fn();fn();times=[]
   for j in range(9):t=time.perf_counter();fn();times.append(time.perf_counter()-t)
   panels[label]=dict(median_ms=1000*statistics.median(times),tokens_per_second=L/statistics.median(times))
  out.append(dict(arm=r['arm'],seed=r['seed'],panels=panels));print(out[-1],flush=True)
 return out
@torch.no_grad()
def state_bench(m,seed,L):
 g=torch.Generator().manual_seed(900131+seed+L);recs=[]
 for i in range(48):
  c,k,v,a,y=custody.gen(g,1,L,'retention');split=8+L//2;s=m.encode(c[:,:split],k[:,:split],v[:,:split])[0]
  def resume():
   raw=s.detach().contiguous().numpy().tobytes();s2=torch.from_numpy(np.frombuffer(raw,dtype=np.float32).copy()).reshape_as(s);return m(c[:,split:],k[:,split:],v[:,split:],s2)[0].argmax(-1),len(raw)
  def replay():return m(c,k,v)[0].argmax(-1),None
  rec={};out={};
  for label,fn in [('resume',resume),('replay',replay)] if i%2==0 else [('replay',replay),('resume',resume)]:
   t=time.perf_counter();p,n=fn();rec[label]=time.perf_counter()-t;out[label]=p;rec[label+'_correct']=bool((p==y).all());rec['bytes']=n if n is not None else rec.get('bytes')
  rec['parity']=bool((out['resume']==out['replay']).all());recs.append(rec)
 nr=sum(x['resume_correct'] for x in recs);nc=sum(x['replay_correct'] for x in recs);return dict(n=len(recs),resume_correct=nr,replay_correct=nc,parity=sum(x['parity'] for x in recs),resume_s=sum(x['resume'] for x in recs),replay_s=sum(x['replay'] for x in recs),resume_ms_per_correct=1000*sum(x['resume'] for x in recs)/nr if nr else None,replay_ms_per_correct=1000*sum(x['replay'] for x in recs)/nc if nc else None,state_bytes=recs[0]['bytes'])
@torch.no_grad()
def bench_state():
 out=[]
 for f in sorted((P/'state_fits').glob('fixed_soft_*.json'))+sorted((P/'state_fits').glob('learn_soft_*.json')):
  r=json.loads(f.read_text());arm=r['arm'];ck=torch.load(f.with_suffix('.pt'),weights_only=True)
  for mode in ('native','hardened'):
   m=custody.Model(arm if mode=='native' else arm.replace('soft','hard'));m.load_state_dict(ck['weights']);m.eval();out.append(dict(arm=arm,seed=r['seed'],mode=mode,panels={str(L):state_bench(m,r['seed'],L) for L in (32,128,1024)}));print(arm,r['seed'],mode,out[-1]['panels']['1024'],flush=True)
 return out
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);r={'lm':bench_lm(),'state':bench_state()};(P/'timing.json').write_text(json.dumps(r,indent=2))
