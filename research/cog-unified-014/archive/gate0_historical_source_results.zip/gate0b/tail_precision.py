import torch,math,pathlib,json
import calibration as C
from precision import logits,metrics
P=pathlib.Path(__file__).parent
@torch.no_grad()
def main():
 torch.set_num_threads(1);ds,_,_,rows,_=C.getdata();x,y=rows['dev'][0][:,:-1],rows['dev'][0][:,1:];out=[]
 for rec in json.load(open(P/'inputs/receipts.json')):
  ck=torch.load(P/'inputs'/f"{rec['key']}.pt",weights_only=True);m=C.Model(ck['size'],ck['policy'],ck['L'],ck.get('fixed_ff'));m.load_state_dict(ck['weights']);ref=logits(m,x,'serial','fp32',False);base=logits(m,x,'hier','bf16',True);pl=ref.double().log_softmax(-1);ql=base.double().log_softmax(-1);kl=(pl.exp()*(pl-ql)).sum(-1);idx=int(kl.flatten().argmax());i,j=divmod(idx,x.shape[1]);r=dict(key=rec['key'],worst={'row':i,'position':j,'kl':float(kl[i,j]),'fp32_top':ref[i,j].topk(2).values.tolist(),'bf16_top':base[i,j].topk(2).values.tolist(),'fp32_pred':int(ref[i,j].argmax()),'bf16_pred':int(base[i,j].argmax()),'target':int(y[i,j])},stages={})
  for stage in ('input','output','all_linear'):
   z=logits(m,x,'hier','bf16',True,stage);r['stages'][stage]=metrics(z,ref,y)
  out.append(r);(P/'precision_tail.json').write_text(json.dumps(out,indent=2));print(rec['key'],r['worst'],{k:(v['mean_kl'],v['max_kl'],v['flips']) for k,v in r['stages'].items()},flush=True)
if __name__=='__main__':main()
