import torch,json,pathlib,hashlib,statistics,time,math,io
import sparse as S
import calibration as C
from torch.nn import functional as F
P=pathlib.Path(__file__).parent
@torch.no_grad()
def logits(m,x,dispatch):
 m.dispatch(dispatch);return torch.cat([m(a) for a in x.split(16)])
@torch.no_grad()
def eval_dispatch(m,rows):
 x=rows[0][:,:-1];y=rows[0][:,1:];a=logits(m,x,False);b=logits(m,x,True);return dict(n=y.numel(),argmax_diff=int((a.argmax(-1)!=b.argmax(-1)).sum()),max_abs=float((a-b).abs().max()),bpb_masked=float(F.cross_entropy(a.flatten(0,1),y.flatten())/math.log(2)),bpb_dispatched=float(F.cross_entropy(b.flatten(0,1),y.flatten())/math.log(2)))
@torch.no_grad()
def timing(m,doc):
 out=[]
 for L in (1,32,128):
  x=doc[:L][None];times={False:[],True:[]}
  for v in (False,True):
   m.dispatch(v)
   for _ in range(3):m(x)
  for i in range(7):
   for v in ([False,True] if i%2==0 else [True,False]):
    m.dispatch(v);start=time.perf_counter();m(x);times[v].append(time.perf_counter()-start)
  a,b=[statistics.median(times[v]) for v in (False,True)];out.append(dict(L=L,masked_ms=1000*a,dispatch_ms=1000*b,ratio=a/b))
 return out
@torch.no_grad()
def main():
 torch.set_num_threads(1);ds,t,starts,rows,excluded=C.getdata();out=[]
 for f in sorted((P/'fits').glob('*.json')):
  r=json.loads(f.read_text());p=f.with_suffix('.pt');ck=torch.load(p,weights_only=True);m=S.Model(ck['arm']);m.load_state_dict(ck['weights']);m.eval();d=C.evaluate(m,rows['dev']);te=C.evaluate(m,rows['test']);st=S.stats(m,rows['dev']);disp=eval_dispatch(m,rows['dev']);m.dispatch(True);stream=S.verify_stream(m,ds);q=dict(key=f.stem,hash_ok=hashlib.sha256(p.read_bytes()).hexdigest()==r['checkpoint_sha256'],dev_equal=d==r['dev'],test_equal=te==r['test'],activation_equal=st==r['layers'],dispatch=disp,dispatch_stream=stream,timing=timing(m,max(ds['test'],key=len)));out.append(q);(P/'verification.json').write_text(json.dumps(out,indent=2));print(q,flush=True)
if __name__=='__main__':main()
