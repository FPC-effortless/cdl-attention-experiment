import math,time,json,pathlib,hashlib,statistics,concurrent.futures,random
import torch
from torch import nn
import torch.nn.functional as F
import calibration as C
from hierarchical import hierarchical
P=pathlib.Path(__file__).parent
ARMS={'dense':('gelu',False),'shift':('shift',False),'topk':('topk',False),'hard':('gelu',True),'shift_hard':('shift',True),'topk_hard':('topk',True),'mac_dense':('gelu',False)}
D=320;K=4;H=80;L=2
C.associative=lambda z,a,s=None:hierarchical(z,a,s,accum=torch.float32)
FIX=7*D*D+D*(2*K+1+2*K*4)
OP_FULL=2*K*4*H*H;OP_ONE=2*K*H*H
REF_FF=1089;KFF=math.ceil(.1*REF_FF);MATCH_FF=round((D*(REF_FF+KFF)+OP_ONE-OP_FULL)/(2*D))
class Activation(nn.Module):
 def __init__(self,kind):super().__init__();self.kind=kind
 def forward(self,z):
  if self.kind=='gelu':return F.gelu(z)
  if self.kind=='shift':
   mu=z.mean(-1,keepdim=True);sd=(z.var(-1,keepdim=True,unbiased=False)+1e-5).sqrt();return F.relu(z-mu-1.28155*sd)
  v,i=z.topk(math.ceil(.1*z.shape[-1]),dim=-1);return torch.zeros_like(z).scatter(-1,i,v.relu())
class Block(C.Block):
 def forward(self,h,state=None):
  k,d=self.k,self.d;scan=C.associative;u=self.norm(h);z,a=self.inp(u).chunk(2,-1);a=.5+.49*a.sigmoid();a=a.unflatten(-1,(d//2,2)).mean(-1,keepdim=True).expand(*a.shape[:-1],d//2,2).flatten(-2);r,rs=scan(z.tanh(),a,None if state is None else state[0]);q=r+u
  v=self.pub(q).tanh().unflatten(-1,(k,self.h));w,rp,g=self.route(q).split([k,k,1],-1);gate=.4*g.sigmoid()*w.sigmoid();ms,last=scan(v,1-gate[...,None],None if state is None else state[1]);m=ms*rp.sigmoid()[...,None]*2
  p=self.select(q).unflatten(-1,(2,k,4)).softmax(-1)
  if self.hard:
   hard=F.one_hot(p.argmax(-1),4).to(p.dtype);pp=hard+(p-p.detach()) if self.training else hard
  else:pp=p
  p1,p2=pp.unbind(-3);y1=self.op(m,p1);y2=self.op(y1,p2);msg=self.recv(self.msgnorm(torch.cat([y1.flatten(-2),y2.flatten(-2)],-1)));h=h+self.out(r+self.combine(q).sigmoid()*msg);ffact=self.ff[1](self.ff[0](self.norm2(h)))
  if self.dispatch and self.kind!='gelu':
   v=ffact.flatten(0,-2);out=self.ff[2].bias.expand(v.shape[0],-1).clone();i,j=v.nonzero(as_tuple=True);out.index_add_(0,i,v[i,j,None]*self.ff[2].weight[:,j].T);fout=out.reshape(*ffact.shape[:-1],d)
  else:fout=self.ff[2](ffact)
  h=h+fout
  if self.collect:self.records.append((ffact.detach().reshape(-1,ffact.size(-1)),h.detach().reshape(-1,d),p.detach().reshape(-1,4)))
  return h,(rs,last)
 def op(self,x,p):
  if not (self.dispatch and self.hard):return super().op(x,p)
  q=x.reshape(-1,self.h);idx=p.argmax(-1).flatten();out=torch.empty_like(q)
  for j in range(4):
   chosen=idx==j
   if bool(chosen.any()):out[chosen]=F.linear(q[chosen],self.ow[j],self.ob[j]).tanh()
  return out.reshape_as(x)
class Model(C.Model):
 def __init__(self,arm):
  super().__init__(3,'init_only',2,MATCH_FF if arm=='mac_dense' else REF_FF);self.arm=arm;kind,hard=ARMS[arm]
  for l in self.layers:
   l.__class__=Block;l.kind=kind;l.hard=hard;l.dispatch=False;l.collect=False;l.records=[];l.ff[1]=Activation(kind)
 def dispatch(self,v):
  for l in self.layers:l.dispatch=v
@torch.no_grad()
def stats(m,rows):
 for l in m.layers:l.collect=True;l.records=[]
 m.eval();m(rows[0][:16,:-1]);out=[]
 for l in m.layers:
  f,z,p=l.records[0];l.collect=False;l.records=[];s=torch.linalg.svdvals(z-z.mean(0));q=s.square()/s.square().sum().clamp_min(1e-12);rank=float((-(q*q.clamp_min(1e-12).log()).sum()).exp());act=int((f!=0).sum());out.append(dict(tokens=f.size(0),ff=f.size(1),active=act,zeros=f.numel()-act,total=f.numel(),positive=int((f>0).sum()),never_active=int((~(f!=0).any(0)).sum()),effective_rank=rank,route_entropy=float(-(p*p.clamp_min(1e-12).log()).sum(-1).mean()),route_hist=torch.bincount(p.argmax(-1),minlength=4).tolist(),selected_operator_fraction=.25 if l.hard else 1.,state_norm=float(z.norm(dim=-1).mean())))
 return out
@torch.no_grad()
def verify_stream(m,ds):
 x=ds['test'][0][:96][None];m.eval();z,s=m(x,with_state=True);a,st=m(x[:,:37],with_state=True);b,_=m(x[:,37:],state=st,with_state=True);y=torch.cat([a,b],1);return dict(n=x.numel(),argmax_diff=int((z.argmax(-1)!=y.argmax(-1)).sum()),max_abs=float((z-y).abs().max()),state_bytes=sum(v.numel()*v.element_size() for l in s for v in l))
def run(arm,seed):
 torch.set_num_threads(1);torch.manual_seed(seed);m=Model(arm);ds,t,starts,rows,excluded=C.getdata();opt=m.optimizer(.002);g=torch.Generator().manual_seed(813000+seed);steps=100;grad=[];curves=[];secs=0
 for i in range(1,steps+1):
  m.train();a=t[starts[torch.randint(len(starts),(4,),generator=g)][:,None]+torch.arange(33)];factor=min(1,i/10)*(.2+.8*.5*(1+math.cos(math.pi*i/steps)))
  for pg in opt.param_groups:pg['lr']=pg['base_lr']*factor
  start=time.perf_counter();opt.zero_grad(set_to_none=True);z=m(a[:,:-1]);loss=F.cross_entropy(z.flatten(0,1),a[:,1:].flatten());assert bool(loss.isfinite());loss.backward();gn=float(nn.utils.clip_grad_norm_(m.parameters(),1));assert math.isfinite(gn);grad.append(gn);opt.step();secs+=time.perf_counter()-start
  if i in (50,100):curves.append({'step':i,'dev_bpb':C.evaluate(m,rows['dev'])['bpb']})
 key=f'{arm}_{seed}';path=P/'fits'/f'{key}.pt';torch.save(dict(arm=arm,seed=seed,weights=m.state_dict()),path);st=stats(m,rows['dev']);kind,hard=ARMS[arm];nff=m.ff;ideal_ff=[nff if kind=='gelu' else l['active']/l['tokens'] for l in st];dense_macs=L*(FIX+OP_FULL+2*D*nff)+D*256;ideal_macs=sum(FIX+(OP_ONE if hard else OP_FULL)+D*(nff+j) for j in ideal_ff)+D*256
 r=dict(arm=arm,seed=seed,steps=steps,byte_exposures=steps*128,params=sum(p.numel() for p in m.parameters()),ff=nff,train_seconds=secs,grad_norm_mean=statistics.mean(grad),clip_fraction=sum(x>1 for x in grad)/len(grad),curve=curves,dev=C.evaluate(m,rows['dev']),test=C.evaluate(m,rows['test']),layers=st,stream=verify_stream(m,ds),executed_dense_affine_macs_per_token=dense_macs,ideal_sparse_affine_macs_per_token=ideal_macs,checkpoint_sha256=hashlib.sha256(path.read_bytes()).hexdigest());(P/'fits'/f'{key}.json').write_text(json.dumps(r));print('DONE',key,r['dev']['bpb'],[(round(l['zeros']/l['total'],4),round(l['effective_rank'],2)) for l in st],flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);jobs=[(a,s) for a in ARMS for s in C.SEEDS];random.Random(130013).shuffle(jobs);print('FF',REF_FF,MATCH_FF,flush=True)
 with concurrent.futures.ProcessPoolExecutor(max_workers=3) as pool:
  fut={pool.submit(run,*j):j for j in jobs}
  for f in concurrent.futures.as_completed(fut):
   try:f.result()
   except Exception as e:print('FAIL',fut[f],repr(e),flush=True)
