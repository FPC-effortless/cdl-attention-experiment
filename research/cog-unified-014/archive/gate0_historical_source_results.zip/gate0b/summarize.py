import json,csv,hashlib,pathlib,statistics as S,math,collections
P=pathlib.Path(__file__).parent
rows=[json.loads(p.read_text()) for p in sorted((P/'fits').glob('*.json'))];ver=json.loads((P/'verification.json').read_text());assert len(rows)==21 and len(ver)==21 and len({r['checkpoint_sha256'] for r in rows})==21
assert all(v['hash_ok'] and v['dev_equal'] and v['test_equal'] and v['activation_equal'] for v in ver)
vs={v['key']:v for v in ver};base={r['seed']:r['dev']['bpb'] for r in rows if r['arm']=='dense'};mac={r['seed']:r['dev']['bpb'] for r in rows if r['arm']=='mac_dense'};summary=[]
for arm in sorted(set(r['arm'] for r in rows)):
 a=[r for r in rows if r['arm']==arm];v=[vs[f"{arm}_{r['seed']}"] for r in a];gain=[100*(base[r['seed']]-r['dev']['bpb'])/base[r['seed']] for r in a];s=dict(arm=arm,n_fits=len(a),params=a[0]['params'],ff=a[0]['ff'],mean_dev_bpb=S.mean(r['dev']['bpb'] for r in a),mean_test_bpb=S.mean(r['test']['bpb'] for r in a),mean_gain_pct=S.mean(gain),min_gain_pct=min(gain),all_beats_mac=all(r['dev']['bpb']<=mac[r['seed']] for r in a),train_dense_macs=a[0]['executed_dense_affine_macs_per_token'],ideal_sparse_macs=S.mean(r['ideal_sparse_affine_macs_per_token'] for r in a),mean_clip_fraction=S.mean(r['clip_fraction'] for r in a),ff_zeros_l1=S.mean(r['layers'][0]['zeros']/r['layers'][0]['total'] for r in a),ff_zeros_l2=S.mean(r['layers'][1]['zeros']/r['layers'][1]['total'] for r in a),rank_l1=S.mean(r['layers'][0]['effective_rank'] for r in a),rank_l2=S.mean(r['layers'][1]['effective_rank'] for r in a),mean_rank=S.mean(l['effective_rank'] for r in a for l in r['layers']),mean_inactive_l2=S.mean(r['layers'][1]['never_active']/r['ff'] for r in a),dispatch_flips=sum(x['dispatch']['argmax_diff'] for x in v),dispatch_n=sum(x['dispatch']['n'] for x in v),dispatch_max_abs=max(x['dispatch']['max_abs'] for x in v),stream_flips=sum(x['dispatch_stream']['argmax_diff'] for x in v),stream_n=sum(x['dispatch_stream']['n'] for x in v))
 for j,L in enumerate((1,32,128)):
  for k in ('masked_ms','dispatch_ms','ratio'):s[f'{L}_{k}']=S.mean(x['timing'][j][k] for x in v)
 s['gate_pass']=all(.85<=l['zeros']/l['total']<=.95 for r in a for l in r['layers']) and s['rank_l1']>50 and s['rank_l2']>50 and min(gain)>=1 and s['all_beats_mac'] and s['stream_flips']==0
 summary.append(s)
with (P/'summary.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
prec=json.load(open(P/'precision.json'));pp={}
for panel in ('original','validation'):
 pp[panel]={}
 for name in prec[0]['panels'][panel]:
  v=[r['panels'][panel][name] for r in prec];pp[panel][name]={**{k:max(x[k] for x in v) for k in ('mean_kl','max_kl','relative_l2','max_token_relative_l2','relative_peak','max_abs')},'n':sum(x['n'] for x in v),'flips':sum(x['flips'] for x in v)}
tail=json.load(open(P/'precision_tail.json'));tp={}
for stage in tail[0]['stages']:
 v=[r['stages'][stage] for r in tail];tp[stage]={**{k:max(x[k] for x in v) for k in ('mean_kl','max_kl','relative_l2','max_token_relative_l2','relative_peak')},'n':sum(x['n'] for x in v),'flips':sum(x['flips'] for x in v)}
reset=json.load(open(P/'hold_reset.json'));hr={}
for o in ('all','hold_only'):
 p=[x for x in reset['panels'] if x['objective']==o];hr[o]={**{k:sum(x[k] for x in p) for k in ('hold_n','hold_exact','reset_n','reset_bits_exact','hold_proposal_nonzero','hold_gate_logit_nonzero')},'gate_grad_max_error':max(x['max_differences']['gate_grad'] for x in p)}
hr['signed_zero_stress']=reset['signed_zero_stress']
agg=dict(new_fits=len(rows),prior_checkpoints=6,optimizer_updates=sum(r['steps'] for r in rows),training_byte_exposures=sum(r['byte_exposures'] for r in rows),checkpoint_replays=len(ver),stream_n=sum(r['stream']['n'] for r in rows),stream_flips=sum(r['stream']['argmax_diff'] for r in rows),dispatch_n=sum(v['dispatch']['n'] for v in ver),dispatch_flips=sum(v['dispatch']['argmax_diff'] for v in ver),dispatch_stream_flips=sum(v['dispatch_stream']['argmax_diff'] for v in ver),sparse_summary=summary,precision=pp,precision_tail=tp,hold_reset=hr,official_campaign_credit=0,full_gate0='blocked_GPU_and_mixed_precision_tail',integration='denied')
(P/'aggregate.json').write_text(json.dumps(agg,indent=2));print({k:v for k,v in agg.items() if k not in ('sparse_summary','precision','precision_tail','hold_reset')});print('hold/reset',hr)
for x in summary:print(x['arm'],round(x['mean_dev_bpb'],6),x['gate_pass'],'dispatch flips',x['dispatch_flips'], 'timing',[(n,round(x[f'{n}_masked_ms'],3),round(x[f'{n}_dispatch_ms'],3),round(x[f'{n}_ratio'],3)) for n in (1,32,128)])
