import math,time,json,argparse,pathlib,hashlib,random,statistics,os,traceback
import torch
from torch import nn
import torch.nn.functional as F
from scan import division,associative
P=pathlib.Path(__file__).parent
DIMS={1:192,3:320,10:576}; TARGETS={1:1000000,3:3000000,10:10000000}; T=32; BATCH=4; SEEDS=[173,271,907]; DATA=None
class Block(nn.Module):
 def __init__(self,d,k,h,ff,L,policy):
  super().__init__();self.k=k;self.h=h;self.d=d;self.policy=policy;self.L=L;self.method='assoc';self.collect=False;self.stats=[];m=k*h
  self.norm=nn.LayerNorm(d);self.inp=nn.Linear(d,2*d);self.pub=nn.Linear(d,m);self.route=nn.Linear(d,2*k+1);self.select=nn.Linear(d,2*k*4);self.ow=nn.Parameter(torch.empty(4,h,h));self.ob=nn.Parameter(torch.zeros(4,h));nn.init.uniform_(self.ow,-1/math.sqrt(h),1/math.sqrt(h));self.msgnorm=nn.LayerNorm(2*m);self.recv=nn.Linear(2*m,d);self.combine=nn.Linear(d,d);self.out=nn.Linear(d,d);self.norm2=nn.LayerNorm(d);self.ff=nn.Sequential(nn.Linear(d,ff),nn.GELU(),nn.Linear(ff,d))
 def op(self,x,p):return ((torch.einsum('...gh,koh->...gko',x,self.ow)+self.ob).tanh()*p[...,None]).sum(-2)
 def forward(self,h,state=None):
  k,d=self.k,self.d;scan=associative if self.method=='assoc' else division;u=self.norm(h);z,a=self.inp(u).chunk(2,-1);a=.5+.49*a.sigmoid();a=a.unflatten(-1,(d//2,2)).mean(-1,keepdim=True).expand(*a.shape[:-1],d//2,2).flatten(-2);r,rs=scan(z.tanh(),a,None if state is None else state[0]);q=r+u
  v=self.pub(q).tanh().unflatten(-1,(k,self.h));w,rp,g=self.route(q).split([k,k,1],-1);w=w.sigmoid();rp=rp.sigmoid();gate=.4*g.sigmoid()*w;ms,last=scan(v,1-gate[...,None],None if state is None else state[1]);m=ms*rp[...,None]*2
  p=(self.select(q).unflatten(-1,(2,k,4))).softmax(-1);p1,p2=p.unbind(-3);y1=self.op(m,p1);y2=self.op(y1,p2);msg=self.recv(self.msgnorm(torch.cat([y1.flatten(-2),y2.flatten(-2)],-1)));fac=1/math.sqrt(self.L) if self.policy=='scaled' else 1.;h=h+fac*self.out(r+self.combine(q).sigmoid()*msg);ffact=self.ff[1](self.ff[0](self.norm2(h)));h=h+fac*self.ff[2](ffact)
  if self.collect:
   with torch.no_grad():self.stats.append(dict(n=int(p.numel()),active=int((p>.1).sum()),entropy=float(-(p*p.clamp_min(1e-12).log()).sum(-1).mean()),state_rms=float(r.square().mean().sqrt()),message_rms=float(ms.square().mean().sqrt()),state_peak=float(r.abs().max()),message_peak=float(ms.abs().max()),ff_positive=int((ffact>0).sum()),ff_n=ffact.numel(),ff_exact_zero=int((ffact==0).sum())))
  return h,(rs,last)
class Model(nn.Module):
 def __init__(self,size,policy,L=2):
  super().__init__();d=DIMS[size];k=4;h=d//4;target=TARGETS[size];self.size=size;self.d=d;self.L=L;self.policy=policy
  tmp=Block(d,k,h,1,L,policy);base=L*sum(p.numel() for p in tmp.parameters())+256*d+2*d;ff=max(16,round(1+(target-base)/(L*(2*d+1))));self.ff=ff
  self.emb=nn.Embedding(256,d);self.layers=nn.ModuleList([Block(d,k,h,ff,L,policy) for _ in range(L)]);self.norm=nn.LayerNorm(d);nn.init.normal_(self.emb.weight,std=.02)
  if policy=='scaled':
   for m in self.modules():
    if isinstance(m,nn.Linear):nn.init.normal_(m.weight,std=1/math.sqrt(m.in_features));nn.init.zeros_(m.bias)
    if isinstance(m,Block):nn.init.normal_(m.ow,std=1/math.sqrt(m.h));nn.init.zeros_(m.ob)
 def forward(self,x,state=None,with_state=False):
  h=self.emb(x);ss=[]
  for i,l in enumerate(self.layers):h,s=l(h,None if state is None else state[i]);ss.append(s)
  z=F.linear(self.norm(h),self.emb.weight)*(math.sqrt(192/self.d) if self.policy=='scaled' else 1.)
  return (z,ss) if with_state else z
 def optimizer(self,lr):
  normal=[];hidden=[]
  for name,p in self.named_parameters():
   if self.policy=='scaled' and name.startswith('layers.') and p.ndim>=2:hidden.append(p)
   else:normal.append(p)
  return torch.optim.AdamW([{'params':normal,'lr':lr,'base_lr':lr}]+([{'params':hidden,'lr':lr*192/self.d,'base_lr':lr*192/self.d}] if hidden else []),weight_decay=.01)
def getdata():
 global DATA
 if DATA is not None:return DATA
 ds={k:[torch.tensor(list(d['text'].encode()),dtype=torch.long) for d in v] for k,v in json.load(open(P/'corpus.json')).items()};tr=[bytes(d.tolist()) for d in ds['train']];t=torch.cat(ds['train']);starts=[];off=0
 for d in ds['train']:starts.append(torch.arange(off,off+max(0,len(d)-T)));off+=len(d)
 ev={};excluded={}
 for k in ('dev','test'):
  rows=[];ids=[];exc=0
  for j,d in enumerate(ds[k]):
   for i in torch.linspace(0,len(d)-T-1,min(6,(len(d)-1)//T)).long().unique():
    a=d[i:i+T+1];b=bytes(a.tolist())
    if any(b in doc for doc in tr):exc+=1;continue
    rows.append(a);ids.append(j)
  ev[k]=(torch.stack(rows),ids);excluded[k]=exc
 DATA=(ds,t,torch.cat(starts),ev,excluded);return DATA
@torch.no_grad()
def evaluate(m,rows):
 m.eval();x,ids=rows;losses=[];n=0;ok=0
 for a in x.split(16):
  z=m(a[:,:-1]);y=a[:,1:];losses.extend(F.cross_entropy(z.transpose(1,2),y,reduction='none').sum(-1).tolist());ok+=(z.argmax(-1)==y).sum().item();n+=y.numel()
 return dict(bpb=sum(losses)/n/math.log(2),accuracy=ok/n,n=n,row_nll=losses,doc_ids=ids)
@torch.no_grad()
def diagnostics(m,ds,dev):
 m.eval();x=ds['test'][0][:96][None];z,s=m(x,with_state=True);a,st=m(x[:,:37],with_state=True);b,_=m(x[:,37:],state=st,with_state=True);y=torch.cat([a,b],1)
 for l in m.layers:l.method='division'
 d=m(x)
 for l in m.layers:l.method='assoc';l.collect=True;l.stats=[]
 evaluate(m,dev)
 out=[]
 for l in m.layers:
  q=l.stats;l.collect=False;out.append(dict(active_operator_fraction=sum(x['active'] for x in q)/sum(x['n'] for x in q),operator_entropy=statistics.mean(x['entropy'] for x in q),state_rms=statistics.mean(x['state_rms'] for x in q),message_rms=statistics.mean(x['message_rms'] for x in q),state_peak=max(x['state_peak'] for x in q),message_peak=max(x['message_peak'] for x in q),ff_positive_fraction=sum(x['ff_positive'] for x in q)/sum(x['ff_n'] for x in q),ff_exact_zero_fraction=sum(x['ff_exact_zero'] for x in q)/sum(x['ff_n'] for x in q)))
 w=m.emb.weight;sv=torch.linalg.svdvals(w);p=sv.square()/sv.square().sum();er=float((-(p*p.clamp_min(1e-12).log()).sum()).exp())
 return dict(state_bytes=sum(v.numel()*v.element_size() for l in s for v in l),split_max=float((z-y).abs().max()),split_disagree=int((z.argmax(-1)!=y.argmax(-1)).sum()),scan_max=float((z-d).abs().max()),scan_disagree=int((z.argmax(-1)!=d.argmax(-1)).sum()),n=x.numel(),embedding_effective_rank=er,embedding_rank=int(torch.linalg.matrix_rank(w)),layer=out)
def gradstats(m):
 out=[]
 for l in m.layers:
  pp=[p.grad for p in l.parameters() if p.grad is not None];out.append(float(torch.sqrt(sum(p.square().sum() for p in pp)/sum(p.numel() for p in pp))))
 return out

def run(size,policy,lr,seed,steps=100,L=2):
 torch.set_num_threads(1);torch.manual_seed(seed);ds,t,starts,rows,excluded=getdata();m=Model(size,policy,L);params=sum(p.numel() for p in m.parameters());opt=m.optimizer(lr);g=torch.Generator().manual_seed(813000+seed);curve=[];norms=[];sec=0.;records=[];key=f'{size}M_{L}L_{policy}_{lr:.4f}_{seed}_{steps}';status='completed'
 for i in range(1,steps+1):
  m.train();a=t[starts[torch.randint(len(starts),(BATCH,),generator=g)][:,None]+torch.arange(T+1)];x,y=a[:,:-1],a[:,1:];factor=min(1,i/10)*(.2+.8*.5*(1+math.cos(math.pi*i/steps)))
  for pg in opt.param_groups:pg['lr']=pg['base_lr']*factor
  start=time.perf_counter();opt.zero_grad(set_to_none=True);z=m(x);loss=F.cross_entropy(z.flatten(0,1),y.flatten())
  if not torch.isfinite(loss):status='nonfinite_loss';break
  loss.backward();norm=float(nn.utils.clip_grad_norm_(m.parameters(),1.));norms.append(norm)
  if not math.isfinite(norm):status='nonfinite_grad';break
  if i in [1,10,steps//2,steps]:
   # The gradient RMS is measured after global clip (explicitly labeled).
   before=[l.inp.weight.detach().clone() for l in m.layers];gstats=gradstats(m)
  opt.step();sec+=time.perf_counter()-start
  if i in [1,10,steps//2,steps]:
   records.append(dict(step=i,unclipped_grad_norm=norm,clipped_layer_grad_rms=gstats,relative_inp_update=[float((l.inp.weight.detach()-b).norm()/b.norm().clamp_min(1e-12)) for l,b in zip(m.layers,before)],loss=float(loss.detach())))
  if i in [steps//2,steps]:
   v=evaluate(m,rows['dev']);curve.append(dict(step=i,bpb=v['bpb']));print(key,i,v['bpb'],flush=True)
 if status!='completed':
  (P/'fits'/f'{key}.failed.json').write_text(json.dumps(dict(key=key,status=status,steps_completed=i-1)));print('FAIL',key,status,flush=True);return
 path=P/'fits'/f'{key}.pt';torch.save(dict(weights=m.state_dict(),size=size,policy=policy,lr=lr,seed=seed,steps=steps,L=L),path)
 r=dict(key=key,size=size,depth=L,policy=policy,lr=lr,seed=seed,steps=steps,width=m.d,ff=m.ff,params=params,byte_exposures=steps*BATCH*T,train_seconds=sec,curve=curve,dev=evaluate(m,rows['dev']),test=evaluate(m,rows['test']),excluded=excluded,unclipped_grad_norm=norms,mean_grad_norm=statistics.mean(norms),grad_norm_stdev=statistics.stdev(norms),clip_fraction=sum(n>1 for n in norms)/len(norms),diagnostic_updates=records,diagnostics=diagnostics(m,ds,rows['dev']),checkpoint_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
 (P/'fits'/f'{key}.json').write_text(json.dumps(r));print('DONE',key,params,r['dev']['bpb'],flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('size',type=int);p.add_argument('policy',choices=['default','scaled']);p.add_argument('lr',type=float);p.add_argument('seed',type=int);p.add_argument('--steps',type=int,default=100);p.add_argument('--depth',type=int,default=2);a=p.parse_args();run(a.size,a.policy,a.lr,a.seed,a.steps,a.depth)
