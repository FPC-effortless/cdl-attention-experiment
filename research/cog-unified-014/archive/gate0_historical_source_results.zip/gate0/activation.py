import pathlib,json,torch,statistics
import calibration as C
from verify import load
P=pathlib.Path(__file__).parent
@torch.no_grad()
def main():
 torch.set_num_threads(1);rows=[json.loads(f.read_text()) for f in (P/'fits').glob('*.json') if not f.name.endswith('.failed.json')];sel=[]
 for size in [1,3]:
  for policy in ['default','scaled']:
   groups={lr:[r for r in rows if r['size']==size and r['depth']==2 and r['policy']==policy and r['lr']==lr and r.get('clip_threshold',1)==1] for lr in [.0005,.001,.002,.004,.008]};best=min((lr for lr,r in groups.items() if len(r)==3),key=lambda lr:statistics.mean(r['dev']['bpb'] for r in groups[lr]));sel.extend(groups[best])
 sel.extend(r for r in rows if r['size']==3 and r['depth']==2 and r['policy']=='init_only' and r['lr']==.002);_,_,_,ev,_=C.getdata();x=ev['dev'][0][:16,:-1];out=[]
 for r in sel:
  m=load(r,P/'fits'/f"{r['key']}.pt");m.eval();activations=[{} for l in m.layers];hs=[]
  for i,l in enumerate(m.layers):
   def ff_hook(mod,inp,o,i=i):activations[i]['ff']=o.detach().flatten(0,1)
   def layer_hook(mod,inp,o,i=i):activations[i]['layer']=o[0].detach().flatten(0,1)
   hs.extend([l.ff[1].register_forward_hook(ff_hook),l.register_forward_hook(layer_hook)])
  m(x)
  for h in hs:h.remove()
  aa=[]
  for a in activations:
   f=a['ff'];z=a['layer'];v=torch.linalg.svdvals(z-z.mean(0));p=v.square()/v.square().sum().clamp_min(1e-12);aa.append(dict(ff_neurons=f.shape[1],tokens=f.shape[0],ff_positive=float((f>0).float().mean()),ff_zero=float((f==0).float().mean()),never_positive=int((~(f>0).any(0)).sum()),never_nonzero=int((~(f!=0).any(0)).sum()),effective_rank=float((-(p*p.clamp_min(1e-12).log()).sum()).exp()),max_possible_rank=min(z.shape[0]-1,z.shape[1])))
  out.append(dict(key=r['key'],size=r['size'],policy=r['policy'],seed=r['seed'],lr=r['lr'],layers=aa));print(r['key'],aa,flush=True)
 (P/'activation.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__':main()
