import torch,math,json,pathlib,statistics,time
from torch.nn import functional as F
import calibration as C
from verify import load
from scan import associative,sequential,division
from hierarchical import hierarchical
P=pathlib.Path(__file__).parent

def scan_fp32(fn):return lambda z,a,s=None:fn(z.float(),a.float(),None if s is None else s.float())
METHODS={'serial':scan_fp32(sequential),'assoc':scan_fp32(associative),'hier':scan_fp32(hierarchical),'division':scan_fp32(division)}
def select():
 rows=[json.loads(f.read_text()) for f in (P/'fits').glob('*.json') if not f.name.endswith('.failed.json')];sel=[]
 for policy in ['default','scaled']:
  groups={lr:[r for r in rows if r['size']==3 and r['depth']==2 and r['policy']==policy and r['lr']==lr and r.get('clip_threshold',1)==1] for lr in [.0005,.001,.002,.004,.008]};best=min((lr for lr,r in groups.items() if len(r)==3),key=lambda lr:statistics.mean(r['dev']['bpb'] for r in groups[lr]));sel.extend(groups[best])
 return sel
@torch.no_grad()
def test(m,method,mode,rows):
 C.associative=METHODS[method];m.eval();x,ids=rows;ls=0.;n=ok=0
 with torch.autocast('cpu',dtype=torch.bfloat16,enabled=(mode=='bf16')):
  for a in x.split(16):
   z=m(a[:,:-1]).float();y=a[:,1:];ls+=F.cross_entropy(z.flatten(0,1),y.flatten(),reduction='sum').item();n+=y.numel();ok+=(z.argmax(-1)==y).sum().item()
 return {'bpb':ls/n/math.log(2),'correct':ok,'n':n}
@torch.no_grad()
def logits(m,method,mode,x):
 C.associative=METHODS[method];m.eval()
 with torch.autocast('cpu',dtype=torch.bfloat16,enabled=(mode=='bf16')):
  z,s=m(x,with_state=True)
 return z.float(),[v.float() for l in s for v in l]
def err(x,y):return {'max_abs':float((x-y).abs().max()),'relative_l2':float((x-y).norm()/y.norm().clamp_min(1e-8)),'relative_peak':float((x-y).abs().max()/y.abs().max().clamp_min(1e-8))}
def main():
 torch.set_num_threads(1);ds,_,_,rows,_=C.getdata();x=ds['dev'][0][:128][None];batch=rows['dev'][0][:2];records=[]
 for r in select():
  m=load(r,P/'fits'/f"{r['key']}.pt");rs={'key':r['key'],'policy':r['policy'],'lr':r['lr'],'seed':r['seed'],'fp32':{},'bf16':{},'gradient':{},'timing':[]}
  ref={};gs={}
  for mode in ['fp32','bf16']:
   try:
    z0,s0=logits(m,'serial',mode,x);ref[mode]=z0
    for method in ['serial','assoc','hier']:
     z,s=logits(m,method,mode,x);rs[mode][method]=dict(logits=err(z,z0),state=[err(a,b) for a,b in zip(s,s0)],argmax_diff=int((z.argmax(-1)!=z0.argmax(-1)).sum()),dev=test(m,method,mode,rows['dev']),finite=bool(z.isfinite().all()))
   except Exception as e:rs[mode]['error']=repr(e)
  if 'bf16' in ref:rs['bf16_vs_fp32']=dict(logits=err(ref['bf16'],ref['fp32']),argmax_diff=int((ref['bf16'].argmax(-1)!=ref['fp32'].argmax(-1)).sum()))
  for method in ['serial','assoc','hier','division']:
   C.associative=METHODS[method];m.eval();m.zero_grad(set_to_none=True);z=m(batch[:,:-1]);loss=F.cross_entropy(z.flatten(0,1),batch[:,1:].flatten());gs[method]=torch.cat([g.detach().flatten() for g in torch.autograd.grad(loss,list(m.parameters()))]);rs['gradient'][method]=dict(loss=float(loss.detach()),**err(gs[method],gs['serial']))
  del gs
  with torch.inference_mode():
   for L in [1,32,128,256]:
    q=ds['dev'][0][:L][None];# docs length >=256; use identical input
    times={method:[] for method in ['division','assoc','hier']}
    for method in times:
     C.associative=METHODS[method]
     for _ in range(3):m(q)
    for j in range(5):
     methods=list(times);methods=methods[j%3:]+methods[:j%3]
     for method in methods:
      C.associative=METHODS[method];start=time.perf_counter();m(q);times[method].append(time.perf_counter()-start)
    med={k:statistics.median(v) for k,v in times.items()};rs['timing'].append(dict(L=q.shape[1],seconds=med,tokens_per_second={k:q.shape[1]/v for k,v in med.items()},ratio_to_division={k:med['division']/v for k,v in med.items()}))
  records.append(rs);(P/'whole_model.json').write_text(json.dumps(records,indent=2));print(r['key'],'fp32',rs['fp32'].get('hier'),'bf16',rs['bf16'].get('hier'),'grad',rs['gradient']['hier'],'timing',rs['timing'][-1],flush=True)
if __name__=='__main__':main()
