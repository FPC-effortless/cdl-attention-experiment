import torch,json,pathlib
from scan import associative,sequential
from hierarchical import hierarchical
P=pathlib.Path(__file__).parent
if __name__=='__main__':
 torch.set_num_threads(1);out=[]
 for dtype in [torch.float32,torch.float16,torch.bfloat16]:
  for d in [192,320,576]:
   for L in [32,256,1024]:
    for seed in [173,271]:
     g=torch.Generator().manual_seed(seed+d+L);z=(2*torch.rand(2,L,d,generator=g)-1).to(dtype).float();a=(.5+.49*torch.rand(2,L,d,generator=g)).to(dtype).float();s=(2*torch.rand(2,d,generator=g)-1).to(dtype).float();u=torch.rand(2,L,d,generator=g);hold=u<.25;reset=u>.85;a[hold]=1;a[reset]=0;z2=z.clone();z2[hold]=-z2[hold];r={'dtype':str(dtype),'d':d,'L':L,'seed':seed,'hold_n':int(hold.sum()),'reset_n':int(reset.sum())}
     for name,fn in [('serial',sequential),('assoc',associative),('hier',hierarchical)]:
      y,_=fn(z,a,s);old=torch.cat([s[:,None],y[:,:-1]],1);yy,_=fn(z2,a,s);r[name]={'hold_exact':int((y[hold]==old[hold]).sum()),'reset_exact':int((y[reset]==z[reset]).sum()),'hold_max':float((y[hold]-old[hold]).abs().max()),'reset_max':float((y[reset]-z[reset]).abs().max()),'held_value_perturb_max':float((y-yy).abs().max()),'perturb_exact':bool(torch.equal(y,yy))}
     out.append(r)
 (P/'hold_checks.json').write_text(json.dumps(out,indent=2));print('panels',len(out),'hold',sum(x['hold_n'] for x in out),'reset',sum(x['reset_n'] for x in out))
 for name in ['serial','assoc','hier']:print(name,'hold_mismatch',sum(x['hold_n']-x[name]['hold_exact'] for x in out),'reset_mismatch',sum(x['reset_n']-x[name]['reset_exact'] for x in out),'hold_max',max(x[name]['hold_max'] for x in out),'perturb_max',max(x[name]['held_value_perturb_max'] for x in out))
