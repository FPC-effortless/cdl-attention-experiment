import pathlib,json,zipfile,hashlib,csv,concurrent.futures
P=pathlib.Path(__file__).parent;ROOT=P.parent
rows=[json.loads(f.read_text()) for f in sorted((P/'fits').glob('*.json')) if not f.name.endswith('.failed.json')];groups={k:[] for k in ['1M','3M_lr','3M_ablation','depth']};manifest=[]
for r in rows:
 k='depth' if r['depth']==4 else '1M' if r['size']==1 else '3M_lr' if r['policy'] in ['default','scaled'] and r.get('clip_threshold',1)==1 else '3M_ablation';p=P/'fits'/f"{r['key']}.pt";h=hashlib.sha256(p.read_bytes()).hexdigest();assert h==r['checkpoint_sha256'];groups[k].append(p);manifest.append(dict(key=r['key'],archive=f'cog_gate0_013_{k}_checkpoints.zip',file=str(p.relative_to(P)),bytes=p.stat().st_size,sha256=h))
with (P/'checkpoint_manifest.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(manifest[0]));w.writeheader();w.writerows(manifest)
def bundle(k,files):
 z=ROOT/f'cog_gate0_013_{k}_checkpoints.zip'
 with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_STORED) as f:
  for p in files:f.write(p,p.relative_to(P))
  f.write(P/'checkpoint_manifest.csv','checkpoint_manifest.csv')
 with zipfile.ZipFile(z) as f:assert f.testzip() is None
 return dict(file=z.name,checkpoints=len(files),bytes=z.stat().st_size,sha256=hashlib.sha256(z.read_bytes()).hexdigest())
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:
 a=list(p.map(lambda kv:bundle(*kv),groups.items()))
(P/'checkpoint_archives.json').write_text(json.dumps(a,indent=2));print(a)
