import torch,hashlib,json,pathlib,concurrent.futures,statistics,traceback
import calibration as C
from scan import associative,sequential,division
from hierarchical import hierarchical
P=pathlib.Path(__file__).parent

def load(r,p):
 ck=torch.load(p,weights_only=True);m=C.Model(ck['size'],ck['policy'],ck['L'],ck.get('fixed_ff'));m.load_state_dict(ck['weights']);return m

def replay(f):
 torch.set_num_threads(1);r=json.loads(f.read_text());p=f.with_suffix('.pt');m=load(r,p);ds,_,_,ev,_=C.getdata();d=C.evaluate(m,ev['dev']);t=C.evaluate(m,ev['test']);return dict(key=r['key'],hash_ok=hashlib.sha256(p.read_bytes()).hexdigest()==r['checkpoint_sha256'],dev_equal=d==r['dev'],test_equal=t==r['test'],dev_bpb_delta=d['bpb']-r['dev']['bpb'],test_bpb_delta=t['bpb']-r['test']['bpb'])
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);out=[];jobs=sorted(p for p in (P/'fits').glob('*.json') if not p.name.endswith('.failed.json'))
 with concurrent.futures.ProcessPoolExecutor(max_workers=3) as pool:
  fut={pool.submit(replay,p):p for p in jobs}
  for f in concurrent.futures.as_completed(fut):
   try:r=f.result();out.append(r);print(r,flush=True)
   except Exception as e:print('FAIL',fut[f],repr(e),traceback.format_exc(),flush=True)
   (P/'verification.json').write_text(json.dumps(out,indent=2))
