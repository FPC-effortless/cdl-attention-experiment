import torch,concurrent.futures,random,sys,json,pathlib,traceback
from train import run,SEEDS,P
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 jobs=[(size,policy,lr,seed,100,2) for size in [3,1] for policy in ['default','scaled'] for lr in [.0005,.001,.002] for seed in SEEDS];random.Random(813111).shuffle(jobs);jobs.sort(key=lambda x:0 if x[0]==3 else 1)
 (P/'jobs.json').write_text(json.dumps(jobs))
 with concurrent.futures.ProcessPoolExecutor(max_workers=3) as pool:
  fut={pool.submit(run,*j):j for j in jobs}
  for f in concurrent.futures.as_completed(fut):
   try:f.result()
   except Exception as e:print('FAIL',fut[f],repr(e),traceback.format_exc(),flush=True)
