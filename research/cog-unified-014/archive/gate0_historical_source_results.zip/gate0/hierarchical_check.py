import torch,json,pathlib,statistics,time
from scan import division,associative,sequential
from numerical import metric
from hierarchical import hierarchical
P=pathlib.Path(__file__).parent

def audit():
 torch.set_num_threads(1);g=torch.Generator().manual_seed(813001);res=[];gr=[];times=[]
 for dtype in [torch.float32,torch.float16,torch.bfloat16]:
  for d in [192,320,576]:
   for L in [32,256,1024]:
    for case in ['random','half_positive','half_negative','near_unit','hold_reset']:
     if case=='random':z=2*torch.rand(2,L,d,generator=g)-1;a=.5+.499*torch.rand(2,L,d,generator=g)
     elif case.startswith('half'):z=torch.full((2,L,d),1. if case=='half_positive' else -1.);a=torch.full_like(z,.5)
     elif case=='near_unit':z=2*torch.rand(2,L,d,generator=g)-1;a=torch.full_like(z,.999)
     else:z=2*torch.rand(2,L,d,generator=g)-1;a=(.5+.499*torch.rand(2,L,d,generator=g));a[:,::7]=1.;a[:,::13]=0.
     z,a=z.to(dtype),a.to(dtype);s=(2*torch.rand(2,d,generator=g)-1).to(dtype);y,_=sequential(z.double(),a.double(),s.double());bound=max(float(z.abs().max()),float(s.abs().max()));v,st=hierarchical(z,a,s,accum=torch.float32);v1,s1=hierarchical(z[:,:L//3],a[:,:L//3],s,accum=torch.float32);v2,s2=hierarchical(z[:,L//3:],a[:,L//3:],s1,accum=torch.float32);res.append(dict(dtype=str(dtype),d=d,L=L,case=case,**metric(v,y,bound),split_max=float((torch.cat([v1,v2],1)-v).abs().max())))
 # Verify gradient with both full-sized gates and broadcast gates used in message state.
 for d in [192,320,576]:
  for L in [32,128]:
   for broad in [False,True]:
    z=2*torch.rand(2,L,d,generator=g)-1;a=.5+.49*torch.rand(2,L,1 if broad else d,generator=g);s=2*torch.rand(2,d,generator=g)-1;w=torch.randn(z.shape,generator=g);gs={}
    for k,fn in [('seq',sequential),('hier',hierarchical)]:
     q=[x.clone().requires_grad_() for x in [z,a,s]];v,_=fn(*q);gs[k]=torch.autograd.grad((v*w).mean(),q)
    gr.append(dict(d=d,L=L,broadcast=broad,errors=[float((x-y).abs().max()) for x,y in zip(gs['hier'],gs['seq'])]))
 (P/'hierarchical_numerics.json').write_text(json.dumps(dict(cases=res,gradients=gr),indent=2));print('cases',len(res),'finite',sum(r['finite'] for r in res),'max_rel_peak',max(r['relative_peak'] for r in res),'max_grad',max(max(r['errors']) for r in gr),'max_split',max(r['split_max'] for r in res))

def timing():
 torch.set_num_threads(1);g=torch.Generator().manual_seed(813222);times=[]
 for d in [192,320,576]:
  for L in [32,256,1024]:
   z=2*torch.rand(2,L,d,generator=g)-1;a=.5+.49*torch.rand(2,L,d,generator=g);s=torch.zeros(2,d);methods={'division':division,'assoc':associative,'hierarchical':hierarchical};t={k:[] for k in methods}
   with torch.inference_mode():
    for fn in methods.values():
     for _ in range(3):fn(z,a,s)
    for i in range(9):
     keys=list(methods);keys=keys[i%3:]+keys[:i%3]
     for name in keys:
      start=time.perf_counter();methods[name](z,a,s);t[name].append(time.perf_counter()-start)
   med={k:statistics.median(v) for k,v in t.items()};times.append(dict(d=d,L=L,median_seconds=med,relative_throughput={k:med['division']/v for k,v in med.items()}))
 (P/'hierarchical_timing.json').write_text(json.dumps(times,indent=2));print('timing',[(r['d'],r['L'],r['relative_throughput']) for r in times])
if __name__=='__main__':
 import sys
 audit() if len(sys.argv)==1 else timing()
