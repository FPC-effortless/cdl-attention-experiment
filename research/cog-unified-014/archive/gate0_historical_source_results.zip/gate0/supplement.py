import torch,concurrent.futures,random,json,statistics,traceback
from calibration import run,SEEDS,P

def launch(jobs):
 with concurrent.futures.ProcessPoolExecutor(max_workers=3) as pool:
  f={pool.submit(run,*j):j for j in jobs}
  for v in concurrent.futures.as_completed(f):
   try:v.result()
   except Exception as e:print('FAIL',f[v],repr(e),traceback.format_exc(),flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 jobs=[(size,policy,lr,seed,100,2,1.,None) for size in [3,1] for policy in ['default','scaled'] for lr in [.004,.008] for seed in SEEDS]+[(3,policy,.002,seed,100,2,1.,None) for policy in ['init_only','lr_only','resid_only','readout_only'] for seed in SEEDS]+[(3,policy,.002,seed,100,2,10.,None) for policy in ['default','scaled'] for seed in SEEDS];random.Random(813222).shuffle(jobs);jobs.sort(key=lambda x:0 if x[0]==3 else 1);(P/'supplement_jobs.json').write_text(json.dumps(jobs));launch(jobs)
 rows=[json.loads(p.read_text()) for p in (P/'fits').glob('*.json') if not p.name.endswith('.failed.json')];lrs=[.0005,.001,.002,.004,.008];depth=[];choices={}
 for policy in ['default','scaled']:
  data={lr:[r for r in rows if r['size']==3 and r['depth']==2 and r['policy']==policy and r['lr']==lr and r.get('clip_threshold',1)==1] for lr in lrs};valid={lr:statistics.mean(r['dev']['bpb'] for r in a) for lr,a in data.items() if len(a)==3};best=min(valid,key=valid.get);i=lrs.index(best);neighbor=lrs[i-1] if i>0 else lrs[i+1];ff=data[best][0]['ff'];choices[policy]={'best':best,'neighbor':neighbor,'ff':ff,'all':valid};depth.extend((3,policy,lr,seed,100,4,1.,ff) for lr in [best,neighbor] for seed in SEEDS)
 (P/'depth_jobs.json').write_text(json.dumps({'choices':choices,'jobs':depth},indent=2));launch(depth)
