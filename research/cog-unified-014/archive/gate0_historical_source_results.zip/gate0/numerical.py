import torch,json,math,time,statistics,pathlib
from scan import sequential,division,associative
P=pathlib.Path(__file__).parent
def metric(x,y,bound):
 ok=bool(x.isfinite().all());return dict(finite=ok,max_abs=float((x.double()-y).abs().max()) if ok else None,relative_peak=float((x.double()-y).abs().max()/y.abs().max().clamp_min(1e-8)) if ok else None,relative_l2=float((x.double()-y).norm()/y.norm().clamp_min(1e-8)) if ok else None,peak=float(x.abs().max()) if ok else None,bound_excess=max(0.,float(x.abs().max())-bound) if ok else None)
def main():
 torch.set_num_threads(1);g=torch.Generator().manual_seed(813001);res=[];gr=[];times=[]
 for dtype in [torch.float32,torch.float16,torch.bfloat16]:
  for d in [192,320,576]:
   for L in [32,256,1024]:
    for case in ['random','half_positive','half_negative','near_unit','hold_reset']:
     if case=='random':z=2*torch.rand(2,L,d,generator=g)-1;a=.5+.499*torch.rand(2,L,d,generator=g)
     elif case.startswith('half'):z=torch.full((2,L,d),1. if case=='half_positive' else -1.);a=torch.full_like(z,.5)
     elif case=='near_unit':z=2*torch.rand(2,L,d,generator=g)-1;a=torch.full_like(z,.999)
     else:z=2*torch.rand(2,L,d,generator=g)-1;a=(.5+.499*torch.rand(2,L,d,generator=g));a[:,::7]=1.;a[:,::13]=0.
     z,a=z.to(dtype),a.to(dtype);s=(2*torch.rand(2,d,generator=g)-1).to(dtype);y,_=sequential(z.double(),a.double(),s.double());bound=max(float(z.abs().max()),float(s.abs().max()));r=dict(dtype=str(dtype),d=d,L=L,case=case)
     for name,fn in [('sequential',sequential),('division',division),('assoc_native',associative),('assoc_fp32',lambda z,a,s:associative(z,a,s,accum=torch.float32))]:
      v,st=fn(z,a,s);r[name]=metric(v,y,bound)
      if name=='assoc_fp32':
       v1,s1=fn(z[:,:L//3],a[:,:L//3],s);v2,s2=fn(z[:,L//3:],a[:,L//3:],s1);r['split_max']=float((torch.cat([v1,v2],1)-v).abs().max())
     res.append(r)
 for d in [192,320,576]:
  for L in [32,128]:
   z=2*torch.rand(2,L,d,generator=g)-1;a=.5+.49*torch.rand(2,L,d,generator=g);s=2*torch.rand(2,d,generator=g)-1;w=torch.randn(z.shape,generator=g);gs={};ys={}
   for k,fn in [('seq',sequential),('division',division),('assoc',associative)]:
    q=[x.clone().requires_grad_() for x in [z,a,s]];v,_=fn(*q);ys[k]=v.detach();gs[k]=torch.autograd.grad((v*w).mean(),q)
   gr.append(dict(d=d,L=L,assoc=[float((x-y).abs().max()) for x,y in zip(gs['assoc'],gs['seq'])],division=[float((x-y).abs().max()) for x,y in zip(gs['division'],gs['seq'])]))
 for d in [192,320,576]:
  for L in [32,256,1024]:
   z=2*torch.rand(2,L,d,generator=g)-1;a=.5+.49*torch.rand(2,L,d,generator=g);s=torch.zeros(2,d);t={}
   with torch.inference_mode():
    for name,fn in [('sequential',sequential),('division',division),('assoc',associative)]:
     for _ in range(3):fn(z,a,s)
     elapsed=[]
     for _ in range(7):start=time.perf_counter();fn(z,a,s);elapsed.append(time.perf_counter()-start)
     t[name]=statistics.median(elapsed)
   times.append(dict(d=d,L=L,seconds=t,assoc_vs_division_throughput=t['division']/t['assoc']))
 result=dict(cases=res,gradients=gr,timing=times,device='CPU',dtype_policy='FP32 accumulated state for low-precision inputs; quantized gate/value reference')
 (P/'numerics.json').write_text(json.dumps(result,indent=2));print('cases',len(res),'gradients',len(gr),'timing',len(times))
 for dtype in ['torch.float32','torch.float16','torch.bfloat16']:
  rows=[r for r in res if r['dtype']==dtype];print(dtype)
  for method in ['division','assoc_native','assoc_fp32']:
   r=[x[method] for x in rows];print(method,'finite',sum(x['finite'] for x in r),'of',len(r),'max_rel_peak',max(x['relative_peak'] for x in r if x['finite']),'max_rel_l2',max(x['relative_l2'] for x in r if x['finite']),'max_bound_excess',max(x['bound_excess'] for x in r if x['finite']))
 print('max_grad_error_assoc',max(max(r['assoc']) for r in gr),'max_split',max(r['split_max'] for r in res));print('timing_320', [r for r in times if r['d']==320])
if __name__=='__main__':main()
