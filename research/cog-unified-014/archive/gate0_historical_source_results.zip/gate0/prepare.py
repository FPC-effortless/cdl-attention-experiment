import json, pathlib,random,hashlib,io,pickle,zlib
from sklearn.utils import Bunch
P=pathlib.Path(__file__).parent
class U(pickle.Unpickler):
 def find_class(self,m,n):
  if m=='sklearn.datasets.base' and n=='Bunch':return Bunch
  return super().find_class(m,n)
source=pathlib.Path('/opt/pyvenv/lib/python3.13/site-packages/gensim/test/test_data/mini_newsgroup')
x=U(io.BytesIO(zlib.decompress(source.read_bytes())),encoding='latin1').load();docs=[];seen=set()
for i,doc in enumerate(x.data):
 doc=doc.split('\n\n',1)[-1];doc='\n'.join(l for l in doc.splitlines() if not l.lstrip().startswith(('>','|'))).strip()
 if len(doc.encode())<256 or doc in seen:continue
 seen.add(doc);docs.append(dict(id=i,text=doc))
random.Random(460201).shuffle(docs);n=len(docs);ds={'train':docs[:int(n*.7)],'dev':docs[int(n*.7):int(n*.85)],'test':docs[int(n*.85):]};(P/'corpus.json').write_text(json.dumps(ds));print('source sha',hashlib.sha256(source.read_bytes()).hexdigest());print([(k,len(v),sum(len(d['text'].encode()) for d in v)) for k,v in ds.items()]);(P/'corpus_manifest.json').write_text(json.dumps({'source':source.name,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'split_seed':460201,'documents':{k:len(v) for k,v in ds.items()},'bytes':{k:sum(len(d['text'].encode()) for d in v) for k,v in ds.items()},'scope':'development-exposed local corpus; no independent generalization claim'},indent=2))
