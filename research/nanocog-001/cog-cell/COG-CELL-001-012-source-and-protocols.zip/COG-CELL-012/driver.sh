#!/bin/bash
cd /mnt/data/cog_cell_012
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
run(){ python native/run012.py $1 $2 > results/${1}_${2}.log 2>&1; printf '%s %s %s\n' "$1" "$2" "$?" >> exit_status; }
export -f run
xargs -n2 -P3 bash -c 'run "$@"' _ < jobs.txt
