import glob,hashlib,json,pathlib,numpy as np,torch
import run009 as old
ROOT=pathlib.Path(__file__).resolve().parents[1]
files=list((ROOT/'results').glob('*.json'));assert len(files)==24
rng=np.random.default_rng(1200127);rows=old.sample(rng,64,1024,True);reps=[(i,(0,)*1024) for i in range(16)]
def targets(rows):
 s=np.array([r[0] for r in rows]);out=[]
 for j in range(1024):
  op=old.OPS[[r[1][j] for r in rows]];s=(op[:,0]*s+op[:,1])%16;out.append(s.copy())
 return np.stack(out)
gold={'mixed':targets(rows),'repeat':targets(reps)};d={};n=0
for p in files:
 r=json.loads(p.read_text());a,o,s=r['arm'],r['objective'],r['seed'];d[a,o,s]=r
 assert r['source_checkpoint_sha256']==hashlib.sha256((ROOT/'controls'/f'{a}_semantic_{s}.pt').read_bytes()).hexdigest()
 assert r['stream']['state_bytes']==3136 and r['stream']['disagree']==0
 if o in ('clean','robust'):
  assert r['steps']==500 and r['corrector_sha256']==hashlib.sha256((ROOT/'results'/f'{a}_{s}_{o}.pt').read_bytes()).hexdigest()
 for panel,target in gold.items():
  q=r[panel];pred=np.array(q['predictions']);assert np.array_equal(target,q['targets']);assert pred.shape==target.shape;ok=pred==target;n+=ok.size
  for e,v in q['endpoints'].items():
   k=int(e);assert v['final_correct']==int(ok[k-1].sum());assert v['all_correct']==int(ok[:k].all(0).sum())
for arm in ['009','010']:
 for seed in old.SEEDS:
  a=d[arm,'native',seed];b=d[arm,'bypass',seed];c=d[arm,'clean',seed];e=d[arm,'robust',seed];assert len(set(x['original_weight_sha256'] for x in (a,b,c,e)))==1
  assert c['batch_sha256']==e['batch_sha256']
  for panel in gold:assert a[panel]['predictions']==b[panel]['predictions']
summary={'prediction_positions_recalculated':n,'receipts':len(files),'bypass_pairs_exact_predictions':6,'training_steps':sum(r['steps'] for r in d.values()),'supervised_positions':sum(r['supervised_positions'] for r in d.values()),'stream_predictions':24*31,'stream_disagreements':sum(r['stream']['disagree'] for r in d.values()),'source_checkpoint_hash_checks':24,'corrector_checkpoint_hash_checks':12,'groups':{}}
for arm in ['009','010']:
 for obj in ['native','bypass','clean','robust']:
  rs=[d[arm,obj,s] for s in old.SEEDS];group={p:{e:{k:sum(r[p]['endpoints'][e][k] for r in rs) for k in ('n','final_correct','all_correct')} for e in gold_e['endpoints']} for p,gold_e in ((p,rs[0][p]) for p in gold)};group['params']=rs[0]['params'];group['median_decode_us_mean']=float(np.mean([r['bench']['median_us'] for r in rs]));group['seed_receipts']=[{k:r[k] for k in ('seed','steps','supervised_positions','source_checkpoint_sha256','original_weight_sha256','batch_sha256','stream','bench','preflight')} for r in rs];summary['groups'][f'{arm}_{obj}']=group
(ROOT/'audit.json').write_text(json.dumps(summary,indent=2)+'\n');print({k:v for k,v in summary.items() if k!='groups'})
