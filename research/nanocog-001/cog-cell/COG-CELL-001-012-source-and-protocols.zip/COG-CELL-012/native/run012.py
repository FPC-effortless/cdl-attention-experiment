import pathlib, hashlib, json, time, math, argparse
import torch, numpy as np
from torch import nn
import torch.nn.functional as F
import run009 as old, run010 as wide, run011 as prior
ROOT=pathlib.Path(__file__).resolve().parents[1]; K,H=old.K,old.H
class Corrector(nn.Module):
 def __init__(self):
  super().__init__();self.w1=nn.Parameter(torch.empty(K,64,16));self.b1=nn.Parameter(torch.zeros(K,64));self.w2=nn.Parameter(torch.zeros(K,16,64));self.b2=nn.Parameter(torch.zeros(K,16));nn.init.uniform_(self.w1,-.25,.25)
 def forward(self,s,dim):
  h=F.gelu(torch.einsum('...ki,koi->...ko',s,self.w1)+self.b1)
  r=(s+torch.einsum('...ki,koi->...ko',h,self.w2)+self.b2).unflatten(-1,(16//dim,dim));return (r/r.norm(dim=-1,keepdim=True).clamp_min(1.)).flatten(-2)
def load(arm,seed):
 torch.manual_seed(seed);m=old.model('orthogonal') if arm=='009' else wide.model('w16_trace');p=ROOT/'controls'/f'{arm}_semantic_{seed}.pt';m.load_state_dict(torch.load(p,weights_only=True)['weights'],strict=True);m.eval().requires_grad_(False);return m,hashlib.sha256(p.read_bytes()).hexdigest()
def train(m,arm,seed,obj,steps=500):
 torch.manual_seed(seed+12000);c=Corrector();opt=torch.optim.AdamW(c.parameters(),lr=.001,weight_decay=.01);dim=4 if arm=='009' else 16
 with torch.no_grad():bank=prior.codes(m).detach();q,_=prior.matrices(m,arm);q=q.detach()
 gen=torch.Generator().manual_seed(seed+12400);bs=old.batchdata(seed+120000,steps);log=[];st=time.perf_counter();ns=0
 for i,(x,y) in enumerate(bs,1):
  s=bank[x[:,0]];loss=0.;opt.zero_grad(set_to_none=True)
  for j in range(y.shape[1]):
   a=x[:,j+1]-32;raw=(q[a]@s.unflatten(-1,(16//dim,dim))[...,None]).squeeze(-1).flatten(-2);noise=torch.randn(raw.shape,generator=gen)*.03;s=c(raw+(noise if obj=='robust' else 0.),dim);loss=loss+(s-bank[y[:,j]]).square().mean();ns+=x.shape[0]
  loss=loss/y.shape[1];loss.backward();torch.nn.utils.clip_grad_norm_(c.parameters(),1.,error_if_nonfinite=True);opt.param_groups[0]['lr']=.001*min(1,i/25)*(.2+.8*.5*(1+math.cos(math.pi*i/steps)));opt.step()
  if i in (1,100,250,500):log.append(dict(step=i,mse=float(loss.detach())));print(arm,seed,obj,log[-1],flush=True)
 return c.eval(),log,ns,time.perf_counter()-st,old.hash_tensors(t for row in bs for t in row)
class CorrectedBlock(old.orig.Block):
 def forward(self,h,state=None,ab=None):
  u=self.norm(h);z,a=self.inp(u).chunk(2,-1);r,rs=old.scan(z.tanh(),.5+.49*a.sigmoid(),None if state is None else state[0]);q=r+u;v=self.pub(q).tanh().unflatten(-1,(K,H));w,rp,g=self.route(q).split([K,K,1],-1);w=w.sigmoid()*2/K;rp=rp.sigmoid()*2/K;gate=.8*g.sigmoid()*w
  prev=None if state is None else state[1];tail,tail_last=old.scan(v[...,16:],1-gate[...,None],None if prev is None else prev[...,16:]);dim=self.cdim;nb=16//dim;Q=self.cachedQ[self.tokens];keep=self.cachedG[self.tokens];vv=v[...,:16].unflatten(-1,(nb,dim));vv=vv/vv.norm(dim=-1,keepdim=True).clamp_min(1.)
  s=torch.zeros_like(vv[:,0]) if prev is None else prev[...,:16].unflatten(-1,(nb,dim));states=[]
  for t in range(vv.shape[1]):
   s=keep[:,t,...,None]*(Q[:,t]@s[...,None]).squeeze(-1)+(1-keep[:,t,...,None])*vv[:,t]
   if self.correction is not None:
    p=self.correction(s.flatten(-2),dim).unflatten(-1,(nb,dim));mask=((self.tokens[:,t]>=32)&(self.tokens[:,t]<38))[:,None,None,None];s=torch.where(mask,p,s)
   states.append(s.flatten(-2))
  rot=torch.stack(states,1);ms=torch.cat((rot,tail),-1);last=torch.cat((rot[:,-1],tail_last),-1);m=ms*rp[...,None]*K;aa=self.A(m).tanh();bb=self.B(m.roll(1,-2)).tanh();y=aa*(1+bb);msg=self.recv(self.msgnorm(y.flatten(-2)));h=h+self.out(r+self.combine(q).sigmoid()*msg);h=h+self.ff(self.norm2(h));return h,(rs,last)
class CorrectedLM(old.orig.LM):
 def forward(self,x,state=None,ab=None,with_state=False):
  self.layers[0].tokens=x;return super().forward(x,state,ab,with_state)
@torch.no_grad()
def install(m,arm,c):
 l=m.layers[0];u=l.norm(m.emb(torch.arange(256)))
 if arm=='009':par=l.rotation(u).unflatten(-1,(K,4,5));Q=old.matrices(par[...,:4],l.mode);g=(.85+par[...,4]).clamp(0,1)
 else:Q,g=wide.operators(l,u)
 m.__class__=CorrectedLM;l.__class__=CorrectedBlock;l.cdim=Q.shape[-1];l.cachedQ=Q;l.cachedG=g;l.correction=c;return m
@torch.no_grad()
def eval_paths(m,rows):
 x,_=old.encode(rows);s=x[:,0].clone();_,st=m(x[:,:1],with_state=True);ok=torch.ones(len(rows),dtype=torch.bool);preds=[];targets=[];ends={};last=0
 for end in (1,2,4,8,16,32,64,128,256,512,1024):
  for j in range(last,end,32):
   n=min(end-j,32);z,st=m(x[:,j+1:j+1+n],state=st,with_state=True);p=z.argmax(-1)
   for k in range(n):
    a=x[:,j+k+1]-32;op=torch.as_tensor(old.OPS)[a];s=(op[:,0]*s+op[:,1])%16;ok&=p[:,k]==s;targets.append(s.tolist());preds.append(p[:,k].tolist())
  ends[str(end)]={'n':len(rows),'final_correct':int((p[:,-1]==s).sum()),'all_correct':int(ok.sum())};last=end
 return dict(endpoints=ends,predictions=preds,targets=targets)
@torch.no_grad()
def stream(m):
 x=torch.tensor([[3]+[32,33,34,35,36,37]*5]);a,s=m(x,with_state=True);st=None;ys=[]
 for j in range(x.shape[1]):z,st=m(x[:,j:j+1],state=st,with_state=True);ys.append(z)
 z=torch.cat(ys,1);return dict(disagree=int((a.argmax(-1)!=z.argmax(-1)).sum()),max_logit_diff=float((a-z).abs().max()),max_state_diff=max(float((q-r).abs().max()) for L,M in zip(s,st) for q,r in zip(L,M)),state_bytes=sum(q.numel()*q.element_size() for L in st for q in L))
@torch.no_grad()
def bench(m):
 x=torch.tensor([[3]+[32,33,34,35,36,37]*8]);runs=[]
 for _ in range(4):
  st=None;t=time.perf_counter()
  for j in range(x.shape[1]):_,st=m(x[:,j:j+1],state=st,with_state=True)
  runs.append((time.perf_counter()-t)*1e6/x.numel())
 return dict(median_us=float(np.median(runs[1:])),runs_us=runs,warning='concurrent diagnostics; not isolated serving timing')
def main(arm,seed):
 torch.set_num_threads(1);torch.set_num_interop_threads(1);m,ch=load(arm,seed);basehash=old.hash_tensors(m.parameters());rng=np.random.default_rng(1200127);rows=old.sample(rng,64,1024,True);reps=[(i,(0,)*1024) for i in range(16)];x=torch.tensor([[3,32,34,35,37],[9,35,34,33,32]])
 with torch.no_grad():expected,st=m(x,with_state=True)
 preflight=None
 for obj in ('native','bypass','clean','robust'):
  m,_=load(arm,seed);c=None;log=[];ns=0;sec=0;bh=None
  if obj in ('clean','robust'):c,log,ns,sec,bh=train(m,arm,seed,obj)
  if obj!='native':m=install(m,arm,c)
  if obj=='bypass':
   with torch.no_grad():actual,state=m(x,with_state=True);preflight={'max_logit_error':float((expected-actual).abs().max()),'max_state_error':max(float((a-b).abs().max()) for L,M in zip(st,state) for a,b in zip(L,M)),'argmax_disagreements':int((expected.argmax(-1)!=actual.argmax(-1)).sum())}
   assert preflight['argmax_disagreements']==0 and preflight['max_logit_error']<.001,preflight
  r=dict(arm=arm,seed=seed,objective=obj,source_checkpoint_sha256=ch,original_weight_sha256=basehash,steps=500 if c is not None else 0,supervised_positions=ns,train_seconds=sec,batch_sha256=bh,log=log,params=sum(p.numel() for p in m.parameters()),preflight=preflight,stream=stream(m),bench=bench(m));r['mixed']=eval_paths(m,rows);r['repeat']=eval_paths(m,reps)
  if c is not None:
   p=ROOT/'results'/f'{arm}_{seed}_{obj}.pt';torch.save(dict(arm=arm,seed=seed,objective=obj,corrector=c.state_dict(),source_checkpoint_sha256=ch),p);r['corrector_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  (ROOT/'results'/f'{arm}_{seed}_{obj}.json').write_text(json.dumps(r));print('DONE',arm,seed,obj,r['mixed']['endpoints'],r['repeat']['endpoints'],r['bench'],flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('arm',choices=['009','010']);a.add_argument('seed',type=int);p=a.parse_args();main(p.arm,p.seed)
