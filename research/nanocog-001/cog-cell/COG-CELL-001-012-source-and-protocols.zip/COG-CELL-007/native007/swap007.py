from run007 import *
import itertools
@torch.no_grad()
def test(m):
 rows=[(x,o) for x in range(16) for o in product(range(6),repeat=3) if not held(o)];names={'native':set(),'backbone':{0,2},'messages':{1,3},'layer1':{0,1},'layer2':{2,3},'all':{0,1,2,3}}
 modes=['native']+[k+v for k in names if k!='native' for v in ['_true','_wrong']];r={k:dict(n=0,correct=0,prev_correct=0,correct_given_prev=0,native_wrong=0,rescued=0) for k in modes}
 for start in range(0,len(rows),128):
  subset=rows[start:start+128];x,_,y=encode(subset);z=torch.tensor([[answer(v,o[:2])] for v,o in subset]);p,st=m(x[:,:-1],with_state=True);_,true=m(z,with_state=True);_,wrong=m((z+1)%16,with_state=True);prev=p[:,-1].argmax(-1)==z[:,0];outs=[];variants=[]
  for key in modes:
   name=key.split('_')[0];dest=wrong if key.endswith('_wrong') else true;take=names[name];s=[tuple(dest[i][j] if 2*i+j in take else st[i][j] for j in range(2)) for i in range(2)];variants.append(s)
  batched=[tuple(torch.cat([s[i][j] for s in variants],0) for j in range(2)) for i in range(2)];pred=m(x[:,-1:].repeat(len(modes),1),state=batched)[:,0].argmax(-1).reshape(len(modes),len(y));native_wrong=pred[0]!=y
  for name,p in zip(modes,pred):
   q=r[name];ok=p==y;q['n']+=len(y);q['correct']+=int(ok.sum());q['prev_correct']+=int(prev.sum());q['correct_given_prev']+=int((prev&ok).sum());q['native_wrong']+=int(native_wrong.sum());q['rescued']+=int((native_wrong&ok).sum())
 return r
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);out={}
 for a,s,m in itertools.product(ARMS,SEEDS,MODES):
  cp=ROOT/'results'/f'{a}_{s}_{m}.pt';meta=cp.with_suffix('.json');assert cp.exists() and meta.exists();assert digest(cp)==json.loads(meta.read_text())['checkpoint_sha256'];net=model(a);net.load_state_dict(torch.load(cp,weights_only=True,map_location='cpu')['weights']);net.eval();key=f'{a}_{s}_{m}';out[key]=test(net);print(key,{k:v['correct']/v['n'] for k,v in out[key].items()},flush=True)
 (ROOT/'swap.json').write_text(json.dumps(out,indent=2))
