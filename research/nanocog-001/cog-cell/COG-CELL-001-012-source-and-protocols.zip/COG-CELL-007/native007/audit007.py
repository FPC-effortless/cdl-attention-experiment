from run007 import *
import itertools,zipfile,platform,statistics,collections

def avg(v):return float(np.mean(v))
def ci(v):
 v=list(v);return [avg(v)-4.3026527299*np.std(v,ddof=1)/math.sqrt(3),avg(v)+4.3026527299*np.std(v,ddof=1)/math.sqrt(3)]

def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 origzip=pathlib.Path(os.environ.get('UNIFIED006_ARCHIVE','/mnt/data/files/cog_unified_006_evidence.zip'));oldzip=pathlib.Path(os.environ.get('CELL006_ARCHIVE','/mnt/data/COG-CELL-006-native-evidence.zip'));source_verified=[]
 for zp in [origzip,oldzip]:
  with zipfile.ZipFile(zp) as z:
   assert z.testzip() is None
   files=z.namelist();manifest=[p for p in files if p.endswith('SHA256SUMS.txt')];p=min(manifest,key=lambda p:len(p));records=[]
   for line in z.read(p).decode().splitlines():
    h,f=line.split(maxsplit=1);f=f.lstrip('*');name=str(pathlib.PurePosixPath(p).parent / f);assert hashlib.sha256(z.read(name)).hexdigest()==h,(zp,name);records.append(name)
   source_verified.append(dict(archive=zp.name,sha256=digest(zp),count=len(records)))
   if zp==origzip:
    for name in ['run.py','previous_reference.py']:
     assert z.read('cog_unified_006/'+name)==(ROOT.parent/'cog_unified_006'/name).read_bytes()
   else:
    for name in ['cog_unified_006/run.py','cog_unified_006/previous_reference.py','native002/native.py','native004/native004.py','native005/native005.py','native005/composition_task.py','native006/run006.py']:
     assert z.read(name)==(ROOT.parent/name).read_bytes(),name
 res={};count=0;prediction_count=0;replay=[];scores=panel_rows();rng=np.random.default_rng(744717);fresh={f'depth{L}_{"heldout" if heldout else "allowed"}':sample_rows(rng,512,L,heldout) for L,heldout in [(4,True),(8,False),(12,True),(16,False)]};overlap={k:len(set(v)&set(scores.get(k,[]))) for k,v in fresh.items()};rows3=[(x,o) for x in range(16) for o in product(range(6),repeat=3) if not held(o)];truth=[answer(x,o) for x,o in rows3]
 for a,s,m in itertools.product(ARMS,SEEDS,MODES):
  p=ROOT/'results'/f'{a}_{s}_{m}.json';r=json.loads(p.read_text());assert r['checkpoint_sha256']==digest(p.with_suffix('.pt'));assert r['steps']==STEPS;assert len(r['history'])==4;assert r['reference_sha256']==digest(OLD/f'{a}_{s}_trace.phase1.pt');expected_hash=hashlib.sha256(b''.join(v.numpy().tobytes() for row in batchdata(s) for v in row)).hexdigest();assert r['batch_sha256']==expected_hash
  for k,panels in [('scores',scores),('fresh',fresh)]:
   for n,v in r[k].items():
    y=[answer(x,o) for x,o in panels[n]];assert len(y)==v['n']==len(v['predictions']);assert sum(p==t for p,t in zip(v['predictions'],y))==v['correct'];assert abs(v['correct']/v['n']-v['acc'])<1e-12;prediction_count+=len(y)
  for ab,panels in r['interventions'].items():
   for n,v in panels.items():
    y=[answer(x,o) for x,o in scores[n]];assert sum(p==t for p,t in zip(v['predictions'],y))==v['correct'];prediction_count+=len(y)
  for k in ['pre','post']:
   q=r[k];assert sum(p==t for p,t in zip(q['predictions'],truth))==q['native_ok'];prediction_count+=len(truth)
  count+=1;res[a,s,m]=r
  # independent checkpoint replay on all 18 final checkpoints, withheld pair and fresh depth 8
  net=model(a);net.load_state_dict(torch.load(p.with_suffix('.pt'),weights_only=True,map_location='cpu')['weights']);net.eval()
  for key,rows,expected in [('heldout_pairs',scores['depth2_heldout'],r['scores']['depth2_heldout']),('fresh8',fresh['depth8_allowed'],r['fresh']['depth8_allowed'])]:
   observed=panel(net,rows);assert observed['predictions']==expected['predictions'];replay.append(dict(arm=a,seed=s,mode=m,panel=key,n=observed['n']))
 for s in SEEDS:
  v=[res[a,s,m] for a,m in itertools.product(ARMS,MODES)];assert len({r['batch_sha256'] for r in v})==1;assert len({r['labels'] for r in v})==1;assert len({r['train_tokens'] for r in v})==1
 report={'archive_audits':source_verified,'checkpoint_count':count,'predictions_recalculated':prediction_count,'replay_count':len(replay),'replay':replay,'fresh_overlap':overlap,'cpu':platform.processor(),'torch':torch.__version__,'cuda':torch.cuda.is_available(),'steps':sum(r['steps'] for r in res.values()),'history_examples':sum(r['history_examples'] for r in res.values()),'anchor_examples':sum(r['anchor_examples'] for r in res.values()),'labels':sum(r['labels'] for r in res.values()),'tokens':sum(r['train_tokens'] for r in res.values()),'means':{},'paired':{},'gates':{}}
 for a,m in itertools.product(ARMS,MODES):
  v=[res[a,s,m] for s in SEEDS];key=f'{a}/{m}';report['means'][key]={'scores':{k:avg([r['scores'][k]['acc'] for r in v]) for k in scores},'trajectory':{k:avg([r['scores'][k]['trajectory_acc'] for r in v]) for k in scores},'fresh':{k:avg([r['fresh'][k]['acc'] for r in v]) for k in fresh},'pre':{},'post':{},'seconds':avg([r['train_seconds'] for r in v]),'interventions':{ab:{k:avg([r['scores'][k]['acc']-r['interventions'][ab][k]['acc'] for r in v]) for k in v[0]['interventions'][ab]} for ab in v[0]['interventions']}}
  for phase in ['pre','post']:
   q=[r[phase] for r in v];report['means'][key][phase]={'previous':sum(r['previous_ok'] for r in q)/sum(r['n'] for r in q),'conditional':sum(r['next_ok_given_previous_ok'] for r in q)/sum(r['previous_ok'] for r in q),'native':sum(r['native_ok'] for r in q)/sum(r['n'] for r in q),'canonical':sum(r['canonical_ok'] for r in q)/sum(r['n'] for r in q),'agreement':sum(r['native_anchor_agree'] for r in q)/sum(r['n'] for r in q),'all_correct_groups':sum(r['all_correct_groups'] for r in q),'all_same_groups':sum(r['groups_all_same'] for r in q),'groups':sum(r['groups'] for r in q),'same_mse':np.mean([r['same_state_mse'] for r in q],axis=0).tolist(),'different_mse':np.mean([r['different_state_mse'] for r in q],axis=0).tolist(),'kl':avg([r['mean_kl'] for r in q]),'chunk_disagree':sum(r['chunk_disagree'] for r in q)}
  if m!='trace':
   pairs={k:[res[a,s,m]['scores'][k]['acc']-res[a,s,'trace']['scores'][k]['acc'] for s in SEEDS] for k in scores};report['paired'][key]={k:dict(values=d,mean=avg(d),ci95=ci(d)) for k,d in pairs.items()}
  report['gates'][key]={str(s):dict(absolute=all(res[a,s,m]['scores'][k]['acc']>=threshold for k,threshold in [('atomic',.95),('depth2_heldout',.90),('depth4_heldout',.8),('depth8_allowed',.8)]),improvement=all(res[a,s,m]['scores'][k]['acc']-res[a,s,'trace']['scores'][k]['acc']>=.05 for k in ['depth4_heldout','depth8_allowed']),serial_specific=(all(res[a,s,m]['scores'][k]['acc']-res['base',s,m]['scores'][k]['acc']>=.05 for k in ['depth4_heldout','depth8_allowed']) if a=='serial_peer' else None)) for s in SEEDS}
 (ROOT/'aggregate.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:report[k] for k in ['archive_audits','checkpoint_count','predictions_recalculated','replay_count','fresh_overlap','steps','history_examples','anchor_examples','labels','tokens','gates']},indent=2));
 for k,v in report['means'].items():print(k,{p:round(100*v['scores'][p],2) for p in scores}, 'closure',v['post'])
if __name__=='__main__':main()
