import pathlib,sys,os,math,time,hashlib,json,argparse
ROOT=pathlib.Path(__file__).absolute().parent
sys.path.insert(0,str(ROOT.parent/'native006'))
from run006 import model,trace_targets,score,panel,encode,panel_rows,OPS,NEXT,held,answer,init_hash,sample_rows,torch,nn,F,np,product
from collections import defaultdict
ARMS=['base','serial_peer']; MODES=['trace','behavior','state_behavior']; SEEDS=[173,271,907]; STEPS=500; BATCH=32
OLD=ROOT.parent/'native006'/'results'

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def batchdata(seed):
 r=np.random.default_rng(970001+seed);rows=[]
 for step in range(STEPS):
  L=int(r.integers(1,4));x=r.integers(16,size=BATCH);ops=np.empty((BATCH,L+1),np.int64);ops[:,0]=r.integers(6,size=BATCH)
  for i in range(1,L+1):ops[:,i]=NEXT[ops[:,i-1],r.integers(5,size=BATCH)]
  states=[x.copy()]
  for i in range(L+1):states.append((OPS[ops[:,i],0]*states[-1]+OPS[ops[:,i],1])%16)
  prefix=np.concatenate([x[:,None],ops[:,:L]+32],axis=1);suffix=ops[:,L:L+1]+32;targets=np.stack(states[1:L+1],axis=1);z=states[L][:,None];y=states[-1]
  assert all(not held(tuple(p)) for p in ops)
  rows.append(tuple(torch.from_numpy(a.copy()) for a in [prefix,suffix,targets,z,y]))
 return rows

def combine(s1,s2):return [tuple(torch.cat([a,b],dim=0) for a,b in zip(l1,l2)) for l1,l2 in zip(s1,s2)]

def sloss(h,c):return torch.stack([((a-b.detach()).square().mean()/(b.detach().square().mean()+.01)) for l,k in zip(h,c) for a,b in zip(l,k)]).mean()

def forward(m,prefix,suffix,targets,z,y):
 logits,st=m(prefix,with_state=True);_,anchor=m(z,with_state=True);last=m(torch.cat([suffix,suffix],0),state=combine(st,anchor))[:,0];h,c=last.chunk(2,0)
 ce_hist=F.cross_entropy(torch.cat([logits[:,1:],h[:,None]],1).transpose(1,2),torch.cat([targets,y[:,None]],1));ce_anchor=F.cross_entropy(c,y)
 ce=(ce_hist+ce_anchor)*.5;kl=F.kl_div(h.log_softmax(-1),c.detach().softmax(-1),reduction='batchmean');state=sloss(st,anchor)
 return ce,kl,state,h,c

@torch.no_grad()
def closure(m):
 # Full allowed depth-3 domain. Prefix length 2; examine all valid next operations.
 rows=[(x,o) for x in range(16) for o in product(range(6),repeat=3) if not held(o)]
 groups=defaultdict(list);n=previous_ok=next_ok=canonical_ok=native_ok=agree=0;state_sq=[0.]*4;other_sq=[0.]*4;anchor_sq=[0.]*4;kl=0.;max_diff=0.;chunk_disagree=0;predictions=[]
 for start in range(0,len(rows),64):
  subset=rows[start:start+64];x,_,y=encode(subset);z=torch.tensor([[answer(v,o[:2])] for v,o in subset]);p,hs=m(x[:,:-1],with_state=True);_,cs=m(z,with_state=True);_,wrong=m((z+1)%16,with_state=True);h=m(x[:,-1:],state=hs)[:,0];c=m(x[:,-1:],state=cs)[:,0];full=m(x)[:,-1];max_diff=max(max_diff,(h-full).abs().max().item());chunk_disagree+=int((h.argmax(-1)!=full.argmax(-1)).sum());hp=h.argmax(-1);cp=c.argmax(-1);ok=p[:,-1].argmax(-1)==z[:,0];previous_ok+=int(ok.sum());next_ok+=int((ok&(hp==y)).sum());native_ok+=int((hp==y).sum());canonical_ok+=int((cp==y).sum());agree+=int((hp==cp).sum());n+=len(y);kl+=F.kl_div(h.log_softmax(-1),c.softmax(-1),reduction='sum').item()
  for j,(a,b,d) in enumerate(zip([v for l in hs for v in l],[v for l in cs for v in l],[v for l in wrong for v in l])):
   state_sq[j]+=(a-b).square().reshape(len(y),-1).mean(-1).sum().item();other_sq[j]+=(a-d).square().reshape(len(y),-1).mean(-1).sum().item();anchor_sq[j]+=b.square().reshape(len(y),-1).mean(-1).sum().item()
  for (v,o),pred,truth in zip(subset,hp.tolist(),y.tolist()):groups[(answer(v,o[:2]),o[-1])].append((pred,truth));predictions.append(pred)
 return dict(n=n,previous_ok=previous_ok,next_ok_given_previous_ok=next_ok,native_ok=native_ok,canonical_ok=canonical_ok,native_anchor_agree=agree,groups=len(groups),all_correct_groups=sum(all(p==y for p,y in v) for v in groups.values()),groups_all_same=sum(len({p for p,y in v})==1 for v in groups.values()),same_state_mse=[v/n for v in state_sq],different_state_mse=[v/n for v in other_sq],anchor_mean_square=[v/n for v in anchor_sq],mean_kl=kl/n,max_chunk_logit_diff=max_diff,chunk_disagree=chunk_disagree,predictions=predictions)

def main(arm,seed,mode):
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(seed);m=model(arm);cp=OLD/f'{arm}_{seed}_trace.phase1.pt';old=json.loads((OLD/f'{arm}_{seed}_trace.phase1.json').read_text());assert digest(cp)==old['phase1_checkpoint_sha256'];assert init_hash(m)==old['init_sha256'];m.load_state_dict(torch.load(cp,weights_only=True,map_location='cpu')['weights']);assert sum(p.numel() for p in m.parameters())==old['params'];batches=batchdata(seed);bh=hashlib.sha256(b''.join(v.numpy().tobytes() for row in batches for v in row)).hexdigest();out=ROOT/'results'/f'{arm}_{seed}_{mode}';pre=closure(m);print('PRE',arm,seed,mode,pre['native_ok'],pre['previous_ok'],flush=True)
 opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01);s=time.perf_counter();log=[];m.train();labels=0;tokens=0
 for i,(p,suf,t,z,y) in enumerate(batches,1):
  opt.param_groups[0]['lr']=.001*min(1,i/50)*(.2+.8*.5*(1+math.cos(math.pi*i/STEPS)));opt.zero_grad(set_to_none=True);ce,kl,st,h,c=forward(m,p,suf,t,z,y);loss=ce if mode=='trace' else ce+.5*kl if mode=='behavior' else ce+.5*kl+.5*st;loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True);opt.step();labels+=t.numel()+2*len(y);tokens+=p.numel()+3*len(y)
  if i in [1,100,250,500]:
   row=dict(step=i,loss=loss.item(),ce=ce.item(),kl=kl.item(),state=st.item(),native_acc=(h.argmax(-1)==y).float().mean().item(),anchor_acc=(c.argmax(-1)==y).float().mean().item());log.append(row);print(arm,seed,mode,row,flush=True)
 sec=time.perf_counter()-s;ck=out.with_suffix('.pt');torch.save(dict(arm=arm,seed=seed,mode=mode,weights=m.state_dict()),ck);m.eval();scores=score(m);post=closure(m);rng=np.random.default_rng(744717);fresh={f'depth{L}_{"heldout" if heldout else "allowed"}':panel(m,sample_rows(rng,512,L,heldout)) for L,heldout in [(4,True),(8,False),(12,True),(16,False)]};abls={}
 for ab in (['self','reverse','no_B','drop'] if arm=='base' else ['self_message','raw_message','reverse_message','no_B','no_feedback']):abls[ab]={k:panel(m,panel_rows()[k],ab) for k in ['depth2_heldout','depth4_heldout','depth8_allowed']}
 res=dict(arm=arm,seed=seed,mode=mode,params=old['params'],reference_sha256=digest(cp),checkpoint_sha256=digest(ck),batch_sha256=bh,steps=STEPS,history_examples=STEPS*BATCH,anchor_examples=STEPS*BATCH,labels=labels,train_tokens=tokens,train_seconds=sec,history=log,pre=pre,post=post,scores=scores,fresh=fresh,interventions=abls);out.with_suffix('.json').write_text(json.dumps(res,indent=2));print('DONE',arm,seed,mode,{k:round(v['acc'],4) for k,v in scores.items()},flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('arm',choices=ARMS);p.add_argument('seed',type=int);p.add_argument('mode',choices=MODES);a=p.parse_args();main(a.arm,a.seed,a.mode)
