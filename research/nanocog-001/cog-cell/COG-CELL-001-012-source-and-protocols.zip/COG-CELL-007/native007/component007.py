# Exploratory follow-up to completed swap007: replace one first-layer component at a time.
from run007 import *
import itertools
@torch.no_grad()
def test(m):
 rows=[(x,o) for x in range(16) for o in product(range(6),repeat=3) if not held(o)];keys=['native','r1_true','r1_wrong','m1_true','m1_wrong'];out={k:dict(n=0,correct=0,native_wrong=0,rescued=0) for k in keys}
 for start in range(0,len(rows),128):
  subset=rows[start:start+128];x,_,y=encode(subset);z=torch.tensor([[answer(v,o[:2])] for v,o in subset]);_,st=m(x[:,:-1],with_state=True);_,tr=m(z,with_state=True);_,wr=m((z+1)%16,with_state=True)
  variants=[st,[(tr[0][0],st[0][1]),st[1]],[(wr[0][0],st[0][1]),st[1]],[(st[0][0],tr[0][1]),st[1]],[(st[0][0],wr[0][1]),st[1]]];batch=[tuple(torch.cat([v[i][j] for v in variants],0) for j in range(2)) for i in range(2)];pred=m(x[:,-1:].repeat(len(keys),1),state=batch)[:,0].argmax(-1).reshape(len(keys),len(y));nw=pred[0]!=y
  for k,p in zip(keys,pred):
   q=out[k];ok=p==y;q['n']+=len(y);q['correct']+=int(ok.sum());q['native_wrong']+=int(nw.sum());q['rescued']+=int((nw&ok).sum())
 return out
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);out={}
 for a,s,mode in itertools.product(ARMS,SEEDS,MODES):
  cp=ROOT/'results'/f'{a}_{s}_{mode}.pt';assert digest(cp)==json.loads(cp.with_suffix('.json').read_text())['checkpoint_sha256'];m=model(a);m.load_state_dict(torch.load(cp,weights_only=True,map_location='cpu')['weights']);m.eval();key=f'{a}_{s}_{mode}';out[key]=test(m);print(key,{k:v['correct']/v['n'] for k,v in out[key].items()},flush=True)
 (ROOT/'component.json').write_text(json.dumps(out,indent=2))
