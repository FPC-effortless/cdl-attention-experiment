#!/bin/bash
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cat jobs.txt | xargs -P 4 -n 2 bash -c 'python native003.py --arm "$0" --seed "$1" > results/${0}_${1}.log 2>&1; e=$?; echo "$0 $1 $e" >> exit_status; exit "$e"'
echo "driver exit $?" >> driver.log
