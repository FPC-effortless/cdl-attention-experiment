import sys,pathlib,math,time,json,argparse,hashlib,platform
import torch
from torch import nn
import torch.nn.functional as F
ROOT=pathlib.Path(__file__).resolve().parent
SRC=ROOT.parent/'cog_unified_006'
sys.path.insert(0,str(SRC));sys.path.insert(0,str(ROOT.parent/'native002'))
from native import orig,clean,evaluate,init_hash
from previous_reference import scan
K,D,H,T=orig.K,orig.D,orig.H,orig.T
class AutonomousBlock(orig.Block):
 def controls(self,v,head,ab):
  z=(v*self.local_w[head]).sum(-1)+self.local_b[head]
  if self.mode=='population' or ab=='mean_all' or ab==f'mean_{head}':z=z.mean(-1,keepdim=True).expand_as(z)
  if ab==f'rotate_{head}':z=z.roll(1,-1)
  return z
 def forward(self,h,state=None,ab=None):
  if ab=='bypass':return super().forward(h,state)
  u=self.norm(h);z,a=self.inp(u).chunk(2,-1);r,rs=scan(z.tanh(),.5+.49*a.sigmoid(),None if state is None else state[0]);q=r+u;v=self.pub(q).tanh().unflatten(-1,(K,H));w,rp,g=self.route(q).split([K,K,1],-1);w=w.sigmoid()*2/K;rp=rp.sigmoid()*2/K
  gw=2*self.controls(v,0,ab).sigmoid()
  if ab=='fix_write':gw=torch.ones_like(gw)
  gate=.8*g.sigmoid()*w*gw;ms,last=scan(v,1-gate[...,None],None if state is None else state[1]);m=ms*rp[...,None]*K
  gr=2*self.controls(ms,1,ab).sigmoid();alpha=(self.controls(ms,2,ab)-2).sigmoid();ge=2*self.controls(ms,3,ab).sigmoid()
  if ab=='fix_read':gr=torch.ones_like(gr)
  if ab=='fix_route':alpha=torch.zeros_like(alpha)
  if ab=='fix_activity':ge=torch.ones_like(ge)
  if ab=='reverse':alpha=torch.ones_like(alpha)
  src=((1-alpha[...,None])*m).roll(1,-2)+(alpha[...,None]*m).roll(-1,-2)
  if ab=='self':src=m
  a=self.A(m).tanh();b=self.B(src*gr[...,None]).tanh()
  if ab=='no_B':b=torch.zeros_like(b)
  y=ge[...,None]*a*(1+b)
  if getattr(self,'record',False):self.last_controls=torch.stack([gw,gr,alpha,ge],-2).detach()
  msg=self.recv(self.msgnorm(y.flatten(-2)))
  if ab=='drop':msg=torch.zeros_like(msg)
  h=h+self.out(r+self.combine(q).sigmoid()*msg);h=h+self.ff(self.norm2(h));return h,(rs,last)
def model(arm):
 m=orig.LM('composed')
 if arm!='base':
  for l in m.layers:
   l.__class__=AutonomousBlock;l.mode=arm;l.local_w=nn.Parameter(torch.zeros(4,K,H));l.local_b=nn.Parameter(torch.zeros(4,K))
 return m
ARMS=['population','cell']
ABS=['bypass','fix_write','fix_read','fix_route','fix_activity','mean_all','rotate_2','no_B','self','drop']
def stat(m,rows):
 for l in m.layers:l.record=True
 allx=[[] for l in m.layers]
 with torch.no_grad():
  for a in rows:
   for b in a.split(8):
    m(b[:,:-1]);
    for i,l in enumerate(m.layers):allx[i].append(l.last_controls.reshape(-1,4,K))
 for l in m.layers:l.record=False
 return [dict(mean=z.mean(0).tolist(),std=z.std(0).tolist(),unit_dispersion=z.std(-1,unbiased=False).mean(0).tolist(),min=z.amin((0,2)).tolist(),max=z.amax((0,2)).tolist()) for z in map(torch.cat,allx)]
def score(m,ds,dev,test,arm):
 res=dict(dev=evaluate(m,dev),test=evaluate(m,test),history=orig.history(m,ds['test']),stream=orig.streaming(m,ds['test'][0]));res['interventions']={ab:evaluate(m,test,ab=ab) for ab in (ABS if arm!='base' else ['no_B','self','drop','reverse'])}
 if arm!='base':res['gate_stats']=stat(m,test)
 return res
def main():
 p=argparse.ArgumentParser();p.add_argument('--arm',choices=['base']+ARMS,required=True);p.add_argument('--seed',type=int,required=True);a=p.parse_args();torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(a.seed)
 ds=orig.data();dev,de=clean(ds,'dev');test,te=clean(ds,'test');t,starts=orig.train_data(ds['train']);m=model(a.arm);ih=init_hash(m);nparams=sum(p.numel() for p in m.parameters());out=ROOT/'results';prefix=out/f'{a.arm}_{a.seed}'
 if a.arm=='base':
  cp=ROOT.parent/'native002'/'results'/f'base_{a.seed}.pt';m.load_state_dict(torch.load(cp,weights_only=True,map_location='cpu')['weights']);res=dict(arm=a.arm,seed=a.seed,params=nparams,steps=1000,train_bytes=512000,checkpoint_sha256=hashlib.sha256(cp.read_bytes()).hexdigest(),reused=True,init_sha256=ih);res.update(score(m,ds,dev,test,a.arm));prefix.with_suffix('.json').write_text(json.dumps(res,indent=2));print('DONE',a.arm,a.seed,res['dev']['bpb'],res['test']['bpb'],flush=True);return
 g=torch.Generator().manual_seed(100000+a.seed);opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01);log=[];elapsed=0.;m.train()
 for i in range(1,1001):
  pos=starts[torch.randint(len(starts),(8,),generator=g)];batch=t[pos[:,None]+torch.arange(T+1)[None]];x,y=batch[:,:-1],batch[:,1:];s=time.perf_counter();opt.param_groups[0]['lr']=.001*min(1,i/50)*(.2+.8*.5*(1+math.cos(math.pi*i/1000)));opt.zero_grad(set_to_none=True);z=m(x);ce=F.cross_entropy(z.flatten(0,1),y.flatten());ce.backward();nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step();elapsed+=time.perf_counter()-s
  if i in [1,250,500,750,1000]:
   val=evaluate(m,dev);m.train();row=dict(step=i,ce=ce.item(),dev_bpb=val['bpb']);log.append(row);print(a.arm,a.seed,row,flush=True);prefix.with_suffix('.progress.json').write_text(json.dumps(log))
 torch.save(dict(arm=a.arm,seed=a.seed,weights=m.state_dict()),prefix.with_suffix('.pt'));res=dict(arm=a.arm,seed=a.seed,params=nparams,steps=1000,train_bytes=512000,train_seconds=elapsed,init_sha256=ih,history_train=log,excluded_dev=de,excluded_test=te);res.update(score(m,ds,dev,test,a.arm));prefix.with_suffix('.json').write_text(json.dumps(res,indent=2));print('DONE',a.arm,a.seed,res['dev']['bpb'],res['test']['bpb'],flush=True)
if __name__=='__main__':main()
