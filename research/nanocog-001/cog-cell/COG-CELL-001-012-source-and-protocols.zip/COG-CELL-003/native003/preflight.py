from native003 import *
torch.set_num_threads(1);torch.set_num_interop_threads(1)
res={'torch':torch.__version__,'python':platform.python_version(),'cuda':torch.cuda.is_available(),'seeds':[],'source_sha256':hashlib.sha256((SRC/'run.py').read_bytes()).hexdigest(),'corpus_sha256':hashlib.sha256((SRC/'corpus.json').read_bytes()).hexdigest()}
for seed in [173,271,907]:
 torch.manual_seed(seed);base=model('base');torch.manual_seed(seed);cell=model('cell');torch.manual_seed(seed);pop=model('population')
 x=torch.randint(0,256,(2,64),generator=torch.Generator().manual_seed(seed+10));y=torch.randint(0,256,(2,64),generator=torch.Generator().manual_seed(seed+20));zb,sb=base(x,with_state=True);zc,sc=cell(x,ab='bypass',with_state=True);zp=pop(x,ab='bypass');F.cross_entropy(zb.flatten(0,1),y.flatten()).backward();F.cross_entropy(zc.flatten(0,1),y.flatten()).backward();diff=max((p.grad-dict(cell.named_parameters())[k].grad).abs().max().item() for k,p in base.named_parameters());old_equal=all(torch.equal(v,cell.state_dict()[k]) for k,v in base.state_dict().items());info=dict(seed=seed,params=[sum(p.numel() for p in m.parameters()) for m in [base,cell,pop]],old_weights_identical=old_equal,pop_init_identical=init_hash(cell)==init_hash(pop),bypass_logits_diff=(zb-zc).abs().max().item(),pop_bypass_diff=(zb-zp).abs().max().item(),state_diff=max((p-q).abs().max().item() for s,t in zip(sb,sc) for p,q in zip(s,t)),gradient_diff=diff)
 assert old_equal and info['pop_init_identical'] and all(info[k]==0 for k in ['bypass_logits_diff','pop_bypass_diff','state_diff','gradient_diff']),info
 with torch.no_grad():
  x=torch.randint(0,256,(2,129),generator=torch.Generator().manual_seed(seed+30));full,ss=cell(x,with_state=True);p,ps=cell(x[:,:47],with_state=True);q,qs=cell(x[:,47:],state=ps,with_state=True);info.update(chunk_diff=(full[:,47:]-q).abs().max().item(),causal_diff=(full[:,:47]-p).abs().max().item(),state_bytes=sum(v[0].numel()*v.element_size() for l in ss for v in l));assert info['chunk_diff']<1e-4 and info['causal_diff']<1e-4
 res['seeds'].append(info)
(ROOT/'preflight.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
