import pathlib,json,statistics as st,math,csv
R=pathlib.Path(__file__).parent;arms=['base','population','cell'];seeds=[173,271,907];d={}
for a in arms:
 for s in seeds:
  p=R/'results'/f'{a}_{s}.json'
  if p.exists():d[a,s]=json.loads(p.read_text())
rows=[]
for (a,s),x in d.items():rows.append(dict(arm=a,seed=s,params=x['params'],steps=x['steps'],new_training=not x.get('reused',False),dev_bpb=x['dev']['bpb'],test_bpb=x['test']['bpb'],test_acc=x['test']['acc'],history_gain=x['history']['reset_bpb']-x['history']['full_bpb'],state_bytes=x['stream']['state_bytes'],stream_disagreements=x['stream']['argmax_disagree']))
means={}
for a in arms:
 xs=[x for x in rows if x['arm']==a]
 if xs:
  means[a]={'n':len(xs),**{k:st.mean(x[k] for x in xs) for k in ['dev_bpb','test_bpb','test_acc','history_gain']}}
  means[a]['intervention_delta']={k:st.mean(x['interventions'][k]['bpb']-x['test']['bpb'] for (a0,s),x in d.items() if a0==a) for k in next(x['interventions'] for (a0,s),x in d.items() if a0==a)}
  if a!='base':
   means[a]['gate_dispersion']=[[st.mean(x['gate_stats'][layer]['unit_dispersion'][j] for (a0,s),x in d.items() if a0==a) for j in range(4)] for layer in range(2)]
   means[a]['gate_minmax']=[[min(x['gate_stats'][layer]['min'][j] for (a0,s),x in d.items() if a0==a),max(x['gate_stats'][layer]['max'][j] for (a0,s),x in d.items() if a0==a)] for j in range(4) for layer in [0,1]]
pairs={}
for a in ['base','population']:
 ss=[s for s in seeds if ('cell',s) in d and (a,s) in d];pairs[a]={}
 for split in ['dev','test']:
  delta=[d['cell',s][split]['bpb']-d[a,s][split]['bpb'] for s in ss]
  item={'seeds':ss,'differences_cell_minus_control':delta}
  if delta:
   item['mean']=st.mean(delta)
   if len(delta)==3:
    se=st.stdev(delta)/math.sqrt(3);item['paired_t_95_ci']=[item['mean']-4.30265273*se,item['mean']+4.30265273*se]
  pairs[a][split]=item
complete=len(d)==9
passed=complete and all(all(d['cell',s]['dev']['bpb']<=d[a,s]['dev']['bpb']-.01 for a in ['base','population']) for s in seeds)
output=dict(complete=complete,passed=passed,new_fits=sum(not x.get('reused',False) for x in d.values()),new_updates=sum(x['steps'] for x in d.values() if not x.get('reused',False)),new_byte_presentations=sum(x['train_bytes'] for x in d.values() if not x.get('reused',False)),rows=rows,means=means,pairs=pairs)
(R/'aggregate.json').write_text(json.dumps(output,indent=2));
if rows:
 with (R/'summary.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
print(json.dumps(output,indent=2))
