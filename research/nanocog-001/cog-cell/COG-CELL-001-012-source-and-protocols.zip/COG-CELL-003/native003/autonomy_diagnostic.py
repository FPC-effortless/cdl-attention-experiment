"""Secondary intervention (declared before first fit completed): flip only one
source unit's two-way outgoing probabilities; measure causal state dependence and
loss. This is a distribution-shift diagnostic, not retraining or semantic labels.
"""
from native003 import *
def load(arm,seed):
 p=ROOT/"results"/f"{arm}_{seed}.pt"
 m=model(arm);m.load_state_dict(torch.load(p,weights_only=True,map_location="cpu")["weights"]);m.eval();return m
import types
@torch.no_grad()
def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);ds=orig.data();test,_=clean(ds,'test');x=test[0][0:1,:-1];out=[]
 for seed in [173,271,907]:
  if not (ROOT/'results'/f'cell_{seed}.json').exists():continue
  m=load('cell',seed);base=evaluate(m,test)['bpb'];logits,states=m(x,with_state=True)
  for i,l in enumerate(m.layers):
   original=l.controls
   for unit in range(K):
    def flip(self,v,head,ab,unit=unit):
     z=original(v,head,ab)
     if head==2:
      z=z.clone();z[...,unit]=4-z[...,unit]
     return z
    l.controls=types.MethodType(flip,l)
    try:
     # A single input to check local state invariance and output influence; full test for loss.
     z,st=m(x,with_state=True);loss=evaluate(m,test)['bpb'];delta=[max((a-b).abs().max().item() for a,b in zip(p,q)) for p,q in zip(states,st)]
     out.append(dict(seed=seed,layer=i,unit=unit,test_bpb=loss,delta_bpb=loss-base,layer_state_max_abs_diff=delta,logit_max_abs_diff=(z-logits).abs().max().item()))
     assert delta[i]==0,(seed,i,unit,delta)
    finally:l.controls=original
 (ROOT/'autonomy_diagnostic.json').write_text(json.dumps(out,indent=2));print(len(out),'interventions complete')
if __name__=='__main__':main()
