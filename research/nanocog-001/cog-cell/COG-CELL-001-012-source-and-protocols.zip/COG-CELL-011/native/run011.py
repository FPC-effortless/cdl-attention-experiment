import pathlib,sys,math,json,time,hashlib,argparse
import torch
import torch.nn.functional as F
import numpy as np
import run010 as wide
import run009 as old
ROOT=pathlib.Path(__file__).resolve().parents[1]
SEEDS=old.SEEDS
STEPS=500
ARMS=('009','010'); OBJECTIVES=('trace','semantic','fade')

def load(arm,seed):
    torch.manual_seed(seed)
    m=old.model('orthogonal') if arm=='009' else wide.model('w16_trace')
    p=ROOT/'controls'/f'{arm}_{seed}.pt'; ck=torch.load(p,weights_only=True);m.load_state_dict(ck['weights'],strict=True)
    return m,hashlib.sha256(p.read_bytes()).hexdigest()

def codes(m):
    _,st=m(torch.arange(16)[:,None],with_state=True)
    return st[0][1][...,:16]

def matrices(m,arm):
    l=m.layers[0];u=l.norm(m.emb(torch.arange(32,38)))
    if arm=='009':
        p=l.rotation(u).unflatten(-1,(old.K,4,5));return old.matrices(p[...,:4],l.mode),(0.85+p[...,4]).clamp(0,1)
    return wide.operators(l,u)

def sem_loss(m,arm,x,y,bank):
    q,g=matrices(m,arm);d=q.shape[-1]; nb=16//d
    start=codes(m)[x[:,0]];state=start.unflatten(-1,(nb,d))
    states=[start]
    for j in range(y.shape[1]):
        state=(q[x[:,j+1]-32]@state[...,None]).squeeze(-1);states.append(state.flatten(-2))
    states=torch.stack(states,1);labels=torch.cat((x[:,:1],y),1);target=bank[labels]
    mse=(states-target).square().mean()/bank.square().mean().clamp_min(1e-8)
    cos=F.normalize(states.flatten(-2),dim=-1)@F.normalize(bank.flatten(-2),dim=-1).T
    nce=F.cross_entropy((cos/.1).flatten(0,1),labels.flatten())
    return mse+.1*nce,mse,nce

def panels():
    p=old.panels();rng=np.random.default_rng(1100117)
    # disjoint from original fixed panels and CELL-010 retrospective panel generator
    prev_rng=np.random.default_rng(10100117)
    prior={n:set(old.sample(prev_rng,512,n,True)) for n in (8,12,16,32,64)}
    for n in (4,8,12,16,32,64):
        existing=set(p.get(f'held{n}',[]))|set(p.get(f'allowed{n}',[]))|prior.get(n,set()); target=1024 if n==4 else 512
        rows=[];seen=set()
        while len(rows)<target:
            for row in old.sample(rng,target,n,True):
                if row not in existing and row not in seen:
                    seen.add(row);rows.append(row)
                    if len(rows)==target:break
        p[f'fresh_held{n}']=rows
    return p

@torch.no_grad()
def eval_panel(m,rows,ab=None):
    x,y=old.encode(rows); op=x[:,1:]-32;s=x[:,0].clone();ys=[]
    for j in range(op.shape[1]):
        s=(torch.as_tensor(old.OPS)[op[:,j],0]*s+torch.as_tensor(old.OPS)[op[:,j],1])%16;ys.append(s)
    ytrace=torch.stack(ys,1); predictions=[];nll=0.
    for a,b in zip(x.split(32),ytrace.split(32)):
        z=m(a,ab=ab)[:,1:];predictions.append(z.argmax(-1));nll+=F.cross_entropy(z.flatten(0,1),b.flatten(),reduction='sum').item()
    pred=torch.cat(predictions);correct=pred==ytrace
    return {'n':len(rows),'final_correct':int(correct[:,-1].sum()),'all_correct':int(correct.all(1).sum()),'final_acc':float(correct[:,-1].float().mean()),'all_acc':float(correct.all(1).float().mean()),'step_acc':float(correct.float().mean()),'trace_nll':nll/ytrace.numel(),'predictions':pred.tolist()}

@torch.no_grad()
def repeat(m,op):
    x=torch.arange(16)[:,None];_,st=m(x,with_state=True);z=torch.full((16,1),32+op,dtype=torch.long);s=x[:,0];allok=torch.ones(16,dtype=torch.bool);out={};preds=[];last=0
    for n in (1,2,4,8,16,32,64,128,256,512,1024):
        for j in range(last,n,16):
            length=min(16,n-j);logits,st=m(z.expand(-1,length),state=st,with_state=True);p=logits.argmax(-1);preds.extend(p.T.tolist())
            for k in range(length):
                s=(int(old.OPS[op,0])*s+int(old.OPS[op,1]))%16;allok&=p[:,k]==s
        out[str(n)]={'correct':int((p[:,-1]==s).sum()),'all_steps_correct':int(allok.sum()),'span':float((st[0][1][...,:16].max(0).values-st[0][1][...,:16].min(0).values).abs().max())};last=n
    return {'endpoints':out,'predictions':preds}

@torch.no_grad()
def diagnostic(m,arm,bank):
    c=codes(m);q,g=matrices(m,arm);d=q.shape[-1];nb=16//d
    p=(q[:,None]@c[None].unflatten(-1,(nb,d))[...,None]).squeeze(-1).flatten(-2)
    labels=torch.tensor([[(a*x+b)%16 for x in range(16)] for a,b in old.OPS]);cos=F.normalize(p.flatten(-2),dim=-1)@F.normalize(bank.flatten(-2),dim=-1).T
    selfcos=F.normalize(p.flatten(-2),dim=-1)@F.normalize(c.flatten(-2),dim=-1).T
    cp=F.normalize(c.flatten(-2),dim=-1);sim=cp@cp.T;off=sim[~torch.eye(16,dtype=torch.bool)]
    ortho=(q.transpose(-1,-2)@q-torch.eye(d)).abs().max()
    return dict(anchored_operator_accuracy=float((cos.argmax(-1)==labels).float().mean()),self_operator_accuracy=float((selfcos.argmax(-1)==labels).float().mean()),anchor_mse_relative=float((p-bank[labels]).square().mean()/bank.square().mean().clamp_min(1e-8)),code_norm=float(c.flatten(-2).norm(dim=-1).mean()),max_offdiag_cos=float(off.max()),mean_offdiag_cos=float(off.mean()),retention=float(g.mean()),exact_keep_fraction=float((g==1).float().mean()),orthogonality_error=float(ortho),T16_error=float((torch.linalg.matrix_power(q[0],16)-torch.eye(d)).square().mean().sqrt()),T_relative_displacement=float((p[0]-c).norm()/c.norm()))

def run(arm,obj,seed,steps=STEPS):
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    m,ch=load(arm,seed);m.train(); init=old.hash_tensors(m.parameters());bank=codes(m).detach().clone(); before=diagnostic(m,arm,bank);log=[];times=0.;ntarget=0;bs=old.batchdata(seed+110000,steps);bh=old.hash_tensors(t for row in bs for t in row)
    if obj!='start':
        opt=torch.optim.AdamW(m.parameters(),lr=.0003,weight_decay=.01)
        for i,(x,y) in enumerate(bs,1):
            start=time.perf_counter();opt.param_groups[0]['lr']=.0003*min(1,i/25)*(.2+.8*.5*(1+math.cos(math.pi*i/steps)));opt.zero_grad(set_to_none=True)
            z=m(x)[:,1:];ce=F.cross_entropy(z.flatten(0,1),y.flatten());reg=torch.zeros(());mm=nnc=0.;weight=.25 if obj=='semantic' else .25*max(0,min(1,(400-i)/150)) if obj=='fade' else 0.
            if weight>0:reg,ms,nc=sem_loss(m,arm,x,y,bank);mm=float(ms.detach());nnc=float(nc.detach())
            loss=ce+weight*reg;loss.backward();nn=torch.nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True);opt.step();times+=time.perf_counter()-start;ntarget+=y.numel()
            if i in (1,100,250,400,500,steps):
                row=dict(step=i,ce=float(ce.detach()),sem=float(reg.detach()),mse=mm,nce=nnc,weight=weight,trace_acc=float((z.argmax(-1)==y).float().mean()),grad=float(nn));log.append(row);print(arm,obj,seed,row,flush=True)
    p=ROOT/'results'/f'{arm}_{obj}_{seed}';ck=p.with_suffix('.pt');torch.save(dict(arm=arm,objective=obj,seed=seed,weights=m.state_dict()),ck);m.eval();after=diagnostic(m,arm,bank);ps=panels();scores={k:eval_panel(m,v) for k,v in ps.items() if k in ['atomic','allowed2','held2','allowed8','allowed12'] or k.startswith('fresh_')}; reps={str(op):repeat(m,op) for op in (0,1,5)};abl={k:eval_panel(m,ps['fresh_held8'],k) for k in ['no_rotation','self','damp']};stream=old.stream(m)
    res=dict(arm=arm,objective=obj,seed=seed,params=sum(p.numel() for p in m.parameters()),steps=steps if obj!='start' else 0,training_examples=steps*old.BATCH if obj!='start' else 0,supervised_positions=ntarget,train_seconds=times,source_checkpoint_sha256=ch,init_sha256=init,batch_sha256=bh,checkpoint_sha256=hashlib.sha256(ck.read_bytes()).hexdigest(),log=log,before=before,after=after,scores=scores,repeated=reps,ablation=abl,stream=stream)
    p.with_suffix('.json').write_text(json.dumps(res)); print('DONE',arm,obj,seed,{k:round(v['final_acc'],4) for k,v in scores.items()},'repeat',reps['0']['endpoints']['1024'],flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('arm',choices=ARMS);p.add_argument('objective',choices=(*OBJECTIVES,'start'));p.add_argument('seed',type=int);a=p.parse_args();run(a.arm,a.objective,a.seed)
