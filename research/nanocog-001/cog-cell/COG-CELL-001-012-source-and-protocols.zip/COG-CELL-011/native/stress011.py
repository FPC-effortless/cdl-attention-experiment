import run011 as r
import torch,numpy as np,json,argparse
@torch.no_grad()
def main(a,o,s):
 torch.set_num_threads(1);torch.set_num_interop_threads(1);rng=np.random.default_rng(111019);rows=[];seen=set()
 while len(rows)<64:
  x=int(rng.integers(16));ops=tuple(map(int,rng.integers(6,size=1024)));row=(x,ops)
  if r.old.held(ops[:64]) and row not in seen:seen.add(row);rows.append(row)
 x,_=r.old.encode(rows);m,_=r.load(a,s);m.load_state_dict(torch.load(r.ROOT/'results'/f'{a}_{o}_{s}.pt',weights_only=True)['weights']);m.eval();ys=[];traces=[]
 for xx in x.split(16):
  _,st=m(xx[:,:1],with_state=True);p=[]
  for chunk in xx[:,1:].split(32,dim=1):
   z,st=m(chunk,state=st,with_state=True);p.append(z.argmax(-1))
  traces.append(torch.cat(p,dim=1))
 pred=torch.cat(traces);y=x[:,0].clone();labels=[]
 for t in range(1,x.shape[1]):
  op=x[:,t]-32;y=(torch.as_tensor(r.old.OPS)[op,0]*y+torch.as_tensor(r.old.OPS)[op,1])%16;labels.append(y)
 yy=torch.stack(labels,1);ok=pred==yy;out={str(n):{'correct':int(ok[:,n-1].sum()),'all_correct':int(ok[:,:n].all(1).sum()),'n':len(x),'step_acc':float(ok[:,:n].float().mean())} for n in (64,128,256,512,1024)}
 p=r.ROOT/'stress'/f'{a}_{o}_{s}.json';p.write_text(json.dumps(dict(arm=a,objective=o,seed=s,input_sha256=r.old.hash_tensors([x]),predictions=pred.tolist(),endpoints=out)));print(a,o,s,out,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('arm');p.add_argument('obj');p.add_argument('seed',type=int);a=p.parse_args();main(a.arm,a.obj,a.seed)
