import run011 as r
import torch,numpy as np,json,hashlib,pathlib,collections
R=r.ROOT
@torch.no_grad()
def operator_only(m,arm,rows):
    x,y=r.old.encode(rows);c=r.codes(m);q,g=r.matrices(m,arm);d=q.shape[-1];nb=16//d;state=c[x[:,0]].unflatten(-1,(nb,d));actual=x[:,0].clone();allok=torch.ones(len(x),dtype=torch.bool);ok_count=0;pred=[];bank=torch.nn.functional.normalize(c.flatten(-2),dim=-1)
    for j in range(1,x.shape[1]):
        o=x[:,j]-32;state=(q[o]@state[...,None]).squeeze(-1);z=torch.nn.functional.normalize(state.flatten(-3),dim=-1)@bank.T;p=z.argmax(-1);actual=(torch.as_tensor(r.old.OPS)[o,0]*actual+torch.as_tensor(r.old.OPS)[o,1])%16;ok=p==actual;allok&=ok;ok_count+=int(ok.sum());pred.append(p.tolist())
    return dict(n=len(x),final_acc=float(ok.float().mean()),all_acc=float(allok.float().mean()),step_acc=ok_count/(len(x)*(x.shape[1]-1)))
@torch.no_grad()
def main():
    torch.set_num_threads(1);torch.set_num_interop_threads(1);ps=r.panels();out={};counts=collections.Counter()
    for seed in r.SEEDS:
      bs=r.old.batchdata(seed+110000,r.STEPS);bh=r.old.hash_tensors(v for row in bs for v in row)
      for arm in r.ARMS:
       initial,ih=r.load(arm,seed);bank=r.codes(initial);initial_hash=r.old.hash_tensors(initial.parameters())
       for obj in ('start',*r.OBJECTIVES):
        name=f'{arm}_{obj}_{seed}';p=R/'results'/name;res=json.loads(p.with_suffix('.json').read_text());assert res['checkpoint_sha256']==hashlib.sha256(p.with_suffix('.pt').read_bytes()).hexdigest();assert res['source_checkpoint_sha256']==ih;assert res['init_sha256']==initial_hash;assert res['batch_sha256']==bh
        for k,v in res['scores'].items():
            rows=ps[k];ys=[]
            for x,ops in rows:
                ys.append([r.old.answer(x,ops[:i+1]) for i in range(len(ops))]);assert len(ys[-1])==len(ops)
            a=np.asarray(ys);pred=np.asarray(v['predictions']);ok=a==pred;assert int(ok[:,-1].sum())==v['final_correct'];assert int(ok.all(axis=1).sum())==v['all_correct'];assert abs(ok.mean()-v['step_acc'])<1e-6;counts['panel_predictions']+=ok.size
        for o,v in res['repeated'].items():
            pred=np.asarray(v['predictions']);a=np.arange(16);ok=[]
            for t in range(1024):
                a=(r.old.OPS[int(o),0]*a+r.old.OPS[int(o),1])%16;ok.append(a==pred[t])
            ok=np.asarray(ok);counts['repeated_predictions']+=ok.size
            for n,ep in v['endpoints'].items():
                assert int(ok[int(n)-1].sum())==ep['correct'];assert int(ok[:int(n)].all(0).sum())==ep['all_steps_correct']
        for k,v in res['ablation'].items():
            a=np.asarray([[r.old.answer(x,ops[:i+1]) for i in range(len(ops))] for x,ops in ps['fresh_held8']]);ok=a==np.asarray(v['predictions']);assert int(ok[:,-1].sum())==v['final_correct'];assert int(ok.all(axis=1).sum())==v['all_correct'];counts['ablation_predictions']+=ok.size
        m,_=r.load(arm,seed);m.load_state_dict(torch.load(p.with_suffix('.pt'),weights_only=True)['weights']);m.eval()
        for k in ('held2','fresh_held4'):
            rep=r.eval_panel(m,ps[k]);assert rep['predictions']==res['scores'][k]['predictions'];counts['replays']+=1
        isolated={k:operator_only(m,arm,ps[k]) for k in ('held2','fresh_held4','fresh_held8','fresh_held12','fresh_held32','fresh_held64')};out[name]=isolated;counts['checkpoints']+=1;counts['stream_disagree']+=res['stream']['disagree'];counts['stream_n']+=res['stream']['n'];print(name,'audit passed', {k:round(v['final_acc'],4) for k,v in isolated.items()},flush=True)
    (R/'audit.json').write_text(json.dumps(dict(counts=counts,operator_only=out),indent=2));print(dict(counts))
if __name__=='__main__':main()
