import hashlib,json, pathlib, numpy as np
R=pathlib.Path(__file__).resolve().parents[1]
OPS=np.array([[1,1],[1,3],[3,1],[5,2],[7,3],[15,4]],np.int64)
FORBIDDEN={(0,2),(2,0),(1,3),(3,1),(4,5),(5,4)}
rng=np.random.default_rng(111019);rows=[];seen=set()
while len(rows)<64:
    x=int(rng.integers(16));ops=tuple(map(int,rng.integers(6,size=1024)));row=(x,ops)
    if any((a,b) in FORBIDDEN for a,b in zip(ops[:64],ops[1:64])) and row not in seen:seen.add(row);rows.append(row)
x=np.asarray([[v]+[o+32 for o in ops] for v,ops in rows],dtype=np.int64);sha=hashlib.sha256(x.tobytes()).hexdigest();state=x[:,0].copy();yy=[]
for j in range(1,1025):
    op=x[:,j]-32;state=(OPS[op,0]*state+OPS[op,1])%16;yy.append(state.copy())
y=np.asarray(yy).T;total=0;files=[]
for p in sorted((R/'stress').glob('*.json')):
    d=json.loads(p.read_text());assert d['input_sha256']==sha;pred=np.asarray(d['predictions']);assert pred.shape==y.shape;ok=pred==y
    for k,v in d['endpoints'].items():
        n=int(k);assert int(ok[:,n-1].sum())==v['correct'];assert int(ok[:,:n].all(1).sum())==v['all_correct'];assert abs(ok[:,:n].mean()-v['step_acc'])<1e-6
    total+=ok.size;files.append(p.name)
assert len(files)==18
out={'verified_files':files,'prediction_count':total,'input_sha256':sha};(R/'stress_audit.json').write_text(json.dumps(out,indent=2));print(out)
