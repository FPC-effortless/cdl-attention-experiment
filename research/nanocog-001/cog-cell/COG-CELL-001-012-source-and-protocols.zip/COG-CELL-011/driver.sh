#!/bin/bash
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cat jobs.txt | xargs -P4 -n3 bash -c 'python native/run011.py "$0" "$1" "$2" > results/${0}_${1}_${2}.log 2>&1; ec=$?; echo "$0 $1 $2 $ec" >> exit_status; exit "$ec"'
