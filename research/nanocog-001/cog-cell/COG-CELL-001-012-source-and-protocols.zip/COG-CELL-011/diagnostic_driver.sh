#!/bin/bash
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
# Wait only for the training driver to exit within this active research session.
while kill -0 11801 2>/dev/null && [ "$(wc -l < exit_status)" -lt 24 ]; do sleep 1; done
python native/audit011.py > audit.log 2>&1 & p=$!
grep -v ' start ' jobs.txt | xargs -P3 -n3 bash -c 'python native/stress011.py "$0" "$1" "$2" > stress/${0}_${1}_${2}.log 2>&1; ec=$?; echo "$0 $1 $2 $ec" >> stress_exit; exit "$ec"'
s=$?; wait "$p"; a=$?; echo "audit $a stress $s" > diagnostic_exit
