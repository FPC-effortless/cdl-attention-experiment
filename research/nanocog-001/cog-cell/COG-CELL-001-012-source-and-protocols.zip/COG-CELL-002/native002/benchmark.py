import torch,time,json,statistics as st,random,pathlib
from native import model,orig
R=pathlib.Path(__file__).parent

def run():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(173)
 ms={};x=torch.randint(0,256,(1,64));xd=torch.randint(0,256,(1,1));long=torch.randint(0,256,(1,512));times={};replay=[]
 for arm in ('base','common','cell'):
  for seed in (173,271,907):
   ck=torch.load(R/'results'/f'{arm}_{seed}.pt',weights_only=True,map_location='cpu');m=model(arm);m.load_state_dict(ck['weights']);m.eval();ms[arm,seed]=m;times[arm,seed]={k:[] for k in ['prefill64_us_per_byte','prefill512_us_per_byte','decode_us_per_byte']}
   if arm=='base':
    old=torch.load(orig.P/f'composed_{seed}.pt',weights_only=True,map_location='cpu')['weights'];delta=[(old[k]-v).abs().max().item() for k,v in m.state_dict().items()];replay.append(dict(seed=seed,max_weight_abs_diff=max(delta)))
 rng=random.Random(173)
 with torch.inference_mode():
  for k,m in ms.items():
   for _ in range(3):m(x);m(long);m(xd)
  for rep in range(5):
   keys=list(ms);rng.shuffle(keys)
   for k in keys:
    m=ms[k];_,state=m(x,with_state=True);state=tuple(tuple(v.clone() for v in p) for p in state)
    for name,seq,num in [('prefill64_us_per_byte',x,15),('prefill512_us_per_byte',long,5)]:
     t=time.perf_counter()
     for _ in range(num):m(seq)
     times[k][name].append((time.perf_counter()-t)*1e6/(num*seq.numel()))
    t=time.perf_counter()
    for _ in range(64):
     _,state=m(xd,state=state,with_state=True)
    times[k]['decode_us_per_byte'].append((time.perf_counter()-t)*1e6/64)
 result={'measurement':'Single-process CPU FP32 1 thread, batch 1, 5 interleaved repeated timing passes; Python implementation only. Repeated fixed inputs and model-resident weights; no tokenizer or I/O. No optimized-kernel speed claim.','models':[dict(arm=k[0],seed=k[1],raw=v,median={n:st.median(t) for n,t in v.items()}) for k,v in times.items()],'archive_weight_replay':replay}
 result['arm_mean_of_seed_medians']={arm:{n:st.mean(r['median'][n] for r in result['models'] if r['arm']==arm) for n in next(iter(times.values()))} for arm in ('base','common','cell')}
 (R/'benchmark.json').write_text(json.dumps(result,indent=2));print(json.dumps(result['arm_mean_of_seed_medians'],indent=2))
if __name__=='__main__':run()
