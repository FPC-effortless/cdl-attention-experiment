import torch,json,sys,pathlib,hashlib,platform
from native import model,init_hash,orig,clean
from torch.nn import functional as F
torch.set_num_threads(1);torch.set_num_interop_threads(1)
R=pathlib.Path(__file__).parent
r={'torch':torch.__version__,'python':platform.python_version(),'cuda':torch.cuda.is_available(),'checks':[],'seeds':[]}
for seed in (173,271,907):
 torch.manual_seed(seed);a=model('base');torch.manual_seed(seed);b=model('cell');torch.manual_seed(seed);c=model('common');hashes=[init_hash(m) for m in (a,b,c)]
 x=torch.randint(0,256,(2,64),generator=torch.Generator().manual_seed(seed+100));y=torch.randint(0,256,(2,64),generator=torch.Generator().manual_seed(seed+200));a.eval();b.eval();c.eval();za,sa=a(x,with_state=True);zb,sb=b(x,ab='uniform_gain',with_state=True);zc,sc=c(x,ab='uniform_gain',with_state=True)
 F.cross_entropy(za.flatten(0,1),y.flatten()).backward();F.cross_entropy(zb.flatten(0,1),y.flatten()).backward()
 grad=max((p.grad-q.grad).abs().max().item() for p,q in zip(a.parameters(),b.parameters()))
 rr=dict(seed=seed,params=[sum(p.numel() for p in m.parameters()) for m in (a,b,c)],init_hashes=hashes,logit_diff_cell=(za-zb).abs().max().item(),logit_diff_common=(za-zc).abs().max().item(),state_diff=max((p-q).abs().max().item() for s,t in zip(sa,sb) for p,q in zip(s,t)),grad_diff=grad)
 assert len(set(hashes))==1 and len(set(rr['params']))==1 and rr['logit_diff_cell']==rr['logit_diff_common']==rr['state_diff']==0 and grad==0,rr
 r['seeds'].append(rr)
# Full original architecture retained, with no added parameters or recurrence storage.
# Test random input and causal prefix/chunk continuation for candidate before training.
with torch.no_grad():
 torch.manual_seed(42);b=model('cell');b.eval();x=torch.randint(0,256,(2,129));full,s=b(x,with_state=True);p,ps=b(x[:,:47],with_state=True);q,qs=b(x[:,47:],state=ps,with_state=True);rr={'causal_prefix_max':(full[:,:47]-p).abs().max().item(),'chunk_max':(full[:,47:]-q).abs().max().item(),'state_bytes_per_sequence':sum(v[0].numel()*v.element_size() for l in s for v in l)};r['checks'].append(rr);assert rr['chunk_max']<1e-4
r['archive_corpus_sha256']=hashlib.sha256((orig.P/'corpus.json').read_bytes()).hexdigest()
(R/'preflight.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
