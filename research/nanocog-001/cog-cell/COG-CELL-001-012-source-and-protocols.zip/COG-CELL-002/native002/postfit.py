"""Secondary diagnostics: unit message-operator lesions and archived checkpoint replay.
Zeroing A output silences the unit's local composed output; zeroing the input
of B at the ring successor silences its incoming contribution except B bias.
Not a full unit/state deletion, and an out-of-distribution intervention.
"""
import torch, json, math, time, statistics, pathlib, argparse, random
from native import model,orig,clean,evaluate,init_hash
R=pathlib.Path(__file__).parent

def load(p,arm):
 ck=torch.load(p,map_location='cpu',weights_only=True);m=model(arm);m.load_state_dict(ck['weights']);m.eval();return m

def lesion(m,layer,i):
 def h_A(mod,inp,out):
  z=out.clone();z[...,i,:]=0;return z
 def h_B(mod,inp):
  z=inp[0].clone();z[...,(i+1)%4,:]=0;return (z,)
 return [m.layers[layer].A.register_forward_hook(h_A),m.layers[layer].B.register_forward_pre_hook(h_B)]

@torch.no_grad()
def stream_diag(m,x):
 full,s=m(x,with_state=True);a,st=m(x[:,:57],with_state=True);compact=tuple(tuple(v.detach().clone() for v in pair) for pair in st);b,st2=m(x[:,57:],state=compact,with_state=True);o=torch.cat([a,b],dim=1)
 def sizes(st):
  vs=[v for pair in st for v in pair];return {'logical_bytes':sum(v.numel()*v.element_size() for v in vs),'backing_storage_bytes':sum(v.untyped_storage().nbytes() for v in vs)}
 return dict(logit_diff=(full-o).abs().max().item(),argmax_disagree=int((full.argmax(-1)!=o.argmax(-1)).sum()),raw_state=sizes(st),compact_state=sizes(compact))

def main():
 p=argparse.ArgumentParser();p.add_argument('--arm',choices=['base','cell','common','archive'],required=True);p.add_argument('--seed',type=int,required=True);a=p.parse_args();torch.set_num_threads(1);torch.set_num_interop_threads(1)
 ds=orig.data();dev,de=clean(ds,'dev');test,te=clean(ds,'test');r={'arm':a.arm,'seed':a.seed}
 if a.arm=='archive':
  for arm in ['composed','self']:
   p=orig.P/f'{arm}_{a.seed}.pt';ck=torch.load(p,map_location='cpu',weights_only=True);m=orig.LM(arm);m.load_state_dict(ck['weights']);r[arm]={'dev':evaluate(m,dev),'test':evaluate(m,test),'weight_hash':init_hash(m)}
 else:
  m=load(R/'results'/f'{a.arm}_{a.seed}.pt',a.arm);base=evaluate(m,test)['bpb'];r['test_bpb']=base;r['weight_hash']=init_hash(m);r['lesions']=[]
  for layer in range(2):
   for i in range(4):
    hs=lesion(m,layer,i)
    try:bpb=evaluate(m,test)['bpb']
    finally:
     for h in hs:h.remove()
    r['lesions'].append(dict(layer=layer,unit=i,bpb=bpb,delta=bpb-base))
  r['chunk_restart']=stream_diag(m,ds['test'][0][:256][None]);r['state_unit_note']='Private message state and global recurrent state unchanged; compact backing bytes count only those two tensors per layer.'
 (R/'results'/f'{a.arm}_{a.seed}.postfit.json').write_text(json.dumps(r,indent=2));print(a.arm,a.seed,'DONE',flush=True)
if __name__=='__main__':main()
