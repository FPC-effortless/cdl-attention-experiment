import sys,pathlib,math,time,json,argparse,hashlib
import torch
from torch import nn
import torch.nn.functional as F
ROOT=pathlib.Path(__file__).resolve().parent
SRC=ROOT.parent/'cog_unified_006'
sys.path.insert(0,str(SRC))
import run as orig
from previous_reference import scan
K,D,H,T=orig.K,orig.D,orig.H,orig.T
class NeuronBlock(orig.Block):
 def forward(self,h,state=None,ab=None):
  u=self.norm(h);z,a=self.inp(u).chunk(2,-1);r,rs=scan(z.tanh(),.5+.49*a.sigmoid(),None if state is None else state[0]);q=r+u;v=self.pub(q).tanh().unflatten(-1,(K,H));w,rp,g=self.route(q).split([K,K,1],-1);w=w.sigmoid()*2/K;rp=rp.sigmoid()*2/K
  gate=.8*g.sigmoid()*w;ms,last=scan(v,1-gate[...,None],None if state is None else state[1]);m=ms*rp[...,None]*K
  a=self.A(m).tanh();e=2*torch.sigmoid(4*a.mean(-1,keepdim=True))
  if self.cell_mode=='common' or ab=='mean_gain':e=e.mean(-2,keepdim=True).expand_as(e)
  if ab=='uniform_gain':e=torch.ones_like(e)
  if ab=='rotate_gain':e=e.roll(1,-2)
  if getattr(self,'record_gain',False):self.last_gain=e.detach()
  src=(e*m).roll(1,-2)
  if ab=='self':src=e*m
  if ab=='reverse':src=(e*m).roll(-1,-2)
  b=self.B(src).tanh()
  if ab=='no_B':b=torch.zeros_like(b)
  y=e*a*(1+b)
  msg=self.recv(self.msgnorm(y.flatten(-2)))
  if ab=='drop':msg=torch.zeros_like(msg)
  h=h+self.out(r+self.combine(q).sigmoid()*msg);h=h+self.ff(self.norm2(h));return h,(rs,last)
def model(arm):
 m=orig.LM('composed')
 if arm!='base':
  for l in m.layers:l.__class__=NeuronBlock;l.cell_mode=arm
 return m

def clean(ds,split):
 tr=[bytes(t.tolist()) for t in ds['train']];rows=[];excluded=[]
 for i,d in enumerate(ds[split]):
  a=orig.windows(d,T,24);keep=[]
  for j,w in enumerate(a):
   if any(bytes(w.tolist()) in t for t in tr):excluded.append([i,j])
   else:keep.append(j)
  rows.append(a[keep])
 return rows,excluded
@torch.no_grad()
def evaluate(m,rows,ab=None):
 m.eval();ls=n=ok=0;doc=[]
 for a in rows:
  dl=dn=0
  for b in a.split(8):
   x,y=b[:,:-1],b[:,1:];z=m(x,ab=ab);l=F.cross_entropy(z.flatten(0,1),y.flatten(),reduction='sum').item();ls+=l;dl+=l;dn+=y.numel();n+=y.numel();ok+=(z.argmax(-1)==y).sum().item()
  doc.append(dl/dn/math.log(2))
 return dict(bpb=ls/n/math.log(2),acc=ok/n,n=n,doc_bpb=doc)
def init_hash(m):
 h=hashlib.sha256()
 for k,v in m.state_dict().items():h.update(k.encode());h.update(v.detach().numpy().tobytes())
 return h.hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--arm',choices=['base','common','cell'],required=True);p.add_argument('--seed',type=int,required=True);a=p.parse_args();torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(a.seed)
 ds=orig.data();dev,de=clean(ds,'dev');test,te=clean(ds,'test');t,starts=orig.train_data(ds['train']);m=model(a.arm);ih=init_hash(m);nparams=sum(p.numel() for p in m.parameters());g=torch.Generator().manual_seed(100000+a.seed);opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01);log=[];elapsed=0.;m.train();out=ROOT/'results';prefix=out/f'{a.arm}_{a.seed}'
 for i in range(1,1001):
  pos=starts[torch.randint(len(starts),(8,),generator=g)];batch=t[pos[:,None]+torch.arange(T+1)[None]];x,y=batch[:,:-1],batch[:,1:];s=time.perf_counter();opt.param_groups[0]['lr']=.001*min(1,i/50)*(.2+.8*.5*(1+math.cos(math.pi*i/1000)));opt.zero_grad(set_to_none=True);z=m(x);ce=F.cross_entropy(z.flatten(0,1),y.flatten());ce.backward();nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step();elapsed+=time.perf_counter()-s
  if i in [1,250,500,750,1000]:
   val=evaluate(m,dev);m.train();row=dict(step=i,ce=ce.item(),dev_bpb=val['bpb']);log.append(row);print(a.arm,a.seed,row,flush=True)
   prefix.with_suffix('.progress.json').write_text(json.dumps(log))
 torch.save(dict(arm=a.arm,seed=a.seed,weights=m.state_dict()),prefix.with_suffix('.pt'))
 res=dict(arm=a.arm,seed=a.seed,params=nparams,steps=1000,train_bytes=512000,train_seconds=elapsed,init_sha256=ih,history_train=log,excluded_dev=de,excluded_test=te,dev=evaluate(m,dev),test=evaluate(m,test),stream=orig.streaming(m,ds['test'][0]))
 if a.arm!='base':
  res['interventions']={ab:evaluate(m,test,ab=ab) for ab in ['uniform_gain','mean_gain','rotate_gain','no_B','self','drop']}
  for l in m.layers:l.record_gain=True
  stats=[[] for _ in m.layers]
  with torch.no_grad():
   for rows in test:
    for b in rows.split(8):
     m(b[:,:-1]);
     for i,l in enumerate(m.layers):stats[i].append(l.last_gain.reshape(-1,K))
  res['gain_stats']=[dict(mean=z.mean(0).tolist(),std=z.std(0).tolist(),cross_cell_std=z.std(-1,unbiased=False).mean().item(),min=z.min().item(),max=z.max().item()) for z in map(torch.cat,stats)]
 else:res['interventions']={ab:evaluate(m,test,ab=ab) for ab in ['no_B','self','drop']}
 prefix.with_suffix('.json').write_text(json.dumps(res,indent=2));print('DONE',a.arm,a.seed,res['dev']['bpb'],res['test']['bpb'],flush=True)
if __name__=='__main__':main()
