import json, pathlib, statistics as st, csv, math
R=pathlib.Path(__file__).parent; P=R/'results'; arms=['base','common','cell']; seeds=[173,271,907]
def read(p): return json.loads(p.read_text())
rows={a:{s:read(P/f'{a}_{s}.json') for s in seeds if (P/f'{a}_{s}.json').exists()} for a in arms}; archive={s:read(P/f'archive_{s}.postfit.json') for s in seeds if (P/f'archive_{s}.postfit.json').exists()}; post={a:{s:read(P/f'{a}_{s}.postfit.json') for s in seeds if (P/f'{a}_{s}.postfit.json').exists()} for a in arms}
mean=st.mean
out={'completed_fits':sum(len(x) for x in rows.values()),'completed_steps':sum(r['steps'] for a in rows.values() for r in a.values()),'training_byte_exposures':sum(r['train_bytes'] for a in rows.values() for r in a.values()),'all_three_seeds_complete':all(len(rows[a])==3 for a in arms),'arms':{},'paired':[],'archived_control_replay':[]}
for a,rs in rows.items():
 if not rs:continue
 z={'n':len(rs),'params':sorted(set(r['params'] for r in rs.values())),'mean_dev_bpb':mean(r['dev']['bpb'] for r in rs.values()),'mean_test_bpb':mean(r['test']['bpb'] for r in rs.values()),'mean_test_acc':mean(r['test']['acc'] for r in rs.values()),'max_stream_diff':max(r['stream']['max_logit_diff'] for r in rs.values()),'argmax_disagreement':sum(r['stream']['argmax_disagree'] for r in rs.values()),'stream_tokens':sum(r['stream']['n'] for r in rs.values()),'state_bytes':sorted(set(r['stream']['state_bytes'] for r in rs.values())),'intervention_delta_bpb':{k:mean(r['interventions'][k]['bpb']-r['test']['bpb'] for r in rs.values()) for k in next(iter(rs.values()))['interventions']}}
 if a!='base':z['gain_cross_cell_std']=[mean(r['gain_stats'][l]['cross_cell_std'] for r in rs.values()) for l in range(2)];z['gain_range']=[min(q['min'] for r in rs.values() for q in r['gain_stats']),max(q['max'] for r in rs.values() for q in r['gain_stats'])]
 if post[a]:
  z['lesion_n_models']=len(post[a]);z['lesion_mean_delta_by_layer']=[mean(d['delta'] for r in post[a].values() for d in r['lesions'] if d['layer']==l) for l in range(2)];z['lesion_range_by_layer']=[[min(d['delta'] for r in post[a].values() for d in r['lesions'] if d['layer']==l),max(d['delta'] for r in post[a].values() for d in r['lesions'] if d['layer']==l)] for l in range(2)];z['chunk_restart_max_diff']=max(r['chunk_restart']['logit_diff'] for r in post[a].values());z['chunk_restart_argmax_disagree']=sum(r['chunk_restart']['argmax_disagree'] for r in post[a].values());z['compact_state_bytes']=sorted(set(r['chunk_restart']['compact_state']['backing_storage_bytes'] for r in post[a].values()))
 out['arms'][a]=z
for s in seeds:
 if all(s in rows[a] for a in arms):
  c,b,g=(rows[a][s] for a in ('cell','base','common'));out['paired'].append({'seed':s,'same_initial_hash':len(set(r['init_sha256'] for r in (c,b,g)))==1,'dev_cell_minus_base':c['dev']['bpb']-b['dev']['bpb'],'dev_cell_minus_common':c['dev']['bpb']-g['dev']['bpb'],'test_cell_minus_base':c['test']['bpb']-b['test']['bpb'],'test_cell_minus_common':c['test']['bpb']-g['test']['bpb']})
 if s in rows['base'] and s in archive:
  r=rows['base'][s];old=archive[s]['composed'];out['archived_control_replay'].append({'seed':s,'dev_delta':r['dev']['bpb']-old['dev']['bpb'],'test_delta':r['test']['bpb']-old['test']['bpb'],'trained_weight_hash_match':post['base'].get(s,{}).get('weight_hash')==old['weight_hash'] if s in post['base'] else None})
out['advance_gate']=out['all_three_seeds_complete'] and all(x['dev_cell_minus_base']<=-.01 and x['dev_cell_minus_common']<=-.01 and x['same_initial_hash'] for x in out['paired']);out['archive_self_mean_test_bpb']=mean(r['self']['test']['bpb'] for r in archive.values()) if archive else None
(R/'aggregate.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
with (R/'summary.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['arm','seed','params','steps','train_byte_exposures','dev_bpb','test_bpb','test_accuracy','train_seconds','state_bytes']);
 for a,rs in rows.items():
  for s,r in rs.items():w.writerow([a,s,r['params'],r['steps'],r['train_bytes'],r['dev']['bpb'],r['test']['bpb'],r['test']['acc'],r['train_seconds'],r['stream']['state_bytes']])
