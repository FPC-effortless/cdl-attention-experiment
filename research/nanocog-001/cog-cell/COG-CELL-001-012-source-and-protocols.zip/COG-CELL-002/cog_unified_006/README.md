# COG-UNIFIED-006 — Conditional operator composition

Completed CPU pilot: 12 trained checkpoints (4 arms × 3 seeds), 12,000 optimizer steps, 6,144,000 next-byte training exposures. Three COG arms have 1,018,426 parameters; the RoPE SDPA control has 1,016,800. All use identical training examples per seed, schedule and objective. See PROTOCOL.md and SUPPLEMENT.md for the pre-fit primary gate and external-control protocol.

## Findings

Original held-article mean BPB: self 2.833026; composed 2.836801; additive 2.851279; transformer 2.927544. The conditional cross-unit model wins all three seeds against additive and Transformer, but only one of three against self. The primary qualification gate fails. A secondary audit found two 65-byte test windows verbatim in training; excluding them yields respectively 2.833592, 2.837325, 2.851869 and 2.928155 BPB, preserving the ordering. No hyperparameters were changed after viewing test scores.

Interventions show a useful message path but much weaker dependence on the cross-unit conditional branch: mean +1.544029 BPB for dropping all messages and +0.024278 for setting the neighbor branch to zero. Replacing neighbor with self raises loss by 0.043197. These post-training interventions cause distribution shift; they do not establish superiority, semantic roles or causal necessity for an optimized alternative.

All models trained with 64-byte contexts. The COG variants carry 3,136 bytes of recurrent state per sequence across both layers. Equal-target 1,024-byte history gives no material improvement over 256 bytes; Transformer extrapolation degrades sharply under this limited training regime. No claim of long-context reasoning or general superiority. Fixed ring topology, soft state, CPU FP32, no FLOP match, architecture-specific hyperparameter tuning, 10M models, Shakespeare benchmark, GPU, or external recurrent baselines. Timing is a descriptive Python CPU implementation measurement, not optimized-kernel or hardware-independent speed.

## Reproduction

Python 3.13.5, PyTorch 2.10.0+cpu, Gensim 4.4.0 (see environment.json). Run from the extracted directory. `corpus.json` is the cleaned Wikipedia fixture; article titles and exact hashes in corpus_manifest.json provide attribution and identity. Source is the English Wikipedia fixture distributed with Gensim's test data, original article content subject to Wikipedia licensing; preprocessing removes markup/normalizes whitespace. `prepare.py` regenerates it using the local installed fixture. All results are from this corpus, not directly comparable to UNIFIED-005 BPB on Lee news.

```
for seed in 173 271 907; do
  for arm in self additive composed; do
    python run.py --arm "$arm" --seed "$seed" --steps 1000
  done
  python transformer.py --seed "$seed" --steps 1000
done
python clean_eval.py
python context_span.py
python layer_diagnostic.py
python benchmark.py
python summarize.py
```

Raw seed-specific JSON, training logs, checkpoints, aggregate.json, summary.csv, clean_eval.json, context_span.json, layer_diagnostic.json, corpus_audit.json, benchmark.json and source are retained. The aggregate resampling intervals are exploratory, not confirmatory inference: only three training seeds and fourteen test articles. Streaming checks use numerical FP32 tolerance rather than bitwise state equality.
