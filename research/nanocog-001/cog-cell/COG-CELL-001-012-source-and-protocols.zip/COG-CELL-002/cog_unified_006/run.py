import argparse,json,math,pathlib,time
import torch
from torch import nn
import torch.nn.functional as F
P=pathlib.Path(__file__).parent
K=4;D=196;V=256;T=64;H=D//K
from previous_reference import scan
class GroupLinear(nn.Module):
 def __init__(self):
  super().__init__();self.w=nn.Parameter(torch.empty(K,H,H));self.b=nn.Parameter(torch.zeros(K,H));nn.init.uniform_(self.w,-1/math.sqrt(H),1/math.sqrt(H))
 def forward(self,x):return torch.einsum('...ki,koi->...ko',x,self.w)+self.b
class Block(nn.Module):
 def __init__(self,arm):
  super().__init__();self.arm=arm;self.norm=nn.LayerNorm(D);self.inp=nn.Linear(D,2*D);self.pub=nn.Linear(D,D);self.route=nn.Linear(D,2*K+1);self.A=GroupLinear();self.B=GroupLinear();self.msgnorm=nn.LayerNorm(D);self.recv=nn.Linear(D,D);self.combine=nn.Linear(D,D);self.out=nn.Linear(D,D);self.norm2=nn.LayerNorm(D);self.ff=nn.Sequential(nn.Linear(D,584),nn.GELU(),nn.Linear(584,D))
 def forward(self,h,state=None,ab=None):
  u=self.norm(h);z,a=self.inp(u).chunk(2,-1);r,rs=scan(z.tanh(),.5+.49*a.sigmoid(),None if state is None else state[0]);q=r+u;v=self.pub(q).tanh().unflatten(-1,(K,H));w,rp,g=self.route(q).split([K,K,1],-1);w=w.sigmoid()*2/K;rp=rp.sigmoid()*2/K
  gate=.8*g.sigmoid()*w;ms,last=scan(v,1-gate[...,None],None if state is None else state[1]);m=ms*rp[...,None]*K
  a=self.A(m).tanh();src=m if self.arm=='self' else m.roll(1,-2)
  if ab=='self':src=m
  if ab=='reverse':src=m.roll(-1,-2)
  if ab=='cross':src=m.roll(1,-2)
  b=self.B(src).tanh()
  if ab=='no_B':b=torch.zeros_like(b)
  if ab=='no_A':a=torch.zeros_like(a)
  y=a+b if self.arm=='additive' else a*(1+b)
  msg=self.recv(self.msgnorm(y.flatten(-2)))
  if ab=='drop':msg=torch.zeros_like(msg)
  h=h+self.out(r+self.combine(q).sigmoid()*msg);h=h+self.ff(self.norm2(h));return h,(rs,last)
class LM(nn.Module):
 def __init__(self,arm):
  super().__init__();self.arm=arm;self.emb=nn.Embedding(V,D);self.layers=nn.ModuleList([Block(arm) for _ in range(2)]);self.norm=nn.LayerNorm(D);self.head=nn.Linear(D,V,bias=False);self.head.weight=self.emb.weight;nn.init.normal_(self.emb.weight,std=.02)
 def forward(self,x,state=None,ab=None,with_state=False):
  h=self.emb(x);ss=[]
  for i,l in enumerate(self.layers):h,s=l(h,None if state is None else state[i],ab);ss.append(s)
  out=self.head(self.norm(h));return (out,ss) if with_state else out

def data():
 ds=json.loads((P/'corpus.json').read_text());return {k:[torch.tensor(list(d['text'].encode()),dtype=torch.long) for d in v] for k,v in ds.items()}
def train_data(ds):
 t=torch.cat(ds);starts=[];off=0
 for d in ds:starts.append(torch.arange(off,off+len(d)-T));off+=len(d)
 return t,torch.cat(starts)
def windows(d,T,n):
 pos=torch.linspace(0,len(d)-T-1,n).long();return d[pos[:,None]+torch.arange(T+1)[None]]
@torch.no_grad()
def evaluate(m,ds,ab=None):
 m.eval();ls=n=ok=0;doc_loss=[]
 for d in ds:
  dl=dn=0
  for a in windows(d,T,24).split(8):
   x,y=a[:,:-1],a[:,1:];z=m(x,ab=ab);l=F.cross_entropy(z.flatten(0,1),y.flatten(),reduction='sum').item();ls+=l;dl+=l;dn+=y.numel();n+=y.numel();ok+=(z.argmax(-1)==y).sum().item()
  doc_loss.append(dl/dn/math.log(2))
 return {'bpb':ls/n/math.log(2),'acc':ok/n,'n':n,'doc_bpb':doc_loss}
@torch.no_grad()
def history(m,ds):
 m.eval();loss=[0.,0.];n=0
 for d in ds:
  for a in windows(d,256,8).split(4):
   y=a[:,193:257];short=m(a[:,192:256]);long=m(a[:,:256])[:,-64:]
   for i,z in enumerate([short,long]):loss[i]+=F.cross_entropy(z.flatten(0,1),y.flatten(),reduction='sum').item()
   n+=y.numel()
 return {'n':n,'reset_bpb':loss[0]/n/math.log(2),'full_bpb':loss[1]/n/math.log(2)}
@torch.no_grad()
def streaming(m,d):
 m.eval();x=d[:512][None];z,s=m(x,with_state=True);st=None;ys=[]
 for i in range(x.size(1)):
  o,st=m(x[:,i:i+1],state=st,with_state=True);ys.append(o)
 out=torch.cat(ys,1);return {'n':x.size(1),'max_logit_diff':(z-out).abs().max().item(),'argmax_disagree':(z.argmax(-1)!=out.argmax(-1)).sum().item(),'state_bytes':sum(v.numel()*v.element_size() for l in s for v in l),'causal_max_diff':(z[:,:128]-m(x[:,:128])).abs().max().item()}
def train(a):
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(a.seed);ds=data();t,starts=train_data(ds['train']);m=LM(a.arm);nparams=sum(p.numel() for p in m.parameters());g=torch.Generator().manual_seed(100000+a.seed);opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01);log=[];elapsed=0.;m.train()
 for i in range(1,a.steps+1):
  pos=starts[torch.randint(len(starts),(8,),generator=g)];batch=t[pos[:,None]+torch.arange(T+1)[None]];x,y=batch[:,:-1],batch[:,1:];s=time.perf_counter();opt.param_groups[0]['lr']=.001*min(1,i/50)*(.2+.8*.5*(1+math.cos(math.pi*i/a.steps)));opt.zero_grad(set_to_none=True);z=m(x);ce=F.cross_entropy(z.flatten(0,1),y.flatten());ce.backward();nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step();elapsed+=time.perf_counter()-s
  if i in [1,a.steps//2,a.steps]:
   val=evaluate(m,ds['dev']);m.train();log.append(dict(step=i,ce=ce.item(),val_bpb=val['bpb']));print(a.arm,a.seed,i,log[-1],flush=True)
 torch.save(dict(arm=a.arm,seed=a.seed,weights=m.state_dict()),P/f'{a.arm}_{a.seed}.pt')
 res=dict(arm=a.arm,seed=a.seed,params=nparams,steps=a.steps,batch=8,context=T,train_bytes=a.steps*8*T,train_seconds=elapsed,history_train=log,dev=evaluate(m,ds['dev']),test=evaluate(m,ds['test']),history=history(m,ds['test']),stream=streaming(m,ds['test'][0]))
 res['interventions']={ab:evaluate(m,ds['test'],ab=ab) for ab in ['self','reverse','cross','no_B','no_A','drop']};(P/f'{a.arm}_{a.seed}.json').write_text(json.dumps(res,indent=2));print('DONE',a.arm,a.seed,nparams,res['test']['bpb'],res['history'],flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--arm',choices=['self','additive','composed'],required=True);p.add_argument('--seed',type=int,required=True);p.add_argument('--steps',type=int,default=1000);train(p.parse_args())
