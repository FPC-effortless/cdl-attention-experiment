#!/bin/bash
cd /mnt/data/cog_cell_010
cat jobs.txt | xargs -n2 -P4 bash -c 'OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=1 python native010/run010.py "$0" "$1" > results/${0}_${1}.log 2>&1; echo "$0 $1 $?" >> exit_status'
