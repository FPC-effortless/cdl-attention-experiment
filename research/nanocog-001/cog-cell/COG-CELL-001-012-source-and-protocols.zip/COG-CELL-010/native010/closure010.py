'''Retrospective mechanism diagnostic: distinguish matrix-relation satisfaction from action on learned value states. No oracle input during native model evaluation.'''
from run010 import *
@torch.no_grad()
def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);rng=np.random.default_rng(1001021);out={}
 for arm in ARMS:
  for seed in SEEDS:
   m=model(arm);m.load_state_dict(torch.load(ROOT/'results'/f'{arm}_{seed}.pt',weights_only=True)['weights']);m.eval();l=m.layers[0];_,st=m(torch.arange(16)[:,None],with_state=True);s=st[0][1][...,:16].unflatten(-1,(l.blocks,l.dim)).double();_,Q,g=algebra(m);Q=Q.double();I=torch.eye(l.dim,dtype=Q.dtype);T=Q[0];rels=[torch.linalg.matrix_power(T,16)-I,Q[1]-torch.linalg.matrix_power(T,3)]+[Q[o]@T-torch.linalg.matrix_power(T,int(OPS[o,0]))@Q[o] for o in range(2,6)];den=s.square().sum().clamp_min(1e-16);metrics={'relation_action_relative_rms':[float(((a@s[...,None]).square().sum()/den).sqrt()) for a in rels], 'T_to_I_relative_rms':float((((T-I)@s[...,None]).square().sum()/den).sqrt()),'state_norm_mean':float(s.flatten(1).norm(dim=-1).mean())}
   # Is the pure learned operator capable of correct value-to-value transformation? Decode nearest start state, not native model output.
   # Use newly seeded sequences; full true state value is used only for scoring.
   canon=s.flatten(1);cases=256;start=torch.from_numpy(rng.integers(16,size=cases));ops=torch.from_numpy(rng.integers(6,size=(cases,1024)));v=s[start];t=start.clone();r={};all_ok=torch.ones(cases,dtype=torch.bool);all_native=torch.ones(cases,dtype=torch.bool)
   for j in range(1024):
    idx=ops[:,j];v=(Q[idx]@v[...,None]).squeeze(-1);a=torch.from_numpy(OPS)[idx];t=(a[:,0]*t+a[:,1])%16;pred=torch.cdist(v.flatten(1),canon).argmin(-1);ok=pred==t;all_ok&=ok
    if j+1 in [1,4,8,12,16,64,256,1024]:r[str(j+1)]={'n':cases,'correct':int(ok.sum()),'all_steps_correct':int(all_ok.sum()),'relative_error':float(((v-s[t]).square().sum()/s[t].square().sum().clamp_min(1e-16)).sqrt())}
   metrics['pure_operator_nearest_initial_state']=r;out[f'{arm}_{seed}']=metrics;print(arm,seed,{k:v['correct'] for k,v in r.items()},flush=True)
 (ROOT/'closure.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__':main()
