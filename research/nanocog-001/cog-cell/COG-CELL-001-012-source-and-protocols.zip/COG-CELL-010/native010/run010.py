import sys,pathlib,math,time,json,hashlib,argparse
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
import run009 as old
from run009 import orig,scan,affine_scan,OPS,SEEDS,STEPS,BATCH,batchdata,panels,hash_tensors,eval_rows,encode,held,answer
ROOT=pathlib.Path(__file__).resolve().parents[1]; K,D,H=orig.K,orig.D,orig.H
ARMS=[f'w{w}_{o}' for w in (4,8,16) for o in ('trace','algebra')]

def generator(coeff,basis,dim,idx):
 # [U,K,16] x [K,blocks,16,tri] -> [U,K,blocks,tri]
 x=torch.einsum('ukr,kbrp->ukbp',coeff,basis);S=x.new_zeros(*x.shape[:-1],dim,dim);S[...,idx[0],idx[1]]=x;return S-S.transpose(-1,-2)

def operators(l,u):
 par=l.rotation(u).unflatten(-1,(K,20));c=par[...,:16];keep=(.85+par[...,16:].unflatten(-1,(l.blocks,4//l.blocks)).mean(-1)).clamp(0,1)
 S=generator(c,l.basis,l.dim,l.idx);Q=torch.matrix_exp(S);return Q,keep

class WideBlock(orig.Block):
 def forward(self,h,state=None,ab=None):
  if ab=='bypass':return super().forward(h,state)
  u=self.norm(h);z,a=self.inp(u).chunk(2,-1);r,rs=scan(z.tanh(),.5+.49*a.sigmoid(),None if state is None else state[0]);q=r+u;v=self.pub(q).tanh().unflatten(-1,(K,H));w,rp,g=self.route(q).split([K,K,1],-1);w=w.sigmoid()*2/K;rp=rp.sigmoid()*2/K;gate=.8*g.sigmoid()*w
  prev=None if state is None else state[1];tail,tail_last=scan(v[...,16:],1-gate[...,None],None if prev is None else prev[...,16:]);dim=self.dim;nb=self.blocks
  Q,keep=operators(self,self.unique_u);Q=Q[self.inverse];keep=keep[self.inverse]
  if ab=='damp':keep=keep*.99
  if ab=='no_rotation':Q=torch.eye(dim,dtype=Q.dtype,device=Q.device).expand_as(Q)
  vv=v[...,:16].unflatten(-1,(nb,dim));vv=vv/vv.norm(dim=-1,keepdim=True).clamp_min(1.)
  rot,rl=affine_scan(keep[...,None,None]*Q,((1-keep)[...,None]*vv)[...,None],None if prev is None else prev[...,:16].unflatten(-1,(nb,dim))[...,None]);rot=rot.squeeze(-1).flatten(-2);rl=rl.squeeze(-1).flatten(-2);ms=torch.cat((rot,tail),-1);last=torch.cat((rl,tail_last),-1);m=ms*rp[...,None]*K
  aa=self.A(m).tanh();src=m.roll(1,-2) if ab!='self' else m;bb=self.B(src).tanh();y=aa*(1+bb);msg=self.recv(self.msgnorm(y.flatten(-2)));h=h+self.out(r+self.combine(q).sigmoid()*msg);h=h+self.ff(self.norm2(h));return h,(rs,last)

class WideLM(orig.LM):
 def forward(self,x,state=None,ab=None,with_state=False):
  l=self.layers[0];tokens,inv=torch.unique(x,sorted=True,return_inverse=True);l.inverse=inv;l.unique_u=l.norm(self.emb(tokens));return super().forward(x,state,ab,with_state)

def model(arm):
 m=orig.LM('composed');m.__class__=WideLM;l=m.layers[0];l.__class__=WideBlock;l.dim=int(arm.split('_')[0][1:]);l.blocks=16//l.dim;l.register_buffer('idx',torch.triu_indices(l.dim,l.dim,1),persistent=False);l.rotation=nn.Linear(D,K*20);nn.init.normal_(l.rotation.weight,std=.005);nn.init.zeros_(l.rotation.bias)
 # same projection shape/init across widths; width-specific basis
 l.basis=nn.Parameter(torch.randn(K,l.blocks,16,l.dim*(l.dim-1)//2)*(.2/math.sqrt(16)))
 return m

def algebra(m):
 l=m.layers[0];Q,g=operators(l,l.norm(m.emb(torch.arange(32,38,device=l.basis.device))));T=Q[0];I=torch.eye(l.dim,device=Q.device,dtype=Q.dtype);relations=[torch.linalg.matrix_power(T,16)-I,Q[1]-torch.linalg.matrix_power(T,3)]
 for o in range(2,6):relations.append(Q[o]@T-torch.linalg.matrix_power(T,int(OPS[o,0]))@Q[o])
 # normalize by dimension (mean squared Frobenius per row), equally weighted constraints
 return torch.stack([r.square().sum((-1,-2)).mean()/l.dim for r in relations]),Q,g

@torch.no_grad()
def repeat(m,ab=None,dense=False):
 x=torch.arange(16)[:,None];_,st=m(x,with_state=True,ab=ab);z=torch.full((16,1),32,dtype=torch.long);out={};last=0;allok=torch.ones(16,dtype=torch.bool);total=0
 for n in [1,2,4,8,16,32,64,128,256,512,1024]:
  for start in range(last,n,16):
   length=min(16,n-start);logits,st=m(z.expand(-1,length),state=st,with_state=True,ab=ab);preds=logits.argmax(-1);targets=(x+torch.arange(start+1,start+length+1)[None])%16;ok=preds==targets;allok&=ok.all(1);total+=int(ok.sum())
  pred=preds[:,-1];target=(x[:,0]+n)%16;s=st[0][1][...,:16];span=(s.max(0).values-s.min(0).values).abs().max().item();out[str(n)]={'correct':int((pred==target).sum()),'all_steps_correct':int(allok.sum()),'total_correct':total,'predictions':pred.tolist(),'subspace_span':span};last=n
 return out

@torch.no_grad()
def diag(m):
 l=m.layers[0];r,Q,g=algebra(m);ortho=(Q.transpose(-1,-2)@Q-torch.eye(l.dim)).abs().max();comm=(Q[0]@Q[2]-Q[2]@Q[0]).norm(dim=(-1,-2)).mean();return {'relations':r.tolist(),'mean_relation':float(r.mean()),'orthogonality_max':float(ortho),'mean_commutator_frobenius':float(comm),'op_keep_mean':float(g.mean()),'op_keep_fraction_one':float((g==1).float().mean()),'op_keep':g.tolist()}

def main(arm,seed,steps=1000):
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(seed);m=model(arm);p=ROOT/'results'/f'{arm}_{seed}';ih=hash_tensors(m.parameters());baseih=hash_tensors(v for k,v in m.named_parameters() if 'rotation' not in k and 'basis' not in k);bs=batchdata(seed,steps);bh=hash_tensors(v for row in bs for v in row);opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01);log=[];start=time.perf_counter();labels=tokens=0
 for i,(x,y) in enumerate(bs,1):
  opt.param_groups[0]['lr']=.001*min(1,i/50)*(.2+.8*.5*(1+math.cos(math.pi*i/steps)));opt.zero_grad(set_to_none=True);z=m(x)[:,1:];ce=F.cross_entropy(z.flatten(0,1),y.flatten());reg=torch.zeros(())
  if arm.endswith('algebra'):reg=algebra(m)[0].mean()
  loss=ce+.25*min(1,i/200)*reg;loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True);opt.step();labels+=y.numel();tokens+=x.numel()
  if i in [1,250,500,750,1000,steps]:
   row=dict(step=i,ce=ce.item(),reg=reg.item(),trace_acc=float((z.argmax(-1)==y).float().mean()));log.append(row);print(arm,seed,row,flush=True)
 sec=time.perf_counter()-start;ck=p.with_suffix('.pt');torch.save(dict(arm=arm,seed=seed,weights=m.state_dict()),ck);ps=panels();scores={k:eval_rows(m,v) for k,v in ps.items()};rep=repeat(m);gd=diag(m);st=old.stream(m);abl={}
 for ab in ['no_rotation','damp','self']:
  abl[ab]={k:eval_rows(m,ps[k],ab) for k in ['held4','allowed8','allowed12']}
 res=dict(arm=arm,seed=seed,params=sum(p.numel() for p in m.parameters()),steps=steps,training_examples=steps*BATCH,supervised_positions=labels,tokens=tokens,train_seconds=sec,init_sha256=ih,base_init_sha256=baseih,batch_sha256=bh,checkpoint_sha256=hashlib.sha256(ck.read_bytes()).hexdigest(),log=log,scores=scores,repeat=rep,gate_diag=gd,stream=st,ablation=abl);p.with_suffix('.json').write_text(json.dumps(res,indent=2));print('DONE',arm,seed,{k:round(v['acc'],4) for k,v in scores.items()},flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('arm',choices=ARMS);p.add_argument('seed',type=int);p.add_argument('--steps',type=int,default=1000);a=p.parse_args();main(a.arm,a.seed,a.steps)
