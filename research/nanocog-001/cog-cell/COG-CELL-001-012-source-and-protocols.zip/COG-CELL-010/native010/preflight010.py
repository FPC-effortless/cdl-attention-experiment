from run010 import *
torch.set_num_threads(1);torch.set_num_interop_threads(1)
for seed in SEEDS:
 torch.manual_seed(seed);base=old.model('base');x=torch.randint(0,38,(3,7));b,bs=base(x,with_state=True)
 for w in (4,8,16):
  torch.manual_seed(seed);m=model(f'w{w}_trace');v,st=m(x,ab='bypass',with_state=True);assert torch.equal(b,v);assert all(torch.equal(c,d) for l,k in zip(bs,st) for c,d in zip(l,k));assert all(torch.equal(p,m.state_dict()[k]) for k,p in base.state_dict().items());loss=m(x).square().mean()+algebra(m)[0].mean();loss.backward();assert all(torch.isfinite(p.grad).all() for p in m.parameters() if p.grad is not None);print(seed,w,sum(p.numel() for p in m.parameters()),old.stream(m),flush=True)
for d in (4,8,16):
 for n in [1,3,7,16,33]:
  S=torch.randn(2,n,4,16//d,d,d,dtype=torch.float64,requires_grad=True);Q=torch.matrix_exp(S-S.transpose(-1,-2));assert torch.allclose(Q@Q.transpose(-1,-2),torch.eye(d,dtype=Q.dtype),atol=1e-10,rtol=1e-10);A=Q*.9;b=torch.randn(2,n,4,16//d,d,1,dtype=torch.float64,requires_grad=True);s=torch.randn(2,4,16//d,d,1,dtype=torch.float64);y,l=affine_scan(A,b,s);ys=[]
  for i in range(n):s=A[:,i]@s+b[:,i];ys.append(s)
  ref=torch.stack(ys,1);assert torch.allclose(y,ref,atol=1e-10,rtol=1e-10);gp=torch.autograd.grad(y.square().sum(),[S,b],retain_graph=True);gr=torch.autograd.grad(ref.square().sum(),[S,b]);assert all(torch.allclose(c,e,atol=1e-8,rtol=1e-8) for c,e in zip(gp,gr));print('scan',d,n,float((y-ref).abs().max().detach()),flush=True)
