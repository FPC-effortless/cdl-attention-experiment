'''Exhaustive operation-order test and fresh long-horizon panels. Sequence generation fixed before secondary evaluation.''' 
from run010 import *
@torch.no_grad()
def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);rng=np.random.default_rng(10100117);pairs=[(x,(a,b)) for x in range(16) for a in range(6) for b in range(a+1,6) if answer(x,(a,b))!=answer(x,(b,a))];reverse=[(x,tuple(reversed(o))) for x,o in pairs];original=panels();new={}
 for n in [8,12,16,32,64]:
  rows=old.sample(rng,512,n,True);seen=set(original.get(f'held{n}',[]))|set(original.get(f'allowed{n}',[]));rows=[r for r in rows if r not in seen];new[f'fresh_held{n}']=rows
 res={}
 for seed in SEEDS:
  for arm in ['base','orthogonal']+ARMS:
   p=ROOT/('controls' if arm in ['base','orthogonal'] else 'results')/f'{arm}_{seed}.pt';m=old.model(arm) if arm in ['base','orthogonal'] else model(arm);m.load_state_dict(torch.load(p,weights_only=True)['weights']);a=eval_rows(m,pairs);b=eval_rows(m,reverse);targets=[answer(x,o) for x,o in pairs];rev_targets=[answer(x,o) for x,o in reverse];ok=sum(p==ta and q==tb for p,q,ta,tb in zip(a['predictions'],b['predictions'],targets,rev_targets));order={'n':len(pairs),'both_correct':ok,'both_correct_rate':ok/len(pairs),'distinct_predictions':sum(p!=q for p,q in zip(a['predictions'],b['predictions']))};fresh={k:eval_rows(m,v) for k,v in new.items()};res[f'{arm}_{seed}']={'order':order,'fresh':fresh};print(arm,seed,order['both_correct_rate'],{k:round(v['acc'],4) for k,v in fresh.items()},flush=True);(ROOT/'order.json').write_text(json.dumps(res,indent=2))
if __name__=='__main__':main()
