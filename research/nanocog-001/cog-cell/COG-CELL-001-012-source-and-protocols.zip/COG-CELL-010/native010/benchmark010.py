'''Retrospective operator caching experiment: all 256 token-conditioned matrices precomputed from frozen learned weights, never task answers. Run after training in isolation.''' 
from run010 import *
import run010 as cur
import statistics
orig_operators=cur.operators
class CachedWideLM(WideLM):
 def forward(self,x,state=None,ab=None,with_state=False):
  l=self.layers[0];l.inverse=x;l.unique_u=None;return orig.LM.forward(self,x,state,ab,with_state)

def cached_operators(l,u):
 return l.frozen_table if hasattr(l,'frozen_table') else orig_operators(l,u)

@torch.no_grad()
def cache(m):
 l=m.layers[0];start=time.perf_counter();l.frozen_table=orig_operators(l,l.norm(m.emb(torch.arange(256))));sec=time.perf_counter()-start;m.__class__=CachedWideLM;cur.operators=cached_operators;return {'cache_bytes':sum(t.numel()*t.element_size() for t in l.frozen_table),'build_ms':sec*1000}

@torch.no_grad()
def timed(m,seq):
 m.eval();res={}
 for n in (64,512):
  x=seq[:,:n];m(x);vals=[]
  for _ in range(5):
   a=time.perf_counter();m(x);vals.append((time.perf_counter()-a)*1e6/n)
  res[f'prefill{n}_us_per_token']=statistics.median(vals);res[f'prefill{n}_all']=vals
 x=seq[:,:128];vals=[]
 for _ in range(4):
  st=None;t=time.perf_counter()
  for i in range(x.size(1)):_,st=m(x[:,i:i+1],state=st,with_state=True)
  vals.append((time.perf_counter()-t)*1e6/x.size(1))
 res['decode_us_per_token']=statistics.median(vals[1:]);res['decode_all']=vals[1:];return res

@torch.no_grad()
def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(100100);seq=torch.randint(0,256,(1,512));x=torch.cat([torch.arange(256)[None],seq[:,:256]],1);res={}
 for seed in SEEDS:
  for arm in ['base','orthogonal','w4_trace','w8_trace','w16_trace']:
   p=ROOT/('controls' if arm in ['base','orthogonal'] else 'results')/f'{arm}_{seed}.pt';m=old.model(arm) if arm in ['base','orthogonal'] else model(arm);m.load_state_dict(torch.load(p,weights_only=True)['weights']);m.eval();entry={'eager':timed(m,seq)}
   if arm in ARMS:
    z,s=m(x,with_state=True);entry.update(cache(m));zc,sc=m(x,with_state=True);diff=float((z-zc).abs().max());state_diff=max(float((a-b).abs().max()) for l,k in zip(s,sc) for a,b in zip(l,k));entry['parity']={'positions':x.numel(),'argmax_disagree':int((z.argmax(-1)!=zc.argmax(-1)).sum()),'max_logit_diff':diff,'max_state_diff':state_diff};entry['cached']=timed(m,seq)
    # evaluate primary panels after caching; compare all predicted tokens to original receipts
    ps=panels();j=json.loads((ROOT/'results'/f'{arm}_{seed}.json').read_text());entry['task_parity']={k:sum(a!=b for a,b in zip(eval_rows(m,ps[k])['predictions'],j['scores'][k]['predictions'])) for k in ['held4','allowed8','allowed12']}
   res[f'{arm}_{seed}']=entry;print(arm,seed,entry['eager']['decode_us_per_token'],entry.get('cached',{}).get('decode_us_per_token'),flush=True);(ROOT/'benchmark.json').write_text(json.dumps(res,indent=2))
if __name__=='__main__':main()
