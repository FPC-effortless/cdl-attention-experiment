'''Exploratory post-training intervention, specified after first seed: separate operator quality from retention-gate attenuation.'''
from run010 import *
import run010 as cur
from benchmark010 import cache,orig_operators
@torch.no_grad()
def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);ps=panels();out={}
 for seed in SEEDS:
  for arm in ARMS:
   m=model(arm);m.load_state_dict(torch.load(ROOT/'results'/f'{arm}_{seed}.pt',weights_only=True)['weights']);m.eval();cache(m);l=m.layers[0];Q,g=l.frozen_table;g=g.clone();g[32:38]=1.;l.frozen_table=(Q,g);scores={k:eval_rows(m,ps[k]) for k in ['held2','held4','allowed8','allowed12']};rep=repeat(m);out[f'{arm}_{seed}']={'scores':scores,'repeat':rep};print(arm,seed,{k:round(v['acc'],4) for k,v in scores.items()},flush=True)
 (ROOT/'retention.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__':main()
