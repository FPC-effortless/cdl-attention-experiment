from run010 import *
import zipfile
@torch.no_grad()
def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);ps=panels();n=0;replays=0;out={};controls={};batches={};inits={}
 for seed in SEEDS:
  for arm in ['base','orthogonal']+ARMS:
   root=ROOT/('controls' if arm in ['base','orthogonal'] else 'results');p=root/f'{arm}_{seed}';j=json.loads(p.with_suffix('.json').read_text());ck=p.with_suffix('.pt');assert hashlib.sha256(ck.read_bytes()).hexdigest()==j['checkpoint_sha256'];assert j['steps']==1000 and j['training_examples']==32000
   if seed in batches:assert j['batch_sha256']==batches[seed]
   else:batches[seed]=j['batch_sha256'];inits[seed]=j['base_init_sha256']
   assert j['base_init_sha256']==inits[seed]
   for panel,r in j['scores'].items():
    yy=[answer(x,ops) for x,ops in ps[panel]];assert len(yy)==r['n']==len(r['predictions']);assert sum(a==b for a,b in zip(yy,r['predictions']))==r['correct'];n+=r['n']
   m=old.model(arm) if arm in ['base','orthogonal'] else model(arm);m.load_state_dict(torch.load(ck,weights_only=True,map_location='cpu')['weights']);m.eval()
   panels_to_check=list(ps) if arm in ['base','orthogonal'] else ['held2','held4','allowed8','allowed12']
   for k in panels_to_check:
    r=eval_rows(m,ps[k]);assert r['predictions']==j['scores'][k]['predictions'],(arm,seed,k);replays+=1
   if arm in ['base','orthogonal']:
    controls[f'{arm}_{seed}']={'scores':{k:j['scores'][k]['acc'] for k in ps},'replayed_panels':panels_to_check,'stream':old.stream(m)}
   else:
    r=repeat(m);assert r==j['repeat'],(arm,seed,'repeated');out[f'{arm}_{seed}']={'repeat_replayed':True,'stream':old.stream(m)}
   print('audited',arm,seed,flush=True)
 for seed in SEEDS:
  for w in (4,8,16):
   a=json.loads((ROOT/'results'/f'w{w}_trace_{seed}.json').read_text());b=json.loads((ROOT/'results'/f'w{w}_algebra_{seed}.json').read_text());assert a['init_sha256']==b['init_sha256']
 r={'predictions_recalculated':n,'checkpoint_panel_replays':replays,'repeated_trajectories_replayed':len(out),'matched_init_pairs':9,'controls':controls,'new_models':out};(ROOT/'audit.json').write_text(json.dumps(r,indent=2));print({k:v for k,v in r.items() if k not in ['controls','new_models']},flush=True)
if __name__=='__main__':main()
