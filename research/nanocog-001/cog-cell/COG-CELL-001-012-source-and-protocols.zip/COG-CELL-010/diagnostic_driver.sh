#!/bin/bash
cd /mnt/data/cog_cell_010
for p in audit010 closure010 order010 retention010; do (OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=1 python native010/$p.py > $p.log 2>&1; echo "$p $?" >> diagnostic_exit) & done
wait
OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=1 python native010/benchmark010.py > benchmark010.log 2>&1; echo "benchmark010 $?" >> diagnostic_exit
