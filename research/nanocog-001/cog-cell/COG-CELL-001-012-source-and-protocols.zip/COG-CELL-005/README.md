# COG-CELL-005 native evidence bundle

Begin with `native005/README.md`, `native005/PROTOCOL.md`, and `native005/aggregate.json`. The full 18 newly trained checkpoints, 6 frozen language control checkpoints, original UNIFIED-006 source subset and source archive verification record, exact training/evaluation drivers, raw metrics, 192 grouped-operator lesions, prediction audit, and CPU benchmarks are included. The matched model and task-batch verification receipt is `native005/results_verification.json`. The bundle manifest verifies the actual packaged files.

Integrity check from the extracted bundle root: `sha256sum -c SHA256SUMS.txt`. No architecture promotion or repository changes are represented by this package.
