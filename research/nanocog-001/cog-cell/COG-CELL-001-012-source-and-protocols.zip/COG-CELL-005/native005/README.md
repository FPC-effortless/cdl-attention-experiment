# COG-CELL-005 — Native serial transformed-publication study

This is a continuation of COG-UNIFIED-006 and CELL-004, not a standalone substitute model. The native source and original full-manifest check are included. The archived checkpoint controls originate from CELL-002 (base) and CELL-004 (raw peer). The original full archive manifest lists additional files not reproduced in this focused bundle; `native005/archive_hash_check.txt` records the 68/68 check against the full recovered archive source tree before this study. The bundle-level SHA256SUMS manifest covers the actual packaged files.

## Implementation and controls
The native 2-layer, 4-unit-per-layer model with 49-dimensional unit states is unchanged except for the input to the existing grouped B transformation. The three feedback arms retain the identical CELL-004 recurrent peer-feedback mechanism and are matched in parameter count and initialization. The base has 400 fewer parameters. The serial-self arm controls only the B input source, not the recurrent-feedback path; it still has recurrent peer feedback. The serial-peer arm feeds transformed publication A_j into recipient B_i, with the original local multiplicative merge and shared readout. This is a two-stage output composition pathway, not an unrestricted autonomous neuron or a transformed-message recurrence.

`PROTOCOL.md`, `prefit_sha256.txt` and `supplementary_protocol.md` define fixed budgets, primary gates and diagnostics. The language fits reuse the original corpus and same 64-byte regime; controls are re-evaluated from frozen checkpoints. The independent structured task trains all four architectures from scratch, with matched batches at each seed. It uses six affine permutations modulo 16; only the three reciprocal heldout pair groups are guaranteed noncommuting (the full set includes commuting pairs). Every order reversal within those groups changes the correct label for all 16 start values. Atomic and familiar-depth panels intentionally overlap training support; all held-out pair and longer-depth panels have zero exact training-example overlap. The finite synthetic task is not general language or arbitrary compositional reasoning. Labels are final answers only.

## Reproduce
Run from `native005/` with Python 3.13.5, PyTorch 2.10.0+cpu, NumPy 2.3.5 (environment.json records the actual machine). No external downloads are required. Set `OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1`. The included checkpoint paths and relative imports match this layout.

```
python preflight.py
python task_preflight.py
python audit_task.py
python native005.py --arm serial_peer --seed 173
python composition_task.py --arm serial_peer --seed 173
```
All pairs are listed in `lm_jobs.txt` and `task_jobs.txt`. The included drivers ran within this research turn; don't rerun in the evidence directory unless you intend to overwrite generated records. After all 24 records exist, `task_lesions.py`, `bench005.py`, `summarize.py`, `audit_predictions.py` and `verify_results.py` produce diagnostics, aggregate tables, prediction-score replay and integrity checks. `benchmark.json` contains repeated timing raw values; rerun only with exclusive CPU access.

No original repository modifications, promotion or independent Veritas qualification. CPU-only; three seeds, reused language test/corpus, context 64; no 10M fit or strict base FLOP match. Direct task length generalization is tested only on the fixed finite operation family. Lesions are distribution-shifting interventions, not proof of a neuron possessing an identifiable semantic function. Do not interpret successful mechanism perturbations as architectural superiority.
