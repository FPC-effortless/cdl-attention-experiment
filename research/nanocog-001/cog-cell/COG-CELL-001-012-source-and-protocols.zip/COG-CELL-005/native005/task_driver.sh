#!/bin/bash
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
# Wait until LM run is complete, avoiding concurrent timing/training contention.
while [ ! -f lm_driver_exit ]; do sleep 2; done
cat task_jobs.txt | xargs -n2 -P4 bash -c 'python composition_task.py --arm "$0" --seed "$1" > "results/task_${0}_${1}.log" 2>&1; s=$?; printf "%s %s %s\n" "$0" "$1" "$s" >> task_exit_status; exit "$s"'
echo $? > task_driver_exit
