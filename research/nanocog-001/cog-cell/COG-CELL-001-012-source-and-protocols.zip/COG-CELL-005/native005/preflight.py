from native005 import *
torch.set_num_threads(1);torch.set_num_interop_threads(1);report=[]
for seed in SEEDS:
 ms={}
 for arm in ARMS:
  torch.manual_seed(seed);ms[arm]=model(arm)
 torch.manual_seed(seed);old=model004('peer_feedback');x=torch.randint(0,256,(2,31));y=torch.randint(0,256,(2,31));base=ms['base'];raw=ms['raw_peer'];peer=ms['serial_peer'];selfm=ms['serial_self']
 assert init_hash(raw)==init_hash(peer)==init_hash(selfm)==init_hash(old)
 assert all(torch.equal(v,peer.state_dict()[k]) for k,v in base.state_dict().items())
 z0,s0=base(x,with_state=True);z1,s1=peer(x,ab='bypass',with_state=True);F.cross_entropy(z0.flatten(0,1),y.flatten()).backward();F.cross_entropy(z1.flatten(0,1),y.flatten()).backward()
 gd=max((p.grad-dict(peer.named_parameters())[k].grad).abs().max().item() for k,p in base.named_parameters());assert torch.equal(z0,z1) and gd==0 and all(torch.equal(v,w) for a,b in zip(s0,s1) for v,w in zip(a,b))
 z0,s0=old(x,with_state=True);z1,s1=raw(x,with_state=True);assert torch.equal(z0,z1) and all(torch.equal(v,w) for a,b in zip(s0,s1) for v,w in zip(a,b));F.cross_entropy(z0.flatten(0,1),y.flatten()).backward();F.cross_entropy(z1.flatten(0,1),y.flatten()).backward();gd2=max((p.grad-dict(raw.named_parameters())[k].grad).abs().max().item() for k,p in old.named_parameters());assert gd2==0
 with torch.no_grad():
  z,s=peer(x,with_state=True);a,st=peer(x[:,:13],with_state=True);b,st2=peer(x[:,13:],state=st,with_state=True);chunk=(z[:,13:]-b).abs().max().item();prefix=(z[:,:13]-a).abs().max().item();assert chunk<1e-4 and prefix<1e-4
  # Verify serial peer transform truly influences B receiver: perturb A weights for neuron 0 only, keep state/input fixed.
  l=peer.layers[0];h=torch.randn(1,5,D);l.record=True;_,s=l(h);B0=l.last_b.clone();A0=l.last_a.clone();l.A.b[0].add_(.5);_,s2=l(h);delta=(l.last_b-B0).abs().amax(dim=(0,1,3)).tolist();assert delta[1]>0 and all(delta[i]==0 for i in (0,2,3));assert all(torch.equal(a,b) for a,b in zip(s,s2));l.A.b[0].sub_(.5)
 report.append(dict(seed=seed,params={k:sum(p.numel() for p in m.parameters()) for k,m in ms.items()},matched_init_sha256=init_hash(raw),bypass_gradient_diff=gd,raw_reference_gradient_diff=gd2,chunk_diff=chunk,prefix_diff=prefix,transform_effect_on_B=delta,compact_state_bytes=sum(v[0].numel()*v.element_size() for a in st2 for v in a)))
(ROOT/'preflight.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
