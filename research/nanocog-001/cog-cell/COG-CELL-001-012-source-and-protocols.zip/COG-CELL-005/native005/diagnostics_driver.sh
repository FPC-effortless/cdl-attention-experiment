#!/bin/bash
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
while [ ! -f task_driver_exit ]; do sleep 2; done
python task_lesions.py > task_lesions.log 2>&1; echo $? > task_lesions_exit
python bench005.py > benchmark.log 2>&1; echo $? > benchmark_exit
