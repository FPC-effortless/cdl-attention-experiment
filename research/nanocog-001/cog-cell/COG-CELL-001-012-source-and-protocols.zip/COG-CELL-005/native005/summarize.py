from pathlib import Path
import json,statistics as st,csv,math,hashlib
ROOT=Path(__file__).parent;ARMS=['base','raw_peer','serial_self','serial_peer'];SEEDS=[173,271,907]
def load(kind):
 r={}
 for a in ARMS:
  for s in SEEDS:
   p=ROOT/'results'/f'{kind}_{a}_{s}.json'
   if p.exists():r[a,s]=json.loads(p.read_text())
 return r
lm=load('lm');task=load('task');out={'lm_completed':len(lm),'lm_new_completed':sum(not z['reused'] for z in lm.values()),'task_completed':len(task),'lm':{},'task':{},'paired':{},'gates':{},'reproduced_controls':[]}
for a in ARMS:
 rows=[lm[a,s] for s in SEEDS if (a,s) in lm]
 if rows:
  info={k:st.mean(z[k]['bpb'] for z in rows) for k in ['dev','test']};info.update(n=len(rows),test_accuracy=st.mean(z['test']['acc'] for z in rows),state_bytes=[z['stream']['state_bytes'] for z in rows],stream_disagreement=sum(z['stream']['argmax_disagree'] for z in rows),stream_n=sum(z['stream']['n'] for z in rows),max_logit_diff=max(z['stream']['max_logit_diff'] for z in rows),train_seconds_mean=st.mean(z['train_seconds'] for z in rows) if not rows[0]['reused'] else None,mean_context_benefit=st.mean(z['history']['reset_bpb']-z['history']['full_bpb'] for z in rows))
  if rows[0].get('interventions'):info['intervention_delta_bpb']={k:st.mean(z['interventions'][k]['bpb']-z['test']['bpb'] for z in rows) for k in rows[0]['interventions']}
  out['lm'][a]=info
 rows=[task[a,s] for s in SEEDS if (a,s) in task]
 if rows:
  info={'n':len(rows),'panels':{k:{'mean_acc':st.mean(z['scores'][k]['acc'] for z in rows),'total_correct':sum(z['scores'][k]['correct'] for z in rows),'total_n':sum(z['scores'][k]['n'] for z in rows),'mean_nll':st.mean(z['scores'][k]['nll'] for z in rows)} for k in rows[0]['scores']},'order_both_correct':sum(z['order_check']['both_correct'] for z in rows),'order_changed':sum(z['order_check']['changed_prediction'] for z in rows),'order_total':sum(z['order_check']['n'] for z in rows),'train_seconds_mean':st.mean(z['train_seconds'] for z in rows)}
  if rows[0]['interventions']:info['intervention_delta_acc']={k:{j:st.mean(z['interventions'][k][j]['acc']-z['scores'][j]['acc'] for z in rows) for j in rows[0]['interventions'][k]} for k in rows[0]['interventions']}
  out['task'][a]=info
for a in ['base','raw_peer']:
 for s in SEEDS:
  if (a,s) in lm:
   p=ROOT.parent/('native002' if a=='base' else 'native004')/'results'/f'{"base" if a=="base" else "peer_feedback"}_{s}.json';old=json.loads(p.read_text());out['reproduced_controls'].append(dict(arm=a,seed=s,dev_diff=lm[a,s]['dev']['bpb']-old['dev']['bpb'],test_diff=lm[a,s]['test']['bpb']-old['test']['bpb']))
def paired(rows,control,metric):
 ds=[metric(rows['serial_peer',s])-metric(rows[control,s]) for s in SEEDS if ('serial_peer',s) in rows and (control,s) in rows];mean=st.mean(ds) if ds else None
 ci=None
 if len(ds)==3:
  d=4.3026527299*st.stdev(ds)/math.sqrt(3);ci=[mean-d,mean+d]
 return {'deltas':ds,'mean':mean,'illustrative_t95':ci}
for a in ARMS[:3]:
 out['paired'][a]={'lm_dev':paired(lm,a,lambda z:z['dev']['bpb']),'lm_test':paired(lm,a,lambda z:z['test']['bpb']),'task_held4':paired(task,a,lambda z:z['scores']['depth4_heldout']['acc']),'task_depth8':paired(task,a,lambda z:z['scores']['depth8_allowed']['acc'])}
out['gates']['lm']={str(s):{a:lm[a,s]['dev']['bpb']-lm['serial_peer',s]['dev']['bpb']>=.01 for a in ARMS[:3] if (a,s) in lm} for s in SEEDS if ('serial_peer',s) in lm}
out['gates']['task']={}
for s in SEEDS:
 if ('serial_peer',s) not in task:continue
 t=task['serial_peer',s]['scores'];g={k:t[k]['acc']>=v for k,v in [('atomic',.90),('depth2_heldout',.90),('depth4_heldout',.8),('depth8_allowed',.8)]}
 for a in ['raw_peer','serial_self']:
  if (a,s) in task:
   for k in ['depth4_heldout','depth8_allowed']:g[f'{a}_{k}_gain']=t[k]['acc']-task[a,s]['scores'][k]['acc']>=.05
 out['gates']['task'][str(s)]=g
out['gates']['lm_all_pass']=len(lm)==12 and all(all(v.values()) for v in out['gates']['lm'].values());out['gates']['task_all_pass']=len(task)==12 and all(all(v.values()) for v in out['gates']['task'].values())
if (ROOT/'task_lesions.json').exists():
 r=json.loads((ROOT/'task_lesions.json').read_text());out['lesions']={'total':sum(len(z['lesions']) for z in r),'arms':{}}
 for a in ARMS:
  rr=[z for z in r if z['arm']==a]
  if not rr:continue
  z=[l for row in rr for l in row['lesions'] if l['branch']=='A'];out['lesions']['arms'][a]={'A_mean_op_nll_delta_range':st.mean(l['atomic_nll_delta_range'] for l in z),'A_mean_op_nll_delta':st.mean(st.mean(l['atomic_nll_delta_by_op']) for l in z),'mean_atomic_accuracy_change':st.mean(l['scores']['atomic']['acc']-row['intact']['atomic']['acc'] for row in rr for l in row['lesions']),'mean_heldout2_accuracy_change':st.mean(l['scores']['depth2_heldout']['acc']-row['intact']['depth2_heldout']['acc'] for row in rr for l in row['lesions'])}
if (ROOT/'benchmark.json').exists():out['benchmark']=json.loads((ROOT/'benchmark.json').read_text())['arm_mean_seed_median']
(ROOT/'aggregate.json').write_text(json.dumps(out,indent=2));
with (ROOT/'lm_summary.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['arm','seed','params','dev_bpb','test_bpb','test_acc','reused','checkpoint_sha256']);w.writerows([a,s,z['params'],z['dev']['bpb'],z['test']['bpb'],z['test']['acc'],z['reused'],z['checkpoint_sha256']] for (a,s),z in lm.items())
with (ROOT/'task_summary.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['arm','seed','panel','correct','n','accuracy','nll']);w.writerows([a,s,k,t['correct'],t['n'],t['acc'],t['nll']] for (a,s),z in task.items() for k,t in z['scores'].items())
print(json.dumps(out,indent=2))
