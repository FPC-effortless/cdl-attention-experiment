from composition_task import *
import statistics as st
@torch.no_grad()
def evaluate_groups(m,rows):
 m.eval();x,i,y=encode(rows);loss=[];correct=[]
 for a,b,c in zip(x.split(64),i.split(64),y.split(64)):
  z=m(a)[torch.arange(len(b)),b];loss+=F.cross_entropy(z,c,reduction='none').tolist();correct+=(z.argmax(-1)==c).tolist()
 groups={str(j):[i for i,(_,ops) in enumerate(rows) if ops[0]==j] for j in range(6)}
 return dict(n=len(rows),nll=st.mean(loss),acc=st.mean(correct),by_first_op={k:{'n':len(ids),'nll':st.mean(loss[i] for i in ids),'acc':st.mean(correct[i] for i in ids)} for k,ids in groups.items()})
def lesion_fn(unit):
 def hook(mod,args,out):
  result=out.clone();result[...,unit,:]=0.;return result
 return hook

def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);panels=panel_rows();result=[]
 for arm in ARMS:
  for seed in SEEDS:
   p=ROOT/'results'/f'task_{arm}_{seed}.pt';j=ROOT/'results'/f'task_{arm}_{seed}.json'
   if not (p.exists() and j.exists()):continue
   m=model(arm);m.load_state_dict(torch.load(p,map_location='cpu',weights_only=True)['weights']);ref={k:evaluate_groups(m,panels[k]) for k in ['atomic','depth2_heldout']};ls=[]
   for layer in range(2):
    for branch in ['A','B']:
     for unit in range(K):
      handle=getattr(m.layers[layer],branch).register_forward_hook(lesion_fn(unit));scores={k:evaluate_groups(m,panels[k]) for k in ref};handle.remove();delta=[scores['atomic']['by_first_op'][str(o)]['nll']-ref['atomic']['by_first_op'][str(o)]['nll'] for o in range(6)];ls.append(dict(layer=layer,branch=branch,unit=unit,scores=scores,atomic_nll_delta_by_op=delta,atomic_nll_delta_range=max(delta)-min(delta)))
   result.append(dict(arm=arm,seed=seed,intact=ref,lesions=ls));print('DONE',arm,seed,len(ls),flush=True)
 (ROOT/'task_lesions.json').write_text(json.dumps(result,indent=2));print('TOTAL',sum(len(r['lesions']) for r in result),flush=True)
if __name__=='__main__':main()
