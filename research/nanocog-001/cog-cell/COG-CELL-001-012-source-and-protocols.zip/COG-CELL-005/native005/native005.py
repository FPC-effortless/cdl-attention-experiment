import pathlib,sys,time,math,json,argparse,hashlib,platform
import torch
from torch import nn
import torch.nn.functional as F
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'native004'))
from native004 import orig,scan,coupled_scan,CoupledBlock,model as model004,clean,evaluate,init_hash,K,H,D,T,SEEDS
ARMS=['base','raw_peer','serial_self','serial_peer']
class ComposeBlock(CoupledBlock):
 def forward(self,h,state=None,ab=None):
  if ab=='bypass':return super().forward(h,state,ab='bypass')
  if ab=='raw_reference':return super().forward(h,state)
  u=self.norm(h);z,g0=self.inp(u).chunk(2,-1);r,rs=scan(z.tanh(),.5+.49*g0.sigmoid(),None if state is None else state[0]);q=r+u;v=self.pub(q).tanh().unflatten(-1,(K,H));w,rp,g=self.route(q).split([K,K,1],-1);w=w.sigmoid()*2/K;rp=rp.sigmoid()*2/K
  gate=.8*g.sigmoid()*w;c=((v*self.feedback_w).sum(-1)+self.feedback_b-2).sigmoid()
  if ab=='no_feedback':c=torch.zeros_like(c)
  adjacency=torch.eye(K,device=v.device,dtype=v.dtype).roll(1,0)
  M=torch.diag_embed(1-gate)+(gate*c)[...,None]*adjacency
  b=(gate*(1-c))[...,None]*v;ms,last=coupled_scan(M,b,None if state is None else state[1]);m=ms*rp[...,None]*K
  a=self.A(m).tanh();pub=m if self.compose_mode=='raw_peer' or ab=='raw_message' else a
  if ab=='raw_message':pub=m
  if ab=='zero_message':pub=torch.zeros_like(pub)
  if ab=='rotate_transform':pub=pub.roll(1,-1)
  src=pub if self.compose_mode=='serial_self' or ab=='self_message' else pub.roll(1,-2)
  if ab=='peer_message':src=pub.roll(1,-2)
  if ab=='reverse_message':src=pub.roll(-1,-2)
  b=self.B(src).tanh()
  if ab=='no_B':b=torch.zeros_like(b)
  y=a*(1+b);msg=self.recv(self.msgnorm(y.flatten(-2)))
  if ab=='drop':msg=torch.zeros_like(msg)
  h=h+self.out(r+self.combine(q).sigmoid()*msg);h=h+self.ff(self.norm2(h))
  if getattr(self,'record',False):self.last_a=a.detach();self.last_b=b.detach();self.last_ms=ms.detach()
  return h,(rs,last)
def model(arm):
 if arm=='base':return model004('base')
 m=model004('peer_feedback')
 for l in m.layers:l.__class__=ComposeBlock;l.compose_mode=arm
 return m

def load_existing(arm,seed):
 m=model(arm)
 if arm=='base':p=ROOT.parent/'native002'/'results'/f'base_{seed}.pt'
 elif arm=='raw_peer':p=ROOT.parent/'native004'/'results'/f'peer_feedback_{seed}.pt'
 else:p=ROOT/'results'/f'lm_{arm}_{seed}.pt'
 m.load_state_dict(torch.load(p,map_location='cpu',weights_only=True)['weights']);m.eval();return m,p

def main():
 p=argparse.ArgumentParser();p.add_argument('--arm',choices=ARMS,required=True);p.add_argument('--seed',type=int,required=True);a=p.parse_args();torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(a.seed)
 ds=orig.data();dev,de=clean(ds,'dev');test,te=clean(ds,'test');t,starts=orig.train_data(ds['train']);m=model(a.arm);ih=init_hash(m);nparams=sum(p.numel() for p in m.parameters());out=ROOT/'results';prefix=out/f'lm_{a.arm}_{a.seed}';log=[];elapsed=0.
 reused=a.arm in ['base','raw_peer']
 if reused:m,cp=load_existing(a.arm,a.seed)
 else:
  g=torch.Generator().manual_seed(100000+a.seed);opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01);m.train()
  for i in range(1,1001):
   pos=starts[torch.randint(len(starts),(8,),generator=g)];batch=t[pos[:,None]+torch.arange(T+1)[None]];x,y=batch[:,:-1],batch[:,1:];s=time.perf_counter();opt.param_groups[0]['lr']=.001*min(1,i/50)*(.2+.8*.5*(1+math.cos(math.pi*i/1000)));opt.zero_grad(set_to_none=True);z=m(x);ce=F.cross_entropy(z.flatten(0,1),y.flatten());ce.backward();nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True);opt.step();elapsed+=time.perf_counter()-s
   if i in [1,250,500,750,1000]:
    val=evaluate(m,dev);m.train();row=dict(step=i,ce=ce.item(),dev_bpb=val['bpb']);log.append(row);print(a.arm,a.seed,row,flush=True);prefix.with_suffix('.progress.json').write_text(json.dumps(log))
  cp=prefix.with_suffix('.pt');torch.save(dict(arm=a.arm,seed=a.seed,weights=m.state_dict()),cp)
 res=dict(arm=a.arm,seed=a.seed,params=nparams,steps=1000,train_bytes=512000,train_seconds=elapsed,init_sha256=ih,checkpoint_sha256=hashlib.sha256(cp.read_bytes()).hexdigest(),reused=reused,history_train=log,excluded_dev=de,excluded_test=te,dev=evaluate(m,dev),test=evaluate(m,test),history=orig.history(m,ds['test']),stream=orig.streaming(m,ds['test'][0]))
 if a.arm!='base':res['interventions']={ab:evaluate(m,test,ab=ab) for ab in ['raw_message','self_message','reverse_message','rotate_transform','no_B','no_feedback','drop']}
 prefix.with_suffix('.json').write_text(json.dumps(res,indent=2));print('DONE',a.arm,a.seed,res['dev']['bpb'],res['test']['bpb'],flush=True)
if __name__=='__main__':main()
