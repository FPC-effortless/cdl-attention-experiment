from composition_task import *
from collections import Counter

def canonical(x,ops):
 a,b=1,0
 for op in ops:
  q,r=map(int,OPS[op]);a,b=(q*a)%16,(q*b+r)%16
 return (a*x+b)%16
panels=panel_rows();report={'oracle':{},'pair_order':{},'coverage':{}}
for key,rows in panels.items():
 labels=[answer(x,op) for x,op in rows];oracle=[canonical(x,op) for x,op in rows];assert labels==oracle
 report['oracle'][key]={'n':len(rows),'correct':sum(a==b for a,b in zip(labels,oracle)),'most_common_label_accuracy':max(Counter(labels).values())/len(labels)}
for a,b in sorted(FORBIDDEN):
 if a<b:
  n=sum(answer(x,(a,b))!=answer(x,(b,a)) for x in range(16));assert n==16;report['pair_order'][f'{a}-{b}']={'noncommuting_start_values':n,'out_of':16}
for seed in SEEDS:
 x,i,y=train_arrays(seed);train={(int(row[0]),tuple(int(v)-32 for v in row[1:int(n)+1])) for row,n in zip(x.flatten(0,1),i.flatten())};report['coverage'][str(seed)]={'unique_train_examples':len(train),'panels':{key:{'n':len(rows),'overlap':len(set(rows)&train)} for key,rows in panels.items()}}
 for k,z in report['coverage'][str(seed)]['panels'].items():
  if 'heldout' in k or k.startswith(('depth6','depth8','depth12')):assert z['overlap']==0
(ROOT/'task_audit.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
