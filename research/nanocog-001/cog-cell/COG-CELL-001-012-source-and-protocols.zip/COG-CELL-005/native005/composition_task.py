"""Native full architecture; final-answer supervised finite affine composition."""
from native005 import *
import numpy as np
from itertools import product
OPS=np.array([[1,1],[1,3],[3,1],[5,2],[7,3],[15,4]],dtype=np.int64)
FORBIDDEN={(0,2),(2,0),(1,3),(3,1),(4,5),(5,4)}
ALLOWED=np.ones((6,6),dtype=bool)
for i,j in FORBIDDEN:ALLOWED[i,j]=False
NEXT=np.array([np.flatnonzero(row) for row in ALLOWED])

def answer(x,ops):
 for o in ops:x=int((OPS[o,0]*x+OPS[o,1])%16)
 return x

def encode(rows,L=None):
 L=L or max(len(ops) for x,ops in rows)
 inp=np.zeros((len(rows),L+1),np.int64);idx=np.empty(len(rows),np.int64);y=np.empty(len(rows),np.int64)
 for i,(x,ops) in enumerate(rows):
  inp[i,0]=x;inp[i,1:len(ops)+1]=np.array(ops)+32;idx[i]=len(ops);y[i]=answer(x,ops)
 return tuple(torch.from_numpy(a) for a in (inp,idx,y))

def held(ops):return any((a,b) in FORBIDDEN for a,b in zip(ops,ops[1:]))
def sample_rows(rng,n,L,ood):
 # Unique rows and deterministic ordering, never use a set's unordered iteration.
 rows=[];seen=set()
 while len(rows)<n:
  x=int(rng.integers(16));ops=tuple(int(i) for i in rng.integers(6,size=L))
  if held(ops)==ood and (x,ops) not in seen:seen.add((x,ops));rows.append((x,ops))
 return rows

def panel_rows():
 r=np.random.default_rng(891075);all2=[(x,op) for x in range(16) for op in product(range(6),repeat=2)]
 panels={'atomic':[(x,(o,)) for x in range(16) for o in range(6)],'depth2_allowed':[row for row in all2 if not held(row[1])],'depth2_heldout':[row for row in all2 if held(row[1])]}
 for L,ood in [(4,False),(4,True),(6,False),(8,False),(8,True),(12,False)]:panels[f'depth{L}_{"heldout" if ood else "allowed"}']=sample_rows(r,1024,L,ood)
 return panels

def train_arrays(seed,steps=1000,batch=32):
 rng=np.random.default_rng(100000+seed);X=np.zeros((steps,batch,5),np.int64);idx=rng.integers(1,5,size=(steps,batch));Y=np.empty((steps,batch),np.int64)
 X[:,:,0]=rng.integers(16,size=(steps,batch));ops=np.empty((steps,batch,4),np.int64);ops[:,:,0]=rng.integers(6,size=(steps,batch));
 for i in range(1,4):ops[:,:,i]=NEXT[ops[:,:,i-1],rng.integers(5,size=(steps,batch))]
 state=X[:,:,0].copy()
 for i in range(4):
  active=idx>i;X[:,:,i+1]=np.where(active,ops[:,:,i]+32,0);state=np.where(active,(OPS[ops[:,:,i],0]*state+OPS[ops[:,:,i],1])%16,state)
 Y[:]=state
 for i in range(3):assert not np.any(~ALLOWED[ops[:,:,i],ops[:,:,i+1]])
 return tuple(torch.from_numpy(z) for z in (X,idx,Y))

@torch.no_grad()
def eval_panel(m,rows,ab=None):
 m.eval();x,idx,y=encode(rows);correct=[];nll=0.;preds=[];range_acc=0
 for a,i,b in zip(x.split(64),idx.split(64),y.split(64)):
  z=m(a,ab=ab)[torch.arange(len(i)),i];p=z.argmax(-1);correct.extend((p==b).tolist());preds.extend(p.tolist());nll+=F.cross_entropy(z,b,reduction='sum').item();range_acc+=int((z[:,:16].argmax(-1)==b).sum())
 return dict(n=len(rows),correct=sum(correct),acc=sum(correct)/len(rows),nll=nll/len(rows),restricted_acc=range_acc/len(rows),predictions=preds)

def order_check(rows,results):
 pred=dict(zip(rows,results['predictions']));n=both=changed=0
 for x,op in rows:
  rev=tuple(reversed(op))
  if op<rev and answer(x,op)!=answer(x,rev):
   n+=1;both+=pred[x,op]==answer(x,op) and pred[x,rev]==answer(x,rev);changed+=pred[x,op]!=pred[x,rev]
 return dict(n=n,both_correct=both,changed_prediction=changed)

def main():
 p=argparse.ArgumentParser();p.add_argument('--arm',choices=ARMS,required=True);p.add_argument('--seed',type=int,required=True);a=p.parse_args();torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(a.seed)
 m=model(a.arm);ih=init_hash(m);tr,idx,ys=train_arrays(a.seed);th=hashlib.sha256(b''.join(z.numpy().tobytes() for z in (tr,idx,ys))).hexdigest();panels=panel_rows();path=ROOT/'results'/f'task_{a.arm}_{a.seed}';opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01);log=[];s=time.perf_counter();m.train()
 for step,(x,i,y) in enumerate(zip(tr,idx,ys),1):
  opt.param_groups[0]['lr']=.001*min(1,step/50)*(.2+.8*.5*(1+math.cos(math.pi*step/1000)));opt.zero_grad(set_to_none=True);z=m(x)[torch.arange(len(i)),i];ce=F.cross_entropy(z,y);ce.backward();nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True);opt.step()
  if step in [1,250,500,750,1000]:
   row=dict(step=step,ce=ce.item(),batch_acc=(z.argmax(-1)==y).float().mean().item());log.append(row);print(a.arm,a.seed,row,flush=True);path.with_suffix('.progress.json').write_text(json.dumps(log))
 elapsed=time.perf_counter()-s;torch.save(dict(arm=a.arm,seed=a.seed,weights=m.state_dict()),path.with_suffix('.pt'))
 scores={k:eval_panel(m,v) for k,v in panels.items()};order=order_check(panels['depth2_heldout'],scores['depth2_heldout']);abls={}
 if a.arm!='base':
  for ab in ['raw_message','self_message','peer_message','reverse_message','rotate_transform','no_B','no_feedback']:
   abls[ab]={k:eval_panel(m,panels[k],ab=ab) for k in ['atomic','depth2_heldout','depth4_heldout','depth8_allowed']}
 res=dict(arm=a.arm,seed=a.seed,params=sum(p.numel() for p in m.parameters()),steps=1000,training_examples=32000,train_input_tokens=int((idx+1).sum()),train_seconds=elapsed,train_batch_sha256=th,init_sha256=ih,history_train=log,scores=scores,order_check=order,interventions=abls,checkpoint_sha256=hashlib.sha256(path.with_suffix('.pt').read_bytes()).hexdigest())
 path.with_suffix('.json').write_text(json.dumps(res,indent=2));print('DONE',a.arm,a.seed,{k:round(v['acc'],5) for k,v in scores.items()},flush=True)

if __name__=='__main__':main()
