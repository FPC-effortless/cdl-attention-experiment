# Post-hoc analysis: distinguish exact seen from unseen length-4 familiar pairs.
from composition_task import *
from collections import defaultdict
import statistics as st
panels=panel_rows();rows=panels['depth4_allowed'];result=[]
for seed in SEEDS:
 x,idx,y=train_arrays(seed);seen={(int(row[0]),tuple(int(v)-32 for v in row[1:int(n)+1])) for row,n in zip(x.flatten(0,1),idx.flatten())};seen_ids=[i for i,r in enumerate(rows) if r in seen];unseen_ids=[i for i,r in enumerate(rows) if r not in seen];labels=[answer(x,op) for x,op in rows]
 for arm in ARMS:
  p=ROOT/'results'/f'task_{arm}_{seed}.json'
  if not p.exists():continue
  r=json.loads(p.read_text());pred=r['scores']['depth4_allowed']['predictions'];result.append({'arm':arm,'seed':seed,'seen_n':len(seen_ids),'seen_correct':sum(pred[i]==labels[i] for i in seen_ids),'unseen_n':len(unseen_ids),'unseen_correct':sum(pred[i]==labels[i] for i in unseen_ids)})
summary={}
for arm in ARMS:
 rr=[r for r in result if r['arm']==arm]
 if rr:summary[arm]={'seen_n':sum(z['seen_n'] for z in rr),'seen_correct':sum(z['seen_correct'] for z in rr),'unseen_n':sum(z['unseen_n'] for z in rr),'unseen_correct':sum(z['unseen_correct'] for z in rr),'mean_seen_acc':st.mean(z['seen_correct']/z['seen_n'] for z in rr),'mean_unseen_acc':st.mean(z['unseen_correct']/z['unseen_n'] for z in rr)}
(ROOT/'seen_analysis.json').write_text(json.dumps({'scope':'Post-hoc; exact input overlap of familiar depth4 panel with the actual training batch stream. No selection or tuning.','rows':result,'summary':summary},indent=2));print(json.dumps(summary,indent=2))
