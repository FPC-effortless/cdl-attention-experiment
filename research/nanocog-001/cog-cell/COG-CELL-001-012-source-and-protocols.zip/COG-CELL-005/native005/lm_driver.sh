#!/bin/bash
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cat lm_jobs.txt | xargs -n2 -P4 bash -c 'python native005.py --arm "$0" --seed "$1" > "results/lm_${0}_${1}.log" 2>&1; s=$?; printf "%s %s %s\n" "$0" "$1" "$s" >> lm_exit_status; exit "$s"'
echo $? > lm_driver_exit
