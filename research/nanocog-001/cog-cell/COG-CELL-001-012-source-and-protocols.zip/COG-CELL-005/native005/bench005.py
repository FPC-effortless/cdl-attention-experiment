from native005 import *
import statistics as st,random

def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);ms={};raw={};g=torch.Generator().manual_seed(173);x=torch.randint(0,256,(1,64),generator=g);long=torch.randint(0,256,(1,512),generator=g);tokens=torch.randint(0,256,(1,64),generator=g);rng=random.Random(173)
 for a in ARMS:
  for s in SEEDS:
   if not (ROOT/'results'/f'lm_{a}_{s}.json').exists():continue
   m,_=load_existing(a,s);ms[a,s]=m;raw[a,s]={k:[] for k in ['prefill64_us_byte','prefill512_us_byte','decode_us_byte']}
 with torch.inference_mode():
  for m in ms.values():
   for _ in range(3):m(x);m(long);m(tokens[:,:1]);
  for rep in range(5):
   keys=list(ms);rng.shuffle(keys)
   for k in keys:
    m=ms[k]
    for name,seq,num in [('prefill64_us_byte',x,15),('prefill512_us_byte',long,5)]:
     t=time.perf_counter()
     for _ in range(num):m(seq)
     raw[k][name].append((time.perf_counter()-t)*1e6/(num*seq.numel()))
    _,state=m(x,with_state=True);t=time.perf_counter()
    for j in range(tokens.shape[1]):_,state=m(tokens[:,j:j+1],state=state,with_state=True)
    raw[k]['decode_us_byte'].append((time.perf_counter()-t)*1e6/tokens.shape[1])
 out={'scope':'Single-process, single-thread CPU FP32, five interleaved passes, batch 1; not optimized kernels; no tokenizer or I/O.','models':[dict(arm=k[0],seed=k[1],raw=v,median={n:st.median(t) for n,t in v.items()}) for k,v in raw.items()]}
 out['arm_mean_seed_median']={a:{n:st.mean(r['median'][n] for r in out['models'] if r['arm']==a) for n in next(iter(raw.values()))} for a in ARMS if any(k[0]==a for k in raw)}
 (ROOT/'benchmark.json').write_text(json.dumps(out,indent=2));print(json.dumps(out['arm_mean_seed_median'],indent=2))
if __name__=='__main__':main()
