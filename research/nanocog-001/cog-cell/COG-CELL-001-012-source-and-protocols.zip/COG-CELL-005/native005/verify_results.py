import pathlib,json,hashlib,sys
ROOT=pathlib.Path(__file__).parent;SEEDS=[173,271,907];ARMS=['base','raw_peer','serial_self','serial_peer'];res={'lm':[],'task':[],'checks':[]}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(kind,a,s):return json.loads((ROOT/'results'/f'{kind}_{a}_{s}.json').read_text())
for s in SEEDS:
 lm=[load('lm',a,s) for a in ARMS];task=[load('task',a,s) for a in ARMS];assert len(set(x['init_sha256'] for x in lm[1:]))==1;assert len(set(x['init_sha256'] for x in task[1:]))==1;assert len(set(x['train_batch_sha256'] for x in task))==1;assert all(x['steps']==1000 for x in lm+task);assert all(x['train_bytes']==512000 for x in lm);assert all(x['training_examples']==32000 for x in task);assert all(x['stream']['state_bytes']==3136 for x in lm)
 for a,l,t in zip(ARMS,lm,task):
  p=ROOT.parent/'native002'/'results'/f'base_{s}.pt' if a=='base' else ROOT.parent/'native004'/'results'/f'peer_feedback_{s}.pt' if a=='raw_peer' else ROOT/'results'/f'lm_{a}_{s}.pt'
  assert sha(p)==l['checkpoint_sha256'];assert sha(ROOT/'results'/f'task_{a}_{s}.pt')==t['checkpoint_sha256'];assert all(len(v['predictions'])==v['n'] and 0<=v['correct']<=v['n'] for v in t['scores'].values())
  res['lm'].append(dict(arm=a,seed=s,checkpoint_hash_verified=True,steps=l['steps'],reused=l['reused'],stream_argmax_disagreement=l['stream']['argmax_disagree']))
  res['task'].append(dict(arm=a,seed=s,checkpoint_hash_verified=True,steps=t['steps'],train_batch_hash=t['train_batch_sha256'],n=t['training_examples']))
 res['checks'].append(dict(seed=s,matched_init=True,matched_task_batch_hash=True,full_budgets=True,constant_state=True))
for f in ['lm_exit_status','task_exit_status']:
 rows=(ROOT/f).read_text().splitlines();assert len(rows)==12 and all(line.endswith(' 0') for line in rows)
for f in ['lm_driver_exit','task_driver_exit','task_lesions_exit','benchmark_exit']:assert (ROOT/f).read_text().strip()=='0'
assert len(json.loads((ROOT/'task_lesions.json').read_text()))==12
(ROOT/'results_verification.json').write_text(json.dumps(res,indent=2));print('PASS: 24 model receipts, 18 new model checkpoints, 6 archived control hashes, matched initialization and batches, full budgets, successful exit receipts, diagnostic coverage')
