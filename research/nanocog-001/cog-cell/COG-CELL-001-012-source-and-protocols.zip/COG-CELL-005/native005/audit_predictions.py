# Read-only independent score reconstruction, using an affine coefficient oracle.
import json,pathlib,hashlib,math
P=pathlib.Path(__file__).parent
panels=json.loads((P/'task_panels.json').read_text());meta=json.loads((P/'task_preflight.json').read_text());ops=meta['operations'];labels={}
for k,rows in panels.items():
 labels[k]=[]
 for start,seq in rows:
  a=1;b=0
  for o in seq:
   c,d=ops[o];a=(c*a)%16;b=(c*b+d)%16
  labels[k].append((a*start+b)%16)
 assert len(labels[k])==meta['panels'][k]['n']
count=0;pred_count=0;fits=[]
for f in sorted((P/'results').glob('task_*.json')):
 if f.name.endswith('.progress.json'):continue
 r=json.loads(f.read_text());n=0;pc=0
 for group in [r['scores'],*r['interventions'].values()]:
  for key,v in group.items():
   p=v['predictions'];y=labels[key];assert len(p)==len(y)==v['n'];correct=sum(a==b for a,b in zip(p,y));assert correct==v['correct'] and math.isclose(correct/len(y),v['acc'],abs_tol=1e-15);n+=1;pc+=len(p)
 # Verify order pairs independently, no reliance on original score function.
 key='depth2_heldout';index={(start,tuple(seq)):i for i,(start,seq) in enumerate(panels[key])};p=r['scores'][key]['predictions'];y=labels[key];pairs=[]
 for (x,seq),i in index.items():
  j=index[x,tuple(reversed(seq))]
  if i<j and y[i]!=y[j]:pairs.append((i,j))
 assert len(pairs)==r['order_check']['n'];assert sum(p[i]==y[i] and p[j]==y[j] for i,j in pairs)==r['order_check']['both_correct'];assert sum(p[i]!=p[j] for i,j in pairs)==r['order_check']['changed_prediction']
 count+=n;pred_count+=pc;fits.append({'arm':r['arm'],'seed':r['seed'],'score_records':n,'predictions_checked':pc})
result={'fits':fits,'score_records_verified':count,'predictions_verified':pred_count};(P/'prediction_audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
