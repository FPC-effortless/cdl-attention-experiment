from composition_task import *
import collections
r=panel_rows();res={'operations':OPS.tolist(),'forbidden':sorted(FORBIDDEN),'panels':{},'training':{}}
for k,rows in r.items():
 assert len(set(rows))==len(rows);assert all(0<=answer(x,op)<16 for x,op in rows);assert all(held(op) for _,op in rows) if k.endswith('heldout') else all(not held(op) for _,op in rows)
 res['panels'][k]={'n':len(rows),'sha256':hashlib.sha256(json.dumps(rows).encode()).hexdigest(),'label_counts':dict(collections.Counter(answer(x,op) for x,op in rows))}
for seed in SEEDS:
 x,i,y=train_arrays(seed);assert not any(held(tuple((row[1:int(n)+1]-32).tolist())) for row,n in zip(x.flatten(0,1),i.flatten()))
 for idx in [0,1,400,777,999]:
  for j in range(32):assert y[idx,j].item()==answer(x[idx,j,0].item(),(x[idx,j,1:i[idx,j]+1]-32).tolist())
 res['training'][str(seed)]={'examples':int(y.numel()),'real_input_tokens':int((i+1).sum()),'length_counts':torch.bincount(i.flatten(),minlength=5).tolist(),'sha256':hashlib.sha256(b''.join(z.numpy().tobytes() for z in (x,i,y))).hexdigest()}
(ROOT/'task_preflight.json').write_text(json.dumps(res,indent=2));(ROOT/'task_panels.json').write_text(json.dumps(r));print(json.dumps(res,indent=2))
