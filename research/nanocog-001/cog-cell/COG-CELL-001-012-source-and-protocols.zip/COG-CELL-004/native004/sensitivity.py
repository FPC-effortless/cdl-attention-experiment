from native004 import *
from native004_benchmark import load
# Secondary sensitivity panel, deterministic window selection from reused document splits.
# Exclude any 65-byte window intersecting the original panel and exact copies in training documents.
def new_rows(ds,split):
 train=[bytes(t.tolist()) for t in ds['train']];out=[];counts=[]
 for i,d in enumerate(ds[split]):
  orig_pos=torch.linspace(0,len(d)-T-1,24).long().tolist();g=torch.Generator().manual_seed(41101+i+(0 if split=='dev' else 10000));candidates=torch.arange(0,len(d)-T,T+1);valid=[int(p) for p in candidates if all(abs(int(p)-q)>T for q in orig_pos)];perm=torch.randperm(len(valid),generator=g).tolist();rows=[]
  for idx in perm:
   p=valid[idx];w=d[p:p+T+1];key=bytes(w.tolist());
   if any(key in t for t in train):continue
   rows.append(w)
   if len(rows)>=48:break
  assert rows;out.append(torch.stack(rows));counts.append(len(rows))
 return out,counts

def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);ds=orig.data();panels={sp:new_rows(ds,sp) for sp in ['dev','test']};res={'scope':'Supplementary deterministic disjoint-window sensitivity on reused held-out documents; no model selection; 48 additional windows per document when available; exact train-substring exclusion.','counts':{sp:counts for sp,(_,counts) in panels.items()},'rows':[]}
 for a in ['base']+ARMS:
  for seed in SEEDS:
   if not (ROOT/'results'/f'{a}_{seed}.json').exists():continue
   m=load(a,seed);res['rows'].append(dict(arm=a,seed=seed,**{sp:evaluate(m,rows) for sp,(rows,_) in panels.items()}));print(a,seed,{sp:res['rows'][-1][sp]['bpb'] for sp in panels},flush=True)
 (ROOT/'sensitivity.json').write_text(json.dumps(res,indent=2))
if __name__=='__main__':main()
