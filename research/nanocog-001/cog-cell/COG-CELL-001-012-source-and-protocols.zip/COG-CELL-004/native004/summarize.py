from native004 import *
import statistics as st,csv
rows=[];raw={}
for a in ['base']+ARMS:
 for s in SEEDS:
  p=ROOT/'results'/f'{a}_{s}.json'
  if p.exists():
   r=json.loads(p.read_text());raw[a,s]=r;rows.append(dict(arm=a,seed=s,params=r['params'],steps=r['steps'],reused=r['reused'],dev_bpb=r['dev']['bpb'],test_bpb=r['test']['bpb'],test_acc=r['test']['acc'],history_gain=r['history']['reset_bpb']-r['history']['full_bpb'],state_bytes=r['stream']['state_bytes'],stream_disagreement=r['stream']['argmax_disagree'],train_seconds=r.get('train_seconds',0)))
summary={'complete':len(rows)==9,'new_fits':sum(not r['reused'] for r in rows),'new_steps':sum(r['steps'] for r in rows if not r['reused']),'new_byte_presentations':sum(r['steps']*512 for r in rows if not r['reused']),'rows':rows,'means':{},'paired':{}}
for a in ['base']+ARMS:
 rr=[r for r in rows if r['arm']==a]
 if rr:summary['means'][a]={k:st.mean(r[k] for r in rr) for k in ['dev_bpb','test_bpb','test_acc','history_gain','train_seconds']}
 if a!='base' and rr:
  summary['means'][a]['ablation_delta']={k:st.mean(raw[a,r['seed']]['interventions'][k]['bpb']-r['test_bpb'] for r in rr) for k in raw[a,rr[0]['seed']]['interventions']}
  summary['means'][a]['feedback_gate_mean']=st.mean(c for r in rr for l in raw[a,r['seed']]['feedback_stats'] for c in l['mean']);summary['means'][a]['max_abs_state']=max(l['max_abs_state'] for r in rr for l in raw[a,r['seed']]['feedback_stats'])
for control in ['base','self_feedback']:
 for split in ['dev','test']:
  ds=[raw['peer_feedback',s][split]['bpb']-raw[control,s][split]['bpb'] for s in SEEDS if ('peer_feedback',s) in raw and (control,s) in raw]
  if ds:
   v=dict(deltas=ds,mean=st.mean(ds));
   if len(ds)==3:
    half=4.3026527*st.stdev(ds)/math.sqrt(3);v['t95']=[v['mean']-half,v['mean']+half]
   summary['paired'][control+'_'+split]=v
summary['primary_pass']=summary['complete'] and all(raw['peer_feedback',s]['dev']['bpb']<=raw[a,s]['dev']['bpb']-.01 for a in ['base','self_feedback'] for s in SEEDS)
(ROOT/'aggregate.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
if rows:
 with (ROOT/'summary.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
