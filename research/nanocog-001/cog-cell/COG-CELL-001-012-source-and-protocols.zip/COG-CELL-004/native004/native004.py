import sys,pathlib,math,time,json,argparse,hashlib,platform
import torch
from torch import nn
import torch.nn.functional as F
ROOT=pathlib.Path(__file__).resolve().parent
SRC=ROOT.parent/'cog_unified_006'
sys.path.insert(0,str(SRC));sys.path.insert(0,str(ROOT.parent/'native002'))
from native import orig,clean,evaluate,init_hash
from previous_reference import scan
K,D,H,T=orig.K,orig.D,orig.H,orig.T
# Exact affine prefix scan in real arithmetic, balanced tree; arbitrary positive length.
def coupled_scan(A,b,s=None):
 if s is None:s=torch.zeros_like(b[:,0])
 def rec(A,b,s):
  n=b.shape[1]
  if n==1:return b+A@s[:,None]
  p=n//2;ae=A[:,::2];be=b[:,::2];ao=A[:,1::2];bo=b[:,1::2]
  odd=rec(ao@ae[:,:p],bo+ao@be[:,:p],s)
  prior=torch.cat((s[:,None],odd[:,:ae.shape[1]-1]),dim=1)
  even=be+ae@prior
  out=torch.stack((even[:,:p],odd),dim=2).flatten(1,2)
  return torch.cat((out,even[:,-1:]),dim=1) if n%2 else out
 y=rec(A,b,s);return y,y[:,-1]
class CoupledBlock(orig.Block):
 def forward(self,h,state=None,ab=None):
  if ab=='bypass':return super().forward(h,state)
  u=self.norm(h);z,a=self.inp(u).chunk(2,-1);r,rs=scan(z.tanh(),.5+.49*a.sigmoid(),None if state is None else state[0]);q=r+u;v=self.pub(q).tanh().unflatten(-1,(K,H));w,rp,g=self.route(q).split([K,K,1],-1);w=w.sigmoid()*2/K;rp=rp.sigmoid()*2/K
  gate=.8*g.sigmoid()*w
  c=((v*self.feedback_w).sum(-1)+self.feedback_b-2).sigmoid()
  if ab=='no_feedback':c=torch.zeros_like(c)
  ident=torch.eye(K,device=v.device,dtype=v.dtype)
  offset=0 if self.mode=='self_feedback' or ab=='self_feedback' else (-1 if ab=='reverse_feedback' else 1)
  adjacency=ident.roll(offset,0)
  A=torch.diag_embed(1-gate)+(gate*c)[...,None]*adjacency
  b=(gate*(1-c))[...,None]*v
  ms,last=coupled_scan(A,b,None if state is None else state[1]);m=ms*rp[...,None]*K
  a=self.A(m).tanh();src=m.roll(1,-2)
  if ab=='output_self':src=m
  b=self.B(src).tanh()
  if ab=='no_B':b=torch.zeros_like(b)
  y=a*(1+b);msg=self.recv(self.msgnorm(y.flatten(-2)))
  if ab=='drop':msg=torch.zeros_like(msg)
  h=h+self.out(r+self.combine(q).sigmoid()*msg);h=h+self.ff(self.norm2(h))
  if getattr(self,'record',False):self.feedback_record=c.detach();self.state_record=ms.detach()
  return h,(rs,last)
def model(arm):
 m=orig.LM('composed')
 if arm!='base':
  for l in m.layers:
   l.__class__=CoupledBlock;l.mode=arm;l.feedback_w=nn.Parameter(torch.zeros(K,H));l.feedback_b=nn.Parameter(torch.zeros(K))
 return m
ARMS=['self_feedback','peer_feedback']
SEEDS=[173,271,907]
@torch.no_grad()
def stats(m,rows):
 for l in m.layers:l.record=True
 cs=[[] for l in m.layers];ss=[[] for l in m.layers]
 for a in rows:
  for b in a.split(8):
   m(b[:,:-1])
   for i,l in enumerate(m.layers):cs[i].append(l.feedback_record.reshape(-1,K));ss[i].append(l.state_record.abs().max().item())
 for l in m.layers:l.record=False
 return [dict(mean=z.mean(0).tolist(),std=z.std(0).tolist(),min=z.min().item(),max=z.max().item(),max_abs_state=max(s)) for z,s in zip(map(torch.cat,cs),ss)]
def score(m,ds,dev,test,arm):
 res=dict(dev=evaluate(m,dev),test=evaluate(m,test),history=orig.history(m,ds['test']),stream=orig.streaming(m,ds['test'][0]))
 if arm!='base':res['interventions']={ab:evaluate(m,test,ab=ab) for ab in ['no_feedback','self_feedback','reverse_feedback','output_self','no_B','drop']};res['feedback_stats']=stats(m,test)
 return res
def main():
 p=argparse.ArgumentParser();p.add_argument('--arm',choices=['base']+ARMS,required=True);p.add_argument('--seed',type=int,required=True);a=p.parse_args();torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(a.seed)
 ds=orig.data();dev,de=clean(ds,'dev');test,te=clean(ds,'test');t,starts=orig.train_data(ds['train']);m=model(a.arm);ih=init_hash(m);nparams=sum(p.numel() for p in m.parameters());out=ROOT/'results';prefix=out/f'{a.arm}_{a.seed}'
 if a.arm=='base':
  cp=ROOT.parent/'native002'/'results'/f'base_{a.seed}.pt';m.load_state_dict(torch.load(cp,weights_only=True,map_location='cpu')['weights']);res=dict(arm=a.arm,seed=a.seed,params=nparams,steps=1000,train_bytes=512000,checkpoint_sha256=hashlib.sha256(cp.read_bytes()).hexdigest(),reused=True,init_sha256=ih);res.update(score(m,ds,dev,test,a.arm));prefix.with_suffix('.json').write_text(json.dumps(res,indent=2));print('DONE',a.arm,a.seed,res['dev']['bpb'],res['test']['bpb'],flush=True);return
 g=torch.Generator().manual_seed(100000+a.seed);opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01);log=[];elapsed=0.;m.train()
 for i in range(1,1001):
  pos=starts[torch.randint(len(starts),(8,),generator=g)];batch=t[pos[:,None]+torch.arange(T+1)[None]];x,y=batch[:,:-1],batch[:,1:];s=time.perf_counter();opt.param_groups[0]['lr']=.001*min(1,i/50)*(.2+.8*.5*(1+math.cos(math.pi*i/1000)));opt.zero_grad(set_to_none=True);z=m(x);ce=F.cross_entropy(z.flatten(0,1),y.flatten());ce.backward();nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True);opt.step();elapsed+=time.perf_counter()-s
  if i in [1,250,500,750,1000]:
   val=evaluate(m,dev);m.train();row=dict(step=i,ce=ce.item(),dev_bpb=val['bpb']);log.append(row);print(a.arm,a.seed,row,flush=True);prefix.with_suffix('.progress.json').write_text(json.dumps(log))
 torch.save(dict(arm=a.arm,seed=a.seed,weights=m.state_dict()),prefix.with_suffix('.pt'))
 res=dict(arm=a.arm,seed=a.seed,params=nparams,steps=1000,train_bytes=512000,train_seconds=elapsed,init_sha256=ih,history_train=log,excluded_dev=de,excluded_test=te,reused=False);res.update(score(m,ds,dev,test,a.arm));prefix.with_suffix('.json').write_text(json.dumps(res,indent=2));print('DONE',a.arm,a.seed,res['dev']['bpb'],res['test']['bpb'],flush=True)
if __name__=='__main__':main()
