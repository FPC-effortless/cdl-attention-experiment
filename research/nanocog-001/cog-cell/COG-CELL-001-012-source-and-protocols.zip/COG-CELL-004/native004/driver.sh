#!/bin/bash
set -u
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cat jobs.txt base_jobs.txt | xargs -n2 -P4 bash -c 'python native004.py --arm "$0" --seed "$1" > "results/${0}_${1}.log" 2>&1; s=$?; printf "%s %s %s\n" "$0" "$1" "$s" >> exit_status; exit "$s"'
