from native004 import *
torch.set_num_threads(1);torch.set_num_interop_threads(1)
results={'source_sha256':hashlib.sha256((SRC/'run.py').read_bytes()).hexdigest(),'corpus_sha256':hashlib.sha256((SRC/'corpus.json').read_bytes()).hexdigest(),'torch':torch.__version__,'python':platform.python_version(),'cuda':torch.cuda.is_available(),'scan_checks':[],'seeds':[]}
for length in [1,2,3,7,16,47,64,129]:
 torch.manual_seed(length);A=torch.rand(2,length,K,K,dtype=torch.float64);A=(.8*A/A.sum(-1,keepdim=True)).requires_grad_();b=(torch.randn(2,length,K,H,dtype=torch.float64)*.1).requires_grad_();s=torch.randn(2,K,H,dtype=torch.float64,requires_grad=True)
 y,_=coupled_scan(A,b,s);p=s;ys=[]
 for i in range(length):p=A[:,i]@p+b[:,i];ys.append(p)
 z=torch.stack(ys,1);g1=torch.autograd.grad(y.square().sum(),(A,b,s));g2=torch.autograd.grad(z.square().sum(),(A,b,s));d=(y-z).abs().max().item();gd=max((a-b).abs().max().item() for a,b in zip(g1,g2));assert d<1e-10 and gd<1e-9;(results['scan_checks']).append(dict(length=length,output_diff=d,gradient_diff=gd))
for seed in SEEDS:
 torch.manual_seed(seed);base=model('base');torch.manual_seed(seed);peer=model('peer_feedback');torch.manual_seed(seed);selfm=model('self_feedback');x=torch.randint(0,256,(2,64));y=torch.randint(0,256,(2,64));zb,sb=base(x,with_state=True);zc,sc=peer(x,ab='bypass',with_state=True);F.cross_entropy(zb.flatten(0,1),y.flatten()).backward();F.cross_entropy(zc.flatten(0,1),y.flatten()).backward();info=dict(seed=seed,params=[sum(p.numel() for p in m.parameters()) for m in [base,peer,selfm]],original_weights_identical=all(torch.equal(v,peer.state_dict()[k]) for k,v in base.state_dict().items()),matched_init=init_hash(peer)==init_hash(selfm),bypass_logits_diff=(zb-zc).abs().max().item(),bypass_state_diff=max((p-q).abs().max().item() for s,t in zip(sb,sc) for p,q in zip(s,t)),bypass_grad_diff=max((p.grad-dict(peer.named_parameters())[k].grad).abs().max().item() for k,p in base.named_parameters()))
 assert info['original_weights_identical'] and info['matched_init'] and all(info[k]==0 for k in ['bypass_logits_diff','bypass_state_diff','bypass_grad_diff'])
 with torch.no_grad():
  xx=torch.randint(0,256,(2,129));full,ss=peer(xx,with_state=True);p,ps=peer(xx[:,:47],with_state=True);q,qs=peer(xx[:,47:],state=ps,with_state=True);info.update(chunk_diff=(full[:,47:]-q).abs().max().item(),causal_diff=(full[:,:47]-p).abs().max().item(),max_abs_private_state=max(l[1].abs().max().item() for l in ss),state_bytes=sum(v[0].numel()*v.element_size() for l in ss for v in l));assert info['chunk_diff']<1e-4 and info['causal_diff']<1e-4 and info['max_abs_private_state']<=1+1e-6
  # Direct one-layer perturbation with fixed h, inspect next private states only.
  h=torch.randn(1,1,D);st=(torch.zeros(1,D),torch.zeros(1,K,H));mut=(st[0].clone(),st[1].clone());mut[1][:,0]=.5
  for arm,m in [('self',selfm),('peer',peer)]:
   _,sa=m.layers[0](h,st);_,sb=m.layers[0](h,mut);delta=(sa[1]-sb[1]).abs().amax(-1)[0].tolist();info[arm+'_state_delta_by_cell']=delta;assert delta[0]>0 and ((delta[1]>0 and delta[2]==0 and delta[3]==0) if arm=='peer' else all(v==0 for v in delta[1:]))
 results['seeds'].append(info)
(ROOT/'preflight.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
