from native004 import *
from native004_benchmark import load
import statistics as st

def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 out={'scope':'Fixed exogenous layer input; perturb the initial private state of one cell, measure direct same-layer recurrent transfer, not cross-layer output effects. Diagnostic, not learned semantic specialization.','rows':[]}
 for arm in ['base']+ARMS:
  for seed in SEEDS:
   if not (ROOT/'results'/f'{arm}_{seed}.json').exists():continue
   m=load(arm,seed);g=torch.Generator().manual_seed(3711);inputs=torch.randn(1,16,D,generator=g)
   with torch.inference_mode():
    for layer,l in enumerate(m.layers):
     for cell in range(K):
      s=(torch.zeros(1,D),torch.zeros(1,K,H));p=(s[0].clone(),s[1].clone());p[1][:,cell]=.5;deltas=[]
      for t in range(16):
       _,s=l(inputs[:,t:t+1],s);_,p=l(inputs[:,t:t+1],p);deltas.append((p[1]-s[1]).abs().amax(-1)[0].tolist())
      out['rows'].append(dict(arm=arm,seed=seed,layer=layer,cell=cell,delta=deltas))
 out['summary']={}
 for arm in ['base']+ARMS:
  rows=[r for r in out['rows'] if r['arm']==arm]
  if rows:
   out['summary'][arm]={'cases':len(rows),'peer_transfer_at_first_step':sum(any(v>1e-7 for i,v in enumerate(r['delta'][0]) if i!=r['cell']) for r in rows),'max_other_cells_reached_at_steps_1_2_3_16':[max(sum(v>1e-7 for i,v in enumerate(r['delta'][k]) if i!=r['cell']) for r in rows) for k in [0,1,2,15]],'mean_delta_by_ring_distance_at_steps_1_2_3_4_8_16':[[st.mean(r['delta'][k][(r['cell']+d)%K] for r in rows) for d in range(K)] for k in [0,1,2,3,7,15]]}
 (ROOT/'diagnostics.json').write_text(json.dumps(out,indent=2));print(json.dumps(out['summary'],indent=2))
if __name__=='__main__':main()
