from run006 import *
from collections import defaultdict
@torch.no_grad()
def predictions(m,rows):
 x,idx,y=encode(rows);out=[]
 for a in x.split(64):out.extend(m(a)[:,1:].argmax(-1).tolist())
 t,mask=trace_targets(x,idx);return out,t.tolist()
def calculate(m):
 m.eval();ps=panel_rows();atomic=ps['atomic'];p,_=predictions(m,atomic);tab={r[0:1]+r[1]:q[0] for r,q in zip(atomic,p)}
 all3=[(x,op) for x in range(16) for op in product(range(6),repeat=3) if not held(op)];assert len(all3)==2400
 rows_by={'depth3_allowed_exhaustive':all3,**{k:ps[k] for k in ['depth2_heldout','depth4_allowed','depth4_heldout','depth8_allowed','depth12_allowed']}}
 out={}
 for name,rows in rows_by.items():
  preds,truth=predictions(m,rows);native=reset=rec=prev_correct=next_native=next_reset=0;groups=defaultdict(list);step_counts=[]
  for t in range(len(rows[0][1])):
   n=sum(int(pr[t]==yt[t]) for pr,yt in zip(preds,truth));step_counts.append(n)
  for (x,ops),pr,yt in zip(rows,preds,truth):
   native+=int(pr[-1]==yt[-1]);prev=pr[-2];reset_p=tab.get((prev,ops[-1]),-1);reset+=int(reset_p==yt[-1]);prev_correct+=int(prev==yt[-2]);next_native+=int(prev==yt[-2] and pr[-1]==yt[-1]);next_reset+=int(prev==yt[-2] and reset_p==yt[-1]);state=x
   for o in ops:state=tab.get((state,o),-1)
   rec+=int(state==yt[-1]);groups[(yt[-2],ops[-1])].append((pr[-1],yt[-1]))
  out[name]=dict(n=len(rows),native_correct=native,reset_correct=reset,atomic_table_rollout_correct=rec,previous_readout_correct=prev_correct,next_native_correct_given_previous_correct=next_native,next_reset_correct_given_previous_correct=next_reset,groups=len(groups),groups_all_same=sum(len({p for p,y in v})==1 for v in groups.values()),groups_all_correct=sum(all(p==y for p,y in v) for v in groups.values()),prefix_correct=step_counts)
 return out
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 import glob
 out={}
 for regime in ['final','trace']:
  for a in ARMS:
   for s in SEEDS:
    p=OLD/'results'/f'task_{a}_{s}.pt' if regime=='final' else ROOT/'results'/f'{a}_{s}_trace.phase1.pt'
    if not p.exists():continue
    m=model(a);m.load_state_dict(torch.load(p,weights_only=True,map_location='cpu')['weights']);key=f'{a}_{s}_{regime}';out[key]=dict(checkpoint_sha256=digest(p),scores=calculate(m));print(key,out[key]['scores']['depth3_allowed_exhaustive'],flush=True)
 (ROOT/'state_diagnostic.json').write_text(json.dumps(out,indent=2))
