#!/bin/bash
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cat jobs.txt | xargs -n3 -P4 bash -c 'python run006.py "$0" "$1" "$2" > "results/${0}_${1}_${2}.log" 2>&1; s=$?; printf "%s %s %s %s\n" "$0" "$1" "$2" "$s" >> exit_status; exit "$s"'
echo $? > driver_exit
