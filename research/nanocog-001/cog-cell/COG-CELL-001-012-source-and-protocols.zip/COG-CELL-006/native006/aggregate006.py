from run006 import *
from statistics import mean,stdev
from collections import defaultdict
import csv
ps=panel_rows();res={};checks=[];counts=defaultdict(int)
for p in sorted((ROOT/'results').glob('*.json')):
 if p.name.endswith('.phase1.json'):continue
 r=json.loads(p.read_text());a,s,g=r['arm'],r['seed'],r['regime'];res[(a,s,g)]=r;pref=ROOT/'results'/f'{a}_{s}_{g}'
 p1=OLD/'results'/f'task_{a}_{s}.pt' if g=='final' else pref.with_suffix('.phase1.pt');p2=pref.with_suffix('.phase2.pt');assert digest(p1)==r['phase1_checkpoint_sha256'];assert digest(p2)==r['phase2_checkpoint_sha256'];counts['phase1_checkpoint_hashes']+=1;counts['phase2_checkpoint_hashes']+=1
 for phase in [1,2]:
  d=r[f'phase{phase}_scores'];assert set(d)==set(ps)
  for k,panel in ps.items():
   q=d[k];truth=[answer(x,op) for x,op in panel];assert len(q['predictions'])==q['n']==len(truth);assert q['correct']==sum(p==y for p,y in zip(q['predictions'],truth));assert abs(q['acc']-q['correct']/q['n'])<1e-12;assert 0<=q['trajectory_correct']<=q['correct'];assert q['prefix_correct'][-1]==q['correct'];counts['final_predictions_audited']+=q['n'];counts['panel_receipts']+=1
 if g=='final':assert all(r['replay_matches'].values());counts['archived_panels_exact_replay']+=len(r['replay_matches'])
 for k,panels in r.get('phase2_interventions',{}).items():
  for key,q in panels.items():
   truth=[answer(x,op) for x,op in ps[key]];assert q['correct']==sum(p==y for p,y in zip(q['predictions'],truth));counts['intervention_predictions_audited']+=len(truth)
 checks.append({'arm':a,'seed':s,'regime':g,'ok':True})
for a in ARMS:
 for s in SEEDS:
  if (a,s,'trace') in res and (a,s,'final') in res:
   t,f=(res[a,s,k] for k in ['trace','final']);assert t['init_sha256']==f['init_sha256'];assert t['params']==f['params'];assert t['phase1_training']['train_batch_sha256']==f['phase1_training']['train_batch_sha256'];assert t['phase2_training']['train_batch_sha256']==f['phase2_training']['train_batch_sha256'];counts['matched_pairs']+=1
means={};gates=[];table=[]
for a in ARMS:
 for g in ['final','trace']:
  rr=[res[a,s,g] for s in SEEDS if (a,s,g) in res];m={}
  for phase in [1,2]:
   if not rr:continue
   vals={k:{'mean_acc':mean(r[f'phase{phase}_scores'][k]['acc'] for r in rr),'mean_trajectory':mean(r[f'phase{phase}_scores'][k]['trajectory_acc'] for r in rr),'per_seed_acc':{str(r['seed']):r[f'phase{phase}_scores'][k]['acc'] for r in rr},'mean_prefix':[mean(r[f'phase{phase}_scores'][k]['prefix_correct'][i]/r[f'phase{phase}_scores'][k]['prefix_n'][i] for r in rr) for i in range(len(rr[0][f'phase{phase}_scores'][k]['prefix_n']))]} for k in ps}
   m[str(phase)]=vals;table.append(dict(arm=a,regime=g,phase=phase,seeds=len(rr),**{k:v['mean_acc'] for k,v in vals.items()}))
  means[f'{a}_{g}']=m
for a in ARMS:
 for s in SEEDS:
  if (a,s,'trace') not in res or (a,s,'final') not in res:continue
  t,f=(res[a,s,k] for k in ['trace','final']);
  def passes(phase):
   x,y=(r[f'phase{phase}_scores'] for r in (t,f));return bool(x['atomic']['acc']>=.95 and x['depth2_heldout']['acc']>=.9 and x['depth4_heldout']['acc']>=.8 and x['depth8_allowed']['acc']>=.8 and all(x[k]['acc']-y[k]['acc']>=.1 for k in ['depth2_heldout','depth8_allowed']))
  gates.append({'arm':a,'seed':s,'trace_gate':passes(1),'retention_gate':passes(1) and passes(2) and all(t['phase2_scores'][k]['acc']>=t['phase1_scores'][k]['acc']-.05 for k in ['depth2_heldout','depth4_heldout','depth8_allowed'])})
summary={'n_completed':len(res),'checks':dict(counts),'verification':checks,'means':means,'gates':gates,'new_steps':sum(r['phase2_training']['steps']+(r['phase1_training']['steps'] if r['regime']=='trace' else 0) for r in res.values()),'new_training_examples':sum(r['phase2_training']['train_examples']+(r['phase1_training']['train_examples'] if r['regime']=='trace' else 0) for r in res.values()),'new_supervised_positions':sum(r['phase2_training']['supervised_positions']+(r['phase1_training']['supervised_positions'] if r['regime']=='trace' else 0) for r in res.values()),'phase1_trace_supervised_positions':sum(r['phase1_training']['supervised_positions'] for r in res.values() if r['regime']=='trace'),'all_done':len(res)==24}
(ROOT/'aggregate.json').write_text(json.dumps(summary,indent=2));
with (ROOT/'summary.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(table[0]));w.writeheader();w.writerows(table)
print(json.dumps({k:v for k,v in summary.items() if k!='means'},indent=1))
for row in table:print(row['arm'],row['regime'],row['phase'],row['seeds'],*[round(row[k]*100,2) for k in ps])
