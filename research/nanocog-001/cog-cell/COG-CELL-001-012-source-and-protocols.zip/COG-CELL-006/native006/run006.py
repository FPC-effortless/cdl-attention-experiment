import sys,pathlib,json,math,time,argparse,hashlib
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'native005'))
from composition_task import *
from composition_task import ROOT as OLD
ROOT=pathlib.Path(__file__).resolve().parent

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def trace_targets(x,idx):
 s=x[:,0].clone();targets=[];active=torch.arange(1,x.size(1))[None,:]<=idx[:,None];op=torch.as_tensor(OPS)
 for i in range(1,x.size(1)):
  a=op[(x[:,i]-32).clamp(0,5)];s=torch.where(active[:,i-1],(a[:,0]*s+a[:,1])%16,s);targets.append(s)
 return torch.stack(targets,1),active
@torch.no_grad()
def panel(m,rows,ab=None):
 m.eval();x,idx,y=encode(rows);p=[];correct=total=exact=0;nll=0.;prefix_correct=None;prefix_n=None
 for a,i,b in zip(x.split(64),idx.split(64),y.split(64)):
  z=m(a,ab=ab);target,mask=trace_targets(a,i);pred=z[:,1:].argmax(-1);ok=pred==target;last=z[torch.arange(len(i)),i];p+=last.argmax(-1).tolist();correct+=int((last.argmax(-1)==b).sum());nll+=F.cross_entropy(last,b,reduction='sum').item();total+=len(i);exact+=int((ok|~mask).all(1).sum());c=(ok&mask).sum(0);n=mask.sum(0);prefix_correct=c if prefix_correct is None else prefix_correct+c;prefix_n=n if prefix_n is None else prefix_n+n
 return dict(n=total,correct=correct,acc=correct/total,nll=nll/total,trajectory_correct=exact,trajectory_acc=exact/total,prefix_correct=prefix_correct.tolist(),prefix_n=prefix_n.tolist(),predictions=p)

def train(m,arm,seed,phase,objective):
 steps=1000 if phase==1 else 500; data_seed=seed if phase==1 else seed+500000;tr,idx,ys=train_arrays(data_seed,steps=steps);th=hashlib.sha256(b''.join(z.numpy().tobytes() for z in (tr,idx,ys))).hexdigest();opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01);log=[];nlabels=0;s=time.perf_counter();m.train()
 for step,(x,i,y) in enumerate(zip(tr,idx,ys),1):
  opt.param_groups[0]['lr']=.001*min(1,step/50)*(.2+.8*.5*(1+math.cos(math.pi*step/steps)));opt.zero_grad(set_to_none=True);z=m(x);end=z[torch.arange(len(i)),i];target,mask=trace_targets(x,i);assert torch.equal(target[torch.arange(len(i)),i-1],y)
  if objective=='trace':
   ce0=F.cross_entropy(z[:,1:].transpose(1,2),target,reduction='none');ce=((ce0*mask).sum(1)/i).mean();nlabels+=int(mask.sum())
  else:ce=F.cross_entropy(end,y);nlabels+=len(i)
  ce.backward();nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True);opt.step()
  if step in [1,250,500,750,1000]:
   row=dict(step=step,loss=ce.item(),final_batch_accuracy=(end.argmax(-1)==y).float().mean().item());log.append(row);print(arm,seed,phase,objective,row,flush=True)
 return dict(steps=steps,train_examples=steps*32,train_input_tokens=int((idx+1).sum()),supervised_positions=nlabels,train_batch_sha256=th,history=log,seconds=time.perf_counter()-s)

def score(m):return {k:panel(m,v) for k,v in panel_rows().items()}
def run(arm,seed,regime):
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(seed);m=model(arm);ih=init_hash(m);prefix=ROOT/'results'/f'{arm}_{seed}_{regime}';old=OLD/'results'/f'task_{arm}_{seed}';arch=json.loads(old.with_suffix('.json').read_text());assert ih==arch['init_sha256'];assert digest(old.with_suffix('.pt'))==arch['checkpoint_sha256'];params=sum(p.numel() for p in m.parameters());assert params==arch['params'];out=dict(arm=arm,seed=seed,regime=regime,params=params,init_sha256=ih,reference_hash=arch['checkpoint_sha256'])
 if regime=='final':
  m.load_state_dict(torch.load(old.with_suffix('.pt'),map_location='cpu',weights_only=True)['weights']);out['phase1_training']={'reused':True,'steps':1000,'train_examples':32000,'supervised_positions':32000,'train_batch_sha256':arch['train_batch_sha256']};out['phase1_checkpoint_sha256']=arch['checkpoint_sha256']
 else:
  out['phase1_training']=train(m,arm,seed,1,'trace');assert out['phase1_training']['train_batch_sha256']==arch['train_batch_sha256'];p=prefix.with_suffix('.phase1.pt');torch.save(dict(arm=arm,seed=seed,regime=regime,weights=m.state_dict()),p);out['phase1_checkpoint_sha256']=digest(p)
 out['phase1_scores']=score(m)
 if regime=='final':
  out['replay_matches']={k:v['predictions']==arch['scores'][k]['predictions'] for k,v in out['phase1_scores'].items()};assert all(out['replay_matches'].values())
 prefix.with_suffix('.phase1.json').write_text(json.dumps(out,indent=2));print('PHASE1',arm,seed,regime,{k:round(v['acc'],3) for k,v in out['phase1_scores'].items()},flush=True)
 out['phase2_training']=train(m,arm,seed,2,'final');p=prefix.with_suffix('.phase2.pt');torch.save(dict(arm=arm,seed=seed,regime=regime,weights=m.state_dict()),p);out['phase2_checkpoint_sha256']=digest(p);out['phase2_scores']=score(m)
 if arm!='base' and regime=='trace':out['phase2_interventions']={ab:{k:panel(m,panel_rows()[k],ab) for k in ['atomic','depth2_heldout','depth4_heldout','depth8_allowed']} for ab in ['self_message','raw_message','reverse_message','no_B','no_feedback']}
 prefix.with_suffix('.json').write_text(json.dumps(out,indent=2));print('DONE',arm,seed,regime,{k:round(v['acc'],3) for k,v in out['phase2_scores'].items()},flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('arm',choices=ARMS);p.add_argument('seed',type=int);p.add_argument('regime',choices=['trace','final']);a=p.parse_args();run(a.arm,a.seed,a.regime)
