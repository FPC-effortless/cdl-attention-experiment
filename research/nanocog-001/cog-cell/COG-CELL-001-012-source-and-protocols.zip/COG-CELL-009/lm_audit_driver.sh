#!/bin/bash
cd /mnt/data/cog_cell_009
while [ ! -f benchmark_exit ]; do sleep 2; done
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 python native009/lm_audit009.py > lm_audit.log 2>&1; echo $? > lm_audit_exit
