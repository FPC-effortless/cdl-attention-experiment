from run009 import *

def clean(ds,split):
 tr=[bytes(t.tolist()) for t in ds['train']];rows=[];excluded=[]
 for i,d in enumerate(ds[split]):
  a=orig.windows(d,64,24);keep=[]
  for j,w in enumerate(a):
   if any(bytes(w.tolist()) in t for t in tr):excluded.append([i,j])
   else:keep.append(j)
  rows.append(a[keep])
 return rows,excluded
@torch.no_grad()
def evaluate(m,rows,ab=None):
 m.eval();ls=n=ok=0
 for a in rows:
  for b in a.split(8):
   x,y=b[:,:-1],b[:,1:];z=m(x,ab=ab);ls+=F.cross_entropy(z.flatten(0,1),y.flatten(),reduction='sum').item();n+=y.numel();ok+=int((z.argmax(-1)==y).sum())
 return dict(bpb=ls/n/math.log(2),acc=ok/n,n=n)

def main(arm,seed):
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(seed);m=model(arm);ih=hash_tensors(v for k,v in m.named_parameters() if 'rotation' not in k);ds=orig.data();dev,de=clean(ds,'dev');test,te=clean(ds,'test');t,starts=orig.train_data(ds['train']);g=torch.Generator().manual_seed(100000+seed);p=ROOT/'lm_results'/f'{arm}_{seed}';log=[];elapsed=0.;batchhash=hashlib.sha256();steps=1000
 if arm=='base':
  cp=ROOT/'lm_controls'/f'base_{seed}.pt';old=json.loads(cp.with_suffix('.json').read_text());m.load_state_dict(torch.load(cp,weights_only=True,map_location='cpu')['weights']);elapsed=old['train_seconds']
 else:
  opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01);m.train();start=time.perf_counter()
  for i in range(1,steps+1):
   pos=starts[torch.randint(len(starts),(8,),generator=g)];batch=t[pos[:,None]+torch.arange(65)[None]];batchhash.update(batch.numpy().tobytes());x,y=batch[:,:-1],batch[:,1:];opt.param_groups[0]['lr']=.001*min(1,i/50)*(.2+.8*.5*(1+math.cos(math.pi*i/steps)));opt.zero_grad(set_to_none=True);z=m(x);ce=F.cross_entropy(z.flatten(0,1),y.flatten());ce.backward();nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True);opt.step()
   if i in [1,250,500,750,1000]:row=dict(step=i,ce=ce.item());log.append(row);print(arm,seed,row,flush=True)
  elapsed=time.perf_counter()-start;cp=p.with_suffix('.pt');torch.save(dict(arm=arm,seed=seed,weights=m.state_dict()),cp)
 res=dict(arm=arm,seed=seed,params=sum(p.numel() for p in m.parameters()),steps=steps,reused=arm=='base',training_bytes=512000,train_seconds=elapsed,base_init_sha256=ih,batch_sha256=batchhash.hexdigest() if arm!='base' else None,checkpoint_sha256=hashlib.sha256(cp.read_bytes()).hexdigest(),log=log,excluded_dev=de,excluded_test=te,dev=evaluate(m,dev),test=evaluate(m,test),stream=orig.streaming(m,ds['test'][0]))
 if arm=='base':res['replay_dev_diff']=res['dev']['bpb']-old['dev']['bpb'];res['replay_test_diff']=res['test']['bpb']-old['test']['bpb']
 else:res['ablation']={ab:evaluate(m,test,ab) for ab in ['no_rotation','damp','self','bypass']}
 p.with_suffix('.json').write_text(json.dumps(res,indent=2));print('DONE',arm,seed,res['dev']['bpb'],res['test']['bpb'],flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('arm',choices=['base','orthogonal','damped']);p.add_argument('seed',type=int);a=p.parse_args();main(a.arm,a.seed)
