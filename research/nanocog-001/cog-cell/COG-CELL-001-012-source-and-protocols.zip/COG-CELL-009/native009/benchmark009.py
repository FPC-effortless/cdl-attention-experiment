'''Isolated, single-thread CPU benchmark. Native language checkpoints, same input per architecture.''' 
from run009 import *
import statistics,platform
@torch.inference_mode()
def benchmark(m,x):
 m.eval();out={};z=x[:,:64];p=x[:,:512]
 for label,a in [('prefill64',z),('prefill512',p)]:
  for _ in range(3):m(a,with_state=True)
  times=[]
  for _ in range(7):
   start=time.perf_counter()
   for _ in range(10):m(a,with_state=True)
   times.append((time.perf_counter()-start)*1e6/(10*a.numel()))
  out[label]={'median_us_per_byte':statistics.median(times),'passes':times}
 def decode():
  st=None
  for i in range(128):_,st=m(x[:,i:i+1],state=st,with_state=True)
  return st
 decode();times=[]
 for _ in range(5):
  start=time.perf_counter();st=decode();times.append((time.perf_counter()-start)*1e6/128)
 out['decode']={'median_us_per_byte':statistics.median(times),'passes':times};out['state_bytes']=sum(t.numel()*t.element_size() for l in st for t in l);return out

def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);ds=orig.data();x=ds['test'][0][:512][None];assert x.size(1)==512;results=[]
 # Interleave models by seed and rotate arm order.
 for j,s in enumerate(SEEDS):
  arms=['base','orthogonal','damped'];arms=arms[j:]+arms[:j]
  for a in arms:
   d=json.loads((ROOT/'lm_results'/f'{a}_{s}.json').read_text());p=(ROOT/'lm_controls' if a=='base' else ROOT/'lm_results')/f'{a}_{s}.pt';assert hashlib.sha256(p.read_bytes()).hexdigest()==d['checkpoint_sha256'];m=model(a);m.load_state_dict(torch.load(p,weights_only=True,map_location='cpu')['weights']);b=benchmark(m,x);results.append(dict(arm=a,seed=s,metrics=b));print(a,s,{k:round(v['median_us_per_byte'],2) for k,v in b.items() if isinstance(v,dict)},flush=True)
 (ROOT/'benchmark.json').write_text(json.dumps(dict(platform=platform.platform(),torch_version=torch.__version__,threads=torch.get_num_threads(),results=results),indent=2))
if __name__=='__main__':main()
