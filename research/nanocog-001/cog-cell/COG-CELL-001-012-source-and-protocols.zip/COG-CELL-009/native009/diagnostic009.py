from run009 import *
import itertools
@torch.no_grad()
def load(arm,seed):
 m=model(arm);p=ROOT/'results'/f'{arm}_{seed}.pt';m.load_state_dict(torch.load(p,map_location='cpu',weights_only=True)['weights']);m.eval();return m
@torch.no_grad()
def exhaust(m):
 # Exhaustive depth-four domain. Report exact trajectory accuracy and final accuracy separately.
 rows=[(x,o) for x in range(16) for o in product(range(6),repeat=4)];out={key:dict(n=0,correct_prefix=[0]*4,exact_trajectory=0,wrong_order_groups=0,order_pairs=0) for key in ['allowed','held']};preds={}
 for a in range(0,len(rows),128):
  sub=rows[a:a+128];x,y=encode(sub);z=m(x)[:,1:].argmax(-1);state=x[:,0];targets=[];ops=torch.tensor(OPS)
  for j in range(4):
   a=ops[x[:,j+1]-32];state=(a[:,0]*state+a[:,1])%16;targets.append(state)
  y=torch.stack(targets,1);ok=z==y
  for name,ho in [('allowed',False),('held',True)]:
   mask=torch.tensor([held(o)==ho for _,o in sub]);d=out[name];d['n']+=int(mask.sum());d['correct_prefix']=[a+b for a,b in zip(d['correct_prefix'],ok[mask].sum(0).tolist())];d['exact_trajectory']+=int(ok[mask].all(1).sum())
  for row,p,t in zip(sub,z[:,-1].tolist(),y[:,-1].tolist()):preds[row]=(p,t)
 for (x,o),(p,t) in preds.items():
  rev=o[::-1]
  if o>=rev:continue
  p2,t2=preds[x,rev]
  if t==t2:continue
  key='held' if held(o) else 'allowed';d=out[key];d['order_pairs']+=1;d['wrong_order_groups']+=int(p!=t or p2!=t2)
 return out
@torch.no_grad()
def geometry(m):
 if not isinstance(m.layers[0],RotBlock):return None
 l=m.layers[0];l.record=True;m(torch.arange(38)[:,None]);l.record=False;g=l.last_keep[32:38,0];ang=l.last_angles[32:38,0];q=matrices(ang,l.mode);q16=torch.linalg.matrix_power(q[0],16);eye=torch.eye(4);errors=(q16-eye).norm(dim=(-1,-2));comm=[]
 for a,b in [(0,2),(1,3),(4,5)]:comm.append(float((q[a]@q[b]-q[b]@q[a]).norm(dim=(-1,-2)).mean()))
 # Actual state return test using all 16 initial values and +1 token; same-value return after 16 operations.
 x=torch.arange(16)[:,None];_,s=m(x,with_state=True);orig_s=s[0][1][...,:16];z=torch.full((16,16),32);_,s1=m(z,state=s,with_state=True);next_s=s1[0][1][...,:16];return dict(keep_plus1=g[0].tolist(),learned_phase_angles_plus1=ang[0].tolist(),q16_frobenius=errors.tolist(),q16_frobenius_mean=float(errors.mean()),commutators_mean=comm,actual_state_cycle_rmse=float((orig_s-next_s).square().mean().sqrt()),actual_state_start_rmse=float(orig_s.square().mean().sqrt()))

def main(arm,seed):
 torch.set_num_threads(1);torch.set_num_interop_threads(1);m=load(arm,seed);res=dict(arm=arm,seed=seed,exhaust=exhaust(m),geometry=geometry(m));(ROOT/'diagnostics'/f'{arm}_{seed}.json').write_text(json.dumps(res,indent=2));print(arm,seed,res['exhaust'],flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('arm',choices=ARMS);p.add_argument('seed',type=int);a=p.parse_args();main(a.arm,a.seed)
