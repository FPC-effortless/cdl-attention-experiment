'''Recompute recorded answer counts using independent modular arithmetic; verify frozen-source hashes and matched batches; replay heldout2/allowed8.''' 
from run009 import *
import subprocess

def verify():
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 for f in ['prefit_sha256.txt','lm_prefit_sha256.txt','diagnostic_source_sha256.txt']:
  subprocess.run(['sha256sum','-c',f],cwd=ROOT,check=True)
 assert sorted((ROOT/'exit_status').read_text().splitlines())==sorted(f'{a} {s} 0' for a in ARMS for s in SEEDS)
 ps=panels();r={};total_predictions=0;replays=0;stats={}
 def oracle(x,seq):
  # Independent composed affine map, modulo only at the final evaluation.
  a,b=1,0
  for i in seq:
   p,q=map(int,OPS[i]);a=p*a;b=p*b+q
  return (a*x+b)%16
 for s in SEEDS:
  records=[json.loads((ROOT/'results'/f'{a}_{s}.json').read_text()) for a in ARMS]
  assert len({d['base_init_sha256'] for d in records})==1
  assert len({d['init_sha256'] for d in records[1:]})==1
  assert len({d['batch_sha256'] for d in records})==1
  assert len({d['params'] for d in records[1:]})==1
  bs=batchdata(s);assert hash_tensors(v for row in bs for v in row)==records[0]['batch_sha256']
  for x,y in bs:
   for row,ys in zip(x.tolist(),y.tolist()):
    ops=tuple(o-32 for o in row[1:]);assert not held(ops);assert [oracle(row[0],ops[:i]) for i in range(1,len(ops)+1)]==ys
  for d in records:
   a=d['arm'];p=ROOT/'results'/f'{a}_{s}.pt';assert hashlib.sha256(p.read_bytes()).hexdigest()==d['checkpoint_sha256'];assert d['steps']==STEPS;assert d['log'][-1]['step']==STEPS
   for k,v in d['scores'].items():
    rr=ps[k];assert len(rr)==v['n']==len(v['predictions']);assert sum(oracle(x,o)==p for (x,o),p in zip(rr,v['predictions']))==v['correct'];total_predictions+=len(rr)
   for h,v in d['repeat'].items():assert sum((x+int(h))%16==p for x,p in enumerate(v['predictions']))==v['correct'];total_predictions+=16
   for ab,abl in d['ablation'].items():
    for k in ['held2','allowed8']:
     v=abl[k];assert sum(oracle(x,o)==p for (x,o),p in zip(ps[k],v['predictions']))==v['correct'];total_predictions+=v['n']
    for h,v in abl['repeat'].items():assert sum((x+int(h))%16==p for x,p in enumerate(v['predictions']))==v['correct'];total_predictions+=16
   m=model(a);m.load_state_dict(torch.load(p,map_location='cpu',weights_only=True)['weights'])
   for k in ['held2','allowed8']:
    assert eval_rows(m,ps[k])['predictions']==d['scores'][k]['predictions'];replays+=1
   assert d['stream']['state_bytes']==3136
   stats[a,s]=d;print('PASS',a,s,flush=True)
 summary={}
 for a in ARMS:
  ds=[stats[a,s] for s in SEEDS]
  summary[a]={'n':len(ds),'params':ds[0]['params'],'scores':{k:float(np.mean([d['scores'][k]['acc'] for d in ds])) for k in ps},'repeat_accuracy':{k:sum(d['repeat'][k]['correct'] for d in ds)/(16*len(ds)) for k in ds[0]['repeat']},'mean_rot_state_span_1024':float(np.mean([d['repeat']['1024']['subspace_span'] for d in ds])),'mean_full_state_span_1024':float(np.mean([d['repeat']['1024']['state_span'] for d in ds])),'stream_disagree':sum(d['stream']['disagree'] for d in ds),'max_stream_logit_diff':max(d['stream']['max_logit_diff'] for d in ds),'train_seconds_mean':float(np.mean([d['train_seconds'] for d in ds])),'ablation':{ab:{k:float(np.mean([d['ablation'][ab][k]['acc'] for d in ds])) for k in ['held2','allowed8']} for ab in ds[0]['ablation']}}
  if a!='base':summary[a]['mean_keep_exact_fraction']=float(np.mean([d['gate_diag']['exact_keep_fraction'] for d in ds]));summary[a]['mean_op_keep']=float(np.mean([d['gate_diag']['mean_op_keep'] for d in ds]));summary[a]['mean_max_commutator']=float(np.mean([d['gate_diag']['op_commutator_max'] for d in ds]))
 r=dict(status='PASS',predictions_recomputed=total_predictions,panel_replays=replays,matched_batches_and_original_initialization=True,training_examples=sum(d['training_examples'] for d in stats.values()),supervised_positions=sum(d['supervised_positions'] for d in stats.values()),train_tokens=sum(d['tokens'] for d in stats.values()),summary=summary)
 (ROOT/'task_audit.json').write_text(json.dumps(r,indent=2));print('AUDIT PASS',total_predictions,replays,flush=True)
if __name__=='__main__':verify()
