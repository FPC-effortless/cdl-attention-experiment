'''Analytic constructive witness for exact affine actions in an 8D real Fourier subspace; not trained COG.'''
from run009 import *
@torch.no_grad()
def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1)
 vals=torch.arange(16,dtype=torch.float64);freq=[1,3,5,7];angle=vals[:,None]*torch.tensor(freq,dtype=torch.float64)[None,:]*math.tau/16
 phi=torch.stack((angle.cos(),angle.sin()),dim=-1).flatten(-2)/2.;operators=[]
 for a,b in OPS.tolist():
  M=torch.zeros(8,8,dtype=torch.float64)
  for i,k in enumerate(freq):
   r=k*a%16;sign=1 if r<8 else -1;j=freq.index(min(r,16-r));theta=k*b*math.tau/16;c,s=math.cos(theta),math.sin(theta);M[2*i:2*i+2,2*j:2*j+2]=torch.tensor([[c,-sign*s],[s,sign*c]],dtype=torch.float64)
  operators.append(M)
 operators=torch.stack(operators);ortho=float((operators@operators.transpose(-1,-2)-torch.eye(8)).abs().max());one_step=float(max((phi@M.T-phi[(vals.long()*a+b)%16]).abs().max() for (a,b),M in zip(OPS.tolist(),operators)))
 rng=np.random.default_rng(909991);out={};forbidden=FORBIDDEN
 for L in [4,8,12,64,1024]:
  n=256;x=torch.from_numpy(rng.integers(16,size=n));ops=rng.integers(6,size=(n,L));s=phi[x];t=x.clone()
  for j in range(L):
   idx=torch.from_numpy(ops[:,j]);s=(operators[idx]@s[...,None]).squeeze(-1);o=torch.from_numpy(OPS[ops[:,j]]);t=(o[:,0]*t+o[:,1])%16
  pred=(s@phi.T).argmax(-1);out[str(L)]={'n':n,'correct':int((pred==t).sum()),'max_absolute_error':float((s-phi[t]).abs().max())}
 res=dict(orthogonality_error=ortho,one_step_error=one_step,determinants=torch.linalg.det(operators).tolist(),results=out,warning='Explicit analytic encoding and known operations; not learned weights. No model claim.');(ROOT/'fourier_capacity.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
if __name__=='__main__':main()
