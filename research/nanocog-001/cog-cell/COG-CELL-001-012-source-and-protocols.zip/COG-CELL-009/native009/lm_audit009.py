from language009 import *
import subprocess

def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);subprocess.run(['sha256sum','-c','lm_prefit_sha256.txt'],cwd=ROOT,check=True);assert sorted((ROOT/'lm_exit_status').read_text().splitlines())==sorted(f'{a} {s} 0' for a in ['base','orthogonal','damped'] for s in SEEDS)
 ds=orig.data();dev,_=clean(ds,'dev');test,_=clean(ds,'test');t,starts=orig.train_data(ds['train']);scores={}
 for s in SEEDS:
  rec=[json.loads((ROOT/'lm_results'/f'{a}_{s}.json').read_text()) for a in ['base','orthogonal','damped']];assert len({d['base_init_sha256'] for d in rec})==1;assert rec[1]['batch_sha256']==rec[2]['batch_sha256'];assert rec[1]['params']==rec[2]['params'];g=torch.Generator().manual_seed(100000+s);h=hashlib.sha256()
  for _ in range(1000):pos=starts[torch.randint(len(starts),(8,),generator=g)];b=t[pos[:,None]+torch.arange(65)[None]];h.update(b.numpy().tobytes())
  assert h.hexdigest()==rec[1]['batch_sha256']
  for d in rec:
   a=d['arm'];p=(ROOT/'lm_controls' if a=='base' else ROOT/'lm_results')/f'{a}_{s}.pt';assert hashlib.sha256(p.read_bytes()).hexdigest()==d['checkpoint_sha256'];assert d['steps']==1000 and d['training_bytes']==512000;m=model(a);m.load_state_dict(torch.load(p,weights_only=True,map_location='cpu')['weights']);r=evaluate(m,test);assert abs(r['bpb']-d['test']['bpb'])<1e-9 and r['acc']==d['test']['acc'];assert d['stream']['state_bytes']==3136
   if a=='base':assert abs(d['replay_dev_diff'])<1e-8 and abs(d['replay_test_diff'])<1e-8
   else:assert d['log'][-1]['step']==1000
   scores[a,s]=d;print('PASS',a,s,flush=True)
 out={'status':'PASS','test_score_replays':9,'summary':{}}
 for a in ['base','orthogonal','damped']:
  dd=[scores[a,s] for s in SEEDS];out['summary'][a]={'dev_bpb':float(np.mean([d['dev']['bpb'] for d in dd])),'test_bpb':float(np.mean([d['test']['bpb'] for d in dd])),'test_acc':float(np.mean([d['test']['acc'] for d in dd])),'stream_argmax_disagree':sum(d['stream']['argmax_disagree'] for d in dd),'train_seconds_mean':float(np.mean([d['train_seconds'] for d in dd])),'ablation_delta_bpb':{k:float(np.mean([d['ablation'][k]['bpb']-d['test']['bpb'] for d in dd])) for k in dd[0].get('ablation',{})}}
 (ROOT/'lm_audit.json').write_text(json.dumps(out,indent=2));print('AUDIT PASS',flush=True)
if __name__=='__main__':main()
