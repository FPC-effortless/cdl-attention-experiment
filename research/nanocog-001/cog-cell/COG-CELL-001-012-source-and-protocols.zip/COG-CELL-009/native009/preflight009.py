from run009 import *
torch.set_num_threads(1)
for seed in SEEDS:
 torch.manual_seed(seed);base=model('base');x=torch.randint(0,38,(3,7));b,bs=base(x,with_state=True)
 for arm in ARMS[1:]:
  torch.manual_seed(seed);m=model(arm);v,st=m(x,ab='bypass',with_state=True);assert torch.equal(b,v);assert all(torch.equal(c,d) for l,k in zip(bs,st) for c,d in zip(l,k));assert all(torch.equal(p,m.state_dict()[k]) for k,p in base.state_dict().items());loss=m(x).square().mean();loss.backward();assert all(torch.isfinite(p.grad).all() for p in m.parameters() if p.grad is not None);print(seed,arm,sum(p.numel() for p in m.parameters()),stream(m))
for n in [1,2,3,7,16,33,64]:
 a=torch.randn(2,n,4,4,4,dtype=torch.float64,requires_grad=True);g=torch.rand(2,n,4,4,1,1,dtype=torch.float64);Q=matrices(a,'orthogonal');A=g*Q;b=torch.randn(2,n,4,4,4,1,dtype=torch.float64,requires_grad=True);s=torch.randn(2,4,4,4,1,dtype=torch.float64);y,l=affine_scan(A,b,s);ys=[]
 for i in range(n):s=A[:,i]@s+b[:,i];ys.append(s)
 ref=torch.stack(ys,1);assert torch.allclose(y,ref,atol=1e-10,rtol=1e-10);gp=torch.autograd.grad(y.square().sum(),[a,b],retain_graph=True);gr=torch.autograd.grad(ref.square().sum(),[a,b]);assert all(torch.allclose(c,d,atol=1e-9,rtol=1e-9) for c,d in zip(gp,gr));print('scan',n,float((y-ref).abs().max().detach()))
