'''Analytic capacity sanity check only; not a trained network. Same rotation matrix and scan as native009.'''
from run009 import *
@torch.no_grad()
def main():
 torch.set_num_threads(1);out={}
 for dtype in [torch.float32,torch.float64]:
  # Embed 16 cyclic states as a unit circle in a 4D block. This deliberately supplies the exact phase.
  x=torch.arange(16,dtype=dtype)*math.tau/16;s=torch.stack((x.cos(),x.sin(),torch.zeros_like(x),torch.zeros_like(x)),-1);basis=s.clone();s=s[...,None];res={}
  for cap,eps in [(1.,0.),(.99,0.),(1.,.001),(1.,.01)]:
   a=torch.tensor([math.tau/16+eps,0.,0.,0.],dtype=dtype);Q=matrices(a,'orthogonal');st=s.clone();rows={};last=0
   for n in [1,16,64,256,1024,4096]:
    for j in range(last,n,64):
     L=min(64,n-j);A=(cap*Q).expand(16,L,4,4);b=torch.zeros(16,L,4,1,dtype=dtype);_,st=affine_scan(A,b,st)
    pred=(st.squeeze(-1)@basis.T).argmax(-1);truth=(torch.arange(16)+n)%16;rows[str(n)]={'correct':int((pred==truth).sum()),'mean_norm':float(st.norm(dim=-2).mean()),'max_absolute_error':float((st.squeeze(-1)-basis[truth]).abs().max())};last=n
   res[f'cap={cap}_phase_error={eps}']=rows
  out[str(dtype)]=res
 (ROOT/'capacity.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
