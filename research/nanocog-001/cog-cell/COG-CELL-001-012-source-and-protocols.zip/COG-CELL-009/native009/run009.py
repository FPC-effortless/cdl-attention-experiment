import sys,pathlib,math,time,json,hashlib,argparse
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
from itertools import product
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'cog_unified_006'))
import run as orig
from previous_reference import scan
K,D,H=orig.K,orig.D,orig.H
OPS=np.array([[1,1],[1,3],[3,1],[5,2],[7,3],[15,4]],np.int64)
FORBIDDEN={(0,2),(2,0),(1,3),(3,1),(4,5),(5,4)}
NEXT=np.array([[j for j in range(6) if (i,j) not in FORBIDDEN] for i in range(6)])
ARMS=['base','commuting','orthogonal','damped']; SEEDS=[173,271,907]; STEPS=1000; BATCH=32

def affine_scan(A,b,s=None):
 if s is None:s=torch.zeros_like(b[:,0])
 def rec(A,b,s):
  n=b.shape[1]
  if n==1:return b+A@s[:,None]
  p=n//2;ae=A[:,::2];be=b[:,::2];ao=A[:,1::2];bo=b[:,1::2]
  odd=rec(ao@ae[:,:p],bo+ao@be[:,:p],s)
  prior=torch.cat((s[:,None],odd[:,:ae.shape[1]-1]),dim=1)
  even=be+ae@prior
  out=torch.stack((even[:,:p],odd),dim=2).flatten(1,2)
  return torch.cat((out,even[:,-1:]),dim=1) if n%2 else out
 y=rec(A,b,s);return y,y[:,-1]

def pair_rot(a,b):
 ca,sa,cb,sb=a.cos(),a.sin(),b.cos(),b.sin();z=torch.zeros_like(ca)
 return torch.stack([ca,-sa,z,z,sa,ca,z,z,z,z,cb,-sb,z,z,sb,cb],-1).unflatten(-1,(4,4))

def matrices(angles,mode):
 a,b,c,d=angles.unbind(-1);A=pair_rot(a,b);B=pair_rot(c,d)
 if mode!='commuting':B=B[..., [0,2,1,3],:][...,:,[0,2,1,3]]
 return B@A

class RotBlock(orig.Block):
 def forward(self,h,state=None,ab=None):
  if ab=='bypass':return super().forward(h,state)
  u=self.norm(h);z,a=self.inp(u).chunk(2,-1);r,rs=scan(z.tanh(),.5+.49*a.sigmoid(),None if state is None else state[0]);q=r+u;v=self.pub(q).tanh().unflatten(-1,(K,H));w,rp,g=self.route(q).split([K,K,1],-1);w=w.sigmoid()*2/K;rp=rp.sigmoid()*2/K
  gate=.8*g.sigmoid()*w
  prev=None if state is None else state[1];tail,tail_last=scan(v[...,16:],1-gate[...,None],None if prev is None else prev[...,16:]);par=self.rotation(u).unflatten(-1,(K,4,5));angles=par[...,:4];keep=(.85+par[...,4]).clamp(0,1)
  if self.mode=='damped' or ab=='damp':keep=keep*.99
  if ab=='no_rotation':angles=torch.zeros_like(angles)
  Q=matrices(angles,self.mode);vv=v[...,:16].unflatten(-1,(4,4));vv=vv/vv.norm(dim=-1,keepdim=True).clamp_min(1.)
  rot,rl=affine_scan(keep[...,None,None]*Q,((1-keep)[...,None]*vv)[...,None],None if prev is None else prev[...,:16].unflatten(-1,(4,4))[...,None]);rot=rot.squeeze(-1).flatten(-2);rl=rl.squeeze(-1).flatten(-2);ms=torch.cat((rot,tail),-1);last=torch.cat((rl,tail_last),-1);m=ms*rp[...,None]*K
  if getattr(self,'record',False):self.last_keep=keep.detach();self.last_angles=angles.detach();self.last_ms=ms.detach()
  aa=self.A(m).tanh();src=m.roll(1,-2) if ab!='self' else m;bb=self.B(src).tanh();y=aa*(1+bb);msg=self.recv(self.msgnorm(y.flatten(-2)));h=h+self.out(r+self.combine(q).sigmoid()*msg);h=h+self.ff(self.norm2(h));return h,(rs,last)

def model(arm):
 m=orig.LM('composed')
 if arm!='base':
  l=m.layers[0];l.__class__=RotBlock;l.mode=arm;l.rotation=nn.Linear(D,K*4*5);nn.init.normal_(l.rotation.weight,std=.005);nn.init.zeros_(l.rotation.bias)
 return m

def held(ops):return any((a,b) in FORBIDDEN for a,b in zip(ops,ops[1:]))
def answer(x,ops):
 for o in ops:x=int((OPS[o,0]*x+OPS[o,1])%16)
 return x

def sample(rng,n,L,ood):
 out=[];seen=set()
 while len(out)<n:
  x=int(rng.integers(16));ops=tuple(map(int,rng.integers(6,size=L)));row=(x,ops)
  if held(ops)==ood and row not in seen:seen.add(row);out.append(row)
 return out

def panels():
 r=np.random.default_rng(900093);all2=[(x,o) for x in range(16) for o in product(range(6),repeat=2)]
 p={'atomic':[(x,(o,)) for x in range(16) for o in range(6)],'allowed2':[v for v in all2 if not held(v[1])],'held2':[v for v in all2 if held(v[1])]}
 for L,ood in [(4,False),(4,True),(8,False),(8,True),(12,False)]:p[f'{"held" if ood else "allowed"}{L}']=sample(r,1024,L,ood)
 return p

def batchdata(seed,steps=STEPS):
 rng=np.random.default_rng(910009+seed);out=[]
 for _ in range(steps):
  L=int(rng.integers(1,5));x=rng.integers(16,size=BATCH);ops=np.empty((BATCH,L),np.int64);ops[:,0]=rng.integers(6,size=BATCH)
  for j in range(1,L):ops[:,j]=NEXT[ops[:,j-1],rng.integers(5,size=BATCH)]
  assert all(not held(tuple(row)) for row in ops)
  inp=np.concatenate([x[:,None],ops+32],1);y=[]
  for j in range(L):x=(OPS[ops[:,j],0]*x+OPS[ops[:,j],1])%16;y.append(x.copy())
  out.append((torch.from_numpy(inp),torch.from_numpy(np.stack(y,1))))
 return out

def hash_tensors(ts):return hashlib.sha256(b''.join(t.detach().cpu().numpy().tobytes() for t in ts)).hexdigest()

def encode(rows):return torch.tensor([[x]+[o+32 for o in ops] for x,ops in rows]),torch.tensor([answer(x,ops) for x,ops in rows])
@torch.no_grad()
def eval_rows(m,rows,ab=None):
 m.eval();x,y=encode(rows);p=[];loss=0.
 for a,b in zip(x.split(64),y.split(64)):
  z=m(a,ab=ab)[:,-1];p.extend(z.argmax(-1).tolist());loss+=F.cross_entropy(z,b,reduction='sum').item()
 correct=int((torch.tensor(p)==y).sum());return dict(n=len(y),correct=correct,acc=correct/len(y),nll=loss/len(y),predictions=p)
@torch.no_grad()
def repeated(m,ab=None):
 m.eval();x=torch.arange(16)[:,None];_,st=m(x,with_state=True,ab=ab);z=torch.full((16,1),32,dtype=torch.long);out={};steps=[1,2,4,8,16,32,64,128,256,512,1024];last=0
 # Chunked recurrence evaluation; record endpoint after each specified number of operations.
 for n in steps:
  for length in ([min(16,n-last-i) for i in range(0,n-last,16)]):
   logits,st=m(z.expand(-1,length),state=st,with_state=True,ab=ab)
  pred=logits[:,-1].argmax(-1);target=(x[:,0]+n)%16;s=st[0][1];span=(s.max(0).values-s.min(0).values).abs().max().item()
  out[str(n)]=dict(correct=int((pred==target).sum()),predictions=pred.tolist(),state_span=span,subspace_span=(s[...,:16].max(0).values-s[...,:16].min(0).values).abs().max().item(),max_quartet_norm=s[...,:16].unflatten(-1,(4,4)).norm(dim=-1).max().item());last=n
 return out
@torch.no_grad()
def stream(m):
 m.eval();x=torch.tensor([[1]+[32,33,34,35,36,37]*11]);a,s=m(x,with_state=True);st=None;ys=[]
 for i in range(x.shape[1]):o,st=m(x[:,i:i+1],state=st,with_state=True);ys.append(o)
 b=torch.cat(ys,1);return dict(n=x.numel(),disagree=int((a.argmax(-1)!=b.argmax(-1)).sum()),max_logit_diff=float((a-b).abs().max()),max_state_diff=max(float((c-d).abs().max()) for l,k in zip(s,st) for c,d in zip(l,k)),state_bytes=sum(v.numel()*v.element_size() for l in s for v in l))
@torch.no_grad()
def gate_diag(m):
 if not isinstance(m.layers[0],RotBlock):return None
 l=m.layers[0];l.record=True;_,_=m(torch.arange(38)[:,None],with_state=True);l.record=False
 g=l.last_keep[:,0];a=l.last_angles[:,0];Q=matrices(a,l.mode);err=float((Q.transpose(-1,-2)@Q-torch.eye(4)).abs().max());comm=float((Q[32]@Q[34]-Q[34]@Q[32]).abs().max());return dict(orthogonality_error=err,op_commutator_max=comm,keep_by_token=g.tolist(),mean_start_keep=float(g[:16].mean()),mean_op_keep=float(g[32:38].mean()),exact_keep_fraction=float((g[32:38]==1).float().mean()))

def main(arm,seed,steps=STEPS):
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(seed);m=model(arm);p=ROOT/'results'/f'{arm}_{seed}';ih=hash_tensors(m.parameters());baseih=hash_tensors(v for k,v in m.named_parameters() if 'rotation' not in k);bs=batchdata(seed,steps);bh=hash_tensors(v for row in bs for v in row);opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01);log=[];start=time.perf_counter();labels=0;tokens=0
 for i,(x,y) in enumerate(bs,1):
  opt.param_groups[0]['lr']=.001*min(1,i/50)*(.2+.8*.5*(1+math.cos(math.pi*i/steps)));opt.zero_grad(set_to_none=True);z=m(x)[:,1:];ce=F.cross_entropy(z.flatten(0,1),y.flatten());ce.backward();nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True);opt.step();labels+=y.numel();tokens+=x.numel()
  if i in [1,250,500,750,1000,steps]:
   row=dict(step=i,ce=ce.item(),trace_acc=float((z.argmax(-1)==y).float().mean()));log.append(row);print(arm,seed,row,flush=True)
 sec=time.perf_counter()-start;ck=p.with_suffix('.pt');torch.save(dict(arm=arm,seed=seed,weights=m.state_dict()),ck);ps=panels();scores={k:eval_rows(m,v) for k,v in ps.items()};rep=repeated(m);gd=gate_diag(m);st=stream(m);abl={}
 if arm!='base':
  for ab in ['no_rotation','damp','self']:abl[ab]={'held2':eval_rows(m,ps['held2'],ab),'allowed8':eval_rows(m,ps['allowed8'],ab),'repeat':repeated(m,ab)}
 res=dict(arm=arm,seed=seed,params=sum(p.numel() for p in m.parameters()),steps=steps,training_examples=steps*BATCH,supervised_positions=labels,tokens=tokens,train_seconds=sec,init_sha256=ih,base_init_sha256=baseih,batch_sha256=bh,checkpoint_sha256=hashlib.sha256(ck.read_bytes()).hexdigest(),log=log,scores=scores,repeat=rep,gate_diag=gd,stream=st,ablation=abl);p.with_suffix('.json').write_text(json.dumps(res,indent=2));print('DONE',arm,seed,{k:round(v['acc'],4) for k,v in scores.items()},flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('arm',choices=ARMS);p.add_argument('seed',type=int);p.add_argument('--steps',type=int,default=STEPS);a=p.parse_args();main(a.arm,a.seed,a.steps)
