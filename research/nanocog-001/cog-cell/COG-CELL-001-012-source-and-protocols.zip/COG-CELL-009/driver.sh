#!/bin/bash
cd /mnt/data/cog_cell_009
cat jobs.txt | xargs -n2 -P4 bash -c 'OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=1 python native009/run009.py "$1" "$0" > results/${1}_${0}.log 2>&1; echo "$1 $0 $?" >> exit_status'
