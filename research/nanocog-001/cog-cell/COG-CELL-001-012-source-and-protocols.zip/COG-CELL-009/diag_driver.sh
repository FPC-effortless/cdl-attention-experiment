#!/bin/bash
cd /mnt/data/cog_cell_009
while [ "$(wc -l < exit_status)" -lt 12 ]; do sleep 2; done
cat jobs.txt | xargs -n2 -P1 bash -c 'OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 python native009/diagnostic009.py "$1" "$0" > diagnostics/${1}_${0}.log 2>&1; echo "$1 $0 $?" >> diag_exit_status'
