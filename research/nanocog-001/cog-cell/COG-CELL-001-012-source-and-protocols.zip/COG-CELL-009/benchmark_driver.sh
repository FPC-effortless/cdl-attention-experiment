#!/bin/bash
cd /mnt/data/cog_cell_009
while [ ! -f lm_exit_status ] || [ "$(wc -l < lm_exit_status)" -lt 9 ]; do sleep 2; done
if [ "$(grep -c ' 0$' lm_exit_status)" -ne 9 ]; then echo 1 > benchmark_exit; exit 1; fi
sleep 2
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 python native009/benchmark009.py > benchmark.log 2>&1; echo $? > benchmark_exit
