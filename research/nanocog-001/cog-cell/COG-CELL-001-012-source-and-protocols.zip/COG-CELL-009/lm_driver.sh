#!/bin/bash
cd /mnt/data/cog_cell_009
# Wait for current task campaign, then run language secondary study in same turn.
while [ "$(wc -l < exit_status)" -lt 12 ]; do sleep 2; done
printf '%s\n' '173 base' '271 base' '907 base' '173 orthogonal' '173 damped' '271 orthogonal' '271 damped' '907 orthogonal' '907 damped' | xargs -n2 -P4 bash -c 'OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 OMP_NUM_THREADS=1 python native009/language009.py "$1" "$0" > lm_results/${1}_${0}.log 2>&1; echo "$1 $0 $?" >> lm_exit_status'
