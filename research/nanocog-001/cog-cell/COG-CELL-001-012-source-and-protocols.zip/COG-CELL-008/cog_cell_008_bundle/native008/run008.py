import pathlib,sys,time,hashlib,json,math,argparse
ROOT=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'native007'))
from run007 import model,score,panel,encode,panel_rows,OPS,NEXT,held,answer,torch,nn,F,np,product,combine,closure,sample_rows
ARMS=['base','serial_peer']; MODES=['trace','functional','rollout']; SEEDS=[173,271,907]; STEPS=500; BATCH=32
OLD=ROOT.parent/'native007'/'results'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def batches(seed):
 r=np.random.default_rng(980003+seed);rows=[]
 for step in range(STEPS):
  L=int(r.integers(1,3));x=r.integers(16,size=BATCH);ops=np.empty((BATCH,L+2),np.int64);ops[:,0]=r.integers(6,size=BATCH)
  for i in range(1,L+2):ops[:,i]=NEXT[ops[:,i-1],r.integers(5,size=BATCH)]
  states=[x.copy()]
  for i in range(L+2):states.append((OPS[ops[:,i],0]*states[-1]+OPS[ops[:,i],1])%16)
  assert all(not held(tuple(p)) for p in ops)
  rows.append(tuple(torch.from_numpy(a.copy()) for a in [np.concatenate([x[:,None],ops[:,:L]+32],1),ops[:,L:]+32,np.stack(states[1:L+1],1),states[L][:,None],np.stack(states[L+1:],1)]))
 return rows
def joint(s):return torch.cat([v.flatten(1) for v in s[0]],-1)
def ce3(a,b):return F.cross_entropy(a.reshape(-1,a.size(-1)),b.reshape(-1))
def forward(m,probe,batch,mode):
 p,suf,t,z,y=batch;logits,hs=m(p,with_state=True);_,cs=m(z,with_state=True);st=combine(hs,cs);pp=[];h=[];c=[];pv=[]
 for j in range(3):
  if j:
   out,st=m(torch.cat([suf[:,j-1:j],suf[:,j-1:j]],0),state=st,with_state=True);a,b=out[:,0].chunk(2,0);h.append(a);c.append(b)
  s=joint(st);pl=probe(s.detach() if mode=='trace' else s);a,b=pl.chunk(2,0);pp.append(a);pv.append(b)
 h=torch.stack(h,1);c=torch.stack(c,1);pp=torch.stack(pp,1);pv=torch.stack(pv,1);py=torch.cat([z,y],1)
 native=(ce3(torch.cat([logits[:,1:],h],1),torch.cat([t,y],1))+ce3(c,y))*.5;aux=(ce3(pp,py)+ce3(pv,py))*.5
 nk=F.kl_div(h.log_softmax(-1),c.detach().softmax(-1),reduction='none').sum(-1).mean();pk=F.kl_div(pp[:,1:].log_softmax(-1),pv[:,1:].detach().softmax(-1),reduction='none').sum(-1).mean();kl=(nk+pk)*.5
 return native+.5*aux+(.5*kl if mode=='rollout' else 0),native,aux,kl,(h.argmax(-1)==y).float().mean(),(pp.argmax(-1)==py).float().mean()
def fresh_rows():
 prev=panel_rows();r=np.random.default_rng(744717);rng=np.random.default_rng(856880);out={}
 for L,ho in [(4,True),(8,False),(12,True),(16,False)]:
  k=f'depth{L}_{"heldout" if ho else "allowed"}';exclude=set(sample_rows(r,512,L,ho))|set(prev.get(k,[]));rows=[];seen=set(exclude)
  while len(rows)<512:
   x=int(rng.integers(16));o=tuple(int(i) for i in rng.integers(6,size=L));v=(x,o)
   if held(o)==ho and v not in seen:seen.add(v);rows.append(v)
  assert not set(rows)&exclude;out[k]=rows
 return out
@torch.no_grad()
def probe_panel(m,probe,rows):
 x,idx,y=encode(rows);assert (idx==idx[0]).all();L=int(idx[0]);probes=[];natives=[];targets=[];max_diff=0.;disagree=0
 for b in x.split(64):
  full=m(b);st=None;ps=[];ns=[];ts=[];v=b[:,0];op=torch.as_tensor(OPS)
  for j in range(L+1):
   a,st=m(b[:,j:j+1],state=st,with_state=True);max_diff=max(max_diff,(a[:,0]-full[:,j]).abs().max().item());disagree+=int((a[:,0].argmax(-1)!=full[:,j].argmax(-1)).sum())
   if j:
    o=op[b[:,j]-32];v=(o[:,0]*v+o[:,1])%16;ps.append(probe(joint(st)).argmax(-1));ns.append(a[:,0].argmax(-1));ts.append(v)
  probes.extend(torch.stack(ps,1).tolist());natives.extend(torch.stack(ns,1).tolist());targets.extend(torch.stack(ts,1).tolist())
 p=np.array(probes);n=np.array(natives);t=np.array(targets);ok=n==t;po=p==t
 return dict(n=len(x),depth=L,probe_prefix_correct=po.sum(0).tolist(),native_prefix_correct=ok.sum(0).tolist(),probe_exact=int(po.all(1).sum()),native_exact=int(ok.all(1).sum()),probe_native_agreement=(p==n).sum(0).tolist(),native_next_correct_given_probe_previous_correct=(ok[:,1:]&po[:,:-1]).sum(0).tolist(),probe_previous_correct=po[:,:-1].sum(0).tolist(),native_chunk_disagree=disagree,max_chunk_logit_diff=max_diff,probe_predictions=probes,native_prefix_predictions=natives,targets=targets)
def main(arm,seed,mode):
 torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.manual_seed(seed);m=model(arm);cp=OLD/f'{arm}_{seed}_trace.pt';old=json.loads(cp.with_suffix('.json').read_text());assert digest(cp)==old['checkpoint_sha256'];m.load_state_dict(torch.load(cp,weights_only=True,map_location='cpu')['weights']);params=sum(p.numel() for p in m.parameters());assert params==old['params'];torch.manual_seed(seed+8000);probe=nn.Linear(392,16);ih=hashlib.sha256(b''.join(v.detach().numpy().tobytes() for v in probe.parameters())).hexdigest();bs=batches(seed);bh=hashlib.sha256(b''.join(v.numpy().tobytes() for row in bs for v in row)).hexdigest();out=ROOT/'results'/f'{arm}_{seed}_{mode}'
 for k in ['atomic','depth2_heldout']:assert panel(m,panel_rows()[k])['predictions']==old['scores'][k]['predictions'],k
 opt=torch.optim.AdamW(list(m.parameters())+list(probe.parameters()),lr=.001,weight_decay=.01);start=time.perf_counter();history=[];labels=0;alabels=0;tokens=0;m.train()
 for i,b in enumerate(bs,1):
  p,s,t,z,y=b;opt.param_groups[0]['lr']=.001*min(1,i/50)*(.2+.8*.5*(1+math.cos(math.pi*i/STEPS)));opt.zero_grad(set_to_none=True);loss,native,aux,kl,na,pa=forward(m,probe,b,mode);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1.,error_if_nonfinite=True);nn.utils.clip_grad_norm_(probe.parameters(),1.,error_if_nonfinite=True);opt.step();labels+=t.numel()+2*y.numel();alabels+=6*len(y);tokens+=p.numel()+z.numel()+2*s.numel()
  if i in [1,100,250,500]:
   row=dict(step=i,loss=loss.item(),native_ce=native.item(),aux_ce=aux.item(),kl=kl.item(),native_acc=na.item(),probe_acc=pa.item());history.append(row);print(arm,seed,mode,row,flush=True)
 sec=time.perf_counter()-start;ck=out.with_suffix('.pt');torch.save(dict(arm=arm,seed=seed,mode=mode,weights=m.state_dict(),probe=probe.state_dict()),ck);m.eval();probe.eval();scores=score(m);fresh=fresh_rows();fs={k:panel(m,v) for k,v in fresh.items()};pp={k:probe_panel(m,probe,v) for k,v in fresh.items()};cl=closure(m);ab='self' if arm=='base' else 'self_message';abl={k:panel(m,panel_rows()[k],ab) for k in ['depth2_heldout','depth4_heldout','depth8_allowed']};res=dict(arm=arm,seed=seed,mode=mode,params=params,probe_params=sum(p.numel() for p in probe.parameters()),starting_sha256=digest(cp),checkpoint_sha256=digest(ck),probe_init_sha256=ih,batch_sha256=bh,steps=STEPS,history_examples=STEPS*BATCH,anchor_examples=STEPS*BATCH,native_labels=labels,aux_labels=alabels,input_tokens=tokens,train_seconds=sec,history=history,scores=scores,fresh=fs,probe_panels=pp,closure=cl,ablation=abl);out.with_suffix('.json').write_text(json.dumps(res,indent=2));print('DONE',arm,seed,mode,{k:round(v['acc'],4) for k,v in scores.items()},flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('arm',choices=ARMS);p.add_argument('seed',type=int);p.add_argument('mode',choices=MODES);a=p.parse_args();main(a.arm,a.seed,a.mode)
