import json,hashlib,pathlib,sys,collections
from run008 import *
torch.set_num_threads(1);torch.set_num_interop_threads(1)
fs=sorted((ROOT/'results').glob('*.json'));assert len(fs)==18,len(fs)
rs=[json.loads(f.read_text()) for f in fs];n=0;replays=0;stream=0;disagree=0;max_diff=0.
old=panel_rows();fresh=fresh_rows();groups=collections.defaultdict(list);pairs=collections.defaultdict(list)
for r in rs:
 arm,seed,mode=r['arm'],r['seed'],r['mode'];cp=ROOT/'results'/f'{arm}_{seed}_{mode}.pt';assert digest(cp)==r['checkpoint_sha256'];assert digest(OLD/f'{arm}_{seed}_trace.pt')==r['starting_sha256'];assert r['steps']==STEPS;groups[arm,seed].append(r);pairs[arm,mode].append(r)
 for name,panels in [('scores',old),('fresh',fresh),('ablation',old)]:
  for k,z in r[name].items():
   rows=panels[k];truth=[answer(x,o) for x,o in rows];p=z['predictions'];assert len(p)==len(truth)==z['n'];assert sum(a==b for a,b in zip(p,truth))==z['correct'];assert abs(z['acc']-z['correct']/z['n'])<1e-12;n+=len(p)
 for k,z in r['probe_panels'].items():
  rows=fresh[k];t=np.array([[answer(x,o[:i+1]) for i in range(len(o))] for x,o in rows]);p=np.array(z['probe_predictions']);q=np.array(z['native_prefix_predictions']);assert t.tolist()==z['targets'];assert (p==t).sum(0).tolist()==z['probe_prefix_correct'];assert (q==t).sum(0).tolist()==z['native_prefix_correct'];assert (p==q).sum(0).tolist()==z['probe_native_agreement'];assert int((p==t).all(1).sum())==z['probe_exact'];assert int((q==t).all(1).sum())==z['native_exact'];assert ((q[:,1:]==t[:,1:])&(p[:,:-1]==t[:,:-1])).sum(0).tolist()==z['native_next_correct_given_probe_previous_correct'];assert (p[:,:-1]==t[:,:-1]).sum(0).tolist()==z['probe_previous_correct'];n+=2*t.size;stream+=len(rows)*(len(rows[0][1])+1);disagree+=z['native_chunk_disagree'];max_diff=max(max_diff,z['max_chunk_logit_diff']);assert q[:,-1].tolist()==r['fresh'][k]['predictions'] or z['native_chunk_disagree']>0
 z=r['closure'];rows=[(x,o) for x in range(16) for o in product(range(6),repeat=3) if not held(o)];truth=[answer(x,o) for x,o in rows];assert sum(a==b for a,b in zip(z['predictions'],truth))==z['native_ok'];n+=len(truth)
 m=model(arm);ck=torch.load(cp,map_location='cpu',weights_only=True);m.load_state_dict(ck['weights']);m.eval();probe=nn.Linear(392,16);probe.load_state_dict(ck['probe']);probe.eval()
 for k in ['atomic','depth2_heldout','depth4_heldout']:
  assert panel(m,old[k])['predictions']==r['scores'][k]['predictions'];replays+=1
 k='depth4_heldout';z=probe_panel(m,probe,fresh[k]);assert z['probe_predictions']==r['probe_panels'][k]['probe_predictions'];assert z['native_prefix_predictions']==r['probe_panels'][k]['native_prefix_predictions'];replays+=1
for key,g in groups.items():
 assert set(x['mode'] for x in g)==set(MODES)
 for k in ['starting_sha256','batch_sha256','probe_init_sha256','params','probe_params','native_labels','aux_labels','input_tokens']:assert len({x[k] for x in g})==1,(key,k)
for seed in SEEDS:assert len({x['batch_sha256'] for x in rs if x['seed']==seed})==1
summary={}
for (arm,mode),g in pairs.items():
 mean=lambda f:sum(f(x) for x in g)/len(g)
 summary[f'{arm}_{mode}']={'seeds':len(g),'mean_scores':{k:mean(lambda x:x['scores'][k]['acc']) for k in old},'mean_fresh':{k:mean(lambda x:x['fresh'][k]['acc']) for k in fresh},'mean_probe_final':{k:mean(lambda x:x['probe_panels'][k]['probe_prefix_correct'][-1]/x['probe_panels'][k]['n']) for k in fresh},'mean_probe_prefix':{k:np.mean([np.array(x['probe_panels'][k]['probe_prefix_correct'])/x['probe_panels'][k]['n'] for x in g],axis=0).tolist() for k in fresh},'mean_native_prefix':{k:np.mean([np.array(x['probe_panels'][k]['native_prefix_correct'])/x['probe_panels'][k]['n'] for x in g],axis=0).tolist() for k in fresh},'mean_native_next_given_probe_previous_correct':{k:sum(sum(x['probe_panels'][k]['native_next_correct_given_probe_previous_correct']) for x in g)/max(1,sum(sum(x['probe_panels'][k]['probe_previous_correct']) for x in g)) for k in fresh},'closure_native_accuracy':mean(lambda x:x['closure']['native_ok']/x['closure']['n']),'closure_canonical_accuracy':mean(lambda x:x['closure']['canonical_ok']/x['closure']['n']),'closure_next_given_previous_correct':sum(x['closure']['next_ok_given_previous_ok'] for x in g)/sum(x['closure']['previous_ok'] for x in g),'closure_correct_groups':sum(x['closure']['all_correct_groups'] for x in g),'closure_groups':sum(x['closure']['groups'] for x in g),'closure_kl':mean(lambda x:x['closure']['mean_kl']),'ablation_delta':{k:mean(lambda x:x['scores'][k]['acc']-x['ablation'][k]['acc']) for k in g[0]['ablation']},'mean_train_seconds':mean(lambda x:x['train_seconds'])}
lookup={(x['arm'],x['mode'],x['seed']):x for x in rs};gates=[]
for x in rs:
 a,m,s=x['arm'],x['mode'],x['seed'];acc={k:v['acc'] for k,v in x['scores'].items()};checks={'atomic':acc['atomic']>=.95,'heldout_pair':acc['depth2_heldout']>=.9,'heldout4':acc['depth4_heldout']>=.8,'allowed8':acc['depth8_allowed']>=.8}
 if m!='trace':
  for k in ['depth4_heldout','depth8_allowed']:checks['improve_'+k]=acc[k]-lookup[a,'trace',s]['scores'][k]['acc']>=.05
 if a=='serial_peer':
  for k in ['depth4_heldout','depth8_allowed']:checks['peer_'+k]=acc[k]-lookup['base',m,s]['scores'][k]['acc']>=.05
 gates.append(dict(arm=a,mode=m,seed=s,checks=checks,passed=all(checks.values())))
out=dict(fits=len(rs),steps=sum(x['steps'] for x in rs),history_examples=sum(x['history_examples'] for x in rs),anchor_examples=sum(x['anchor_examples'] for x in rs),native_labels=sum(x['native_labels'] for x in rs),aux_labels=sum(x['aux_labels'] for x in rs),predictions_checked=n,replays=replays,stream_positions=stream,stream_disagreements=disagree,max_chunk_logit_diff=max_diff,summary=summary,gates=gates)
(ROOT/'aggregate.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ['summary','gates']},indent=2));print('Gates passed',sum(x['passed'] for x in gates));print('AUDIT PASSED')
