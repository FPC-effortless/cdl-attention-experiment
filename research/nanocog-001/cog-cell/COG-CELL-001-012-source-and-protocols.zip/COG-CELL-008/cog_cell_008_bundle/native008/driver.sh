#!/bin/bash
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
cat jobs.txt | xargs -P 4 -n 3 bash -c 'a=$0; s=$1; m=$2; python -u run008.py "$a" "$s" "$m" > "results/${a}_${s}_${m}.log" 2>&1; r=$?; echo "$a $s $m $r" >> exit_status; exit "$r"'
echo $? > driver_exit
