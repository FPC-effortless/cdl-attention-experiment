#!/bin/bash
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
while [ ! -f driver_exit ]; do sleep 2; done
[ "$(cat driver_exit)" = '0' ] || exit 1
python -u audit008.py > audit.log 2>&1 & ap=$!
mkdir -p repeated
(cat jobs.txt; for s in 173 271 907; do for a in base serial_peer; do echo "$a $s starting"; done; done) | xargs -P 3 -n 3 bash -c 'a=$0; s=$1; m=$2; python -u repeated008.py "$a" "$s" "$m" > "repeated/${a}_${s}_${m}.log" 2>&1; r=$?; echo "$a $s $m $r" >> repeated_status; exit "$r"'
echo $? > repeated_exit
wait $ap; echo $? > audit_exit
