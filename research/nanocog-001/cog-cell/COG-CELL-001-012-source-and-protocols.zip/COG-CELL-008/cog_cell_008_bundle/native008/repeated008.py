from run008 import *
import argparse
@torch.no_grad()
def test(m):
 m.eval();x=torch.arange(16)[:,None];_,st=m(x,with_state=True);ret=[];prev=0
 for t in [1,2,4,8,16,32,64,128,256,512,1024]:
  length=t-prev;z,st=m(torch.full((16,length),32,dtype=torch.long),state=st,with_state=True);truth=(x+torch.arange(prev+1,t+1)[None])%16;p=z.argmax(-1);ok=p==truth;last=z[:,-1];y=truth[:,-1];margin=last.gather(1,y[:,None])[:,0]-last.scatter(1,y[:,None],-float('inf')).max(1).values
  ranges=[float((v.max(dim=0).values-v.min(dim=0).values).abs().max()) for l in st for v in l];logrange=float((last.max(0).values-last.min(0).values).abs().max());ret.append(dict(horizon=t,n=16,correct=int(ok[:,-1].sum()),segment_n=int(ok.numel()),segment_correct=int(ok.sum()),mean_true_margin=margin.mean().item(),min_true_margin=margin.min().item(),distinct_predictions=len(set(p[:,-1].tolist())),logit_range=logrange,state_ranges=ranges,last_step_logit_delta=float((z[:,-1]-z[:,-2]).abs().max()) if length>1 else None,predictions=p[:,-1].tolist(),truth=y.tolist()))
  prev=t
 return ret
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('arm');p.add_argument('seed',type=int);p.add_argument('mode');a=p.parse_args();torch.set_num_threads(1);torch.set_num_interop_threads(1);m=model(a.arm);path=OLD/f'{a.arm}_{a.seed}_trace.pt' if a.mode=='starting' else ROOT/'results'/f'{a.arm}_{a.seed}_{a.mode}.pt';m.load_state_dict(torch.load(path,weights_only=True,map_location='cpu')['weights']);r=test(m);out=ROOT/'repeated';out.mkdir(exist_ok=True);(out/f'{a.arm}_{a.seed}_{a.mode}.json').write_text(json.dumps(dict(arm=a.arm,seed=a.seed,mode=a.mode,checkpoint_sha256=digest(path),horizons=r),indent=2));print('DONE',a.arm,a.seed,a.mode,[(x['horizon'],x['correct'],x['logit_range']) for x in r],flush=True)
