import torch, torch.nn as nn, torch.nn.functional as F, json, time, argparse, platform
from pathlib import Path
P=Path(__file__).parent
N=16; K=8; D=32; B=48; SEEDS=[17,29,43]; STEPS=600
MODES=['attention_anchored','attention_qanchor']
torch.set_num_threads(2);torch.set_num_interop_threads(1)
def batch(g,b=B,hops=3,graph='random'):
    i=torch.arange(N)[None].expand(b,N)
    if graph=='random':
        a=torch.randint(N-1,(b,N),generator=g);a=a+(a>=i)
    else:
        order=torch.rand((b,N),generator=g).argsort(-1);a=torch.zeros_like(order).scatter(1,order,order.roll(-1,dims=1))
    v=torch.randint(K,(b,N),generator=g); dest=i
    for _ in range(hops): dest=a.gather(1,dest)
    return a,v,v.gather(1,dest)
class Cells(nn.Module):
    def __init__(self,mode):
        super().__init__();self.mode=mode;self.embed=nn.Linear(N+K,D);self.pub=nn.Linear(D,D);self.update=nn.GRUCell(D,D);self.route=nn.Linear(D,N);self.route_feature=nn.Linear(N,D);self.mix=nn.Parameter(torch.zeros(N,N));self.key=nn.Linear(D,N);self.id=nn.Parameter(torch.eye(N));self.read=nn.Linear(D,K)
    def forward(self,a,v,hops,intervention='none'):
        b,n=a.shape;s0=torch.tanh(self.embed(torch.cat([F.one_hot(a,N),F.one_hot(v,K)],-1).float()));s=s0; routes=[]
        for _ in range(hops):
            p=self.pub(s); q0=self.route(s0 if self.mode in ['learned_anchored','attention_anchored','attention_qanchor'] else s);q=q0.softmax(-1);aux=self.route_feature(q)
            if self.mode=='independent':m=p
            elif self.mode=='dense':m=torch.einsum('ij,bjd->bid',self.mix.softmax(-1),p)
            elif self.mode in ['attention','attention_anchored','attention_qanchor']:
                scores=torch.bmm(q0,(self.key(s0 if self.mode=='attention_anchored' else s)+self.id.unsqueeze(0)).transpose(1,2))/(N**.5);w=scores.softmax(-1);m=torch.bmm(w,p);routes.append(w.argmax(-1))
            elif self.mode=='addressed':m=p.gather(1,a.unsqueeze(-1).expand(-1,-1,D))
            else:
                ix=q.argmax(-1);routes.append(ix)
                if self.training:
                    w=F.one_hot(ix,N).float()+q-q.detach();m=torch.bmm(w,p)
                else:m=p.gather(1,ix.unsqueeze(-1).expand(-1,-1,D))
            if intervention=='self':m=p
            elif intervention=='zero':m=torch.zeros_like(m)
            elif intervention=='wrong':m=m.roll(1,dims=1)
            s=self.update((m+aux).reshape(-1,D),s.reshape(-1,D)).reshape(b,n,D)
        return self.read(s),routes
@torch.no_grad()
def evaluate(model,hops,graph='random',intervention='none',n_batches=16):
    model.eval();g=torch.Generator().manual_seed(6600);correct=total=whole=rc=rt=0;nll=0
    for _ in range(n_batches):
        a,v,y=batch(g,hops=hops,graph=graph);z,r=model(a,v,hops,intervention);m=z.argmax(-1)==y;correct+=int(m.sum());total+=m.numel();whole+=int(m.all(-1).sum());nll+=float(F.cross_entropy(z.flatten(0,1),y.flatten(),reduction='sum'))
        for ix in r:rc+=int((ix==a).sum());rt+=a.numel()
    return {'acc':correct/total,'whole':whole/(B*n_batches),'n':total,'nll':nll/total,'route_match':rc/rt if rt else None}
@torch.no_grad()
def timing(model,hops=4):
    model.eval();a,v,_=batch(torch.Generator().manual_seed(422),hops=hops)
    for _ in range(10):model(a,v,hops)
    t=time.perf_counter()
    for _ in range(50):model(a,v,hops)
    return (time.perf_counter()-t)*20

def run(mode,seed):
    torch.manual_seed(seed);m=Cells(mode);opt=torch.optim.AdamW(m.parameters(),lr=.003,weight_decay=.0001);g=torch.Generator().manual_seed(15000+seed);gh=torch.Generator().manual_seed(25000+seed);trace=[];t=time.perf_counter()
    for step in range(1,STEPS+1):
        m.train();h=int(torch.randint(1,5,(1,),generator=gh));a,v,y=batch(g,hops=h);z,_=m(a,v,h);loss=F.cross_entropy(z.flatten(0,1),y.flatten());opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step()
        if step%100==0:trace.append([step,h,float(loss.detach())])
    r={'mode':mode,'seed':seed,'steps':STEPS,'total_params':sum(p.numel() for p in m.parameters()),'active_params':sum(p.numel() for p in m.parameters() if p.grad is not None),'seconds':time.perf_counter()-t,'trace':trace,'random':{str(h):evaluate(m,h) for h in [1,2,3,4,6,8,12]},'single_cycle':{str(h):evaluate(m,h,'cycle') for h in [1,4,8,12]},'interventions':{i:evaluate(m,4,intervention=i) for i in ['self','zero','wrong']},'batch48_4round_ms':timing(m)}
    torch.save(m.state_dict(),P/f'{mode}_{seed}.pt');open(P/'runs.jsonl','a').write(json.dumps(r)+'\n'); print(mode,seed,'4',round(r['random']['4']['acc']*100,2),'8',round(r['random']['8']['acc']*100,2),'12',round(r['random']['12']['acc']*100,2),'cycle8',round(r['single_cycle']['8']['acc']*100,2),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seeds',nargs='+',type=int,default=SEEDS);p.add_argument('--modes',nargs='+',default=MODES);p.add_argument('--steps',type=int,default=STEPS);a=p.parse_args();STEPS=a.steps
    (P/'config.json').write_text(json.dumps({'N':N,'K':K,'D':D,'B':B,'steps':STEPS,'seeds':SEEDS,'modes':MODES,'train_hops':[1,2,3,4],'torch':torch.__version__,'python':platform.python_version(),'device':'cpu','threads':2},indent=2))
    for s in a.seeds:
        for mode in a.modes:run(mode,s)
