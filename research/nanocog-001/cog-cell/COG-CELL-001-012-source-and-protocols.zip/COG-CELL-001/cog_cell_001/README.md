# COG-CELL-001: stateful cell communication diagnostic

## Scope and claim boundary
A standalone PyTorch prototype of the proposed neuron-like Unified COG cell abstraction, not the canonical Unified COG repository implementation. The repository lookup did not establish access to the canonical source. CPU only, no natural-language modelling, no 1M/10M-parameter runs, no production or architectural promotion. Task inputs contain explicit one-hot destination-address cues; learned routing receives no address-target loss but must not be described as autonomous semantic discovery. GRU cells use shared weights and have separate per-cell states, not independently parameterized neurons.

## Protocol
Each graph has 16 vertices, an 8-class uniformly sampled payload per vertex, and a randomly chosen nonself outgoing pointer per vertex. Each cell receives only its own payload and pointer one-hot vectors. Predict the payload at the end of a directed h-hop path from each cell. A shared local decoder reads only that cell's state. Random training graphs and test graphs use separate generator seeds. Matched seeds across arms use the same generated examples; test examples are shared across trained models, not independent replications of the test population. Single-cycle stress tests use random permutations forming a 16-vertex cycle (no early path return). Chance is 12.5%; graph returns give independent cells a shortcut in random functional graphs.

Stage 1: 5 arms x 3 seeds x 180 updates, fixed 3 hops. All have 9,784 allocated parameters, 9,528 active except dense (9,784).
Stage 2: 6 arms x 3 seeds x 600 updates, one uniformly sampled horizon in 1..4 per update. All have 10,568 allocated parameters, 9,528 active in independent/addressed/learned arms, 9,784 in dense, 10,312 in attention. Test horizons 1,2,3,4,6,8,12; single-cycle at 1,4,8,12.
Stage 3: 2 matched anchored-attention arms x 3 seeds x 600 updates, same stage 2 seeds and protocol. Both active parameter count 10,312.
Total 39 completed unique fits; 17,100 optimizer updates; 48 graphs per update (820,800 graph presentations, including repeated matched presentations across arms); 12,288 per-cell test decisions for each model/condition (768 test graphs). PyTorch 2.10.0 CPU, two intra-op threads.

## Results
Stage 1 three-hop means: independent 18.26%, ring 19.02%, dense static 24.03%, learned dynamic 21.92%, addressed 100%. Addressed 6-hop accuracy 7.85%; fixed-depth training does not produce depth-invariant computation.

Stage 2/3 random-graph accuracy, means across 3 training seeds:

| Arm | 4 hops | 8 hops | 12 hops |
|---|---:|---:|---:|
| Independent | 22.34 | 23.46 | 27.09 |
| Dense static | 26.44 | 26.14 | 24.66 |
| Dynamic direct | 27.10 | 26.10 | 22.20 |
| Dynamic attention | 99.22 | 50.17 | 34.27 |
| Learned anchored direct | 97.78 | 96.48 | 89.10 |
| Explicit addressed | 100.00 | 98.79 | 94.50 |
| Attention Q+K anchored | 100.00 | 97.25 | 82.19 |
| Attention Q anchored | 100.00 | 98.62 | 86.46 |

The central supported mechanism is a stable address-bearing representation separated from evolving computation. The advantage over dynamic attention does not establish superiority over equally anchored attention. At 12 hops learned anchored direct has higher mean on random graphs than either anchored attention variant, but seed count and variability preclude a reliable superiority claim. On 12-hop single-cycle graphs Q-anchored attention has a higher mean (88.10% vs 84.52%). The dynamic direct routing accuracy across 8 rounds falls from 99.50% to 8.19%; anchored direct remains 99.22% throughout. A complete 128-pair address/payload enumeration found 0,3,0 wrong initial addresses for anchored direct seeds 17,29,43. Learned direct uses dense straight-through surrogate during training and an N-way output head and auxiliary projection at inference; actual routing computation is not demonstrated linear in cell count. No inference-speed claim: timings are descriptive, sequential CPU timings, not controlled accelerator benchmarks. The deterministic symbolic pointer-following oracle solves this synthetic task exactly and is not a competing trained architecture.

## Reproduce
Use Python 3.13 and torch 2.10.0 CPU (as recorded in config.json). In a fresh copy with existing runs.jsonl removed or moved aside (scripts append), run:

```
python experiment.py
python stage2/experiment.py
python stage3/experiment.py
python diagnostics.py
```

Checkpoints are saved state dictionaries, not executable models. `runs.jsonl` at each stage is the complete raw results including training losses, parameter counts, timing, accuracy, graph-level exact accuracy, NLL and intervention results. `diagnostics.json` contains round-wise routing and exhaustive initial address/payload probe. `MANIFEST.sha256` covers files in the bundle except itself. Training scripts reuse fixed evaluation seed within each stage to compare paired models. The staged exploratory choices and additional attention controls were made after observing initial results, so this is hypothesis-generating rather than a preregistered confirmatory experiment.
