import sys, json, statistics as S, torch
from pathlib import Path
root=Path(__file__).parent
sys.path.insert(0,str(root/'stage2'));import experiment as e
results=[]
for seed in e.SEEDS:
 for mode in ['learned_dynamic','learned_anchored','attention','addressed']:
  model=e.Cells(mode);model.load_state_dict(torch.load(root/'stage2'/f'{mode}_{seed}.pt',weights_only=True));model.eval();g=torch.Generator().manual_seed(7777);match=[0]*8;total=0
  with torch.no_grad():
   for _ in range(16):
    a,v,y=e.batch(g,hops=8,graph='cycle');z,r=model(a,v,8);total+=a.numel()
    for i,x in enumerate(r):match[i]+=int((x==a).sum())
   if mode in ['learned_dynamic','learned_anchored']:
    a=torch.arange(e.N).repeat_interleave(e.K);v=torch.arange(e.K).repeat(e.N);s0=torch.tanh(model.embed(torch.cat([torch.nn.functional.one_hot(a,e.N),torch.nn.functional.one_hot(v,e.K)],-1).float()));q=model.route(s0).argmax(-1);wrong=[{'address':int(a[i]),'payload':int(v[i]),'predicted':int(q[i])} for i in torch.where(q!=a)[0]]
   else:wrong=None
  results.append({'mode':mode,'seed':seed,'route_match_by_round':[x/total for x in match] if mode!='addressed' else None,'initial_address_payload_errors':wrong})
(root/'diagnostics.json').write_text(json.dumps(results,indent=2))
for mode in ['learned_dynamic','learned_anchored','attention']:
 rr=[r for r in results if r['mode']==mode];print(mode,[round(S.mean(r['route_match_by_round'][i] for r in rr)*100,2) for i in range(8)],'initial errors',[(r['seed'],len(r['initial_address_payload_errors'])) for r in rr if r['initial_address_payload_errors'] is not None])
