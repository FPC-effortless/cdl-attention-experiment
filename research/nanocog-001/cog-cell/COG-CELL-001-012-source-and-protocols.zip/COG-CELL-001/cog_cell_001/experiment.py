import torch, torch.nn as nn, torch.nn.functional as F, json, time, argparse, platform
from pathlib import Path
P=Path(__file__).parent
N=16; K=8; D=32; STEPS=180; B=48; SEEDS=[17,29,43]; ROUNDS=3
VARIANTS=['independent','ring','dense','addressed','learned']
torch.set_num_threads(2); torch.set_num_interop_threads(1)

def batch(g,b=B,n=N,hops=ROUNDS):
    a=torch.randint(n-1,(b,n),generator=g); i=torch.arange(n)[None]; a=a+(a>=i)
    v=torch.randint(K,(b,n),generator=g)
    dest=i.expand(b,n)
    for _ in range(hops): dest=a.gather(1,dest)
    return a,v,v.gather(1,dest)

class Cells(nn.Module):
    def __init__(self,mode):
        super().__init__(); self.mode=mode
        self.embed=nn.Linear(N+K,D)
        self.pub=nn.Linear(D,D)
        self.update=nn.GRUCell(D,D)
        self.route=nn.Linear(D,N); self.route_feature=nn.Linear(N,D)
        self.mix=nn.Parameter(torch.zeros(N,N))
        self.read=nn.Linear(D,K)
    def forward(self,a,v,rounds=ROUNDS,intervention='none'):
        b,n=a.shape
        s=torch.tanh(self.embed(torch.cat([F.one_hot(a,N),F.one_hot(v,K)],-1).float()))
        routes=[]
        for _ in range(rounds):
            p=self.pub(s); q=self.route(s).softmax(-1); aux=self.route_feature(q)
            if self.mode=='independent': m=p
            elif self.mode=='ring': m=p.roll(1,dims=1)
            elif self.mode=='dense': m=torch.einsum('ij,bjd->bid',self.mix[:n,:n].softmax(-1),p)
            elif self.mode=='addressed': m=p.gather(1,a.unsqueeze(-1).expand(-1,-1,D))
            elif self.mode=='learned':
                ix=q.argmax(-1); routes.append(ix)
                if self.training:
                    hard=F.one_hot(ix,N).float(); w=hard+q-q.detach(); m=torch.bmm(w,p)
                else: m=p.gather(1,ix.unsqueeze(-1).expand(-1,-1,D))
            if intervention=='zero': m=torch.zeros_like(m)
            elif intervention=='self': m=p
            elif intervention=='wrong': m=m.roll(1,dims=1)
            s=self.update((m+aux).reshape(-1,D),s.reshape(-1,D)).reshape(b,n,D)
        return self.read(s),routes

@torch.no_grad()
def evaluate(model,seed,hops,intervention='none',n_batches=16):
    model.eval(); g=torch.Generator().manual_seed(seed); correct=total=ac=ar=graph=0; nll=0.
    for _ in range(n_batches):
        a,v,y=batch(g,hops=hops); out,routes=model(a,v,rounds=hops,intervention=intervention)
        match=out.argmax(-1)==y; correct+=int(match.sum()); total+=y.numel(); graph+=int(match.all(-1).sum()); nll+=float(F.cross_entropy(out.flatten(0,1),y.flatten(),reduction='sum'))
        for ix in routes: ac+=int((ix==a).sum()); ar+=a.numel()
    return {'accuracy':correct/total,'exact_graph':graph/(B*n_batches),'nll':nll/total,'n':total,'route_match':ac/ar if ar else None}

@torch.no_grad()
def timing(model):
    model.eval(); a,v,_=batch(torch.Generator().manual_seed(444),b=48)
    for _ in range(10): model(a,v)
    t=time.perf_counter()
    for _ in range(40): model(a,v)
    return (time.perf_counter()-t)/40*1000

def run(mode,seed):
    torch.manual_seed(seed); model=Cells(mode); opt=torch.optim.AdamW(model.parameters(),lr=.003,weight_decay=.0001)
    gen=torch.Generator().manual_seed(10000+seed); start=time.perf_counter(); trace=[]
    for step in range(1,STEPS+1):
        model.train(); a,v,y=batch(gen); z,_=model(a,v); loss=F.cross_entropy(z.flatten(0,1),y.flatten())
        opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
        if step in [1,50,100,STEPS]: trace.append([step,float(loss.detach())])
    duration=time.perf_counter()-start
    result={'mode':mode,'seed':seed,'params_total':sum(p.numel() for p in model.parameters()),'params_used':sum(p.numel() for p in model.parameters() if p.grad is not None),'train_s':duration,'loss_trace':trace,'test':{str(h):evaluate(model,6000,h) for h in [1,3,6]},'interventions':{i:evaluate(model,6000,3,i) for i in ['self','zero','wrong']},'batch48_ms':timing(model)}
    torch.save(model.state_dict(),P/f'{mode}_{seed}.pt')
    with (P/'runs.jsonl').open('a') as f:f.write(json.dumps(result)+'\n')
    print(json.dumps(result),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--modes',nargs='+',default=VARIANTS);parser.add_argument('--seeds',nargs='+',type=int,default=SEEDS);parser.add_argument('--steps',type=int,default=STEPS);args=parser.parse_args();STEPS=args.steps
    (P/'config.json').write_text(json.dumps({'N':N,'K':K,'D':D,'B':B,'rounds':ROUNDS,'steps':STEPS,'seeds':SEEDS,'modes':VARIANTS,'torch':torch.__version__,'python':platform.python_version(),'threads':2,'device':'cpu','test_seed':6000},indent=2))
    for seed in args.seeds:
        for mode in args.modes:run(mode,seed)
