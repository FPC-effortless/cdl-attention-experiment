import sys, pathlib, math, json, time, random, hashlib, argparse, itertools, concurrent.futures
import numpy as np
import torch
from torch import nn
import torch.nn.functional as F
P=pathlib.Path(__file__).parent
sys.path.insert(0,str(P/'previous'))
import calibration as C
from hierarchical import hierarchical
from hold_reset import exact_hold_reset
C.associative=lambda z,a,s=None: hierarchical(z,a,s,accum=torch.float32)
K=8; H=16; D=24; NAMES='alder birch cedar dahlia elm fir gorse hazel iris juniper kelp larch'.split(); VALUES='amber blue coral denim emerald fawn gold honey'.split(); ARMS=['fixed_soft','dynamic_soft','dynamic_hard','dynamic_anneal','supervised','continuous']; SEEDS=[173,271,907]
TRAIN=[['ignore report for {name} about {value}', 'do not record {name} as {value}', 'keep {name} unchanged despite {value}'],['record {name} as {value}', '{name} now has {value}', 'set {name} to {value}'],['clear {name} regardless of {value}', 'remove record for {name} despite {value}', '{name} is empty not {value}']]
HELD=[['do not set {name} to {value}', 'keep record for {name} unchanged about {value}'],['set record for {name} as {value}', 'now record {name} as {value}'],['remove {name} regardless of {value}', 'clear record for {name} not {value}']]
ALIASES=['{n}','team {n}','{n} team']; HELD_ALIAS=['crew {n}','{n} crew']; ROSTER='show crew {n}'
WORDS=['<pad>','<end>']+sorted(set((' '.join(' '.join(x) for x in TRAIN+HELD)+' '+' '.join(NAMES+VALUES)+' team crew show').replace('{name}','').replace('{value}','').split()))
VOC={w:i for i,w in enumerate(WORDS)}; T=10

def tok(s):
 v=[VOC[x] for x in s.split()]+[1]; assert len(v)<=T; return v+[0]*(T-len(v))
def table(held=False,alias=False):
 templates=HELD if held else TRAIN; aliases=HELD_ALIAS if alias else ALIASES
 z=np.empty((3,len(NAMES),8,len(templates[0])*len(aliases),T),np.int64)
 for a,n,v in itertools.product(range(3),range(len(NAMES)),range(8)):
  z[a,n,v]=[tok(t.format(name=s.format(n=NAMES[n]),value=VALUES[v])) for t in templates[a] for s in aliases]
 return torch.from_numpy(z)
TABLES={(t,a):table(t,a) for t,a in itertools.product([False,True],repeat=2)}
ROST=torch.tensor([tok(ROSTER.format(n=n)) for n in NAMES]);

def gen(seed,n,L,kind='mixed',panel='familiar',shuffle=True):
 g=torch.Generator().manual_seed(seed); roster=torch.arange(K).expand(n,K).clone()
 if panel=='unknown':roster[:,4:]=torch.arange(8,12)
 if shuffle:roster=roster.gather(1,torch.rand(n,K,generator=g).argsort(1))
 a=torch.multinomial(torch.tensor([.5,.38,.12]),n*L,replacement=True,generator=g).reshape(n,L);k=torch.randint(K,(n,L),generator=g);v=torch.randint(8,(n,L),generator=g)
 if kind=='retention':
  a.zero_();a[:,:K]=1;k[:,:K]=torch.rand(n,K,generator=g).argsort(1)
 if kind=='conflict':
  a[:,:K]=1;k[:,:K]=torch.rand(n,K,generator=g).argsort(1);a[:,K:K+3]=2;k[:,K:K+3]=k[:,:3];a[:,K+3:K+6]=1;k[:,K+3:K+6]=k[:,:3]
 names=roster.gather(1,k);tb=TABLES[panel=='held_template',panel=='held_alias'];t=torch.randint(tb.shape[-2],(n,L),generator=g);x=tb[a,names,v,t];x2=tb[a,names,torch.where(a==0,(v+1)%8,v),t];y=torch.zeros(n,K,dtype=torch.long);b=torch.arange(n)
 for i in range(L):y[b,k[:,i]]=torch.where(a[:,i]==1,v[:,i]+1,torch.where(a[:,i]==2,0,y[b,k[:,i]]))
 return x,ROST[roster],a,k,v,y,x2
class Model(nn.Module):
 def __init__(self,arm):
  super().__init__();self.arm=arm;self.mode='hard' if arm=='dynamic_hard' else 'soft';self.temp=1.;self.emb=nn.Embedding(len(VOC),D,padding_idx=0);self.block=C.Block(D,4,D//4,48,1,'init_only');self.norm=nn.LayerNorm(D);self.action=nn.Linear(D,3);self.key=nn.Linear(D,D,bias=False);self.value=nn.Linear(D,H);self.fixed=nn.Linear(D,K);self.read=nn.Sequential(nn.Linear(H,32),nn.GELU(),nn.Linear(32,9));self.scale=nn.Parameter(torch.tensor(2.));
  for m in self.modules():
   if isinstance(m,nn.Linear):
    nn.init.normal_(m.weight,std=1/math.sqrt(m.in_features))
    if m.bias is not None:nn.init.zeros_(m.bias)
  nn.init.normal_(self.block.ow,std=1/math.sqrt(self.block.h));nn.init.normal_(self.emb.weight,std=.15);self.emb.weight.data[0].zero_()
  if arm!='fixed_soft':self.fixed.requires_grad_(False)
  else:self.key.requires_grad_(False);self.scale.requires_grad_(False)
 def text(self,x):
  shape=x.shape[:-1];z=x.reshape(-1,T);h=self.emb(z);h,_=self.block(h);mask=(z!=0).unsqueeze(-1);h=(h*mask).sum(1)/mask.sum(1).clamp_min(1);return self.norm(h).reshape(*shape,D)
 def decisions(self,x,roster):
  h=self.text(x);log=self.action(h);p=(log/self.temp).softmax(-1);v=self.value(h).tanh();
  if self.arm=='fixed_soft':addrlog=self.fixed(h)
  else:
   r=self.emb(roster);mask=(roster!=0).unsqueeze(-1);r=(r*mask).sum(-2)/mask.sum(-2).clamp_min(1);q=F.normalize(self.key(h),dim=-1);r=F.normalize(r,dim=-1);addrlog=torch.einsum('btd,bkd->btk',q,r)*self.scale.exp().clamp(max=40)
  addr=(addrlog/self.temp).softmax(-1)
  if self.mode=='hard':
   def st(p):
    q=F.one_hot(p.argmax(-1),p.shape[-1]).to(p.dtype);return q+(p-p.detach()) if self.training else q
   p,addr=st(p),st(addr)
  return log,addrlog,p,addr,v
 def encode(self,x,roster,s=None):
  log,al,p,addr,v=self.decisions(x,roster);a=1-addr*(p[...,1:2]+p[...,2:3]);
  if self.arm=='continuous':a=.05+.9*a
  proposal=(v*p[...,1:2])[...,None,:].expand(-1,-1,K,-1)
  if self.mode=='hard':
   zeroed=torch.where(p[...,2:3].bool(),torch.zeros_like(v),v);zeroed=zeroed[...,None,:].expand_as(proposal);proposal=zeroed+(proposal-proposal.detach()) if self.training else zeroed
  if s is None:s=torch.zeros_like(proposal[:,0])
  ys,last=exact_hold_reset(proposal,a[...,None],s) if self.mode=='hard' else hierarchical(proposal,a[...,None],s,accum=torch.float32)
  return last,(log,al,p,addr,ys,a)
 def forward(self,x,roster,s=None):
  st,info=self.encode(x,roster,s);return self.read(st),st,info
@torch.no_grad()
def evaluate(m,seed,L,kind,panel,n=48):
 m.eval();tot={k:0 for k in ['complete','slots','actions','addresses','pairs','bitwise','hold_exact','hold_n','split','oracle']};t=0.;bs=8
 for i in range(n//bs):
  x,r,a,k,v,y,x2=gen(seed+i,bs,L,kind,panel,shuffle=m.arm!='fixed_soft');start=time.perf_counter();z,s,info=m(x,r);t+=time.perf_counter()-start;pred=z.argmax(-1);ok=(pred==y).all(-1);tot['complete']+=int(ok.sum());tot['slots']+=int((pred==y).sum());log,al,p,addr,ys,aa=info;tot['actions']+=int((p.argmax(-1)==a).sum());tot['addresses']+=int((addr.argmax(-1)==k).sum());zz,ss,_=m(x2,r);tot['pairs']+=int((ok&(zz.argmax(-1)==y).all(-1)).sum());tot['bitwise']+=int((s.contiguous().view(torch.int32)==ss.contiguous().view(torch.int32)).reshape(bs,-1).all(-1).sum());prev=torch.cat([torch.zeros_like(ys[:,:1]),ys[:,:-1]],1);mask=(a==0)[...,None,None].expand_as(ys);tot['hold_n']+=int(mask.sum());tot['hold_exact']+=int((((ys.contiguous().view(torch.int32)==prev.contiguous().view(torch.int32))&mask)).sum());mid=L//2;_,st,_=m(x[:,:mid],r);zp,_,_=m(x[:,mid:],r,st);tot['split']+=int((zp.argmax(-1)==pred).all(-1).sum());tot['oracle']+=bs
 return dict(n=n,event_n=n*L,slot_n=n*K,seconds=t,**tot)
PANELS=[('familiar',32,'mixed'),('familiar',256,'mixed'),('familiar',256,'retention'),('familiar',256,'conflict'),('held_template',32,'mixed'),('held_template',256,'mixed'),('held_alias',32,'mixed'),('unknown',32,'mixed'),('unknown',256,'mixed')]
def panels(m,seed):
 return {f'{p}_{L}_{k}':evaluate(m,14140000+seed*10000+j*100,L,k,p) for j,(p,L,k) in enumerate(PANELS)}
def train(arm,seed,steps=300):
 torch.set_num_threads(1);torch.manual_seed(seed);m=Model(arm);opt=torch.optim.AdamW([p for p in m.parameters() if p.requires_grad],lr=.004);curve=[];t0=time.perf_counter()
 for i in range(1,steps+1):
  m.train();x,r,a,k,v,y,_=gen(14000000+seed*10000+i,16,12,shuffle=arm!='fixed_soft');
  if arm=='dynamic_anneal':m.temp=max(.25,1-.75*i/steps);m.mode='hard' if i>steps*3//4 else 'soft'
  z,_,info=m(x,r);loss=F.cross_entropy(z.flatten(0,1),y.flatten());
  if arm=='supervised':loss=loss+.4*F.cross_entropy(info[0].flatten(0,1),a.flatten())+.4*F.cross_entropy(info[1].flatten(0,1),k.flatten())
  opt.zero_grad(set_to_none=True);loss.backward();gn=float(nn.utils.clip_grad_norm_(m.parameters(),1));assert math.isfinite(gn);opt.step()
  if i in (1,100,200,300):curve.append([i,float(loss.detach()),float((z.argmax(-1)==y).all(-1).float().mean())]);print(arm,seed,curve[-1],flush=True)
 sec=time.perf_counter()-t0;key=f'{arm}_{seed}';path=P/'fits'/f'{key}.pt';torch.save(dict(arm=arm,seed=seed,mode=m.mode,temp=m.temp,weights=m.state_dict()),path);res=dict(arm=arm,seed=seed,steps=steps,examples=steps*16,params=sum(p.numel() for p in m.parameters() if p.requires_grad),train_seconds=sec,curve=curve,mode=m.mode,temp=m.temp,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),native=panels(m,seed))
 if m.mode=='soft' and arm!='continuous':m.mode='hard';res['hardened']=panels(m,seed)
 (P/'fits'/f'{key}.json').write_text(json.dumps(res,indent=2));print('DONE',key,{k:v['complete'] for k,v in res['native'].items()},flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);p=argparse.ArgumentParser();p.add_argument('--arm');p.add_argument('--seed',type=int);a=p.parse_args();
 if a.arm:train(a.arm,a.seed)
 else:
  jobs=[(a,s) for s in SEEDS for a in ARMS];random.Random(1414).shuffle(jobs)
  with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
   fs={pool.submit(train,*j):j for j in jobs}
   for f in concurrent.futures.as_completed(fs):
    try:f.result()
    except Exception as e:print('FAIL',fs[f],repr(e),flush=True)
