import run as R
import pathlib,json,torch,math,time,hashlib,statistics
from torch.nn import functional as F
P=R.P

def load(path):
 ck=torch.load(path,weights_only=True);m=R.Model(ck.get('model_arm',ck['arm']));m.load_state_dict(ck['weights']);m.mode='hard';m.temp=ck['temp'];m.eval();return m

def lexical(x,r):
 # Unique word in each supplied roster sentence: exclude any occurrence in another roster entry.
 same=(r[:,:,None,:,None]==r[:,None,:,None,:]);match=same.any(-1);eye=torch.eye(r.shape[1],dtype=torch.bool)[None,:,:,None];unique=~(match&~eye).any(2);unique=unique&(r!=0)&(r!=1)
 evidence=((x[:,:,None,:,None]==r[:,None,:,None,:]) & unique[:,None,:,None,:]).any(-1).sum(-1);return evidence.argmax(-1)

def execute(m,v,action,addr,s=None):
 # Exact last-write/reset selection; no historic record carried across calls.
 B,L,H=v.shape;K=R.K
 if s is None:s=torch.zeros(B,K,H)
 j=torch.arange(1,L+1)[None,:,None];changed=(action!=0)[...,None] & F.one_hot(addr,K).bool();idx=torch.where(changed,j,0).max(1).values;prop=torch.where((action==2)[...,None],torch.zeros_like(v),v);vv=torch.cat([torch.zeros(B,1,H),prop],1);z=vv.gather(1,idx[...,None].expand(-1,-1,H));return torch.where((idx==0)[...,None],s,z)
@torch.no_grad()
def intervene(m,seed,panel,L):
 result={a:dict(n=96,complete=0,slot_correct=0,bitwise=0) for a in ('learned','oracle_action','lexical_address','both')}; action_n=addr_n=lex_n=0
 for i in range(12):
  x,r,a,k,v,y,x2=R.gen(15140000+seed*10000+L*10+i,8,L,'mixed',panel);log,al,p,ad,z=m.decisions(x,r);_,_,pp,aa,z2=m.decisions(x2,r);pa=p.argmax(-1);pk=ad.argmax(-1);pa2=pp.argmax(-1);pk2=aa.argmax(-1);lx=lexical(x,r);lx2=lexical(x2,r);action_n+=int((pa==a).sum());addr_n+=int((pk==k).sum());lex_n+=int((lx==k).sum())
  for mode in result:
   ac=a if mode in ['oracle_action','both'] else pa;ac2=a if mode in ['oracle_action','both'] else pa2;ak=lx if mode in ['lexical_address','both'] else pk;ak2=lx2 if mode in ['lexical_address','both'] else pk2;s=execute(m,z,ac,ak);ss=execute(m,z2,ac2,ak2);pred=m.read(s).argmax(-1);q=result[mode];q['complete']+=int((pred==y).all(-1).sum());q['slot_correct']+=int((pred==y).sum());q['bitwise']+=int((s.contiguous().view(torch.int32)==ss.contiguous().view(torch.int32)).reshape(8,-1).all(-1).sum())
 return dict(event_n=96*L,learned_action_correct=action_n,learned_address_correct=addr_n,lexical_address_correct=lex_n,arms=result)
@torch.no_grad()
def exhaust(m,panel):
 ids=list(range(8)) if panel!='unknown' else list(range(4))+list(range(8,12));tb=R.TABLES[panel=='held_template',panel=='held_alias'];x=[];a=[];k=[];v=[]
 for ac in range(3):
  for j,name in enumerate(ids):
   for val in range(8):
    for pat in range(tb.shape[-2]):x.append(tb[ac,name,val,pat]);a.append(ac);k.append(j);v.append(val)
 x=torch.stack(x);a=torch.tensor(a);k=torch.tensor(k);v=torch.tensor(v);r=R.ROST[torch.tensor(ids)];n=len(x);acok=adok=wok=0;wn=0
 for xx,aa,kk,vv in zip(x.split(128),a.split(128),k.split(128),v.split(128)):
  _,_,p,ad,z=m.decisions(xx[:,None],r[None].expand(len(xx),-1,-1));acok+=int((p.argmax(-1)[:,0]==aa).sum());adok+=int((ad.argmax(-1)[:,0]==kk).sum());mask=aa==1;wok+=int((m.read(z[:,0]).argmax(-1)[mask]==vv[mask]+1).sum());wn+=int(mask.sum())
 return dict(n=n,action_correct=acok,address_correct=adok,write_n=wn,write_value_correct=wok,canonical_zero_empty=int(m.read(torch.zeros(1,R.H)).argmax(-1).item())==0)
@torch.no_grad()
def restart(m,seed):
 n=32;correct=parity=0;replay=resume=0.;size=0
 for i in range(n):
  x,r,a,k,v,y,_=R.gen(17140000+seed*10000+i,1,256,'mixed','familiar');_,s,_=m(x[:,:128],r);times={};pred={}
  for mode in (('replay','resume') if i%2==0 else ('resume','replay')):
   t=time.perf_counter()
   if mode=='replay':z,_,_=m(x,r)
   else:
    raw=s.contiguous().numpy().tobytes();size=len(raw);st=torch.frombuffer(bytearray(raw),dtype=torch.float32).reshape_as(s);z,_,_=m(x[:,128:],r,st)
   times[mode]=time.perf_counter()-t;pred[mode]=z.argmax(-1)
  correct+=int((pred['replay']==y).all());parity+=int((pred['resume']==pred['replay']).all());replay+=times['replay'];resume+=times['resume']
 return dict(n=n,correct=correct,parity=parity,bytes=size,replay_s=replay,resume_s=resume,replay_s_per_correct=replay/correct if correct else None,resume_s_per_correct=resume/correct if correct else None)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);out=[]
 for s in R.SEEDS:
  m=load(P/'fits'/f'supervised_{s}.pt');q={'seed':s,'panels':{p:intervene(m,s,p,256) for p in ['familiar','held_template','held_alias','unknown']},'exhaustive':{p:exhaust(m,p) for p in ['familiar','held_template','held_alias','unknown']},'restart':restart(m,s)};out.append(q);print(s,q['exhaustive'],q['restart'],flush=True)
 (P/'diagnostics.json').write_text(json.dumps(out,indent=2))
