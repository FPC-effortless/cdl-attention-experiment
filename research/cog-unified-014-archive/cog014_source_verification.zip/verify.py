import run as R
import torch,hashlib,concurrent.futures,pathlib,json
P=R.P

def check(path):
 torch.set_num_threads(1);r=json.load(open(path));p=path.with_suffix('.pt');ck=torch.load(p,weights_only=True);m=R.Model(ck.get('model_arm',ck['arm']));m.load_state_dict(ck['weights']);m.mode=ck['mode'];m.temp=ck['temp'];m.eval();pan=R.panels(m,ck['seed']);eq=lambda a,b:all({k:v for k,v in a[x].items() if k!='seconds'}=={k:v for k,v in b[x].items() if k!='seconds'} for x in a);out=dict(key=path.stem,hash_ok=hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],native_equal=eq(pan,r['native']),native_split=sum(v['split'] for v in pan.values()),native_n=sum(v['n'] for v in pan.values()))
 if 'hardened' in r:
  m.mode='hard';q=R.panels(m,ck['seed']);out.update(hardened_equal=eq(q,r['hardened']),hardened_split=sum(v['split'] for v in q.values()),hardened_n=sum(v['n'] for v in q.values()))
 return out
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);fs=sorted((P/'fits').glob('*.json'));assert len(fs)==27,len(fs);out=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
  fut={pool.submit(check,f):f for f in fs}
  for f in concurrent.futures.as_completed(fut):
   try:q=f.result();out.append(q);print(q,flush=True)
   except Exception as e:print('FAIL',fut[f],repr(e),flush=True)
   (P/'verification.json').write_text(json.dumps(out,indent=2))
