import run as R
import torch, math, pathlib, json, time, hashlib, concurrent.futures, random
from torch.nn import functional as F
P=R.P
ARMS=['long_control','mixed_length','targeted_pair']

def genpair(seed,n,L):
 g=torch.Generator().manual_seed(seed);roster=torch.arange(R.K).expand(n,R.K).clone().gather(1,torch.rand(n,R.K,generator=g).argsort(1));a=torch.multinomial(torch.tensor([.5,.38,.12]),n*L,replacement=True,generator=g).reshape(n,L);k=torch.randint(R.K,(n,L),generator=g);v=torch.randint(8,(n,L),generator=g);a[:,0]=1;a[:,1]=torch.randint(3,(n,),generator=g);k[:,1]=k[:,0];names=roster.gather(1,k);tb=R.TABLES[False,False];t=torch.randint(tb.shape[-2],(n,L),generator=g);x=tb[a,names,v,t];y=torch.zeros(n,R.K,dtype=torch.long);b=torch.arange(n)
 for j in range(L):y[b,k[:,j]]=torch.where(a[:,j]==1,v[:,j]+1,torch.where(a[:,j]==2,0,y[b,k[:,j]]))
 return x,R.ROST[roster],y

def train(arm,seed):
 torch.set_num_threads(1);torch.manual_seed(seed);m=R.Model('dynamic_soft');opt=torch.optim.AdamW([p for p in m.parameters() if p.requires_grad],lr=.004);curve=[];t0=time.perf_counter();examples=0
 for i in range(1,601):
  L=12 if arm=='long_control' else (1,2,4,12)[(i-1)%4];n=192//L;examples+=n;ss=14200000+seed*10000+i
  if arm=='targeted_pair' and L in (2,4):x,r,y=genpair(ss,n,L)
  else:x,r,_,_,_,y,_=R.gen(ss,n,L)
  m.train();z,_,_=m(x,r);loss=F.cross_entropy(z.flatten(0,1),y.flatten());opt.zero_grad(set_to_none=True);loss.backward();gn=float(torch.nn.utils.clip_grad_norm_(m.parameters(),1));assert math.isfinite(gn);opt.step()
  if i in (1,100,300,600):curve.append([i,L,float(loss.detach()),float((z.argmax(-1)==y).all(-1).float().mean())]);print(arm,seed,curve[-1],flush=True)
 sec=time.perf_counter()-t0;key=f'{arm}_{seed}';path=P/'fits'/f'{key}.pt';torch.save(dict(arm=arm,model_arm='dynamic_soft',seed=seed,mode=m.mode,temp=m.temp,weights=m.state_dict()),path);res=dict(arm=arm,seed=seed,steps=600,examples=examples,events=115200,params=sum(p.numel() for p in m.parameters() if p.requires_grad),train_seconds=sec,curve=curve,mode=m.mode,temp=m.temp,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),native=R.panels(m,seed));m.mode='hard';res['hardened']=R.panels(m,seed);(P/'fits'/f'{key}.json').write_text(json.dumps(res,indent=2));print('DONE',key,{k:v['complete'] for k,v in res['native'].items()},flush=True)
if __name__=='__main__':
 torch.set_num_threads(1);torch.set_num_interop_threads(1);jobs=[(a,s) for a in ARMS for s in R.SEEDS];random.Random(1415).shuffle(jobs)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
  fs={pool.submit(train,*j):j for j in jobs}
  for f in concurrent.futures.as_completed(fs):
   try:f.result()
   except Exception as e:print('FAIL',fs[f],repr(e),flush=True)
