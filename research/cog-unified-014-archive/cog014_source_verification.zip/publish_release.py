#!/usr/bin/env python3
"""Publish exact archive assets using an authenticated GitHub CLI, with download verification."""
import argparse,hashlib,json,pathlib,subprocess,tempfile,sys

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def gh(*args):return subprocess.run(['gh',*args],check=True,capture_output=True,text=True).stdout

def main():
 a=argparse.ArgumentParser();a.add_argument('--repo',required=True);a.add_argument('--tag',required=True);a.add_argument('--target',required=True,help='Existing reviewed commit SHA');a.add_argument('--manifest',type=pathlib.Path,required=True,help='JSON list of archive, bytes, sha256; paths relative to manifest');a.add_argument('--publish',action='store_true');ns=a.parse_args();rows=json.loads(ns.manifest.read_text());files=[];seen=set()
 for r in rows:
  p=(ns.manifest.parent/r['archive']).resolve()
  if p.name in seen:raise ValueError('duplicate asset name: '+p.name)
  seen.add(p.name)
  if p.stat().st_size!=r['bytes'] or sha(p)!=r['sha256']:raise ValueError('local mismatch: '+str(p))
  files.append((p,r))
 if not ns.publish:print(json.dumps({'verified_local':len(files),'published':0,'dry_run':True}));return
 gh('auth','status'); # do not print credentials
 # New unique tag only: never overwrite an existing release asset.
 gh('release','create',ns.tag,'--repo',ns.repo,'--target',ns.target,'--title',ns.tag,'--notes','Exact research evidence archives; qualification decisions in attached source/results.','--draft',*[str(p) for p,r in files]);
 with tempfile.TemporaryDirectory() as td:
  for p,r in files:
   gh('release','download',ns.tag,'--repo',ns.repo,'--pattern',p.name,'--dir',td)
   q=pathlib.Path(td)/p.name
   if q.stat().st_size!=r['bytes'] or sha(q)!=r['sha256']:raise ValueError('remote mismatch: '+p.name)
  gh('release','edit',ns.tag,'--repo',ns.repo,'--draft=false')
  print(json.dumps({'remote_verified':len(files),'release':gh('release','view',ns.tag,'--repo',ns.repo,'--json','url,tagName,assets')},indent=2))
if __name__=='__main__':main()
