# Offline CPU comparison of two implementations of the identical fitted telemetry model.
import os, json, ctypes, subprocess, time, platform
from pathlib import Path
import run, numpy as np, torch
P=Path(__file__).parent

def main():
 torch.set_num_threads(1)
 D,g,_=run.load();r=json.load(open(P/'results.json'));split=r['folds']['Y'];tr=np.array(split['train']);te=np.array(split['test']);mean=D[tr].mean((0,1));std=D[tr].std((0,1));test=run.panels(((D-mean)/std)[te],2000)
 m=run.Bank('hold');m.load_state_dict(torch.load(P/'checkpoints/Y_17_COG-HOLD.pt',weights_only=True)['model']);m.eval()
 weights=m.state_dict();names={'enc.0.weight':'w1','enc.0.bias':'b1','enc.2.weight':'w2','enc.2.bias':'b2','head.0.weight':'w3','head.0.bias':'b3','head.2.weight':'w4','head.2.bias':'b4'}
 header='\n'.join('static const float '+v+'['+str(weights[k].numel())+']={'+','.join(f'{float(x):.9e}f' for x in weights[k].flatten())+'};' for k,v in names.items())
 src='''#include <math.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
'''+header+'''
static inline float sig(float x){return 1.0f/(1.0f+expf(-x));}
static inline float silu(float x){return x*sig(x);}
static inline float softplus(float x){return x>20.0f?x:log1pf(expf(x));}
static inline void linear(const float *x,const float *w,const float *b,float *out,int i,int o){for(int j=0;j<o;j++){float v=b[j];for(int k=0;k<i;k++)v+=x[k]*w[j*i+k];out[j]=v;}}
static inline void step(const float *x,float *h,float *out,int skip){
 for(int k=0;k<2;k++){
  if(skip && x[2+k]==0.0f)continue;
  float z[10],a[16],b[16];for(int j=0;j<8;j++)z[j]=x[j];z[8]=(k==0);z[9]=(k==1);
  linear(z,w1,b1,a,10,16);for(int j=0;j<16;j++)a[j]=silu(a[j]);linear(a,w2,b2,b,16,16);
  for(int j=0;j<8;j++){float g=sig(b[j])*x[2+k];h[k*8+j]=(1-g)*h[k*8+j]+g*tanhf(b[8+j]);}
 }
 float z[24],a[16],b[4];for(int j=0;j<16;j++)z[j]=h[j];for(int j=0;j<8;j++)z[16+j]=x[j];
 linear(z,w3,b3,a,24,16);for(int j=0;j<16;j++)a[j]=silu(a[j]);linear(a,w4,b4,b,16,4);
 for(int j=0;j<2;j++){out[j]=b[j]+x[6+j];out[j+2]=softplus(b[j+2])+0.03f;}
}
void infer(const float*x,float*y,int n,int t,int skip,int reps){for(int r=0;r<reps;r++)for(int b=0;b<n;b++){float h[16]={0};for(int j=0;j<t;j++){step(x+(b*t+j)*8,h,y+(b*t+j)*4,skip);}}}
'''
 (P/'native_bench.c').write_text(src);subprocess.run(['gcc','-O3','-ffp-contract=off','-fPIC','-shared',str(P/'native_bench.c'),'-o',str(P/'native_bench.so'),'-lm'],check=True)
 lib=ctypes.CDLL(str(P/'native_bench.so'));arr=np.ctypeslib.ndpointer(dtype=np.float32,flags='C_CONTIGUOUS');lib.infer.argtypes=[arr,arr,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_int];lib.infer.restype=None
 out={'hardware':platform.machine(),'processor':platform.processor(),'compiler':subprocess.check_output(['gcc','--version'],text=True).splitlines()[0],'scope':'Host CPU only; identical COG-HOLD checkpoint masked vs actual conditional execution; preprocessing excluded, no power measurement.','recurrent_bytes_fp32':64,'parameter_bytes_fp32':4*sum(p.numel() for p in m.parameters()),'panels':{}}
 for k,(x,l,y,mask) in test.items():
  x=x.contiguous();n,t,_=x.shape;xx=x.numpy();a=np.empty((n,t,4),np.float32);b=np.empty_like(a)
  lib.infer(xx,a,n,t,0,1);lib.infer(xx,b,n,t,1,1)
  with torch.no_grad():mu,s=m(x);ref=torch.cat([mu,s],-1).numpy()
  parity=float(np.max(np.abs(a-b)));refdiff=float(np.max(np.abs(a-ref)));assert parity==0 and refdiff<1e-4,(parity,refdiff)
  times={0:[],1:[]};reps=120
  for i in range(7):
   for mode in ([0,1] if i%2==0 else [1,0]):
    start=time.perf_counter_ns();lib.infer(xx,a,n,t,mode,reps);times[mode].append((time.perf_counter_ns()-start)/1000/(n*t*reps))
  full=float(np.median(times[0]));skip=float(np.median(times[1]));out['panels'][k]={'timing_repetitions':7,'samples_per_repetition':n*t*reps,'dense_masked_us_per_tick':full,'event_skip_us_per_tick':skip,'speedup':full/skip,'all_times_us':times,'banks_evaluated_masked':int(n*t*2),'banks_evaluated_skip':int(mask.sum()),'fraction_banks_skipped':float(1-mask.float().mean()),'native_parity_maxdiff':parity,'torch_reference_maxdiff':refdiff}
 (P/'native_profile.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
