import json,torch,numpy as np,run,supplementary,hashlib
from pathlib import Path
P=Path(__file__).parent

def main():
 torch.set_num_threads(1);D,g,meta=run.load();r=json.load(open(P/'results.json'));s=json.load(open(P/'supplementary.json'));rows=r['fits']+s;fact={**run.FACT,**supplementary.FACT};maxdiff=0.;causal=0.;hidden=0.;checks=0;viol=0;tested=0
 assert len(rows)==81 and len(list((P/'checkpoints').glob('*.pt')))==81
 assert len(set(x['blob_sha'] for x in meta))==12
 for row in rows:
  name,seed,fold=row['name'],row['seed'],row['fold'];f=run.GROUPS.index(fold);split=r['folds'][fold];tr,va,te=[np.array(split[k]) for k in ['train','val','test']];assert not (set(tr)&set(va) or set(tr)&set(te) or set(va)&set(te));assert all(g[te]==fold) and all(g[tr]!=fold) and all(g[va]!=fold)
  mean=D[tr].mean((0,1));std=D[tr].std((0,1));z=(D-mean)/std;test=run.panels(z[te],2000+f)
  m=fact[name]();pth=P/'checkpoints'/f'{fold}_{seed}_{name.replace(" ","_")}.pt';state=torch.load(pth,weights_only=True);m.load_state_dict(state['model']);m.eval();assert state['calibration_q']==row['calibration_q'];assert sum(p.numel() for p in m.parameters())==row['params']
  with torch.no_grad():
   for k,(x,l,y,mask) in test.items():
    mu,sd=m(x);res=run.score(mu,sd,y,mask,std,row['calibration_q']);diff=max(abs(res[a]-row['tests'][k][a]) for a in ['nrmse','v_rmse','a_rmse','coverage90','nll']);maxdiff=max(maxdiff,diff);assert diff<1e-6,(name,k,diff)
    # Counterfactual hidden-label invariance: replacing masked targets cannot change input features.
    altered=y.numpy().copy();altered[~mask.numpy()]=900.0;xx,_,_,_=run.inputs(altered,mask.numpy());assert torch.equal(x,xx)
    # Prefix causality, including all recurrence references and supplementary arms.
    short=m(x[:2,:48]);long=(mu[:2,:48],sd[:2,:48]);q=max(float((a-b).abs().max()) for a,b in zip(short,long));causal=max(causal,q);assert q<1e-4
    # Exact unchanged unobserved banks, across all test sequences of protected primary arms.
    if name in ['COG-HOLD','COG-DUAL']:
     st=m.init(x.shape[0]);
     for j in range(x.shape[1]):
      old=st;_,st=m.step(x[:,j],st);zmask=~x[:,j,2:4].bool();checks+=int(zmask.sum())*m.h;viol+=int((old[0][zmask]!=st[0][zmask]).sum())
    tested+=1
 assert viol==0
 result={'checkpoints_replayed':len(rows),'test_panels_replayed':tested,'max_metric_diff':maxdiff,'max_prefix_error':causal,'masked_label_invariance_panels':tested,'protected_scalar_checks':checks,'protected_scalar_violations':viol,'unique_source_blobs':12,'fold_airframe_disjoint':True,'protocol_hash_matches':hashlib.sha256((P/'PROTOCOL.md').read_bytes()).hexdigest()==r['protocol_sha256']};assert result['protocol_hash_matches'];(P/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
