# Post-pilot diagnostic: additional controls, fixed protocol before inspecting their outcomes.
import run, numpy as np, torch, time, json,copy,hashlib
from torch import nn
from pathlib import Path
P=Path(__file__).parent
class Static(run.Out):
 def __init__(self):super().__init__(24);self.enc=nn.Sequential(nn.Linear(8,24),nn.SiLU(),nn.Linear(24,24))
 def forward(self,x):return self.emit(self.enc(x),x)
class DualDense(run.Bank):
 def __init__(self):super().__init__('dual')
 def coeff(self,x):
  z=torch.cat([x.unsqueeze(-2).expand(*x.shape[:-1],2,8),self.ids.expand(*x.shape[:-1],2,2)],-1);g,u=self.enc(z).chunk(2,-1);g=g.sigmoid();return 1-g,g*u.tanh()
class DualNoEvolve(run.Bank):
 def __init__(self):super().__init__('dual')
 def forward(self,x):
  a,b=self.coeff(x);h=run.scan(a,b).flatten(2);g,u=self.pred(x).chunk(2,-1);g=g.sigmoid()*x[...,2:4].amax(-1,keepdim=True);h=torch.cat([h,run.scan(1-g,g*u.tanh())],-1);return self.emit(h,x)
FACT={'Static MLP':Static,'Dual dense ablation':DualDense,'Dual gated evolution ablation':DualNoEvolve}
def main():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);D,group,_=run.load();out=[];ck=P/'checkpoints';
 for fold,g in enumerate(run.GROUPS):
  te=np.flatnonzero(group==g);others=[np.flatnonzero(group==gg) for gg in run.GROUPS if gg!=g];tridx=np.concatenate([z[:-1] for z in others]);dv=np.array([z[-1] for z in others]);mean=D[tridx].mean((0,1));std=D[tridx].std((0,1));z=(D-mean)/std;tr=z[tridx];dev=run.panels(z[dv],1000+fold);test=run.panels(z[te],2000+fold)
  for seed in run.SEEDS:
   for name,f in FACT.items():
    torch.manual_seed(seed);rng=np.random.default_rng(seed+10000*fold);model=f();opt=torch.optim.AdamW(model.parameters(),lr=.003,weight_decay=.002);best=(float('inf'),None,0);tic=time.perf_counter()
    for i in range(run.UPDATES):
     fi=rng.integers(0,len(tr),12);start=rng.integers(0,96-run.T+1,12);y=tr[fi[:,None],start[:,None]+np.arange(run.T)];rate=rng.choice([.25,.5,.75],size=(12,1,1));m=rng.random(y.shape)<rate;m[:,0,:]=True;x,l,y,m=run.inputs(y,m);mu,s=model(x);sel=~m;sel[:,:4]=False;loss=(.5*((mu-y)/s).square()+s.log())[sel].mean();opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
     if (i+1)%40==0:
      model.eval();vs=run.val_score(model,dev);model.train()
      if vs<best[0]:best=(vs,copy.deepcopy(model.state_dict()),i+1)
    model.load_state_dict(best[1]);model.eval();cal=run.calibration(model,dev)
    with torch.no_grad():row={'fold':g,'seed':seed,'name':name,'params':sum(p.numel() for p in model.parameters()),'fit_seconds':time.perf_counter()-tic,'selected_update':best[2],'val_nrmse':best[0],'calibration_q':cal,'tests':{k:run.score(*model(p[0]),p[2],p[3],std,cal) for k,p in test.items()}}
    out.append(row);torch.save({'model':model.state_dict(),'train_mean':mean.tolist(),'train_std':std.tolist(),'calibration_q':cal,'fold':g,'seed':seed,'name':name},ck/f'{g}_{seed}_{name.replace(" ","_")}.pt');print(g,seed,name,row['params'],{k:round(v['nrmse'],4) for k,v in row['tests'].items()},flush=True);(P/'supplementary.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__':main()
