import os
os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
import json,base64,hashlib,time,platform,copy
from pathlib import Path
import numpy as np,torch
from torch import nn
import torch.nn.functional as F
P=Path(__file__).resolve().parent
T=32;UPDATES=160;SEEDS=[17,31,59];GROUPS=['Y','R','G'];RATES=[.5,.15]
def load():
 a=[];groups=[];meta=[]
 for line in (P/'telemetry_extract.txt').read_text().splitlines():
  path,sha,h,b=line.split('|');raw=base64.b64decode(b,validate=True);z=2166136261
  for n in raw:z=((z^n)*16777619)&0xffffffff
  assert len(raw)==384 and f'{z:08x}'==h
  d=np.frombuffer(raw,dtype='<i2').reshape(96,2).astype(np.float32)/np.array([100,10],np.float32)
  g=path.split('/')[-1][3];groups.append(g);a.append(d);meta.append(dict(path=path,blob_sha=sha,fnv1a=h,extract_sha256=hashlib.sha256(raw).hexdigest(),group=g))
 return np.stack(a),np.array(groups),meta

def inputs(y,m):
 b,t,n=y.shape;last=np.zeros((b,n),np.float32);age=np.full((b,n),32,np.float32);xx=[];ll=[]
 for j in range(t):
  z=m[:,j];last=np.where(z,y[:,j],last);age=np.where(z,0,age+1)
  xx.append(np.concatenate([y[:,j]*z,z,np.log1p(age)/4,last],-1).astype(np.float32));ll.append(last.copy())
 return tuple(torch.from_numpy(a) for a in (np.stack(xx,1),np.stack(ll,1),y.astype(np.float32),m))
def panels(y,seed):
 rng=np.random.default_rng(seed);out={}
 for r in RATES:
  yy=np.repeat(y,8,axis=0);m=rng.random(yy.shape)<r;m[:,0,:]=True;out[str(r)]=inputs(yy,m)
 return out

def scan(a,b):
 k=1
 while k<a.shape[1]:
  ap,bp=a,b;a=torch.cat([ap[:,:k],ap[:,k:]*ap[:,:-k]],1);b=torch.cat([bp[:,:k],bp[:,k:]+ap[:,k:]*bp[:,:-k]],1);k*=2
 return b
class Out(nn.Module):
 def __init__(self,d):super().__init__();self.head=nn.Sequential(nn.Linear(d+8,16),nn.SiLU(),nn.Linear(16,4))
 def emit(self,h,x):
  q=self.head(torch.cat([h,x],-1));return q[...,:2]+x[...,6:8],F.softplus(q[...,2:])+.03
class Bank(Out):
 def __init__(self,mode):
  self.mode=mode;self.h=6 if mode=='dual' else 8;self.p=8 if mode=='dual' else 0
  super().__init__(2*self.h+self.p);self.enc=nn.Sequential(nn.Linear(10,16),nn.SiLU(),nn.Linear(16,2*self.h));self.register_buffer('ids',torch.eye(2))
  if self.p:self.pred=nn.Sequential(nn.Linear(8,12),nn.SiLU(),nn.Linear(12,2*self.p))
 def coeff(self,x):
  z=torch.cat([x.unsqueeze(-2).expand(*x.shape[:-1],2,8),self.ids.expand(*x.shape[:-1],2,2)],-1);g,u=self.enc(z).chunk(2,-1);g=g.sigmoid()
  if self.mode!='dense':g=g*x[...,2:4,None]
  return 1-g,g*u.tanh()
 def forward(self,x):
  a,b=self.coeff(x);h=scan(a,b).flatten(2)
  if self.p:
   g,u=self.pred(x).chunk(2,-1);g=g.sigmoid();h=torch.cat([h,scan(1-g,g*u.tanh())],-1)
  return self.emit(h,x)
 def init(self,b):return (torch.zeros(b,2,self.h),torch.zeros(b,self.p))
 def step(self,x,s):
  a,b=self.coeff(x);h=a*s[0]+b;p=s[1];v=h.flatten(1)
  if self.p:
   g,u=self.pred(x).chunk(2,-1);g=g.sigmoid();p=(1-g)*p+g*u.tanh();v=torch.cat([v,p],-1)
  return self.emit(v,x),(h,p)
class Gru(Out):
 def __init__(self,d=12):super().__init__(d);self.d=d;self.rnn=nn.GRU(8,d,batch_first=True)
 def forward(self,x):return self.emit(self.rnn(x)[0],x)
 def init(self,b):return torch.zeros(1,b,self.d)
 def step(self,x,s):
  y,s=self.rnn(x[:,None],s);return self.emit(y[:,0],x),s
class SSM(Out):
 # Mamba-style input-dependent dt, B, C, diagonal A and gated output; reference recurrence only.
 def __init__(self,d=12,n=4):
  super().__init__(d);self.d=d;self.n=n;self.proj=nn.Linear(8,3*d+2*n);self.Alog=nn.Parameter(torch.log(torch.arange(1,n+1.).repeat(d,1)));self.D=nn.Parameter(torch.ones(d))
 def coeff(self,x):
  v,z,dt,B,C=self.proj(x).split([self.d,self.d,self.d,self.n,self.n],-1);v=F.silu(v);dt=F.softplus(dt)+.001;A=-self.Alog.exp();a=(dt[...,None]*A).exp();b=((a-1)/A)*B.unsqueeze(-2)*v[...,None];return a,b,C,v,z
 def forward(self,x):
  a,b,C,v,z=self.coeff(x);s=scan(a,b);return self.emit(((s*C.unsqueeze(-2)).sum(-1)+self.D*v)*F.silu(z),x)
 def init(self,b):return torch.zeros(b,self.d,self.n)
 def step(self,x,s):
  a,b,C,v,z=self.coeff(x);s=a*s+b;return self.emit(((s*C.unsqueeze(-2)).sum(-1)+self.D*v)*F.silu(z),x),s
class Delta(Out):
 # Gated delta rule: forget matrix then write key/value prediction error. Reference recurrence only.
 def __init__(self,d=6,heads=2):super().__init__(d*heads);self.d=d;self.h=heads;self.proj=nn.Linear(8,heads*(4*d+2))
 def coeff(self,x):
  q,k,v,z,a,b=self.proj(x).reshape(*x.shape[:-1],self.h,4*self.d+2).split([self.d]*4+[1,1],-1);return F.normalize(q,dim=-1),F.normalize(k,dim=-1),v,z,a.sigmoid(),b.sigmoid()
 def rec(self,q,k,v,z,a,b,s):
  s=a[...,None]*s;err=v-(s*k.unsqueeze(-1)).sum(-2);s=s+b[...,None]*k.unsqueeze(-1)*err.unsqueeze(-2);h=(s*q.unsqueeze(-1)).sum(-2)*F.silu(z);return h.flatten(-2),s
 def forward(self,x):
  q,k,v,z,a,b=self.coeff(x);s=self.init(x.shape[0]);ys=[]
  for j in range(x.shape[1]):
   h,s=self.rec(q[:,j],k[:,j],v[:,j],z[:,j],a[:,j],b[:,j],s);ys.append(h)
  return self.emit(torch.stack(ys,1),x)
 def init(self,b):return torch.zeros(b,self.h,self.d,self.d)
 def step(self,x,s):
  h,s=self.rec(*self.coeff(x),s);return self.emit(h,x),s
FACT={'COG-HOLD':lambda:Bank('hold'),'Dense bank':lambda:Bank('dense'),'COG-DUAL':lambda:Bank('dual'),'GRU':Gru,'Selective SSM reference':SSM,'Gated delta reference':Delta}

def score(mu,s,y,m,std,q=None):
 e=mu-y;sel=~m;sel[:,:12]=False
 r={'n':int(sel.sum()),'nrmse':float((e[sel]**2).mean().sqrt()),'nll':float((.5*(e/s).square()+s.log())[sel].mean()),'v_rmse':float((e[:,:,0][sel[:,:,0]].square().mean().sqrt())*std[0]),'a_rmse':float((e[:,:,1][sel[:,:,1]].square().mean().sqrt())*std[1])}
 r['per_flight_nrmse']=[float(ee[ss].square().mean().sqrt()) for ee,ss in zip(e.reshape(-1,8,96,2),sel.reshape(-1,8,96,2))]
 if q is not None:
  w=s*torch.tensor(q);r['coverage90']=float((e.abs()<=w)[sel].float().mean());r['interval_width_v']=float((2*w[:,:,0][sel[:,:,0]]).mean()*std[0]);r['interval_width_a']=float((2*w[:,:,1][sel[:,:,1]]).mean()*std[1])
 return r
@torch.no_grad()
def val_score(model,pans):return np.mean([score(*model(x),y,m,np.ones(2))['nrmse'] for x,l,y,m in pans.values()])
@torch.no_grad()
def calibration(model,pans):
 scores=[[],[]]
 for x,l,y,m in pans.values():
  mu,s=model(x);e=(mu-y).abs()/s;sel=~m;sel[:,:12]=False
  for j in range(2):scores[j].extend(e[:,:,j][sel[:,:,j]].tolist())
 return [float(np.quantile(x,.90,method='higher')) for x in scores]
def classical_predict(panel,A,b,Q,R):
 x,l,y,m=panel;obs=x.numpy()[...,:2];ms=m.numpy();out=[];sig=[]
 for xx,mm in zip(obs,ms):
  mu=np.zeros(2);p=np.eye(2)*2;u=[];v=[]
  for z,mask in zip(xx,mm):
   mu=A@mu+b;p=A@p@A.T+Q;idx=np.flatnonzero(mask)
   if len(idx):
    k=np.linalg.solve(p[np.ix_(idx,idx)]+R*np.eye(len(idx)),p[idx,:]).T;mu=mu+k@(z[idx]-mu[idx]);p=p-k@p[idx,:];p=(p+p.T)*.5
   u.append(mu.copy());v.append(np.sqrt(np.maximum(np.diag(p),1e-6)))
  out.append(u);sig.append(v)
 return torch.tensor(np.array(out),dtype=torch.float32),torch.tensor(np.array(sig),dtype=torch.float32)
def tune(tr,dev,test,std):
 prev=tr[:,:-1].reshape(-1,2);nxt=tr[:,1:].reshape(-1,2);w=np.linalg.lstsq(np.c_[prev,np.ones(len(prev))],nxt,rcond=None)[0];A=w[:2].T;b=w[2];res=nxt-prev@A.T-b;Q=np.cov(res.T)+np.eye(2)*1e-5;out={}
 for kind,AA,bb,QQ in [('Random-walk KF',np.eye(2),np.zeros(2),np.diag(np.var(nxt-prev,axis=0))+np.eye(2)*1e-5),('VAR KF',A,b,Q)]:
  best=None
  for q in [.25,1,4]:
   for r in [.001,.01,.1]:
    cfg=(AA,bb,QQ*q,r);v=np.mean([score(*classical_predict(p,*cfg),p[2],p[3],std)['nrmse'] for p in dev.values()])
    if best is None or v<best[0]:best=(v,cfg,q,r)
  v,cfg,q,r=best;out[kind]={'val':v,'q_multiplier':q,'R':r,'tests':{k:score(*classical_predict(p,*cfg),p[2],p[3],std) for k,p in test.items()}}
 out['Last observation']={'tests':{k:score(p[1],torch.ones_like(p[1]),p[2],p[3],std) for k,p in test.items()}}
 return out
def state_count(s):return sum(state_count(z) for z in s) if isinstance(s,(tuple,list)) else s.numel()
@torch.no_grad()
def profile(model,x):
 x=x[:1];a,b=model(x);s=model.init(1);ys=[];ss=[];checks=0;viol=0
 for j in range(x.shape[1]):
  old=s;(mu,sig),s=model.step(x[:,j],s);ys.append(mu);ss.append(sig)
  if isinstance(model,Bank) and model.mode!='dense':
   z=~x[:,j,2:4].bool();checks+=int(z.sum())*model.h;viol+=int((old[0][z]!=s[0][z]).sum())
 diff=max(float((a-torch.stack(ys,1)).abs().max()),float((b-torch.stack(ss,1)).abs().max()));assert diff<1e-4,diff
 ticks=[z.contiguous() for z in x.unbind(1)];times=[]
 for _ in range(5):
  s=model.init(1);t0=time.perf_counter_ns()
  for _ in range(8):
   for z in ticks:_,s=model.step(z,s)
  times.append((time.perf_counter_ns()-t0)/1e3/(8*len(ticks)))
 return {'state_bytes_fp32':4*state_count(s),'weight_bytes_fp32':4*sum(p.numel() for p in model.parameters()),'step_us_median':float(np.median(times)),'step_us_repetitions':times,'max_batch_step_diff':diff,'hold_checks':checks,'hold_violations':viol}
def run():
 torch.set_num_threads(1);torch.set_num_interop_threads(1);data,group,meta=load();results={'protocol_sha256':hashlib.sha256((P/'PROTOCOL.md').read_bytes()).hexdigest(),'source':meta,'torch':torch.__version__,'platform':platform.platform(),'updates':UPDATES,'fits':[],'classical':{},'folds':{},'profiles':{}};out=P/'results.json';ck=P/'checkpoints';ck.mkdir(exist_ok=True)
 for fold,g in enumerate(GROUPS):
  testidx=np.flatnonzero(group==g);other=[np.flatnonzero(group==gg) for gg in GROUPS if gg!=g];trainidx=np.concatenate([z[:-1] for z in other]);devidx=np.array([z[-1] for z in other]);assert not set(trainidx)&set(testidx) and not set(devidx)&set(testidx)
  mean=data[trainidx].mean((0,1));std=data[trainidx].std((0,1));allz=(data-mean)/std;tr=allz[trainidx];dev=panels(allz[devidx],1000+fold);test=panels(allz[testidx],2000+fold);results['folds'][g]={'train':trainidx.tolist(),'val':devidx.tolist(),'test':testidx.tolist(),'mean':mean.tolist(),'std':std.tolist()}
  results['classical'][g]=tune(tr,dev,test,std);print('CLASSICAL',g,{k:round(v['tests']['0.15']['nrmse'],4) for k,v in results['classical'][g].items()},flush=True);out.write_text(json.dumps(results,indent=2))
  for seed in SEEDS:
   for name,f in FACT.items():
    torch.manual_seed(seed);rng=np.random.default_rng(seed+10000*fold);model=f();opt=torch.optim.AdamW(model.parameters(),lr=.003,weight_decay=.002);best=(float('inf'),None,0);tic=time.perf_counter()
    for i in range(UPDATES):
     fi=rng.integers(0,len(tr),12);start=rng.integers(0,96-T+1,12);y=tr[fi[:,None],start[:,None]+np.arange(T)];rate=rng.choice([.25,.5,.75],size=(12,1,1));m=rng.random(y.shape)<rate;m[:,0,:]=True;x,l,y,m=inputs(y,m);mu,s=model(x);sel=~m;sel[:,:4]=False;loss=(.5*((mu-y)/s).square()+s.log())[sel].mean();opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
     if (i+1)%40==0:
      model.eval();vs=val_score(model,dev);model.train()
      if vs<best[0]:best=(vs,copy.deepcopy(model.state_dict()),i+1)
    model.load_state_dict(best[1]);model.eval();elapsed=time.perf_counter()-tic;cal=calibration(model,dev)
    with torch.no_grad():row={'fold':g,'seed':seed,'name':name,'params':sum(p.numel() for p in model.parameters()),'fit_seconds':elapsed,'selected_update':best[2],'val_nrmse':best[0],'calibration_q':cal,'tests':{k:score(*model(p[0]),p[2],p[3],std,cal) for k,p in test.items()}}
    results['fits'].append(row);torch.save({'model':model.state_dict(),'train_mean':mean.tolist(),'train_std':std.tolist(),'calibration_q':cal,'fold':g,'seed':seed,'name':name},ck/f'{g}_{seed}_{name.replace(" ","_")}.pt');print(g,seed,name,row['params'],best[2],round(elapsed,2),{k:round(v['nrmse'],4) for k,v in row['tests'].items()},flush=True)
    if fold==0 and seed==17:results['profiles'][name]=profile(model,test['0.15'][0]);print('PROFILE',name,results['profiles'][name],flush=True)
    out.write_text(json.dumps(results,indent=2))
if __name__=='__main__':run()
