import os,json,time,platform
os.environ['OMP_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
import numpy as np,torch
from torch import nn
import torch.nn.functional as F
from pathlib import Path
P=Path(__file__).resolve().parent
N=6;H=8;T=64;B=32;STEPS=500;SEEDS=[17,31,59];W=64
# Synthetic normalized non-flight-critical telemetry, not actual flight data.
def data(seed,b,t,rate,drift=.028,shared=0.):
    rng=np.random.default_rng(seed);s=rng.normal(0,.35,(b,N));y=np.empty((b,t,N),np.float32);x=np.zeros((b,t,N+2),np.float32);age=np.zeros((b,t,N),np.float32);a=np.full((b,N),64.)
    for j in range(t):
        s=.998*s+rng.normal(0,drift,(b,N))+rng.normal(0,shared,(b,1));s+=rng.normal(0,.25,(b,N))*(rng.random((b,N))<.004);y[:,j]=s
        obs=rng.random(b)<rate;ids=rng.integers(0,N,b);ii=np.arange(b)[obs];kk=ids[obs];x[ii,j,kk]=1;x[ii,j,N]=s[ii,kk]+rng.normal(0,.1,len(ii));x[:,j,N+1]=obs;a+=1;a[ii,kk]=0;age[:,j]=a
    return torch.from_numpy(x),torch.from_numpy(np.log1p(age)/5),torch.from_numpy(y)
def scan(a,b):
    stride=1
    while stride<a.shape[1]:
        a0,b0=a,b;a=torch.cat([a0[:,:stride],a0[:,stride:]*a0[:,:-stride]],1);b=torch.cat([b0[:,:stride],b0[:,stride:]+a0[:,stride:]*b0[:,:-stride]],1);stride*=2
    return b
class Bank(nn.Module):
    def __init__(self,mask):
        super().__init__();self.mask=mask;self.enc=nn.Sequential(nn.Linear(2*N+2,16),nn.Tanh(),nn.Linear(16,2*H));self.head=nn.Sequential(nn.Linear(N*H+N,24),nn.Tanh(),nn.Linear(24,N));self.register_buffer('ids',torch.eye(N))
    def gates(self,x):
        b,t,_=x.shape;inp=torch.cat([x[:,:,None,:].expand(b,t,N,-1),self.ids[None,None].expand(b,t,-1,-1)],-1);g,u=self.enc(inp).chunk(2,-1);g=g.sigmoid();u=u.tanh()
        if self.mask:g=g*x[:,:,:N,None]
        return g,u
    def forward(self,x,age):
        g,u=self.gates(x);h=scan(1-g,g*u);return self.head(torch.cat([h.flatten(2),age],-1))
class GRU(nn.Module):
    def __init__(self,h):
        super().__init__();self.rnn=nn.GRU(N+2,h,batch_first=True);self.head=nn.Sequential(nn.Linear(h+N,24),nn.Tanh(),nn.Linear(24,N))
    def forward(self,x,age):return self.head(torch.cat([self.rnn(x)[0],age],-1))
class Attention(nn.Module):
    def __init__(self,d=16):
        super().__init__();self.emb=nn.Linear(N+2,d);self.qkv=nn.Linear(d,3*d);self.proj=nn.Linear(d,d);self.ln=nn.LayerNorm(d);self.ff=nn.Sequential(nn.Linear(d,2*d),nn.GELU(),nn.Linear(2*d,d));self.ln2=nn.LayerNorm(d);self.head=nn.Sequential(nn.Linear(d+N,24),nn.Tanh(),nn.Linear(24,N));self.bias=nn.Parameter(torch.zeros(W))
    def forward(self,x,age):
        e=self.emb(x);q,k,v=self.qkv(e).chunk(3,-1);t=x.shape[1];ix=torch.arange(t,device=x.device);diff=ix[:,None]-ix[None,:];bias=self.bias[diff.clamp(0,W-1)].masked_fill((diff<0)|(diff>=W),float('-inf'));q=q.reshape(q.shape[0],t,4,-1).transpose(1,2);k=k.reshape(k.shape[0],t,4,-1).transpose(1,2);v=v.reshape(v.shape[0],t,4,-1).transpose(1,2);h=F.scaled_dot_product_attention(q,k,v,attn_mask=bias[None,None]).transpose(1,2).reshape(e.shape);h=self.ln(e+self.proj(h));h=self.ln2(h+self.ff(h));return self.head(torch.cat([h,age],-1))
def classical(x,mode):
    x=x.numpy();b,t,_=x.shape;h=np.zeros((b,N));p=np.full((b,N),.35**2);out=[]
    for j in range(t):
        if mode=='KF':h*=.998;p=.998**2*p+.028**2+.004*.25**2
        mask=x[:,j,:N].astype(bool);z=np.broadcast_to(x[:,j,N,None],(b,N));k=p/(p+.1**2) if mode=='KF' else 1.;h=np.where(mask,h+k*(z-h),h)
        if mode=='KF':p=np.where(mask,(1-k)*p,p)
        out.append(h.copy())
    return torch.from_numpy(np.stack(out,1))
def metrics(pred,y):
    er=(pred[:,64:]-y[:,64:]).square().mean((1,2)).sqrt();return {'rmse':float((pred[:,64:]-y[:,64:]).square().mean().sqrt()),'trajectory_rmse':er.tolist()}
def run():
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    factories={'COG-inspired masked bank':lambda:Bank(True),'Dense bank ablation':lambda:Bank(False),'GRU parameter-near':lambda:GRU(19),'GRU state-matched':lambda:GRU(N*H),'Window-64 four-head attention':lambda:Attention(16)}
    tests={'nominal':data(8101,96,512,.75),'sparse':data(8102,96,512,.15),'sparse_fast_drift':data(8103,96,512,.15,drift=.055,shared=.025)}
    results={'protocol':{'seeds':SEEDS,'updates':STEPS,'batch':B,'train_length':T,'test_length':512,'test_trajectories_per_regime':96,'train_observation_rate':.75,'test_warmup':64,'channels':N,'synthetic':True,'dtype':'float32','torch':torch.__version__,'machine':platform.machine()},'fits':[],'classical':{}}
    for name in ['Last observation','Kalman (known nominal dynamics)']:
        results['classical'][name]={k:metrics(classical(x,'KF' if name.startswith('Kalman') else 'last'),y) for k,(x,a,y) in tests.items()}
    for seed in SEEDS:
        for name,f in factories.items():
            torch.manual_seed(seed);m=f();opt=torch.optim.AdamW(m.parameters(),lr=.004);start=time.perf_counter()
            for i in range(STEPS):
                x,a,y=data(100000*seed+i,B,T,.75);pred=m(x,a);loss=(pred-y).square().mean();opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(m.parameters(),1.);opt.step()
            elapsed=time.perf_counter()-start;m.eval();row={'name':name,'seed':seed,'params':sum(p.numel() for p in m.parameters()),'train_seconds':elapsed,'last_train_mse':float(loss.detach()),'tests':{}}
            with torch.no_grad():
                for k,(x,a,y) in tests.items():
                    pred=torch.cat([m(xx,aa) for xx,aa in zip(x.split(8),a.split(8))]);row['tests'][k]=metrics(pred,y)
            results['fits'].append(row);print(name,seed,row['params'],round(elapsed,2),{k:round(v['rmse'],5) for k,v in row['tests'].items()},flush=True);(P/'results.json').write_text(json.dumps(results,indent=2))
            torch.save(m.state_dict(),P/(name.replace(' ','_')+'_'+str(seed)+'.pt'))
    torch.manual_seed(9);m=Bank(True);x=tests['nominal'][0][:2];b,t,_=x.shape
    with torch.no_grad():
        g,u=m.gates(x);h=torch.zeros(b,N,H);checks=0;viol=0
        for j in range(t):
            new=(1-g[:,j])*h+g[:,j]*u[:,j];mask=~x[:,j,:N].bool();checks+=int(mask.sum())*H;viol+=int((new[mask]!=h[mask]).sum());h=new
    results['hold_check']={'scalar_checks':checks,'violations':viol};(P/'results.json').write_text(json.dumps(results,indent=2))
if __name__=='__main__':run()
