# COG-DRONE-001 — synthetic asynchronous telemetry mechanism screen

Status: exploratory, not a real flight qualification or a full COG-UNIFIED model test. The mask is engineered from known sensor identities; all neural baselines receive the same sensor observations and derived ages. This benchmark intentionally uses independently evolving channels in the nominal regime; the drift stress adds common noise. A conventional Kalman filter with supplied nominal dynamics is the strongest baseline. The test is passive estimation only, not navigation or vehicle control.

Reference: https://github.com/FPC-effortless/cdl-attention-experiment/blob/5c42980a555b3253949e5f556a9af725bd3c34c3/research/nanocog-001/unified-001/ARCHITECTURE.md

Run `python experiment.py`, `python extended/experiment.py`, `python replay.py`, and `python profile_stream.py` from this directory with Python, NumPy, and PyTorch. Each fit includes a state_dict checkpoint, deterministic generator seeds, and per-trajectory RMSE in results.json. Host latency is implementation-specific; the tests do not measure power, onboard hardware, or full-model deployment. No official lab ledger or repository changes were made.

## Extended results

| Model | Parameters | Normal | Sparse | Faster drift |
|---|---:|---:|---:|---:|
| COG-inspired masked bank | 1982 | 0.121543 | 0.212821 | 0.410566 |
| Dense bank ablation | 1982 | 0.150844 | 0.321800 | 0.567922 |
| GRU parameter-near | 2427 | 0.169239 | 0.366968 | 0.650134 |
| GRU state-matched | 9822 | 0.161449 | 0.361583 | 0.625953 |
| Window-64 four-head attention | 3134 | 0.240964 | 0.356569 | 0.634397 |
| Last observation | — | 0.130098 | 0.214602 | 0.374915 |
| Kalman (known nominal dynamics) | — | 0.110162 | 0.203985 | 0.366516 |

## Evidence files

- `results.json`, `extended/results.json`: raw outcomes; identical 288 test trajectories reused across experiments, not independent replication.
- `replay.json`: event-local update and checkpoint continuation for trained pilot seed 17.
- `profile_stream.json`: 7 timed single-thread CPU repetitions per configuration; batch size 1; one output per step; pilot checkpoints.
- `*.pt`: trained PyTorch model state dictionaries; optimizer states not saved.
- `run.log`, `extended/run.log`: training receipts.
- `SHA256SUMS.txt`: per-file SHA-256 manifest.

## Conclusion

The selective state mask materially helps this synthetic problem versus dense and recurrent neural controls. It does not establish novelty, real-world drone superiority, or efficiency at matched performance against Kalman filtering. Real logs, learned routing or a fair typed-routing control, uncertainty quantification, tuned state-space/GRU baselines, embedded profiling, and vehicle-level split validation are required.
