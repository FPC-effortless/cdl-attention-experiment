"""Single-stream Python/PyTorch microbenchmark; not embedded latency or energy."""
import time,json,torch,numpy as np,platform
from experiment import Bank,GRU,data,N,H,P
from replay import step

def dense_step(m,h,age,x):
    age=age+1;mask=x[:N]>0;age[mask]=0
    z=torch.cat([x[None,:].expand(N,-1),m.ids],-1);g,u=m.enc(z).chunk(2,-1);g=g.sigmoid();u=u.tanh();h=(1-g)*h+g*u
    return h,age,m.head(torch.cat([h.flatten(),torch.log1p(age)/5]))
def gru_step(m,h,age,x):
    age=age+1;mask=x[:N]>0;age[mask]=0
    out,h=m.rnn(x.reshape(1,1,-1),h);y=m.head(torch.cat([out.reshape(-1),torch.log1p(age)/5]));return h,age,y

def run():
    torch.set_num_threads(1);torch.set_num_interop_threads(1);models={'COG sparse':(Bank(True),step,torch.zeros(N,H),'COG-inspired_masked_bank_17.pt'),'Dense bank':(Bank(False),dense_step,torch.zeros(N,H),'Dense_bank_ablation_17.pt'),'GRU parameter-near':(GRU(19),gru_step,torch.zeros(1,1,19),'GRU_parameter-near_17.pt'),'GRU state-matched':(GRU(N*H),gru_step,torch.zeros(1,1,N*H),'GRU_state-matched_17.pt')}
    for m,fn,h,file in models.values():m.load_state_dict(torch.load(P/file,weights_only=True));m.eval()
    results={'environment':{'torch':torch.__version__,'cpu':platform.processor(),'threads':1,'batch_size':1,'steps':512,'repetitions':7},'measurements':{}}
    for regime,rate in [('nominal',.75),('sparse',.15)]:
        x=data(30055,1,512,rate)[0][0];xs=list(x.unbind());samples={name:[] for name in models}
        with torch.inference_mode():
            for repeat in range(8):
                for name in np.roll(list(models),repeat%4):
                    m,fn,h0,_=models[name];h=h0.clone();age=torch.full((N,),64.);start=time.perf_counter_ns()
                    for xx in xs:h,age,out=fn(m,h,age,xx)
                    us=(time.perf_counter_ns()-start)/1000/len(xs)
                    if repeat:samples[name].append(us)
        results['measurements'][regime]={n:{'median_us_per_step':float(np.median(v)),'samples_us_per_step':v} for n,v in samples.items()}
    (P/'profile_stream.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
if __name__=='__main__':run()
