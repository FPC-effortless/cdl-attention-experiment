"""Check a genuinely event-local inference implementation and snapshot recovery.
Uses trained pilot seed 17; no new training or model selection."""
import json,time,io
import torch,numpy as np
from experiment import Bank,data,N,H,P

def step(model,h,age,x):
    age=age+1
    ids=torch.where(x[:N]>0)[0]
    if len(ids):
        i=int(ids[0]);age[i]=0
        g,u=model.enc(torch.cat([x,model.ids[i]])).chunk(2,-1);g=g.sigmoid();u=u.tanh();h[i]=(1-g)*h[i]+g*u
    return h,age,model.head(torch.cat([h.flatten(),torch.log1p(age)/5]))

def run():
    torch.set_num_threads(1);m=Bank(True);m.load_state_dict(torch.load(P/'COG-inspired_masked_bank_17.pt',weights_only=True));m.eval();results={}
    with torch.no_grad():
        for label,rate in [('nominal',.75),('sparse',.15)]:
            x,a,y=data(19007,1,512,rate);h=torch.zeros(N,H);age=torch.full((N,),64.);normal=[];restored=[];changed=0;holds=0;violations=0
            for j,xx in enumerate(x[0]):
                before=h.clone();h,age,out=step(m,h,age,xx);normal.append(out.clone());mask=~xx[:N].bool();holds+=int(mask.sum())*H;violations+=int((h[mask]!=before[mask]).sum());changed+=int(xx[-1]);
                if j==255:
                    buf=io.BytesIO();torch.save({'h':h.clone(),'age':age.clone()},buf);buf.seek(0);snap=torch.load(buf,weights_only=True)
            h,age=snap['h'],snap['age'];
            for xx in x[0,256:]:h,age,out=step(m,h,age,xx);restored.append(out.clone())
            normal=torch.stack(normal);restored=torch.stack(restored);ref=m(x,a)[0];results[label]={'event_count':changed,'total_steps':512,'slot_writes_fraction':changed/(512*N),'hidden_hold_scalar_checks':holds,'hold_violations':violations,'max_abs_difference_batch_vs_sparse':float((normal-ref).abs().max()),'restored_bit_exact':bool(torch.equal(normal[256:],restored)),'restored_steps':256,'state_float32_bytes':(N*H+N)*4,'actual_serialized_snapshot_bytes':len(buf.getvalue())}
    (P/'replay.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
if __name__=='__main__':run()
