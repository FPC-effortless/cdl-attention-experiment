# CASM v0 — Compression-Attention Small Model

CASM is a small causal language model trained from scratch to test one specific hypothesis:

> A model can learn to route information using a cheap score trained to predict **future description-length reduction**.

It combines exact local GQA with compressed chunk memory and recurrent persistent state. During training, each memory candidate receives a self-supervised target equal to how much it reduces the negative log-likelihood of upcoming bytes. The runtime router learns to predict that gain without seeing the future.

## v0 architecture

- raw-byte vocabulary (no pretrained tokenizer)
- RMSNorm + RoPE + GQA + SwiGLU local backbone
- fixed-size low-rank chunk memory
- two recurrent persistent-state slots
- compression-attention router
- multi-token prediction auxiliary heads
- verified-continuation contrastive head
- weight tying

The first benchmark compares three identically initialized models:

1. local-only backbone;
2. Q/K memory routing without compression supervision;
3. compression-attention memory routing.

Synthetic multi-task training covers associative recall, state tracking, arithmetic, rule induction, graph reachability, and reversal, with harder out-of-distribution variants at evaluation.
