import torch

from casm.data import VOCAB_SIZE, make_batch
from casm.model import CASM, CASMConfig


def tiny_cfg():
    return CASMConfig(
        vocab_size=VOCAB_SIZE,
        d_model=64,
        n_layers=2,
        n_heads=4,
        n_kv_heads=1,
        d_ff=128,
        chunk_size=16,
        memory_slots=4,
        state_slots=2,
        memory_dim=32,
        mtp_horizons=2,
        compression_future_tokens=3,
    )


def test_forward_backward_finite():
    torch.manual_seed(1)
    model = CASM(tiny_cfg())
    x, _ = make_batch(3, 65, 10)
    out = model(x)
    assert out["logits"].shape == (3, 64, VOCAB_SIZE)
    assert torch.isfinite(out["loss"])
    out["loss"].backward()
    grads = [p.grad for p in model.parameters() if p.requires_grad and p.grad is not None]
    assert grads
    assert all(torch.isfinite(g).all() for g in grads)


def test_compression_router_receives_gradient():
    torch.manual_seed(2)
    model = CASM(tiny_cfg())
    x, _ = make_batch(4, 65, 11)
    out = model(x)
    out["loss"].backward()
    grad = model.router.score_mlp[0].weight.grad
    assert grad is not None
    assert grad.abs().sum() > 0


def test_parameter_count_small():
    model = CASM(tiny_cfg())
    assert model.parameter_count() < 2_000_000
