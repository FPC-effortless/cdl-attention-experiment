from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class CASMConfig:
    vocab_size: int = 260
    d_model: int = 192
    n_layers: int = 6
    n_heads: int = 6
    n_kv_heads: int = 2
    d_ff: int = 512
    chunk_size: int = 32
    memory_slots: int = 8
    state_slots: int = 2
    memory_dim: int = 96
    dropout: float = 0.0
    rope_base: float = 10000.0
    mtp_horizons: int = 3
    compression_future_tokens: int = 16
    compression_temperature: float = 0.5
    compression_loss_weight: float = 0.15
    compression_predictor_loss_weight: float = 0.10
    mtp_loss_weight: float = 0.15
    verifier_loss_weight: float = 0.10
    use_compression_score: bool = True
    use_memory: bool = True

    @property
    def head_dim(self) -> int:
        assert self.d_model % self.n_heads == 0
        return self.d_model // self.n_heads


class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        dtype = x.dtype
        x_float = x.float()
        scale = torch.rsqrt(x_float.pow(2).mean(dim=-1, keepdim=True) + self.eps)
        return (x_float * scale).to(dtype) * self.weight


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    x1 = x[..., ::2]
    x2 = x[..., 1::2]
    return torch.stack((-x2, x1), dim=-1).flatten(-2)


class RotaryEmbedding(nn.Module):
    def __init__(self, dim: int, base: float = 10000.0):
        super().__init__()
        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer("inv_freq", inv_freq, persistent=False)

    def forward(self, seq_len: int, device: torch.device, dtype: torch.dtype) -> Tuple[torch.Tensor, torch.Tensor]:
        t = torch.arange(seq_len, device=device, dtype=self.inv_freq.dtype)
        freqs = torch.outer(t, self.inv_freq.to(device))
        emb = torch.repeat_interleave(freqs, 2, dim=-1)
        return emb.cos().to(dtype), emb.sin().to(dtype)


def apply_rope(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
    # x: [B,H,T,D], cos/sin: [T,D]
    cos = cos[None, None, :, :]
    sin = sin[None, None, :, :]
    return x * cos + rotate_half(x) * sin


class LocalGQAAttention(nn.Module):
    def __init__(self, cfg: CASMConfig):
        super().__init__()
        assert cfg.n_heads % cfg.n_kv_heads == 0
        self.cfg = cfg
        self.q_proj = nn.Linear(cfg.d_model, cfg.n_heads * cfg.head_dim, bias=False)
        self.k_proj = nn.Linear(cfg.d_model, cfg.n_kv_heads * cfg.head_dim, bias=False)
        self.v_proj = nn.Linear(cfg.d_model, cfg.n_kv_heads * cfg.head_dim, bias=False)
        self.o_proj = nn.Linear(cfg.n_heads * cfg.head_dim, cfg.d_model, bias=False)
        self.rope = RotaryEmbedding(cfg.head_dim, cfg.rope_base)
        self.dropout = cfg.dropout

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, t, _ = x.shape
        q = self.q_proj(x).view(b, t, self.cfg.n_heads, self.cfg.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(b, t, self.cfg.n_kv_heads, self.cfg.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(b, t, self.cfg.n_kv_heads, self.cfg.head_dim).transpose(1, 2)
        cos, sin = self.rope(t, x.device, q.dtype)
        q = apply_rope(q, cos, sin)
        k = apply_rope(k, cos, sin)
        repeat = self.cfg.n_heads // self.cfg.n_kv_heads
        k = k.repeat_interleave(repeat, dim=1)
        v = v.repeat_interleave(repeat, dim=1)
        # Chunk processing means full causal attention here is already local/linear in total sequence length.
        out = F.scaled_dot_product_attention(q, k, v, is_causal=True, dropout_p=self.dropout if self.training else 0.0)
        out = out.transpose(1, 2).contiguous().view(b, t, self.cfg.d_model)
        return self.o_proj(out)


class SwiGLU(nn.Module):
    def __init__(self, cfg: CASMConfig):
        super().__init__()
        self.gate = nn.Linear(cfg.d_model, cfg.d_ff, bias=False)
        self.up = nn.Linear(cfg.d_model, cfg.d_ff, bias=False)
        self.down = nn.Linear(cfg.d_ff, cfg.d_model, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.down(F.silu(self.gate(x)) * self.up(x))


class Block(nn.Module):
    def __init__(self, cfg: CASMConfig):
        super().__init__()
        self.attn_norm = RMSNorm(cfg.d_model)
        self.attn = LocalGQAAttention(cfg)
        self.ffn_norm = RMSNorm(cfg.d_model)
        self.ffn = SwiGLU(cfg)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.attn_norm(x))
        x = x + self.ffn(self.ffn_norm(x))
        return x


class CompressionRouter(nn.Module):
    """Cheap inference-time router trained to predict future code-length reduction."""

    def __init__(self, cfg: CASMConfig):
        super().__init__()
        d = cfg.memory_dim
        self.q = nn.Linear(cfg.d_model, d, bias=False)
        self.k = nn.Linear(d, d, bias=False)
        self.score_mlp = nn.Sequential(
            nn.Linear(4 * d, d),
            nn.SiLU(),
            nn.Linear(d, 1, bias=False),
        )
        self.value = nn.Linear(d, cfg.d_model, bias=False)
        self.base_future = nn.Linear(cfg.d_model, cfg.compression_future_tokens * cfg.vocab_size, bias=False)
        self.cond_future = nn.Linear(cfg.d_model + d, cfg.compression_future_tokens * cfg.vocab_size, bias=False)
        self.cfg = cfg

    def scores(self, query: torch.Tensor, memory: torch.Tensor) -> torch.Tensor:
        # query [B,D] or [B,T,D], memory [B,M,Dmem]
        q = F.normalize(self.q(query), dim=-1)
        k = F.normalize(self.k(memory), dim=-1)
        if q.ndim == 2:
            dot = torch.einsum("bd,bmd->bm", q, k)
            if not self.cfg.use_compression_score:
                return dot
            qe = q[:, None, :].expand_as(k)
            feat = torch.cat([qe, k, qe * k, (qe - k).abs()], dim=-1)
        else:
            dot = torch.einsum("btd,bmd->btm", q, k)
            if not self.cfg.use_compression_score:
                return dot
            qe = q[:, :, None, :].expand(-1, -1, k.shape[1], -1)
            ke = k[:, None, :, :].expand(-1, q.shape[1], -1, -1)
            feat = torch.cat([qe, ke, qe * ke, (qe - ke).abs()], dim=-1)
        c = self.score_mlp(feat).squeeze(-1)
        return dot + c

    def retrieve(self, query: torch.Tensor, memory: torch.Tensor, valid_mask: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        scores = self.scores(query, memory)
        if scores.ndim == 2:
            mask = valid_mask
            weights = F.softmax(scores.masked_fill(~mask, -1e9), dim=-1)
            retrieved_mem = torch.einsum("bm,bmd->bd", weights, memory)
        else:
            mask = valid_mask[:, None, :].expand_as(scores)
            weights = F.softmax(scores.masked_fill(~mask, -1e9), dim=-1)
            retrieved_mem = torch.einsum("btm,bmd->btd", weights, memory)
        return self.value(retrieved_mem), scores

    def compression_target(
        self,
        query: torch.Tensor,
        memory: torch.Tensor,
        future_tokens: torch.Tensor,
        valid_mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Return target distribution, raw gain, and predictor loss in nats/token.

        Target = how much each candidate reduces NLL of observed future tokens versus query-only prediction.
        Gradients do not pass through the target computation.
        """
        b, m, d = memory.shape
        k = min(self.cfg.compression_future_tokens, future_tokens.shape[1])
        if k <= 0:
            z = torch.zeros((b, m), device=query.device, dtype=query.dtype)
            return F.softmax(z, dim=-1), z, z.mean()
        fut = future_tokens[:, :k]
        token_mask = (fut != 256).to(query.dtype)
        denom = token_mask.sum(dim=-1).clamp_min(1.0)
        base_logits = self.base_future(query).view(b, self.cfg.compression_future_tokens, self.cfg.vocab_size)[:, :k]
        base_tok_nll = F.cross_entropy(base_logits.transpose(1, 2), fut, reduction="none", ignore_index=256)
        base_nll = (base_tok_nll * token_mask).sum(dim=-1) / denom

        qe = query[:, None, :].expand(b, m, query.shape[-1])
        cond_in = torch.cat([qe, memory], dim=-1)
        cond_logits = self.cond_future(cond_in).view(b, m, self.cfg.compression_future_tokens, self.cfg.vocab_size)[:, :, :k]
        targets = fut[:, None, :].expand(b, m, k)
        cond_tok_nll = F.cross_entropy(
            cond_logits.reshape(b * m * k, self.cfg.vocab_size),
            targets.reshape(-1),
            reduction="none",
            ignore_index=256,
        ).view(b, m, k)
        cond_nll = (cond_tok_nll * token_mask[:, None, :]).sum(dim=-1) / denom[:, None]
        gain = base_nll[:, None] - cond_nll
        gain = gain.masked_fill(~valid_mask, -1e9)
        target = F.softmax(gain.detach() / self.cfg.compression_temperature, dim=-1)
        valid_float = valid_mask.to(cond_nll.dtype)
        cond_pred_loss = (cond_nll * valid_float).sum() / valid_float.sum().clamp_min(1.0)
        predictor_loss = base_nll.mean() + cond_pred_loss
        return target, gain, predictor_loss


class PersistentState(nn.Module):
    def __init__(self, cfg: CASMConfig):
        super().__init__()
        self.cfg = cfg
        self.proposals = nn.ModuleList([nn.Linear(cfg.d_model, cfg.memory_dim) for _ in range(cfg.state_slots)])
        self.gates = nn.ModuleList([nn.Linear(cfg.d_model + cfg.memory_dim, cfg.memory_dim) for _ in range(cfg.state_slots)])

    def update(self, state: torch.Tensor, summary: torch.Tensor) -> torch.Tensor:
        outs = []
        for i in range(self.cfg.state_slots):
            prev = state[:, i]
            proposal = torch.tanh(self.proposals[i](summary))
            gate = torch.sigmoid(self.gates[i](torch.cat([summary, prev], dim=-1)))
            outs.append(gate * prev + (1.0 - gate) * proposal)
        return torch.stack(outs, dim=1)


class CASM(nn.Module):
    """Compression-Attention Small Model.

    Streaming causal LM with exact local chunks, compressed chunk memory, persistent recurrent state,
    and a learned router supervised by future description-length reduction.
    """

    def __init__(self, cfg: CASMConfig):
        super().__init__()
        self.cfg = cfg
        self.embed = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.memory_in = nn.Linear(cfg.d_model, cfg.memory_dim, bias=False)
        self.memory_context = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
        self.blocks = nn.ModuleList([Block(cfg) for _ in range(cfg.n_layers)])
        self.norm = RMSNorm(cfg.d_model)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.lm_head.weight = self.embed.weight
        self.router = CompressionRouter(cfg)
        self.state = PersistentState(cfg)
        self.memory_gate = nn.Linear(2 * cfg.d_model, cfg.d_model)
        self.memory_ffn_norm = RMSNorm(cfg.d_model)
        self.memory_ffn = SwiGLU(cfg)
        self.mtp_heads = nn.ModuleList([nn.Linear(cfg.d_model, cfg.vocab_size, bias=False) for _ in range(cfg.mtp_horizons - 1)])
        self.verify = nn.Sequential(
            nn.Linear(2 * cfg.d_model, cfg.d_model),
            nn.SiLU(),
            nn.Linear(cfg.d_model, 1),
        )
        self.apply(self._init_weights)
        # Start memory as an optional residual path; it must earn influence.
        nn.init.zeros_(self.memory_gate.weight)
        nn.init.constant_(self.memory_gate.bias, -2.0)
        # Compression-specific correction starts at zero, so the model begins as ordinary Q/K memory.
        nn.init.normal_(self.router.score_mlp[-1].weight, mean=0.0, std=1e-4)

    @staticmethod
    def _init_weights(module: nn.Module) -> None:
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def parameter_count(self) -> int:
        return sum(p.numel() for p in self.parameters())

    def _init_memory(self, batch: int, device: torch.device, dtype: torch.dtype) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        ring = torch.zeros(batch, self.cfg.memory_slots, self.cfg.memory_dim, device=device, dtype=dtype)
        ring_valid = torch.zeros(batch, self.cfg.memory_slots, device=device, dtype=torch.bool)
        state = torch.zeros(batch, self.cfg.state_slots, self.cfg.memory_dim, device=device, dtype=dtype)
        return ring, ring_valid, state

    def _candidates(self, ring: torch.Tensor, valid: torch.Tensor, state: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        state_valid = torch.ones(state.shape[:2], device=state.device, dtype=torch.bool)
        return torch.cat([state, ring], dim=1), torch.cat([state_valid, valid], dim=1)

    def forward(
        self,
        tokens: torch.Tensor,
        return_aux: bool = True,
        external_teacher: Optional[torch.Tensor] = None,
        teacher_alpha: float = 0.0,
    ) -> Dict[str, torch.Tensor]:
        # tokens [B,T], targets are tokens shifted by one.
        b, t = tokens.shape
        if t < 2:
            raise ValueError("Need at least two tokens")
        x_in = tokens[:, :-1]
        targets = tokens[:, 1:]
        total_len = x_in.shape[1]
        ring, ring_valid, state = self._init_memory(b, tokens.device, self.embed.weight.dtype)

        logits_chunks: List[torch.Tensor] = []
        target_chunks: List[torch.Tensor] = []
        compression_losses: List[torch.Tensor] = []
        compression_predictor_losses: List[torch.Tensor] = []
        mtp_losses: List[torch.Tensor] = []
        verifier_losses: List[torch.Tensor] = []
        router_entropies: List[torch.Tensor] = []
        gain_means: List[torch.Tensor] = []

        for chunk_idx, start in enumerate(range(0, total_len, self.cfg.chunk_size)):
            end = min(start + self.cfg.chunk_size, total_len)
            ids = x_in[:, start:end]
            y = targets[:, start:end]
            h = self.embed(ids)
            for block in self.blocks:
                h = block(h)
            h = self.norm(h)
            past_candidates, past_valid = self._candidates(ring, ring_valid, state)
            if self.cfg.use_memory:
                retrieved, token_scores = self.router.retrieve(h, past_candidates, past_valid)
                gate = torch.sigmoid(self.memory_gate(torch.cat([h, retrieved], dim=-1)))
                h = h + gate * retrieved
                h = h + self.memory_ffn(self.memory_ffn_norm(h))
            logits = self.lm_head(h)
            logits_chunks.append(logits)
            target_chunks.append(y)

            # Multi-token prediction auxiliary.
            if return_aux and self.cfg.mtp_horizons > 1:
                for horizon, head in enumerate(self.mtp_heads, start=2):
                    valid_len = h.shape[1] - (horizon - 1)
                    if valid_len > 0:
                        pred = head(h[:, :valid_len])
                        tgt_start = start + horizon
                        tgt_end = min(start + h.shape[1] + 1, tokens.shape[1])
                        tgt = tokens[:, tgt_start:tgt_end]
                        if tgt.shape[1] == valid_len and (tgt != 256).any():
                            mtp_losses.append(F.cross_entropy(pred.transpose(1, 2), tgt, ignore_index=256))

            valid_tok = (ids != 256)
            last_idx = valid_tok.long().sum(dim=1).clamp_min(1) - 1
            summary = h[torch.arange(b, device=h.device), last_idx]

            # Write the just-observed chunk before deciding what should explain/predict the next chunk.
            state = self.state.update(state, summary)
            new_mem = torch.tanh(self.memory_in(summary))
            ring = torch.cat([ring[:, 1:], new_mem[:, None, :]], dim=1)
            ring_valid = torch.cat([ring_valid[:, 1:], torch.ones(b, 1, device=tokens.device, dtype=torch.bool)], dim=1)
            candidates, cand_valid = self._candidates(ring, ring_valid, state)

            # Chunk-summary score is used only for compression supervision/diagnostics.
            if self.cfg.use_memory:
                scores = self.router.scores(summary, candidates)
                weights = F.softmax(scores.masked_fill(~cand_valid, -1e9), dim=-1)
                router_entropies.append((-(weights * (weights.clamp_min(1e-8).log())).sum(dim=-1)).mean())
            else:
                scores = torch.zeros(b, candidates.shape[1], device=tokens.device)

            # Compression supervision: which state/memory actually reduces code length of upcoming bytes?
            future_start = end
            future_end = min(future_start + self.cfg.compression_future_tokens, tokens.shape[1])
            need_compression_aux = (
                self.cfg.compression_loss_weight > 0.0
                or self.cfg.compression_predictor_loss_weight > 0.0
                or (external_teacher is not None and teacher_alpha > 0.0)
            )
            if return_aux and self.cfg.use_memory and need_compression_aux and future_end > future_start:
                future = tokens[:, future_start:future_end]
                target_dist, gain, predictor_loss = self.router.compression_target(summary, candidates, future, cand_valid)
                if external_teacher is not None and teacher_alpha > 0.0 and chunk_idx < external_teacher.shape[1]:
                    ext = external_teacher[:, chunk_idx, :].to(target_dist.device, target_dist.dtype)
                    # External compressor only supervises candidate ranking; neural predictive utility takes over gradually.
                    target_dist = teacher_alpha * ext + (1.0 - teacher_alpha) * target_dist
                    target_dist = target_dist / target_dist.sum(dim=-1, keepdim=True).clamp_min(1e-8)
                pred_log = F.log_softmax(scores.masked_fill(~cand_valid, -1e9), dim=-1)
                compression_losses.append(-(target_dist * pred_log).sum(dim=-1).mean())
                compression_predictor_losses.append(predictor_loss)
                finite_gain = gain.masked_fill(~cand_valid, 0.0)
                gain_means.append(finite_gain.sum() / cand_valid.sum().clamp_min(1))

            # Verified-continuation auxiliary: distinguish true next chunk from a batch-permuted continuation.
            if return_aux and end < total_len:
                nxt_end = min(end + self.cfg.chunk_size, total_len)
                next_ids = x_in[:, end:nxt_end]
                if next_ids.shape[1] > 0:
                    next_emb = self.embed(next_ids).mean(dim=1)
                    pos = self.verify(torch.cat([summary, next_emb], dim=-1)).squeeze(-1)
                    if b > 1:
                        perm = torch.roll(next_emb, shifts=1, dims=0)
                        neg = self.verify(torch.cat([summary, perm], dim=-1)).squeeze(-1)
                        verifier_losses.append(
                            0.5 * (F.binary_cross_entropy_with_logits(pos, torch.ones_like(pos)) +
                                   F.binary_cross_entropy_with_logits(neg, torch.zeros_like(neg)))
                        )

        logits_all = torch.cat(logits_chunks, dim=1)
        targets_all = torch.cat(target_chunks, dim=1)
        lm_loss = F.cross_entropy(logits_all.transpose(1, 2), targets_all, ignore_index=256)

        zero = lm_loss.new_zeros(())
        compression_loss = torch.stack(compression_losses).mean() if compression_losses else zero
        compression_predictor_loss = torch.stack(compression_predictor_losses).mean() if compression_predictor_losses else zero
        mtp_loss = torch.stack(mtp_losses).mean() if mtp_losses else zero
        verifier_loss = torch.stack(verifier_losses).mean() if verifier_losses else zero
        total = (lm_loss + self.cfg.compression_loss_weight * compression_loss
                 + self.cfg.compression_predictor_loss_weight * compression_predictor_loss
                 + self.cfg.mtp_loss_weight * mtp_loss
                 + self.cfg.verifier_loss_weight * verifier_loss)

        return {
            "loss": total,
            "lm_loss": lm_loss,
            "compression_loss": compression_loss,
            "compression_predictor_loss": compression_predictor_loss,
            "mtp_loss": mtp_loss,
            "verifier_loss": verifier_loss,
            "router_entropy": torch.stack(router_entropies).mean() if router_entropies else zero,
            "mean_compression_gain": torch.stack(gain_means).mean() if gain_means else zero,
            "logits": logits_all,
        }
