# CSM-GRAPH-001 — Mathematical model, parallel execution, and Lean verification

Date: 2026-11-09

## Result and interpretation

The current CSM record-rewrite backbone now has a complete parameterized model of its ordinary hard-forward state transition and sequence execution, an explicit computation graph, Lean proofs of its structural properties, and an executable parallel scheduling bridge. The formal sources compile with Lean 4.19.0. The separate runtime evidence checks the frozen PyTorch implementation and preserves observed failures.

The main architectural finding is that this system has useful independent branches inside a token step, and independent examples can run concurrently. A single stream still has a recurrent dependency: the next controller reads the record value produced by the previous step. We have not established an efficient parallel scan over an entire token sequence.

The fork/join bridge matches the original forward computation in the tested cases and matches its supplied surrogate gradients within the declared tolerance. It is slower than the scripted serial inference control in all four measured CPU workloads. A separate serial training control fails gradient-presence equivalence: it sometimes materializes zero gradients where the original has `None`. That failure remains in the raw evidence.

This is a verified structural specification with empirical implementation checks. It is not a proof of the whole PyTorch runtime, an architecture novelty result, a learning-convergence result, or evidence of improved model quality.

## 1. What constitutes the system

There are two different graphs. The **stored record graph** is data: records contain values and pointers to other records. It may contain cycles and self-links. The **computation graph** describes which operations require the results of other operations. Its finite time-unrolling must respect causal order. A cyclic pointer structure does not require a cyclic computation graph.

Let the number of records be S, feature width d, number of operation embeddings O, hidden transformation width h, and vocabulary size V. Assume S and O are positive. The mathematical state before token t is

\[
M_t=(V_t,\ell_t,c_t,h^-_t,h_t,n_t).
\]

Here the use of V with a subscript denotes the value store; the unsubscripted V in dimension formulas denotes vocabulary size.

| State component | Mathematical type | Meaning |
|---|---|---|
| Value store \(V_t\) | \(\operatorname{Fin}(S)\to\mathbb R^d\) | The vector in each record |
| Link store \(\ell_t\) | \(\operatorname{Fin}(S)\to\operatorname{Fin}(S)\) | One outgoing pointer per record |
| Cursor \(c_t\) | \(\operatorname{Fin}(S)\) | The active record |
| Older and recent history \(h^-_t,h_t\) | Two vectors in \(\mathbb R^d\) | The previous two token embeddings |
| Position \(n_t\) | Natural number | The stream position |

`Fin S` is an address together with a proof that it is smaller than S. A typed pointer therefore cannot name an out-of-range record. This is a property of the formal representation, not a claim that arbitrary external tensors are already well formed.

The intended initialization is zero record values, identity links, cursor zero, zero history, and position zero. `initialState` makes this explicit, while also allowing other mathematical initializations. Learned parameters remain fixed during a forward sequence. An optimizer step belongs to an outer training iteration and is not part of the token transition.

The scope is the ordinary transition in `experiments/csm_foundation_001/model.py`. All diagnostic interventions—reset, corruption, `links_off`, and `constant_operator`—and free-running token sampling are excluded. The three ordinary modes, `rewrite`, `ring_write`, and `no_links`, are included.

## 2. Complete hard-forward equations

Write \(H_\tau(z)\) for deterministic categorical selection from \(\operatorname{softmax}(z/\tau)\), with the implementation's tie convention. For finite logits and positive temperature this gives a valid address or categorical choice. Each named affine map below includes its learned bias.

### Input and controller

\[
e_t=E(x_t),\qquad
f_t=\tanh F[h^-_t,h_t,e_t],
\]

\[
u_t=\tanh C[f_t,V_t(c_t)].
\]

The controller receives both local token history and the active record. The active read can proceed while the input/frontend branch is being evaluated.

### First read and dependent second read

\[
i_t=H_\tau(A_1u_t),\qquad a_t=V_t(i_t),
\]

\[
j_t^{\mathrm{direct}}=H_\tau(A_2[u_t,a_t]),\qquad
j_t^{\mathrm{link}}=\ell_t(i_t).
\]

Let \(b_t^{\mathrm{link}}\) be the binary use-link decision. Then

\[
j_t=
\begin{cases}
j_t^{\mathrm{direct}}, & \text{in no-links mode},\\
j_t^{\mathrm{link}}, & b_t^{\mathrm{link}}=1,\\
j_t^{\mathrm{direct}}, & \text{otherwise},
\end{cases}
\qquad b_t=V_t(j_t).
\]

The direct second-address head depends on the first retrieved **value**. Consequently, the two address decisions are not independent heads. The seven controller-only heads described below exclude this dependent second-address head.

### Operation and proposed value

\[
k_t=H_\tau(Ku_t),\qquad o_t=\Omega(k_t),
\]

\[
z_t=\tanh T_2\!\left(\tanh T_1[f_t,a_t,b_t,o_t]\right).
\]

The operation embedding conditions one shared transformation. These equations do not establish that different operation labels learn distinct symbolic algorithms.

### Destination and gated rewrite

\[
d_t=
\begin{cases}
n_t\bmod S,&\text{in ring-write mode},\\
H_\tau(Du_t),&\text{otherwise}.
\end{cases}
\]

Let \(\epsilon_t\in\{0,1\}\) be the value-edit decision and let \(\eta_t=\sigma(Gu_t)\). The value written to the destination is

\[
w_t=V_t(d_t)+\epsilon_t\eta_t\big(z_t-V_t(d_t)\big).
\]

In the abstract exact-value model, a disabled edit returns the previous value. This conditional interpretation requires care when relating it to unrestricted IEEE floating-point arithmetic; Section 8 gives concrete counterexamples.

### Commit and output

\[
V_{t+1}=V_t[d_t\mapsto w_t],
\]

\[
\ell_{t+1}=
\begin{cases}
\ell_t[d_t\mapsto j_t],&\text{if link editing is enabled},\\
\ell_t,&\text{otherwise},
\end{cases}
\]

\[
c_{t+1}=d_t,\quad h^-_{t+1}=h_t,\quad h_{t+1}=e_t,\quad
n_{t+1}=n_t+1,\quad y_t=Yw_t.
\]

No-links mode disables link traversal, but the frozen source still computes link updates. The specification preserves that behavior.

These equations define a complete transition

\[
F_\theta:(M_t,x_t)\longmapsto(M_{t+1},y_t).
\]

The Lean implementation parameterizes the affine/nonlinear kernels as pure functions. It proves properties of their composition for all such functions. It does not implement or prove real-number tanh, sigmoid, softmax, BLAS arithmetic, or the mapping from those functions to FP32 instructions.

## 3. The computation graph and a parallel schedule

`CSM/Graph.lean` names 36 computation blocks. Rewrite and ring-write have 69 within-step edges; no-links has 67. It exports all nodes, dependencies, levels, variants, and the five state-field recurrence edges to `graph.json`. The transform block groups both transformation layers. A level is a legal dependency schedule, not a kernel count or a hardware latency.

The following is an overview, not a replacement for the full graph:

```mermaid
flowchart TD
    I["Token and local history"] --> F["Frontend"]
    M["Current record state"] --> A["Active record read"]
    F --> C["Controller"]
    A --> C
    C --> H["Independent routing and edit heads"]
    H --> R["First read and dependent second read"]
    M --> R
    H --> O["Operation embedding"]
    H --> W["Destination read and write gate"]
    M --> W
    F --> T["Value transformation"]
    R --> T
    O --> T
    T --> U["Updated value"]
    W --> U
    U --> Y["Output projection"]
    U --> S["Value commit"]
    R --> L["Link commit"]
    H --> L
```

The full graph separately represents cursor, history, and position updates. Its time-unrolling carries each state field independently rather than forcing every next-step input through an unnecessary whole-state barrier.

A legal schedule exposes these opportunities:

1. Run the active-record read alongside the input/frontend work.
2. Once the controller is available, compute first address, destination, operation, use-link, value-edit, write-strength, and link-edit heads independently.
3. Overlap first-value read, linked-address read, previous-destination read, and operation embedding where their parents are ready.
4. Compute the direct second address only after the first value arrives. Select and read the second value before the transformation consumes it.
5. Commit the new pointer row once its destination, address, and edit flag are ready; it does not need the value proposal.
6. Once the updated value is available, run the vocabulary projection and value-bank commit independently.

Pure functions matter here: none of these ready branches may silently mutate another branch's inputs. The runtime bridge returns fresh states and preserves the original dense operation shapes.

### The sequential dependency that remains

The full-state model proves

\[
\boxed{V_{t+1}(c_{t+1})=w_t.}
\]

Therefore the following chain is part of this computation graph:

\[
w_t\ \longrightarrow\ \text{next active read}\ \longrightarrow\ u_{t+1}\
\longrightarrow\ w_{t+1}.
\]

It remains even when consecutive destination addresses differ. A token's controller can respond to the value created by its predecessor. The specified unrolled graph has a dependency chain whose length grows with sequence length. This is a statement about this graph, not a lower-bound proof ruling out every possible alternative algorithm or special parameter setting.

Input embeddings and local three-token frontends can be precomputed across a sequence when the input tokens are already known, as in teacher forcing. Independent examples can be batched because they share parameters but retain separate recurrent state. Neither observation eliminates the controller/update chain within one stream. Associativity of arbitrary function composition alone also does not provide an efficient scan: that would require a compact representation of composed transitions and a cheap composition operation.

## 4. What parallel processing power means mathematically

Let W denote total primitive work and D the longest dependency chain, also called span. In an ideal model with P processors,

\[
T_P\geq\max(W/P,D).
\]

The work/span scheduling result supplies an upper bound of the form \(T_P\leq W/P+D\) for an ideal greedy schedule under the relevant unit-cost assumptions. It does not remove communication, memory-bandwidth, allocation, launch, or synchronization overhead. The available average parallelism is \(W/D\). This framework is described in Blelloch's work-depth discussion [3]. These general scheduling bounds are explanatory analysis, not theorems newly verified by this Lean project.

If dense scalar reductions use parallel trees, unlimited processors and concurrent reads, and scalar nonlinearities are treated as constant-cost primitives, a token step has an upper span bound of the form

\[
D_{\mathrm{step}}=O(\log d+\log S+\log O+\log h).
\]

The number of serial stages remains significant. Vocabulary projection outputs are independent once their input is available; a training loss that reduces over vocabulary adds its own reduction cost. The current temporal graph has a chain of at least order T for T tokens, and the straightforward sequence schedule has an upper span bound \(O(TD_{\mathrm{step}})\). These are ideal cost-model statements, not CPU or GPU timing predictions.

### Exact counts under a declared convention

The dense implementation executes full tensor reads and full masks despite its hard choices. It does not receive sparse execution merely by choosing one record.

Counting one nominal multiply-accumulate term per dense scalar-product term gives

\[
W_{\mathrm{MAC}}=5d^2+8Sd+2Od+5dh+dV+S^2+7d.
\]

This counts affine products, four dense value reads, one dense pointer-row read, and operation-embedding multiplication. It excludes biases, nonlinearities, categorical selection, interpolation, masks, allocation, memory traffic, backward computation, and optimizer work. A MAC is not one total FLOP or an elapsed-time unit.

The retained floating-state size per example is

\[
M_{\mathrm{scalars}}=Sd+S^2+S+2d.
\]

All allocated parameter scalars, including heads inactive under an ablation, total

\[
P_\theta=2Vd+V+5d^2+4Sd+3S+2Od+O+5dh+h+10d+7.
\]

`CSM/Cost.lean` proves the algebra from the listed component sums to these formulas, and the numerical specializations below. The transcription from Python components was reviewed and parameter/state totals were checked against instantiated models.

| Configuration | Dense MAC terms per token/example | Allocated parameters | Retained FP32 state |
|---|---:|---:|---:|
| S=8, d=32, O=4, h=64, V=20 | 18,592 | 18,359 | 1,568 bytes |
| S=8, d=32, O=4, h=64, V=257 | 26,176 | 33,764 | 1,568 bytes |

The 1,568 bytes cover 392 floating-state scalars. They exclude the position integer, parameters, outputs, autograd activations, gradients, optimizer state, allocator overhead, and process memory. In particular, bounded recurrent state does not mean constant training memory with respect to sequence length.

An indexed implementation could store links as S integers instead of an S-by-S one-hot matrix. Address scoring would still cost order Sd for the existing dense heads. Local write cost would also depend on ownership and copying policy. No indexed or fused implementation is claimed here.

## 5. Safe simultaneous record edits

Record edits are represented with a destination, a read footprint, a proposal function, and a proof that the proposal depends only on that footprint. The routes are fixed at this stage. Parallel proposals are computed from one frozen snapshot.

For two edits A and B, sufficient conflict conditions are

\[
W_A\cap W_B=\varnothing,\qquad
W_A\cap R_B=\varnothing,\qquad
W_B\cap R_A=\varnothing.
\]

Under the formal dependence contract, Lean proves both serial orders equal the snapshot-based commit. It also proves a list version with an induction invariant: after each commit, the current store still agrees with the original snapshot on every remaining proposal's read footprint.

Different destinations alone do not suffice. Starting from records (0,1), let A copy record 1 to record 0, and B copy record 0 to record 1. Simultaneous snapshot proposals produce (1,0); A then B produces (1,1); B then A produces (0,0). The module contains checked write/write and read/write counterexamples.

These theorems concern record edits. Complete CSM token steps also share the cursor, history, position, controller-dependent routes, and output semantics. We have not proved that such full steps commute. A future design with several edits per token needs an explicit conflict-resolution rule and one defined global-state update; it would be an architectural change.

## 6. What Lean checked

The final audit uses Lean 4.19.0 with `--trust=0`. It freshly compiles every project module, audits the axiom dependencies of every project theorem in the compiled environment, exports the graph, and checks that deliberately false arithmetic and a backwards rank inequality are rejected.

There are **76 explicitly written theorem declarations** and **273 audited theorem constants including generated declarations**. Dependencies are limited to the standard Lean foundations `propext`, `Quot.sound`, and `Classical.choice`. There are no admitted project proofs, introduced logical axioms, or native-evaluation proof oracles. The audit records compiler-generated unsafe runtime lambda placeholders separately; they are not admitted proof dependencies. Lean's documentation explains why kernel checking and axiom inspection both matter [1,2].

| Formal module | Main guarantee |
|---|---|
| `CSM/Model.lean` | Complete abstract step; parallel-plan/step/sequence equivalence; frame properties; cursor/write identity; history and position updates; causal prefixes; batch noninterference; typed links |
| `CSM/Graph.lean` | Strict rank increase; no directed cycles; independent controller heads; acyclic time-unrolled and reversed graphs |
| `CSM/Parallel.lean` | Safe record-edit commutativity; snapshot equivalence; safe-batch theorem; conflict counterexamples |
| `CSM/Training.lean` | Separate forward and supplied-pullback contracts; compositional reverse rules; permitted independent accumulation; counterexample to inferring gradient equality from forward equality |
| `CSM/Cost.lean` | Component sums, closed formulas, and concrete parameter/state/MAC arithmetic |

The strongest whole-sequence scheduling statement is `parallelRun_eq_run`: every output and the final abstract state are equal for every finite token list, initial state, mode, and set of pure kernels. This is universal within the stated model; it is not limited to a sample of input sequences.

Graph acyclicity is a different statement. The graph is manually specified, and removing a necessary edge could preserve acyclicity. The current edge list was independently reviewed against both the abstract transition and frozen Python source. A machine-checked extraction/refinement theorem connecting those representations remains open.

### Toolchain adaptation and trust boundary

The official Linux distribution's launcher tries to discover its own executable through `/proc/<pid>/exe`. This environment's process IDs and proc namespace do not agree, so the unmodified launcher fails before elaboration. The small C launcher in `tooling/lean_explicit_path.c` supplies the already known executable path for that one request and otherwise delegates ordinary filesystem operations to libc. It reads no alternative proc entry and changes no permissions or environment access controls.

The actual entry point remains the official distribution's `lean_main`; its shared proof kernel is unchanged. This is therefore a documented runtime adaptation, not an unmodified-launcher claim. The receipt records the distribution URL, archive and toolchain hashes, launcher source/binary hashes, commands, outputs, source hashes, and negative controls. Standard environments can use the ordinary Lean executable without the adaptation. An independent checker was not run.

## 7. Training graph and surrogate gradients

The actual categorical primitive uses

\[
p(z)=\operatorname{softmax}(z/\tau),\qquad
\widehat h(z)=\operatorname{onehot}(\arg\max p(z))+
p(z)-\operatorname{stopgrad}(p(z)).
\]

Its forward output is hard. Its supplied backward rule uses the softmax Jacobian

\[
J_p(z)=\frac{\operatorname{diag}(p)-pp^\top}{\tau}.
\]

This is not the ordinary derivative of the discrete argmax map, which is locally constant away from ties. Straight-through estimators are a family of heuristic gradient estimators [4]. Our task is to specify the chosen forward and backward rules separately and check schedule preservation of that specified program. We do not infer unbiasedness or convergence from the rule.

For a read \(r=\sum_i q_i V_i\), the derivative supplied to an address component involves its candidate value \(V_i\). A hard forward read of one record does not mean that the soft address backward rule only needs that record. Skipping unselected branches can preserve inference yet change training.

The reversed graph proves an available dependency order; it does not validate each local vector-Jacobian product. The generic `Training.lean` contracts are not a complete formal derivation of PyTorch autograd for CSM. Runtime gradient comparisons provide separate evidence.

## 8. Concrete implementation checks and limits

### Forward and state parity

The runtime bridge uses actual TorchScript `fork`/`wait` execution in the pinned PyTorch 2.5.1 CPU environment. Its scripted step has six fork and six wait nodes. A profiler trace records overlapping ATen operator intervals on five runtime threads: four workers and the caller. This is evidence of concurrency, not proof of simultaneous physical CPU execution or of a speedup.

Nine model cases were checked: three random modes plus both frozen tasks' seed-11 checkpoints in all three modes. Five shapes per case were checked, through batch 32 and length 64. At unchanged shapes, logits, states, and route/gate traces matched exactly by the verifier's tensor comparison. Input states and weights were unchanged, outputs were fresh, and causal-prefix and batch checks passed. Splitting a batch into individual runs introduced ordinary FP32 differences up to approximately 2.384e-6 within the declared tolerance. These are finite tests, not a universal implementation proof or raw-bit equality claim.

### Surrogate backward parity

The fork/join target passed all 27 multi-step gradient trials: 756 parameter-gradient and 108 initial-state-gradient comparisons. `None` was compared strictly with `None`. The largest absolute difference was 1.7881393432617188e-7 under the criterion `atol=2e-6 + rtol=2e-5` relative to the reference. Objectives included outputs alone and outputs plus final state. The initial states were structurally valid with bounded nonzero values; they were not all claimed to be reachable training histories.

The additional scripted serial control failed gradient-presence equivalence in 42 comparisons. It materialized exact zero tensors for unused heads where eager execution returned `None`. The combined raw backward report remains **FAIL**, while the requested fork/join target is **PASS** on its comparisons. PyTorch documents that optimizers can treat zero gradients and absent gradients differently [5]. No optimizer step was run, and the serial control is not certified as a drop-in training replacement.

### Measured CPU timing

The benchmark used the frozen byte-LM rewrite checkpoint, FP32 CPU execution, one intra-operation thread, four inter-operation workers, three warmups, and 20 rotating-interleaved repetitions per method. These are warmed inference measurements on this environment, not GPU measurements or an exhaustive performance study.

| Batch | Tokens | Scripted serial median | Fork/join median | Serial time / parallel time |
|---:|---:|---:|---:|---:|
| 1 | 32 | 5.678 ms | 16.004 ms | 0.355 |
| 1 | 64 | 12.138 ms | 29.821 ms | 0.407 |
| 16 | 32 | 9.090 ms | 18.635 ms | 0.488 |
| 32 | 64 | 24.735 ms | 38.442 ms | 0.643 |

A ratio above one would indicate a speedup. Every observed ratio is below one. The results are consistent with scheduling and synchronization overhead outweighing the available work at this small scale; the benchmark does not isolate overhead as a causal explanation. More processors do not by themselves improve the current implementation. TorchScript is deprecated in current PyTorch documentation [6], so this bridge is a pinned verification experiment, not a production-platform recommendation.

### Numerical refinement boundary

Three small CPU FP32 examples were preserved in `NUMERIC_BOUNDARY_VERIFICATION.json`:

| Mathematical shortcut | Counterexample in unrestricted dense arithmetic |
|---|---|
| One-hot selection reads only the selected value | An unselected NaN contaminates a dense `bmm` result |
| Disabled value edit is an identity | A NaN proposal still produces NaN through multiplication by zero |
| An unselected record is unchanged bit for bit | Masked arithmetic changes a stored negative zero to positive zero |

Consequently, the Fin/function-store specification needs a valid representation relation, appropriate nonfinite-intermediate exclusions, and a stated notion of equality before it can be used as a theorem about IEEE tensors. Merely assuming finite input values does not exclude overflow in intermediates. The bridge retains the original dense arithmetic, which is why its empirical parity claim is distinct from a sparse mathematical-refinement claim.

## 9. What this establishes for an architecture foundation

The system now has a precise unit of computation: a learned controller selects records and an operation-conditioned transformation, then commits a value, optional pointer, and global cursor/history updates. The cost of each mechanism and the dependencies that restrict scheduling are explicit.

This supports three concrete engineering conclusions. Within-step scheduling can be changed while preserving the specified computation. Independent batch items can run concurrently. Several fixed-route record edits can share a snapshot when the proved conflict conditions hold. It does not establish unrestricted token-level parallelism, nor does it resolve the earlier learning failures of the prototype.

For a future foundation built around greater graph parallelism, the next design decision is whether one clock tick contains multiple proposed edits. That design must specify proposal footprints, arbitration for conflicting writes, link consistency, one cursor/history update policy, and how gradients flow through arbitration. The safe-edit theorems provide reusable obligations for that work, but that multi-edit architecture has not been implemented here.

The next formal integration obligation is a typed computational-graph representation from which both executable semantics and dependency edges are generated, followed by a refinement theorem to the tensor implementation. That would strengthen the current manually reviewed correspondence. Real-number kernel contracts, IEEE behavior, compiler/runtime correctness, optimizer behavior, learning efficacy, and novelty remain separate obligations rather than consequences of graph acyclicity.

## 10. Reproduction and evidence map

From `formal/csm_graph_001`, with Lean 4.19.0 on PATH:

```bash
python verify_lean.py
```

`lake build` can also compile the formal library, but the Python verifier additionally performs the full axiom audit, graph export, and negative controls. For the specific process-path incompatibility, see `README.md` for building and invoking the disclosed launcher.

Using the experiment's pinned PyTorch environment, first preserve the delivered
runtime evidence in a separate directory as shown in `README.md`; these scripts
deliberately refuse to overwrite prior results. Then run:

```bash
python verify_runtime_bridge.py
python verify_surrogate_backward.py
python diagnose_surrogate_unused.py
python verify_numeric_boundary.py
```

The backward verifier deliberately returns failure while the documented serial-control discrepancy remains. It must not be presented as an all-green suite. No new model fitting or optimizer updates were performed.

| Evidence | Contents |
|---|---|
| `LEAN_VERIFICATION.json` | Version, hashes, explicit theorem count, complete audit count, axiom set, negative controls |
| `verification/axioms.log` | Every audited theorem dependency |
| `verification/build_runs.json` | Actual Lean commands, return codes, timings, and messages |
| `graph.json` | Complete exported graph and mode-specific edges |
| `RUNTIME_VERIFICATION.json` | Forward checks, exact/tolerated differences, state integrity, raw timings, profiler evidence |
| `runtime_parallel_trace.json` | Browser-compatible profiler trace |
| `SURROGATE_BACKWARD_VERIFICATION.json` | Every gradient comparison, including the failing serial control |
| `SURROGATE_UNUSED_GRADIENT_DIAGNOSTIC.json` | The 42 exact-zero-versus-None cases |
| `NUMERIC_BOUNDARY_VERIFICATION.json` | Concrete floating-point refinement counterexamples |
| `REVIEW.md` | Independent semantic review and scope boundaries |
| `PARALLELISM.md` | Detailed runtime schedule, work/span reasoning, and benchmark protocol |

The frozen prototype, data, manifests, and checkpoints were not changed. The work is kept on an isolated local research branch; no remote publication or merge was performed.

## References

1. Lean reference, *Validating a Lean Proof*: https://lean-lang.org/doc/reference/latest/ValidatingProofs/
2. Lean reference, *Axioms*: https://lean-lang.org/doc/reference/latest/Axioms/
3. Guy E. Blelloch, *Programming Parallel Algorithms*, work-depth section, Communications of the ACM 39(3), 1996: https://www.cs.cmu.edu/~scandal/cacm/node3.html
4. Bengio, Léonard, and Courville, *Estimating or Propagating Gradients Through Stochastic Neurons for Conditional Computation*, 2013: https://arxiv.org/abs/1308.3432
5. PyTorch, `Optimizer.zero_grad`, zero versus absent gradient behavior: https://docs.pytorch.org/docs/main/generated/torch.optim.Optimizer.zero_grad.html
6. PyTorch tutorial, TorchScript parallelism/deprecation notice: https://docs.pytorch.org/tutorials/advanced/torch-script-parallelism.html

External references explain established tools and concepts. All CSM-specific counts, proof claims, conformance results, and timings are supported by the accompanying source and local evidence, not inferred from those references.
