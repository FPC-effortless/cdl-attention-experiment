# CSM-GRAPH-001 review package

Read CSM-GRAPH-001-mathematical-model.md first. The full Lean project, graph,
runtime bridge, proof audit, raw timings, gradient comparisons and counterexamples
are in csm-foundation/formal/csm_graph_001. Its README.md gives exact reproduction
commands and documents the optional environment-specific Lean launcher.

The repository snapshot is self-contained for this formal task's checks after
installing Lean 4.19.0 and the recorded PyTorch requirements. Six seed-11 model
checkpoints and receipts are included for the runtime comparisons. No fitting is
needed. The frozen source, data and earlier experimental conclusions were not
changed. Additional model weights from earlier experiments are outside this ZIP.

Distinct verdicts must be preserved: Lean passes; the requested fork/join target
passes its forward and surrogate-gradient checks; fork/join is slower in all four
CPU workloads; the extra scripted serial training control fails None-versus-zero
gradient equivalence, and its combined report intentionally remains FAIL.

DELIVERY_MANIFEST.json records every snapshot file hash and the source commit.
The included Git bundle is incremental from c26ff92b8ecec74045bd2393cdaf956c99a0d9d5.
It can be fetched into an existing repository containing that base. The snapshot
can be used without Git or a remote connection. No remote publication occurred.
