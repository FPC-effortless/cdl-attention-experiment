# Prospective review record

Date: 2026-11-09. These are independent agent reviews, not external peer review. No registered training fit or neural TEST scoring had occurred when the findings below were resolved.

## Mechanism review

The foundation-design reviewer inspected the model and ran seed-49001 random-input checks (batch2, length9, vocabulary31). It found no blocking mechanism defect. Train/eval hard-forward equality, one-hot pointers, bounded values, unchanged unselected records, fixed ring destinations, finite surrogate gradients, expected inactive heads, and exact no-links ablation identity passed.

The reviewer identified two necessary qualifications: pointers name current mutable slots rather than historical occurrence identity; there is only one untyped outgoing pointer per slot. Broad reset/permutation tests are state-sensitivity probes. These qualifications are present in the protocol. Exact value and link no-op paths were included before fitting.

## Data review and corrections

An independent raw-token interpreter verified all5,376 answer labels, separately from the generator's interpreter. Generator checks cover disjoint histories/canonical histories/families, omitted COPY→SUB order in training, ordered subtraction, persistence after source overwrite,64 distinct-answer counterfactual quartets, and128 irrelevant-update pairs.

The reviewer found a counterfactual confound: destination/source aliasing was present only in that panel. Before fitting, its subtraction was changed to three distinct registers. Focal answer frequencies and shortcut baselines were added because ordered-subtraction validation excludes two possible focal values. The final data source hash is recorded in the freeze manifest.

## Baseline and runner review

The architecture-comparison reviewer verified GRU and Transformer causality, full/cached parity including window eviction and state reset, finite gradients, parameter formulas and logical state counts. The largest observed Transformer full/cached logit discrepancy was3.5763e-7 in FP32; GRU was exact.

Source inspection found three runner issues, all repaired before fitting:

1. The language evaluator now scores the final partial block and asserts every next-byte target after the first byte is counted exactly once.
2. A closure artifact validates all30 fit identities and freezes their checkpoint/log/receipt hashes before TEST scoring; training is prohibited after closure.
3. Full-sequence Transformer forward is no longer called cache-producing prefill. Actual incremental state timing and measured-length state bytes are reported separately.

The reviewer confirmed final-token padding indices, query-reset boundaries, complete-world and focal-quartet grouping, identical exposure schedules, supervision boundaries, and final-checkpoint policy. No remaining scoring or fitting blocker was identified. Root added an explicit ID alignment assertion for irrelevant-update pairs and included the corpus provenance file in frozen hashes.

## Scientific review

The foundation-design reviewer accepted this as a finite exploratory pilot with prospective all-seed competency screens, conditional on the repairs and final hashes. It did not approve effectiveness, novelty, convergence, or superiority claims. It asked for observed-token timing terminology, fixed measurement order, logical-state memory terminology and prominent optimization/budget limitations; the protocol includes these.

The standalone `verification.py` preserves reproducible checks. Engineering integrity is distinct from scientific qualification. No optional tuning or extra arm is required before this registered pilot.
