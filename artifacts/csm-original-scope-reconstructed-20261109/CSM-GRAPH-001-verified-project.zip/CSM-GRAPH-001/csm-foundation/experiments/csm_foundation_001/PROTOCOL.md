# CSM-FOUNDATION-001 — prospective bounded pilot

Status at registration: implementation and synthetic-data checks only. No registered fit or neural TEST scoring has occurred. The name Compositional State Model (CSM) is provisional and does not establish architectural novelty.

## Question and falsifier

Can a small complete backbone, learning only from input tokens and answer/next-token labels, use persistent addressed records and local graph edits to execute simple stateful operations? Do explicit links or learned write destinations earn a benefit relative to corresponding ablations? Does the same backbone support ordinary autoregressive byte prediction?

The proposed core is neither a Transformer block nor a linear/selective SSM block. It is nevertheless a nonlinear recurrent machine, closely related to slot-based neural production systems and learned graph rewriting. This pilot cannot establish a new architecture family, competitive large-model scaling, or superior sparse access.

The hypothesis is not supported if the registered competency gates fail, if the links-disabled arm matches or exceeds the full arm, or if a conventional control gives a stronger result within this exposure budget. A failed pilot remains useful evidence about this exact implementation and budget; it is not a proof that all related designs fail.

## Complete model

Input is a token ID. A learned embedding and three-token causal frontend produce a local input vector. The persistent state contains eight mutable 32-dimensional records, one untyped outgoing slot pointer per record, an active slot cursor, and two previous input embeddings.

At each token the controller reads the active record, chooses a first slot, chooses a second slot directly or by following the first record's pointer, selects one of four learned operation embeddings, and proposes a transformed value from the ordered reads and local input. It chooses a destination slot, whether to edit its value, an interpolation strength, and whether to set its outgoing pointer to the second selected slot. The new active cursor is the destination. Output logits come from the resulting destination value. Other value records remain exactly unchanged in the hard forward computation.

Pointers identify current mutable slots, not immutable historical occurrences. Overwriting a slot changes what any existing pointer to it observes. Values and pointers have exact hard no-op choices; the cursor can still move. There is one rewrite per input token, a fixed eight-record capacity, and no allocation, typed relation inventory, multi-edge graph, adaptive computation depth, external retrieval, or semantic parser.

Categorical decisions use deterministic argmax in the forward pass and a softmax straight-through surrogate derivative at temperature1. The derivative is biased. Hard decisions are identical in training and inference for equal input/parameters. No Gumbel noise or soft evaluation is used. Both training and evaluation execute dense selection/masking tensors: hard routes do not imply sparse memory traffic. Dense one-hot link storage costs64FP32 values. Total recurrent tensor state is392FP32 elements (1,568bytes) per example, plus a Python position integer. This excludes weights, activations, autograd history, temporary tensors, allocator overhead, and process RSS.

## Arms and controls

1. **rewrite:** complete proposed record machine.
2. **ring_write:** the same machine with destination fixed to token position modulo8. This tests learned write destination selection; it is a cyclic rewriting control, not append-only memory. The unused destination head remains allocated and is reported separately from active parameters.
3. **no_links:** the same machine forced to choose the second record through the direct address head. Pointer values cannot influence outputs; inactive link heads remain allocated and are disclosed.
4. **gru:** conventional GRUCell with the same embedding, local three-token frontend, projection and vocabulary output dimensions. Hidden width is chosen analytically for the nearest parameter count. State capacity is not matched.
5. **transformer:** conventional two-layer, four-head, width32 causal Transformer. Feedforward width is chosen for the nearest parameter count. It has sinusoidal positions and a128-token attention window, covering all synthetic histories. Its real KV cache is counted separately. It has no supplied semantic state.

The three record arms initialize from identical parameter tensors within each seed. All arms receive identical frozen minibatch IDs/byte offsets within each task and seed. Parameter matching, exposure matching, persistent-state size, and wall time are distinct quantities; no equal-FLOPs claim is made.

## Controlled execution assay

Vocabulary:20 supplied word-level tokens, including four register names and eight values. Programs initialize all registers, then perform SET, COPY or ordered SUB modulo8. The serialized query ends in `ask register ?`; the model predicts the value before seeing the answer token. Each query starts fresh from its history, so earlier gold answers cannot leak into later queries.

Only input token IDs enter the model. Answers supervise full-vocabulary cross-entropy at the final query position. Padding has no answer loss and logits are gathered at actual lengths. The model never receives the generator's operation labels, integer register identities, addresses, supports, symbolic state, or intermediate outputs. The finite grammar and tokenizer are supplied; this is an answer-focused diagnostic, not ordinary language-model training.

Dataset seed1701;512 training families,64 development families,128 IID families,128 composition families,128 correction families,128 long-history families,64 counterfactual families. Ordinary families have four independently serialized questions. Counterfactual families have four variants and four questions per variant. Complete family, exact history, and register-renaming-canonicalized history overlap across panels is prohibited and checked. Final-state overlap is allowed and disclosed: the state space has only4,096 states.

Training/development/IID exclude every adjacent COPY→SUB order. The composition panel requires a held-out adjacent dependent COPY→SUB order. Its focal subtraction is ordered and chosen so operand reversal changes the answer. Longer indirect compositions can still occur in training. Correction requires a copied value to persist after the source changes. Long histories append16 SETs to registers other than the focal target. Counterfactual quartets vary a causally relevant initial value and have four distinct focal answers. SUB uses distinct destinations and operands in both training and counterfactuals, avoiding an extra aliasing shift.

Generator validation uses an explicitly privileged symbolic interpreter. Report train-fitted query-only and most-frequent-value controls, last explicit value, answer frequencies, and focal frequencies/controls. The composition restriction excludes focal values0 and4; do not compare that panel to a blanket12.5% chance figure.

### Registered competency screens

All three initialization seeds must satisfy each requirement:

- IID answer accuracy≥95%.
- Composition **focal** answer accuracy≥90%.
- Correction **focal** answer accuracy≥90%.
- Counterfactual **complete focal quartet** accuracy≥90%.

Whole-world exactness (all four independently issued queries correct) and answer NLL accompany these screens. Long-history accuracy is descriptive, with no post hoc threshold. Compare focal predictions before and after the16 irrelevant writes: report both correct, each accuracy, and unchanged-prediction rate. Unchanged but wrong answers do not demonstrate retention.

These are prospective engineering screens, not population confidence guarantees. Three seeds are reported individually and as ranges/means. No architecture superiority is claimed without competent behavior and evidence of the proposed mechanism's contribution. Ties with ablations cannot establish that mechanism.

### Frozen-model interventions

On the fixed first32 IID families (128 queries): erase all recurrent/KV/frontend history just before the query. For record arms also disable link traversal, force operation0, cyclically permute record values without moving pointers, and zero each of the eight record slots in separate probes at the query boundary. Each condition uses the same frozen weights and examples. Report ordinary-subset performance alongside each probe.

Erasure, permutation and slot zeroing can be out of distribution. These are state-sensitivity probes, not proof of semantic roles, meaningful graphs or causal decomposition. Links-off applied to no_links is an exact negative-control identity. Disabling the operation selector does not remove the entire learned MLP.

## Ordinary byte-language smoke

Pinned TinyShakespeare from `karpathy/char-rnn` commit`6f9487a6fe5b420b7ca9afb0d7c078e37c1d1b4e`, SHA256`86c4e6aa9db7c042ec79f339dcb96d42b0075e16b8fc2e86bf0ca57e2dc565ed`. Corpus1,115,394bytes; half-open train/dev/test boundaries0:1,003,854:1,059,624:1,115,394. Source and license observations are in `corpus_manifest.json`.

Byte value+1 is the token ID;0 is reserved padding;257 output classes. Every prediction position receives ordinary causal next-token CE. Training samples64-byte contexts from the training partition only. Evaluation uses non-overlapping64-byte blocks plus the shorter final block within each held-out partition, fresh state per block, and reports actual scored bytes plus mean bits per byte. Every target after the partition's first byte is scored exactly once. Context resets are identical across arms. This small test demonstrates trainability and relative quality at the specified budget, not long-context language competence.

## Fixed budget, selection and receipts

Initialization seeds11,23,37. Five arms × three seeds × two tasks =30 fits. Batch16; answer assay512 optimizer updates (8,192 answer labels per fit); byte LM256 updates (262,144 byte targets per fit). AdamW lr0.002, betas(0.9,0.999), epsilon1e-8, weight decay0.01, global gradient clipping1.0. No scheduler, curriculum, early stopping or checkpoint selection. Final registered update is authoritative. The same simple optimizer configuration across architectures is not a guarantee that all are optimally tuned.

CPU only, FP32, one PyTorch thread per fit; up to three independent workers. Random-token timing profiling used six discarded steps before the hard no-op head was added; it did not score any benchmark model. Budget chosen for a small auditable local experiment, not by held-out outcome. Train all30 fits before opening neural TEST scoring. Data/label validation before fitting is allowed and logged separately from model evaluation.

Freeze source hashes, dataset hashes, schedule hashes, configuration, corpus provenance, environment and parameter specifications before any fit. Each fit records its source commit, update-by-update losses/timing/gradient norms, final model and optimizer, Python/NumPy/Torch RNG state, schedule hash and checkpoint SHA256. Save per-example answers/NLL, per-block language losses and raw latency samples. A training-closure artifact validates all30 registered receipt identities and freezes checkpoint/log/receipt hashes before any neural TEST evaluation. Evaluation revalidates that closure; training refuses to start after closure. Failed processes are preserved; any rerun must be disclosed and use the same registered configuration.

Measure full batch1 sequence forward computation including vocabulary projection, and actual recurrent/cached observed-token incremental execution, with30 timed full-sequence repetitions after three warmups. Fixture continuation tokens are supplied, so this is not free-running generation. Full-sequence Transformer forward does not return a retained KV cache; do not label it cached prefill. Streaming measurements separately use actual state and disclose its logical tensor bytes at the measured length, not peak RAM. Timing runs are sequential after training: structured task then byte LM; seeds11,23,37; arm order as in config, rotated left by two places per seed index. This fixed rotation reduces but does not eliminate wall-clock drift. Report raw measurements, input length and thread count. Training cost includes forward/backward/optimizer time, excluding setup and evaluation; three concurrent CPU workers may introduce contention, so fit durations are descriptive. A quality-gated score such as12ln(I/Iref)+ln(T/Tref) is not used when competency is unqualified; raw costs remain visible.

## Independent review and scope

Independent agents review model invariants, generator semantics, supervision boundaries, baseline parity, trainer and evaluator before fitting. Independent checkpoint replay follows fitting. A source or evaluation bug requires a documented correction and a prospective rerun if it changes learning or authoritative scoring; do not hide superseded evidence.

Deliver code, exact protocol, negative and positive results, reproduction commands, provenance, and a reviewable branch. No paid compute, main merge or deployment is included. An executable prototype is a completed engineering result; an effective new architectural foundation requires further evidence beyond this pilot.

## Primary related work

- Goyal et al., Neural Production Systems: https://arxiv.org/abs/2103.01937 — slots, rules and selected updates are close prior art.
- Machowczyk and Heckel, Graph Rewriting for Graph Neural Networks: https://arxiv.org/abs/2305.18632 — graph rewriting is an existing formalization and engineering direction for neural computation.
- Vaswani et al., Attention Is All You Need: https://arxiv.org/abs/1706.03762.
- Cho et al., Learning Phrase Representations using RNN Encoder–Decoder: https://arxiv.org/abs/1406.1078.

This is a scoped ancestry check, not an exhaustive novelty search.
