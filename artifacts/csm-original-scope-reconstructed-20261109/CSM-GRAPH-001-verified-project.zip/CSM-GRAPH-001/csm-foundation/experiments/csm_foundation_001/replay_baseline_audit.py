"""Independent post-fit scoring replay for Transformer seed 11.

Uses the frozen model implementation, but no trainer/evaluator/generator helpers.
Language scoring uses Python byte slices, different batches, FP64 log-softmax,
target gathering, and FP64 accumulation. Structured questions run individually.
No fitting, checkpoint selection, or latency benchmarking occurs.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time

import torch

from baselines import TransformerConfig, TransformerLM


ROOT = Path(__file__).resolve().parent
ARM, SEED = "transformer", 11
REPLAY_BATCH, IID_EXAMPLES = 17, 128
TOLERANCES = {
    "test_bits_per_byte_absolute": 1e-6,
    "block_sum_nll_absolute": 1e-4,
    "structured_example_nll_absolute": 1e-5,
    "saved_metric_arithmetic_absolute": 1e-12,
    "forward_cached_logit_absolute": 1e-5,
}


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def check(report, name, passed, observed=None, expected=None, fatal=False):
    report["checks"].append({"name": name, "passed": bool(passed),
                             "observed": observed, "expected": expected})
    if fatal and not passed:
        raise RuntimeError(name)


def equal(report, name, observed, expected, fatal=False):
    check(report, name, observed == expected, observed, expected, fatal)


def close(report, name, observed, expected, tolerance):
    error = abs(observed - expected)
    check(report, name, math.isfinite(error) and error <= tolerance,
          {"absolute_error": error, "value": observed},
          {"value": expected, "maximum_absolute_error": tolerance})
    return error


def check_file(report, relative, expected):
    observed = sha(ROOT / relative)
    equal(report, f"SHA256 {relative}", observed, expected, fatal=True)
    return observed


def verify_registration(report):
    config = read_json(ROOT / "config.json")
    freeze = read_json(ROOT / "frozen_manifest.json")
    closure = read_json(ROOT / "training_closed.json")
    freeze_hash = sha(ROOT / "frozen_manifest.json")
    equal(report, "Closure freeze identity", closure["freeze_sha256"], freeze_hash, True)
    equal(report, "Frozen configuration", freeze["configuration"], config, True)
    cohort = {f"{task}/{arm}/{seed}" for task in ("structured", "lm")
              for arm in config["arms"] for seed in config["seeds"]}
    check(report, "All 30 fits in closure",
          set(closure["completed_fits"]) == cohort and len(cohort) == 30,
          len(closure["completed_fits"]), 30, True)
    check(report, "All 30 final evaluations exist",
          all((ROOT / "runs" / key / "evaluation.json").is_file() for key in cohort),
          expected=True, fatal=True)
    for name, expected in freeze["source_sha256"].items():
        check_file(report, name, expected)
    for name, expected in freeze["input_sha256"].items():
        check_file(report, name, expected)
    report["registration"] = {
        "freeze_sha256": freeze_hash,
        "training_closure_sha256": sha(ROOT / "training_closed.json"),
        "frozen_source_files_checked": len(freeze["source_sha256"]),
        "frozen_input_files_checked": len(freeze["input_sha256"]),
        "closure_fit_count": len(closure["completed_fits"]),
    }
    return config, freeze, closure


def load_checkpoint(task, report, config, freeze, closure):
    prefix = Path("runs") / task / ARM / str(SEED)
    closed = closure["completed_fits"][f"{task}/{ARM}/{SEED}"]
    for name, key in (("completed.json", "completed_sha256"),
                      ("checkpoint.pt", "checkpoint_sha256"),
                      ("updates.jsonl", "updates_sha256")):
        check_file(report, prefix / name, closed[key])
    receipt = read_json(ROOT / prefix / "completed.json")
    saved = read_json(ROOT / prefix / "evaluation.json")
    for field, expected in {
        "task": task, "arm": ARM, "seed": SEED,
        "updates": config[f"{task}_updates"],
        "checkpoint_sha256": closed["checkpoint_sha256"],
        "freeze_sha256": report["registration"]["freeze_sha256"],
    }.items():
        equal(report, f"{task} receipt {field}", receipt[field], expected, True)
    equal(report, f"{task} embedded evaluation receipt", saved["training"], receipt, True)
    equal(report, f"{task} evaluated checkpoint", saved["checkpoint_sha256"],
          closed["checkpoint_sha256"], True)
    specification = receipt["model"]
    equal(report, f"{task} registered model specification", specification,
          freeze["model_specifications"][task][ARM], True)
    checkpoint = torch.load(ROOT / prefix / "checkpoint.pt",
                            map_location="cpu", weights_only=False)
    equal(report, f"{task} final checkpoint update", checkpoint["update"],
          config[f"{task}_updates"], True)
    equal(report, f"{task} checkpoint frozen sources", checkpoint["source_sha256"],
          freeze["source_sha256"], True)
    dimensions = {name: specification[name] for name in
                  ("vocab_size", "width", "layers", "heads", "ff_width", "max_context")}
    model = TransformerLM(TransformerConfig(**dimensions))
    model.load_state_dict(checkpoint["model_state"], strict=True)
    model.eval()
    equal(report, f"{task} instantiated parameter count",
          sum(parameter.numel() for parameter in model.parameters()),
          specification["parameters"], True)
    report["checkpoints"][task] = {
        "checkpoint_sha256": closed["checkpoint_sha256"],
        "completed_sha256": closed["completed_sha256"],
        "updates_sha256": closed["updates_sha256"],
        "evaluation_sha256": sha(ROOT / prefix / "evaluation.json"),
        "model": specification,
    }
    return model, saved, ROOT / prefix


def tensor_bytes(value):
    if isinstance(value, torch.Tensor):
        return value.numel() * value.element_size()
    if isinstance(value, dict):
        return sum(tensor_bytes(item) for item in value.values())
    if isinstance(value, (tuple, list)):
        return sum(tensor_bytes(item) for item in value)
    return 0


@torch.inference_mode()
def replay_language(model, saved, directory, report, config):
    offsets = config["lm_split_offsets"]
    raw = (ROOT / "data" / "input.txt").read_bytes()[offsets[2]:offsets[3]]
    context = config["lm_context"]
    # A single range covers both full blocks and the shorter final block.
    blocks = [{"start": start, "tokens": min(context, len(raw) - start - 1)}
              for start in range(0, len(raw) - 1, context)]
    groups = defaultdict(list)
    for block in blocks:
        groups[block["tokens"]].append(block)
    replayed = {}
    for length, group in groups.items():
        for begin in range(0, len(group), REPLAY_BATCH):
            batch = group[begin:begin + REPLAY_BATCH]
            x = torch.tensor([
                [byte + 1 for byte in raw[row["start"]:row["start"] + length]]
                for row in batch], dtype=torch.long)
            targets = torch.tensor([
                [byte + 1 for byte in raw[row["start"] + 1:row["start"] + length + 1]]
                for row in batch], dtype=torch.long)
            log_probabilities = torch.log_softmax(model(x).to(torch.float64), dim=-1)
            losses = -log_probabilities.gather(-1, targets.unsqueeze(-1)).squeeze(-1)
            for row, total in zip(batch, losses.sum(dim=-1).tolist()):
                replayed[row["start"]] = {**row, "sum_nll_nats": total}
    ordered = [replayed[row["start"]] for row in blocks]
    original = read_json(directory / "loss_blocks.json")["test"]
    equal(report, "LM block start/count partition",
          [(row["start"], row["tokens"]) for row in ordered],
          [(row["start"], row["tokens"]) for row in original], True)
    targets = sum(row["tokens"] for row in ordered)
    equal(report, "LM complete next-byte coverage", targets, len(raw) - 1, True)
    equal(report, "LM saved scored-byte count", saved["test"]["scored_bytes"], targets, True)
    equal(report, "LM final partial-block targets", ordered[-1]["tokens"],
          (len(raw) - 1) % context or context, True)
    total = math.fsum(row["sum_nll_nats"] for row in ordered)
    saved_total = math.fsum(row["sum_nll_nats"] for row in original)
    replay_bpb = total / targets / math.log(2)
    arithmetic_error = close(
        report, "LM saved block arithmetic reproduces BPB",
        saved_total / targets / math.log(2), saved["test"]["bits_per_byte"],
        TOLERANCES["saved_metric_arithmetic_absolute"])
    bpb_error = close(report, "LM independent full-test BPB",
                      replay_bpb, saved["test"]["bits_per_byte"],
                      TOLERANCES["test_bits_per_byte_absolute"])
    comparisons = [{
        "start": new["start"], "tokens": new["tokens"],
        "saved_sum_nll_nats": old["sum_nll_nats"],
        "replayed_sum_nll_nats": new["sum_nll_nats"],
        "absolute_difference": abs(new["sum_nll_nats"] - old["sum_nll_nats"]),
    } for new, old in zip(ordered, original)]
    max_block_error = max(row["absolute_difference"] for row in comparisons)
    check(report, "LM every block sum within tolerance",
          max_block_error <= TOLERANCES["block_sum_nll_absolute"],
          max_block_error, TOLERANCES["block_sum_nll_absolute"])
    first_x = torch.tensor([[byte + 1 for byte in raw[:context]]], dtype=torch.long)
    full = model(first_x)
    state, streamed = model.init_state(1, "cpu"), []
    for token in first_x.unbind(1):
        logits, state = model.step(token, state)
        streamed.append(logits)
    cached_error = (torch.stack(streamed, 1) - full).abs().max().item()
    check(report, "LM trained full/cached logit parity",
          cached_error <= TOLERANCES["forward_cached_logit_absolute"],
          cached_error, TOLERANCES["forward_cached_logit_absolute"])
    retained = tensor_bytes(state)
    equal(report, "LM actual retained cache bytes", retained,
          saved["latency"]["retained_tensor_bytes_at_measured_length"])
    return {
        "test_partition_bytes": len(raw), "scored_next_byte_targets": targets,
        "full_blocks": sum(row["tokens"] == context for row in ordered),
        "total_blocks": len(ordered), "partial_tail_targets": ordered[-1]["tokens"],
        "context": context, "fresh_state_per_block": True,
        "replay_batch": REPLAY_BATCH, "saved_evaluation_batch": config["eval_batch_size"],
        "loss_computation": "FP64 log_softmax, target gather, FP64 sums and math.fsum",
        "saved_bits_per_byte": saved["test"]["bits_per_byte"],
        "replayed_bits_per_byte": replay_bpb,
        "bits_per_byte_absolute_difference": bpb_error,
        "saved_block_arithmetic_bpb_absolute_difference": arithmetic_error,
        "max_block_sum_nll_absolute_difference": max_block_error,
        "mean_block_sum_nll_absolute_difference":
            statistics.fmean(row["absolute_difference"] for row in comparisons),
        "cached_full_max_logit_absolute_difference": cached_error,
        "retained_tensor_bytes_at_64_tokens": retained,
        "loss_blocks_sha256": sha(directory / "loss_blocks.json"),
        "block_comparisons": comparisons,
    }


@torch.inference_mode()
def replay_structured(model, saved, directory, report):
    data_path = ROOT / "data" / "registers" / "iid.jsonl"
    with data_path.open() as handle:
        examples = [json.loads(line) for line in handle][:IID_EXAMPLES]
    ids = {example["id"] for example in examples}
    selected = {}
    with (directory / "predictions.jsonl").open() as handle:
        for line in handle:
            row = json.loads(line)
            if row["condition"] == "ordinary_subset" and row["panel"] == "iid" and row["id"] in ids:
                if row["id"] in selected:
                    raise RuntimeError("Duplicate saved IID-subset prediction")
                selected[row["id"]] = row
    check(report, "Structured saved subset IDs match",
          set(selected) == ids and len(ids) == IID_EXAMPLES,
          len(selected), IID_EXAMPLES, True)
    comparisons, worlds = [], defaultdict(list)
    for example in examples:
        original = selected[example["id"]]
        equal(report, f"Structured answer label {example['id']}",
              original["answer_id"], example["answer_id"], True)
        x = torch.tensor([example["input_ids"]], dtype=torch.long)
        logits = model(x)[0, -1]
        prediction = int(logits.argmax())
        nll = float(-torch.log_softmax(logits.double(), dim=-1)[example["answer_id"]])
        correct = prediction == example["answer_id"]
        worlds[example["metadata"]["world_id"]].append(correct)
        comparisons.append({
            "id": example["id"], "world_id": example["metadata"]["world_id"],
            "answer_id": example["answer_id"], "replayed_prediction_id": prediction,
            "saved_prediction_id": original["prediction_id"],
            "prediction_matches": prediction == original["prediction_id"],
            "replayed_nll_nats": nll, "saved_nll_nats": original["nll_nats"],
            "nll_absolute_difference": abs(nll - original["nll_nats"]), "correct": correct,
        })
    matches = sum(row["prediction_matches"] for row in comparisons)
    max_nll_error = max(row["nll_absolute_difference"] for row in comparisons)
    equal(report, "Structured every predicted token matches", matches, len(examples))
    check(report, "Structured every NLL within tolerance",
          max_nll_error <= TOLERANCES["structured_example_nll_absolute"],
          max_nll_error, TOLERANCES["structured_example_nll_absolute"])
    check(report, "Structured 32 complete four-query worlds",
          len(worlds) == 32 and all(len(rows) == 4 for rows in worlds.values()),
          len(worlds), 32)
    result_accuracy = statistics.fmean(row["correct"] for row in comparisons)
    result_world = statistics.fmean(all(rows) for rows in worlds.values())
    mean_nll = statistics.fmean(row["replayed_nll_nats"] for row in comparisons)
    original_metric = saved["interventions"]["ordinary_subset"]
    equal(report, "Structured subset answer accuracy", result_accuracy, original_metric["accuracy"])
    equal(report, "Structured subset whole-world accuracy",
          result_world, original_metric["complete_world_accuracy"])
    close(report, "Structured subset mean NLL", mean_nll,
          original_metric["answer_nll_nats"], TOLERANCES["structured_example_nll_absolute"])
    close(report, "Structured saved per-example NLL arithmetic",
          statistics.fmean(row["saved_nll_nats"] for row in comparisons),
          original_metric["answer_nll_nats"], TOLERANCES["saved_metric_arithmetic_absolute"])
    return {
        "scope": "first 128 IID examples, four questions from each of first 32 families",
        "individual_unpadded_forwards": True, "examples": len(examples),
        "worlds": len(worlds), "matching_prediction_ids": matches,
        "saved_accuracy": original_metric["accuracy"], "replayed_accuracy": result_accuracy,
        "saved_complete_world_accuracy": original_metric["complete_world_accuracy"],
        "replayed_complete_world_accuracy": result_world,
        "saved_mean_nll_nats": original_metric["answer_nll_nats"],
        "replayed_mean_nll_nats": mean_nll,
        "max_example_nll_absolute_difference": max_nll_error,
        "predictions_sha256": sha(directory / "predictions.jsonl"),
        "iid_data_sha256": sha(data_path), "example_comparisons": comparisons,
    }


def render_markdown(report):
    lines = [
        "# Post-fit baseline replay audit", "",
        f"**Status: {report['status']}**", "",
        f"Arm: {ARM}; initialization seed: {SEED}. LM and structured checkpoints "
        "are separately fitted models.", "",
        f"Checks passed: {sum(row['passed'] for row in report['checks'])}"
        f"/{len(report['checks'])}. No fitting or checkpoint selection occurred.", "",
    ]
    if "error" in report:
        lines += ["## Audit error", "", report["error"], ""]
    if "language" in report:
        r = report["language"]
        lines += [
            "## Full language test replay", "", "| Quantity | Result |", "|---|---:|",
            f"| Saved bits per byte | {r['saved_bits_per_byte']:.15g} |",
            f"| Replayed bits per byte | {r['replayed_bits_per_byte']:.15g} |",
            f"| Absolute BPB difference | {r['bits_per_byte_absolute_difference']:.12g} |",
            f"| Next-byte targets | {r['scored_next_byte_targets']:,} |",
            f"| Full 64-target blocks | {r['full_blocks']} |",
            f"| Final partial-block targets | {r['partial_tail_targets']} |",
            f"| Largest block-sum NLL difference | {r['max_block_sum_nll_absolute_difference']:.12g} |",
            f"| Saved block-arithmetic BPB difference | {r['saved_block_arithmetic_bpb_absolute_difference']:.12g} |",
            f"| Full/cached maximum logit difference | {r['cached_full_max_logit_absolute_difference']:.12g} |",
            f"| Retained tensor bytes at 64 tokens | {r['retained_tensor_bytes_at_64_tokens']:,} |",
            "",
            "The independent loop slices bytes directly, covers the tail with the "
            "same range as full blocks, resets per block, and uses batches of 17 "
            "instead of 128. It uses FP64 log-softmax and accumulation; the "
            "registered evaluator uses FP32 cross-entropy and block sums.", "",
        ]
    if "structured" in report:
        r = report["structured"]
        lines += [
            "## Structured IID subset replay", "", "| Quantity | Result |", "|---|---:|",
            f"| Query presentations / complete worlds | {r['examples']} / {r['worlds']} |",
            f"| Matching predicted token IDs | {r['matching_prediction_ids']} / {r['examples']} |",
            f"| Saved / replayed accuracy | {r['saved_accuracy']:.8f} / {r['replayed_accuracy']:.8f} |",
            f"| Saved / replayed world accuracy | {r['saved_complete_world_accuracy']:.8f} / {r['replayed_complete_world_accuracy']:.8f} |",
            f"| Saved / replayed mean NLL | {r['saved_mean_nll_nats']:.12g} / {r['replayed_mean_nll_nats']:.12g} |",
            f"| Largest per-example NLL difference | {r['max_example_nll_absolute_difference']:.12g} |",
            "",
            "Each of the first 128 IID questions runs individually without padding. "
            "These are all four questions from the first 32 families and match the "
            "saved ordinary-subset control.", "",
        ]
    lines += ["## Integrity and tolerances", ""]
    if "registration" in report:
        r = report["registration"]
        lines += [
            f"Frozen manifest SHA256: {r['freeze_sha256']}.", "",
            f"All {r['frozen_source_files_checked']} frozen source files and "
            f"{r['frozen_input_files_checked']} frozen input files match. The two "
            "replayed checkpoints, update logs and completion receipts match the "
            "training closure. Model dimensions and final update counts match the "
            "registered specifications.", "",
        ]
    lines.extend(f"- {task} checkpoint SHA256: {value['checkpoint_sha256']}."
                 for task, value in report["checkpoints"].items())
    lines += ["", "Tolerances were specified in the script before replay:", ""]
    lines.extend(f"- {key}: {value}." for key, value in TOLERANCES.items())
    lines += [
        "", "## Limits", "",
        "This audit shares the frozen Transformer implementation and fitted weights. "
        "It independently checks slicing, scoring, reductions, saved predictions "
        "and metric arithmetic; it does not independently reimplement the model, "
        "retrain it, audit all arms/seeds, or reproduce latency. Structured coverage "
        "is limited to this IID subset. Reproducibility within this scope does not "
        "establish competence, novelty or superiority.", "",
        "The JSON companion preserves every check, all language-block comparisons, "
        "all structured-example comparisons and artifact hashes.", "",
        "## Reproduction", "",
        "Run python replay_baseline_audit.py in the recorded PyTorch environment. "
        "The script refuses to overwrite an existing audit; move previous audit "
        "artifacts aside before deliberately replaying again.", "",
    ]
    return "\n".join(lines)


def main():
    outputs = [ROOT / "POSTFIT_AUDIT_BASELINE.json", ROOT / "POSTFIT_AUDIT_BASELINE.md"]
    if any(path.exists() for path in outputs):
        raise FileExistsError("Existing audit artifacts will not be overwritten")
    report = {
        "schema_version": 1, "status": "RUNNING", "arm": ARM, "seed": SEED,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "audit_script_sha256": sha(Path(__file__)),
        "source_git_head": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "environment": {"python": platform.python_version(), "torch": torch.__version__,
                        "device": "cpu", "threads": 1},
        "tolerances": TOLERANCES, "checks": [], "checkpoints": {}, "optimizer_steps": 0,
    }
    begin = time.perf_counter()
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.manual_seed(91711)
    try:
        config, freeze, closure = verify_registration(report)
        model, saved, directory = load_checkpoint("lm", report, config, freeze, closure)
        report["language"] = replay_language(model, saved, directory, report, config)
        model, saved, directory = load_checkpoint("structured", report, config, freeze, closure)
        report["structured"] = replay_structured(model, saved, directory, report)
        report["status"] = "PASS" if all(row["passed"] for row in report["checks"]) else "FAIL"
    except Exception as error:
        report["status"] = "FAIL"
        report["error"] = f"{type(error).__name__}: {error}"
    report["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
    report["audit_wall_seconds"] = time.perf_counter() - begin
    outputs[0].write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n")
    outputs[1].write_text(render_markdown(report))
    print(json.dumps({
        "status": report["status"], "checks": len(report["checks"]),
        "passed": sum(row["passed"] for row in report["checks"]),
        "lm_bpb_absolute_difference": report.get("language", {}).get("bits_per_byte_absolute_difference"),
        "lm_max_block_nll_difference": report.get("language", {}).get("max_block_sum_nll_absolute_difference"),
        "structured_matching_predictions": report.get("structured", {}).get("matching_prediction_ids"),
        "structured_max_nll_difference": report.get("structured", {}).get("max_example_nll_absolute_difference"),
        "audit_wall_seconds": report["audit_wall_seconds"], "error": report.get("error"),
    }), flush=True)
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
