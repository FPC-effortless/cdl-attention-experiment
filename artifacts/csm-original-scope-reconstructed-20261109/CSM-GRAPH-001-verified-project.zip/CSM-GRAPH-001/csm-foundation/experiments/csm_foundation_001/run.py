"""Frozen preparation, fitting and held-out evaluation for CSM-FOUNDATION-001.

No evaluator metadata is passed to a model. Training and held-out evaluation are
separate commands; evaluation refuses to start until every registered fit exists.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from dataclasses import fields, is_dataclass, replace
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import random
import subprocess
import time

import numpy as np
import torch
from torch.nn import functional as F

from baselines import build_matched_gru, build_matched_transformer
from data import Example, build_dataset, save_dataset, serialize
from model import Config, RecordRewrite

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "config.json").read_text())
SOURCE_FILES = ["config.json", "PROTOCOL.md", "model.py", "baselines.py", "data.py", "run.py",
                "launch.py", "verification.py", "corpus_manifest.json", "DATA_README.md",
                "requirements.txt", "PREFIT_REVIEW.md"]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def utc():
    return datetime.now(timezone.utc).isoformat()


def git_head():
    return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(CONFIG["threads"])
    torch.use_deterministic_algorithms(True)


def make_model(arm, vocab):
    c = Config(vocab, CONFIG["width"], CONFIG["slots"], CONFIG["operators"],
               CONFIG["inner"], "rewrite", CONFIG["temperature"])
    if arm in {"rewrite", "ring_write", "no_links"}:
        return RecordRewrite(replace(c, mode=arm))
    # Creating a target solely to count parameters must not consume the baseline's
    # random initialization stream. The three record arms initialize identically.
    rng = torch.get_rng_state()
    target = RecordRewrite(c).parameter_count()
    torch.set_rng_state(rng)
    if arm == "gru":
        return build_matched_gru(target, vocab, CONFIG["width"])
    if arm == "transformer":
        return build_matched_transformer(target, vocab, CONFIG["width"])
    raise ValueError(arm)


def frozen_manifest():
    path = ROOT / "frozen_manifest.json"
    if not path.exists():
        raise RuntimeError("Run prepare and review the freeze before any fit")
    manifest = json.loads(path.read_text())
    for name, expected in manifest["source_sha256"].items():
        if sha(ROOT / name) != expected:
            raise RuntimeError(f"Frozen source changed: {name}")
    for name, expected in manifest["input_sha256"].items():
        if sha(ROOT / name) != expected:
            raise RuntimeError(f"Frozen input changed: {name}")
    return manifest


def load_rows(panel):
    with (ROOT / "data" / "registers" / f"{panel}.jsonl").open() as f:
        return [Example(**json.loads(line)) for line in f]


def corpus(part):
    data = np.frombuffer((ROOT / "data" / "input.txt").read_bytes(), dtype=np.uint8)
    offsets = CONFIG["lm_split_offsets"]
    index = {"train": 0, "dev": 1, "test": 2}[part]
    return data[offsets[index]:offsets[index + 1]].astype(np.int64) + 1


def structured_batch(rows):
    lengths = torch.tensor([len(row.input_ids) for row in rows], dtype=torch.long)
    x = torch.zeros(len(rows), int(lengths.max()), dtype=torch.long)
    for index, row in enumerate(rows):
        x[index, :lengths[index]] = torch.tensor(row.input_ids, dtype=torch.long)
    y = torch.tensor([row.answer_id for row in rows], dtype=torch.long)
    return x, y, lengths


def language_batch(tokens, starts, length=None):
    n = CONFIG["lm_context"] if length is None else length
    indices = np.asarray(starts)[:, None] + np.arange(n + 1)[None, :]
    block = torch.from_numpy(tokens[indices])
    return block[:, :-1], block[:, 1:]


def prepare():
    if (ROOT / "frozen_manifest.json").exists():
        raise RuntimeError("Existing freeze will not be overwritten")
    ds = build_dataset(CONFIG["dataset_seed"])
    save_dataset(ROOT / "data" / "registers", ds)
    schedules = ROOT / "data" / "schedules"
    schedules.mkdir(parents=True, exist_ok=True)
    for task, updates in [("structured", CONFIG["structured_updates"]), ("lm", CONFIG["lm_updates"])]:
        limit = len(ds["train"]) if task == "structured" else len(corpus("train")) - CONFIG["lm_context"]
        for seed in CONFIG["seeds"]:
            rng = np.random.default_rng(100_000 + seed)
            schedule = rng.integers(0, limit, size=(updates, CONFIG["batch_size"]), dtype=np.int64)
            np.save(schedules / f"{task}-{seed}.npy", schedule)
    inputs = sorted(path for path in (ROOT / "data").rglob("*") if path.is_file())
    seed_all(0)
    specs = {task: {arm: make_model(arm, vocab).specification() for arm in CONFIG["arms"]}
             for task, vocab in [("structured", len(ds.vocabulary)), ("lm", 257)]}
    manifest = {
        "experiment": CONFIG["experiment"], "frozen_at_utc": utc(), "base_git_head": git_head(),
        "source_sha256": {name: sha(ROOT / name) for name in SOURCE_FILES},
        "input_sha256": {str(path.relative_to(ROOT)): sha(path) for path in inputs},
        "configuration": CONFIG, "model_specifications": specs,
        "environment": {"python": platform.python_version(), "torch": torch.__version__,
                        "numpy": np.__version__, "platform": platform.platform(),
                        "cpu_count": os.cpu_count(), "cuda_used": False,
                        "torch_threads": CONFIG["threads"]},
        "profiling": {"type": "unscored random-token timing pilot, discarded weights",
                      "earlier_model_without_hard_value_edit": True,
                      "batch": 16, "length": 48, "updates": 6,
                      "one_thread_seconds_per_update": 0.26540375733263016,
                      "two_threads_seconds_per_update": 0.20988808516509985},
        "selection_policy": "Final fixed-update checkpoints; no test-guided selection or extension",
    }
    dump(ROOT / "frozen_manifest.json", manifest)
    print(json.dumps({"freeze": str(ROOT / "frozen_manifest.json"), "sha256": sha(ROOT / "frozen_manifest.json"),
                      "parameters": {task: {arm: s["parameters"] for arm, s in arms.items()} for task, arms in specs.items()}}), flush=True)


def run_path(task, arm, seed):
    return ROOT / "runs" / task / arm / str(seed)


def train(task, arm, seed):
    manifest = frozen_manifest()
    if (ROOT / "training_closed.json").exists():
        raise RuntimeError("Training is closed; no fits may be added after TEST opens")
    if arm not in CONFIG["arms"] or seed not in CONFIG["seeds"]:
        raise ValueError("Unregistered arm or seed")
    out = run_path(task, arm, seed)
    if out.exists():
        raise RuntimeError(f"Refusing to overwrite existing run: {out}")
    out.mkdir(parents=True)
    seed_all(seed)
    updates = CONFIG[f"{task}_updates"]
    model = make_model(arm, 20 if task == "structured" else 257)
    optimizer = torch.optim.AdamW(model.parameters(), lr=CONFIG["learning_rate"], weight_decay=CONFIG["weight_decay"])
    schedule_path = ROOT / "data" / "schedules" / f"{task}-{seed}.npy"
    schedule = np.load(schedule_path)
    training = load_rows("train") if task == "structured" else corpus("train")
    receipt = {"task": task, "arm": arm, "seed": seed, "start_utc": utc(),
               "source_git_head": git_head(), "freeze_sha256": sha(ROOT / "frozen_manifest.json"),
               "schedule_sha256": sha(schedule_path), "model": model.specification(),
               "optimizer": {"name": "AdamW", "lr": CONFIG["learning_rate"], "weight_decay": CONFIG["weight_decay"],
                             "betas": [0.9, 0.999], "eps": 1e-8},
               "checkpoint_policy": "last registered update", "updates": updates,
               "forward_scope": "input token IDs only; no evaluator metadata"}
    dump(out / "started.json", receipt)
    start = time.perf_counter()
    tokens_seen = 0
    losses = []
    model.train()
    with (out / "updates.jsonl").open("w") as log:
        for update, batch_ids in enumerate(schedule, 1):
            tick = time.perf_counter()
            optimizer.zero_grad(set_to_none=True)
            if task == "structured":
                batch = [training[int(i)] for i in batch_ids]
                x, y, lengths = structured_batch(batch)
                logits = model(x)[torch.arange(len(batch)), lengths - 1]
                loss = F.cross_entropy(logits, y)
                tokens = int(lengths.sum())
            else:
                x, y = language_batch(training, batch_ids)
                logits = model(x)
                loss = F.cross_entropy(logits.reshape(-1, 257), y.reshape(-1))
                tokens = y.numel()
            if not torch.isfinite(loss):
                raise FloatingPointError(f"Nonfinite loss at {update}")
            loss.backward()
            gradient_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), CONFIG["gradient_clip"])
            if not torch.isfinite(gradient_norm):
                raise FloatingPointError(f"Nonfinite gradient at {update}")
            optimizer.step()
            value = float(loss.detach())
            losses.append(value)
            tokens_seen += tokens
            row = {"update": update, "loss_nats": value, "gradient_norm_before_clip": float(gradient_norm),
                   "seconds": time.perf_counter() - tick, "input_or_prediction_tokens": tokens}
            log.write(json.dumps(row) + "\n")
            if update % 64 == 0 or update == 1:
                log.flush()
                print(f"{task}/{arm}/{seed} {update}/{updates} loss={value:.5f}", flush=True)
    elapsed = time.perf_counter() - start
    checkpoint = {"model_state": model.state_dict(), "optimizer_state": optimizer.state_dict(),
                  "torch_rng_state": torch.get_rng_state(), "numpy_rng_state": np.random.get_state(),
                  "python_rng_state": random.getstate(), "update": updates, "receipt": receipt,
                  "configuration": CONFIG, "source_sha256": manifest["source_sha256"]}
    torch.save(checkpoint, out / "checkpoint.pt")
    receipt.update({"finish_utc": utc(), "training_seconds": elapsed, "tokens_seen": tokens_seen,
                    "supervised_targets": updates * CONFIG["batch_size"] if task == "structured" else tokens_seen,
                    "first_32_mean_loss": float(np.mean(losses[:32])), "last_32_mean_loss": float(np.mean(losses[-32:])),
                    "checkpoint_sha256": sha(out / "checkpoint.pt"), "updates_sha256": sha(out / "updates.jsonl")})
    dump(out / "completed.json", receipt)
    print(json.dumps({"completed": str(out), "seconds": elapsed}), flush=True)


@torch.inference_mode()
def predict_structured(model, rows, intervention=None):
    # Equal-length groups make query-boundary interventions exact for every row.
    groups = defaultdict(list)
    for row in rows:
        groups[len(row.input_ids)].append(row)
    predictions = []
    for length, group in sorted(groups.items()):
        setting = None
        if intervention == "erase_state":
            setting = {"reset_at": length - 3}
        elif intervention == "permute_values":
            setting = {"corrupt_at": length - 3, "permute_values": True}
        elif intervention == "links_off":
            setting = {"links_off": True}
        elif intervention == "constant_operator":
            setting = {"constant_operator": True}
        elif intervention and intervention.startswith("zero_slot_"):
            setting = {"corrupt_at": length - 3, "zero_slot": int(intervention.split("_")[-1])}
        for start in range(0, len(group), CONFIG["eval_batch_size"]):
            batch = group[start:start + CONFIG["eval_batch_size"]]
            x, y, lengths = structured_batch(batch)
            logits = model(x, interventions=setting)[:, -1]
            nll = F.cross_entropy(logits, y, reduction="none")
            predicted = logits.argmax(-1)
            for i, example in enumerate(batch):
                predictions.append({"id": example.id, "panel": example.panel,
                                    "family_id": example.family_id, "world_id": example.metadata["world_id"],
                                    "variant": example.metadata["variant"],
                                    "query_register": example.metadata["query_register"],
                                    "target_register": example.metadata["target_register"],
                                    "answer_id": example.answer_id, "prediction_id": int(predicted[i]),
                                    "correct": bool(predicted[i] == y[i]), "nll_nats": float(nll[i]),
                                    "input_tokens": len(example.input_ids)})
    return sorted(predictions, key=lambda p: p["id"])


def structured_metrics(predictions):
    worlds, quartets = defaultdict(list), defaultdict(list)
    focal = []
    for p in predictions:
        worlds[p["world_id"]].append(p["correct"])
        if p["query_register"] == p["target_register"]:
            focal.append(p["correct"])
            quartets[p["family_id"]].append(p["correct"])
    result = {"examples": len(predictions), "accuracy": float(np.mean([p["correct"] for p in predictions])),
              "answer_nll_nats": float(np.mean([p["nll_nats"] for p in predictions])),
              "complete_world_accuracy": float(np.mean([all(rows) for rows in worlds.values()])),
              "worlds": len(worlds)}
    if focal:
        result["focal_accuracy"] = float(np.mean(focal))
        result["focal_examples"] = len(focal)
    if predictions[0]["panel"] == "counterfactual":
        if not all(len(rows) == 4 for rows in quartets.values()):
            raise AssertionError("Incomplete focal quartet")
        result["complete_quartet_accuracy"] = float(np.mean([all(rows) for rows in quartets.values()]))
        result["quartets"] = len(quartets)
    return result


@torch.inference_mode()
def evaluate_language(model, part):
    tokens = corpus(part)
    n = CONFIG["lm_context"]
    starts = np.arange(0, len(tokens) - n, n, dtype=np.int64)
    rows = []
    for begin in range(0, len(starts), CONFIG["eval_batch_size"]):
        indices = starts[begin:begin + CONFIG["eval_batch_size"]]
        x, y = language_batch(tokens, indices)
        losses = F.cross_entropy(model(x).reshape(-1, 257), y.reshape(-1), reduction="none").reshape(len(indices), n)
        for position, loss in zip(indices, losses):
            rows.append({"start": int(position), "tokens": n, "sum_nll_nats": float(loss.sum())})
    tail_start = int(starts[-1]) + n if len(starts) else 0
    tail_length = len(tokens) - tail_start - 1
    if tail_length > 0:
        x, y = language_batch(tokens, [tail_start], tail_length)
        loss = F.cross_entropy(model(x).reshape(-1, 257), y.reshape(-1), reduction="sum")
        rows.append({"start": tail_start, "tokens": tail_length, "sum_nll_nats": float(loss)})
    total = sum(row["sum_nll_nats"] for row in rows)
    scored = sum(row["tokens"] for row in rows)
    if scored != len(tokens) - 1:
        raise AssertionError("Every held-out next-byte target must be scored exactly once")
    return {"bits_per_byte": total / scored / math.log(2), "nll_nats": total / scored,
            "scored_bytes": scored, "blocks": len(rows), "context": n,
            "reset_between_blocks": True, "split": part}, rows


@torch.inference_mode()
def time_complete_sequence(model, ids):
    x = torch.tensor([ids], dtype=torch.long)
    for _ in range(3):
        model(x)
    full_sequence = []
    for _ in range(CONFIG["latency_repeats"]):
        start = time.perf_counter_ns()
        model(x)
        full_sequence.append((time.perf_counter_ns() - start) / 1e6)
    stream = []
    state = model.init_state(1, x.device)
    for index, token in enumerate(x.unbind(1)):
        start = time.perf_counter_ns()
        _, state = model.step(token, state)
        duration = (time.perf_counter_ns() - start) / 1e6
        if index >= 3:
            stream.append(duration)
    def tensor_bytes(value):
        if isinstance(value, torch.Tensor):
            return value.numel() * value.element_size()
        if isinstance(value, dict):
            return sum(tensor_bytes(item) for item in value.values())
        if isinstance(value, (list, tuple)):
            return sum(tensor_bytes(item) for item in value)
        if is_dataclass(value):
            return sum(tensor_bytes(getattr(value, field.name)) for field in fields(value))
        return 0
    return {"input_tokens": len(ids), "batch": 1, "torch_threads": CONFIG["threads"],
            "full_sequence_forward_ms_p50": float(np.median(full_sequence)),
            "full_sequence_forward_ms_p95": float(np.percentile(full_sequence, 95)),
            "observed_token_incremental_step_ms_p50": float(np.median(stream)),
            "full_sequence_raw_ms": full_sequence, "stream_raw_ms": stream,
            "retained_tensor_bytes_at_measured_length": tensor_bytes(state),
            "timing_note": "CPU wall time; full-sequence forward includes encoding, routing, updates and output projection but does not return a Transformer cache. Separate streaming samples use the actual recurrent/KV state. No tokenization or disk I/O."}


def collect_completed_fits():
    missing = []
    receipts = {}
    freeze_hash = sha(ROOT / "frozen_manifest.json")
    for task in ("structured", "lm"):
        for arm in CONFIG["arms"]:
            for seed in CONFIG["seeds"]:
                path = run_path(task, arm, seed) / "completed.json"
                if not path.exists():
                    missing.append(str(path))
                    continue
                row = json.loads(path.read_text())
                expected = {"task": task, "arm": arm, "seed": seed,
                            "updates": CONFIG[f"{task}_updates"], "freeze_sha256": freeze_hash}
                if any(row.get(key) != value for key, value in expected.items()):
                    raise RuntimeError(f"Completion does not match registered fit: {path}")
                checkpoint_hash = sha(path.parent / "checkpoint.pt")
                update_hash = sha(path.parent / "updates.jsonl")
                if checkpoint_hash != row["checkpoint_sha256"] or update_hash != row["updates_sha256"]:
                    raise RuntimeError(f"Changed training evidence: {path}")
                receipts[f"{task}/{arm}/{seed}"] = {
                    "completed_sha256": sha(path), "checkpoint_sha256": checkpoint_hash,
                    "updates_sha256": update_hash, "finish_utc": row["finish_utc"]}
    if missing:
        raise RuntimeError(f"Held-out scoring is closed until all30 fits finish: {missing[:3]}")
    return receipts


def close_training():
    frozen_manifest()
    path = ROOT / "training_closed.json"
    if path.exists():
        raise RuntimeError("Training closure already exists")
    receipts = collect_completed_fits()
    dump(path, {"closed_at_utc": utc(), "freeze_sha256": sha(ROOT / "frozen_manifest.json"),
                "completed_fits": receipts, "source_git_head": git_head()})
    print(json.dumps({"training_closed": str(path), "fits": len(receipts)}), flush=True)


def require_all_fits():
    path = ROOT / "training_closed.json"
    if not path.exists():
        raise RuntimeError("Run close-training before any held-out evaluation")
    closure = json.loads(path.read_text())
    if closure["freeze_sha256"] != sha(ROOT / "frozen_manifest.json"):
        raise RuntimeError("Training closure belongs to another freeze")
    if closure["completed_fits"] != collect_completed_fits():
        raise RuntimeError("Training evidence changed after closure")


def evaluate(task, arm, seed):
    frozen_manifest()
    require_all_fits()
    seed_all(seed)
    out = run_path(task, arm, seed)
    if (out / "evaluation.json").exists():
        raise RuntimeError("Refusing to overwrite existing evaluation")
    completion = json.loads((out / "completed.json").read_text())
    if sha(out / "checkpoint.pt") != completion["checkpoint_sha256"]:
        raise RuntimeError("Checkpoint hash mismatch")
    checkpoint = torch.load(out / "checkpoint.pt", map_location="cpu", weights_only=False)
    model = make_model(arm, 20 if task == "structured" else 257)
    model.load_state_dict(checkpoint["model_state"])
    model.eval()
    result = {"task": task, "arm": arm, "seed": seed, "evaluation_utc": utc(),
              "checkpoint_sha256": completion["checkpoint_sha256"], "source_git_head": git_head()}
    if task == "structured":
        metrics, saved = {}, []
        for panel in ("dev", "iid", "composition", "correction", "long", "counterfactual"):
            predictions = predict_structured(model, load_rows(panel))
            metrics[panel] = structured_metrics(predictions)
            saved.extend({**p, "condition": "ordinary"} for p in predictions)
        result["panels"] = metrics
        interventions = {}
        names = ["erase_state"]
        if arm in {"rewrite", "ring_write", "no_links"}:
            names += ["permute_values", "links_off", "constant_operator"]
            names += [f"zero_slot_{slot}" for slot in range(CONFIG["slots"])]
        # Fixed first32 IID families (128 query presentations), all controls
        # scored on the same subset; local-slot probes are descriptive.
        probe_rows = load_rows("iid")[:128]
        base_probes = predict_structured(model, probe_rows)
        interventions["ordinary_subset"] = structured_metrics(base_probes)
        saved.extend({**p, "condition": "ordinary_subset"} for p in base_probes)
        for condition in names:
            predictions = predict_structured(model, probe_rows, condition)
            interventions[condition] = structured_metrics(predictions)
            saved.extend({**p, "condition": condition} for p in predictions)
        result["interventions"] = interventions
        long_rows = [e for e in load_rows("long") if e.metadata["query_register"] == e.metadata["target_register"]]
        base_rows = [replace(e, id=e.id + "-base", input_ids=serialize(
            [tuple(op) for op in e.metadata["program"][:-16]], f"r{e.metadata['query_register']}")) for e in long_rows]
        base_predictions = predict_structured(model, base_rows)
        long_predictions = predict_structured(model, long_rows)
        paired = list(zip(base_predictions, long_predictions))
        if any(a["id"].removesuffix("-base") != b["id"] for a, b in paired):
            raise AssertionError("Mismatched irrelevant-update pairs")
        result["irrelevant_update_pairs"] = {
            "families": len(paired),
            "both_correct_accuracy": float(np.mean([a["correct"] and b["correct"] for a, b in paired])),
            "prediction_unchanged_fraction": float(np.mean([a["prediction_id"] == b["prediction_id"] for a, b in paired])),
            "base_accuracy": float(np.mean([a["correct"] for a, _ in paired])),
            "with_distractors_accuracy": float(np.mean([b["correct"] for _, b in paired]))}
        saved.extend({**p, "condition": "long_pair_base"} for p in base_predictions)
        result["latency"] = time_complete_sequence(model, load_rows("iid")[0].input_ids)
        with (out / "predictions.jsonl").open("w") as f:
            for p in saved:
                f.write(json.dumps(p, sort_keys=True) + "\n")
    else:
        result["dev"], dev_rows = evaluate_language(model, "dev")
        result["test"], test_rows = evaluate_language(model, "test")
        dump(out / "loss_blocks.json", {"dev": dev_rows, "test": test_rows})
        result["latency"] = time_complete_sequence(model, corpus("test")[:CONFIG["lm_context"]].tolist())
    result["training"] = completion
    dump(out / "evaluation.json", result)
    print(json.dumps({"evaluated": str(out), "main": result.get("test", result.get("panels", {}).get("iid"))}), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("prepare")
    sub.add_parser("close-training")
    for command in ("train", "evaluate"):
        child = sub.add_parser(command)
        child.add_argument("--task", choices=("structured", "lm"), required=True)
        child.add_argument("--arm", choices=CONFIG["arms"], required=True)
        child.add_argument("--seed", type=int, choices=CONFIG["seeds"], required=True)
    args = parser.parse_args()
    if args.command == "prepare":
        prepare()
    elif args.command == "close-training":
        close_training()
    else:
        globals()[args.command](args.task, args.arm, args.seed)


if __name__ == "__main__":
    main()
