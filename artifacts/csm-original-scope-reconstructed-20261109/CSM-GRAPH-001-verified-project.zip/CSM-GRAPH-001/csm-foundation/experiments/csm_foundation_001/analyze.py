"""Post-closure tabulation of the fixed CSM-FOUNDATION-001 experiment.

This file is postprocessing, not a frozen training or evaluation source. It never
loads model weights, trains a model, selects a checkpoint, or evaluates tokens.
No run output is read until the closure and every registered evaluation exist.
Existing analysis artifacts are not overwritten.

Default output: summary.json, tables/*.csv, and compact evidence/ JSON snapshots
beside this script. All evaluation and receipt fields, including raw timing
samples, are preserved in those snapshots. No interpretation prose is generated.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import io
import json
import math
from pathlib import Path
import statistics


ROOT = Path(__file__).resolve().parent
TASKS = ("structured", "lm")
PANELS = ("dev", "iid", "composition", "correction", "long", "counterfactual")
FOCAL_PANELS = ("composition", "correction", "long", "counterfactual")
ABLATIONS = ("ring_write", "no_links")
GATE_METRICS = {
    "every_seed_iid_accuracy": "iid_accuracy",
    "every_seed_composition_focal_accuracy": "composition_focal_accuracy",
    "every_seed_correction_focal_accuracy": "correction_focal_accuracy",
    "every_seed_counterfactual_complete_quartet_accuracy":
        "counterfactual_complete_quartet_accuracy",
}
COST_METRICS = (
    "full_sequence_forward_ms_p50",
    "full_sequence_forward_ms_p95",
    "observed_token_incremental_step_ms_p50",
    "retained_tensor_bytes_at_measured_length",
    "training_seconds",
)
STRUCTURED_METRICS = tuple(
    f"{panel}_{metric}"
    for panel in PANELS
    for metric in ("accuracy", "complete_world_accuracy", "answer_nll_nats")
) + tuple(f"{panel}_focal_accuracy" for panel in FOCAL_PANELS) + (
    "counterfactual_complete_quartet_accuracy",
    "long_pair_both_correct_accuracy",
    "long_pair_prediction_unchanged_fraction",
    "long_pair_base_accuracy",
    "long_pair_with_distractors_accuracy",
)
LM_METRICS = ("dev_bits_per_byte", "dev_nll_nats",
              "test_bits_per_byte", "test_nll_nats")
INTERVENTION_METRICS = (
    "accuracy", "complete_world_accuracy", "answer_nll_nats",
    "accuracy_difference_from_ordinary",
    "complete_world_accuracy_difference_from_ordinary",
    "answer_nll_difference_from_ordinary",
)


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path):
    with path.open() as handle:
        return json.load(handle)


def json_bytes(value, *, compact=False) -> bytes:
    options = {"sort_keys": True, "allow_nan": False}
    if compact:
        options["separators"] = (",", ":")
    else:
        options["indent"] = 2
    return (json.dumps(value, **options) + "\n").encode()


def csv_bytes(rows: list[dict]) -> bytes:
    if not rows:
        raise ValueError("Refusing to write an empty table")
    columns = list(rows[0])
    if any(set(row) != set(columns) for row in rows):
        raise ValueError("Inconsistent CSV row schema")
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=columns, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return stream.getvalue().encode()


def number(value, name: str):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} is not a number: {value!r}")
    if not math.isfinite(value):
        raise ValueError(f"{name} is not finite")
    return value


def accuracy(value, name: str):
    value = number(value, name)
    if not 0 <= value <= 1:
        raise ValueError(f"{name} is outside [0, 1]")
    return value


def assert_equal(observed, expected, name: str):
    if observed != expected:
        raise ValueError(f"{name}: expected {expected!r}, found {observed!r}")


def verify_hash(path: Path, expected: str):
    observed = sha(path)
    assert_equal(observed, expected, f"SHA256 of {path}")
    return observed


def load_closed_evaluations(root: Path):
    """Validate the complete cohort before exposing results to tabulation."""
    config = read_json(root / "config.json")
    keys = [(task, arm, seed) for task in TASKS
            for arm in config["arms"] for seed in config["seeds"]]
    if len(keys) != 30 or len(set(keys)) != 30:
        raise ValueError("This analyzer expects the 30 registered, unique fits")
    assert_equal(set(config["gates"]), set(GATE_METRICS), "Registered gate names")
    required = [root / "frozen_manifest.json", root / "training_closed.json"]
    required.extend(root / "runs" / task / arm / str(seed) / name
                    for task, arm, seed in keys
                    for name in ("completed.json", "evaluation.json"))
    missing = [str(path.relative_to(root)) for path in required if not path.is_file()]
    if missing:
        raise RuntimeError(
            "Analysis is closed until training closure and all 30 final "
            f"evaluations exist. Missing: {missing[:8]}"
        )

    freeze = read_json(root / "frozen_manifest.json")
    closure = read_json(root / "training_closed.json")
    freeze_hash = sha(root / "frozen_manifest.json")
    closure_hash = sha(root / "training_closed.json")
    assert_equal(closure["freeze_sha256"], freeze_hash, "Closure freeze identity")
    assert_equal(freeze["configuration"], config, "Frozen configuration")
    for name, expected in freeze["source_sha256"].items():
        verify_hash(root / name, expected)
    for name, expected in freeze["input_sha256"].items():
        verify_hash(root / name, expected)
    expected_ids = {f"{task}/{arm}/{seed}" for task, arm, seed in keys}
    assert_equal(set(closure["completed_fits"]), expected_ids, "Closed fit cohort")
    closed_at = datetime.fromisoformat(closure["closed_at_utc"])
    records = []
    provenance = []
    for task, arm, seed in keys:
        run_id = f"{task}/{arm}/{seed}"
        directory = root / "runs" / task / arm / str(seed)
        frozen_receipt = closure["completed_fits"][run_id]
        receipt_hash = verify_hash(
            directory / "completed.json", frozen_receipt["completed_sha256"])
        receipt = read_json(directory / "completed.json")
        for field, expected in {
            "task": task, "arm": arm, "seed": seed,
            "updates": config[f"{task}_updates"], "freeze_sha256": freeze_hash,
        }.items():
            assert_equal(receipt[field], expected, f"{run_id} receipt {field}")
        assert_equal(receipt["model"], freeze["model_specifications"][task][arm],
                     f"{run_id} frozen model specification")
        for name, field in (("checkpoint.pt", "checkpoint_sha256"),
                            ("updates.jsonl", "updates_sha256")):
            assert_equal(receipt[field], frozen_receipt[field], f"{run_id} {field}")
            verify_hash(directory / name, frozen_receipt[field])
        verify_hash(root / "data" / "schedules" / f"{task}-{seed}.npy",
                    receipt["schedule_sha256"])
        assert_equal(receipt["finish_utc"], frozen_receipt["finish_utc"],
                     f"{run_id} completion timestamp")
        if datetime.fromisoformat(receipt["finish_utc"]) > closed_at:
            raise ValueError(f"{run_id} finished after training closure")
        evaluation_path = directory / "evaluation.json"
        evaluation = read_json(evaluation_path)
        for field, expected in (("task", task), ("arm", arm), ("seed", seed),
                                ("checkpoint_sha256", receipt["checkpoint_sha256"])):
            assert_equal(evaluation[field], expected, f"{run_id} evaluation {field}")
        assert_equal(evaluation["training"], receipt,
                     f"{run_id} embedded training receipt")
        if datetime.fromisoformat(evaluation["evaluation_utc"]) < closed_at:
            raise ValueError(f"{run_id} evaluation predates training closure")
        raw_name = "predictions.jsonl" if task == "structured" else "loss_blocks.json"
        raw_hash = sha(directory / raw_name)
        records.append({"task": task, "arm": arm, "seed": seed,
                        "directory": directory, "receipt": receipt,
                        "evaluation": evaluation})
        provenance.append({
            "task": task, "arm": arm, "seed": seed,
            "evaluation_source": str(evaluation_path.relative_to(root)),
            "evaluation_sha256": sha(evaluation_path),
            "completed_sha256": receipt_hash,
            "checkpoint_sha256": receipt["checkpoint_sha256"],
            "updates_sha256": receipt["updates_sha256"],
            "raw_evaluation_source": str((directory / raw_name).relative_to(root)),
            "raw_evaluation_sha256": raw_hash,
        })
    return config, freeze, closure, records, {
        "freeze_sha256": freeze_hash, "training_closure_sha256": closure_hash,
        "registered_fit_count": len(keys), "runs": provenance,
    }


def common_row(record: dict, config: dict) -> dict:
    receipt, evaluation = record["receipt"], record["evaluation"]
    model, latency = receipt["model"], evaluation["latency"]
    capacity = model.get("maximum_state_float32_bytes_per_example",
                         model.get("state_float32_bytes_per_example"))
    row = {"arm": record["arm"], "seed": record["seed"],
           "parameters": model["parameters"],
           "active_parameters": model["active_parameters"],
           "configured_state_capacity_tensor_bytes": capacity,
           "retained_tensor_bytes_at_measured_length":
               latency["retained_tensor_bytes_at_measured_length"],
           "latency_input_tokens": latency["input_tokens"],
           "latency_batch": latency["batch"], "latency_threads": latency["torch_threads"],
           "full_sequence_forward_ms_p50": latency["full_sequence_forward_ms_p50"],
           "full_sequence_forward_ms_p95": latency["full_sequence_forward_ms_p95"],
           "observed_token_incremental_step_ms_p50":
               latency["observed_token_incremental_step_ms_p50"],
           "full_sequence_timing_samples": len(latency["full_sequence_raw_ms"]),
           "streaming_timing_samples": len(latency["stream_raw_ms"]),
           "training_seconds": receipt["training_seconds"],
           "updates": receipt["updates"], "tokens_seen": receipt["tokens_seen"],
           "supervised_targets": receipt["supervised_targets"],
           "first_32_mean_training_loss_nats": receipt["first_32_mean_loss"],
           "last_32_mean_training_loss_nats": receipt["last_32_mean_loss"]}
    for key, value in row.items():
        if key != "arm":
            number(value, key)
    assert_equal(row["full_sequence_timing_samples"], config["latency_repeats"],
                 "Full-sequence latency repetition count")
    assert_equal(row["streaming_timing_samples"], row["latency_input_tokens"] - 3,
                 "Streaming sample count after first three positions")
    assert_equal(row["latency_batch"], 1, "Latency batch")
    assert_equal(row["latency_threads"], config["threads"], "Latency threads")
    return row


def structured_row(record: dict, config: dict) -> dict:
    row = common_row(record, config)
    result = record["evaluation"]
    for panel in PANELS:
        values = result["panels"][panel]
        for metric in ("accuracy", "complete_world_accuracy"):
            row[f"{panel}_{metric}"] = accuracy(values[metric], f"{panel}/{metric}")
        row[f"{panel}_answer_nll_nats"] = number(values["answer_nll_nats"], panel)
        row[f"{panel}_examples"] = values["examples"]
        row[f"{panel}_worlds"] = values["worlds"]
        assert_equal(values["examples"], 4 * values["worlds"],
                     f"{panel} four query presentations per world")
        if panel in FOCAL_PANELS:
            row[f"{panel}_focal_accuracy"] = accuracy(
                values["focal_accuracy"], f"{panel}/focal_accuracy")
            row[f"{panel}_focal_examples"] = values["focal_examples"]
    counterfactual = result["panels"]["counterfactual"]
    row["counterfactual_complete_quartet_accuracy"] = accuracy(
        counterfactual["complete_quartet_accuracy"], "Counterfactual quartet accuracy")
    row["counterfactual_quartets"] = counterfactual["quartets"]
    assert_equal(counterfactual["focal_examples"], 4 * counterfactual["quartets"],
                 "Four focal questions per counterfactual family")
    pair = result["irrelevant_update_pairs"]
    row["long_pair_families"] = pair["families"]
    for metric in ("both_correct_accuracy", "prediction_unchanged_fraction",
                   "base_accuracy", "with_distractors_accuracy"):
        row[f"long_pair_{metric}"] = accuracy(pair[metric], f"Long pairs/{metric}")
    assert_equal(pair["with_distractors_accuracy"], row["long_focal_accuracy"],
                 "Paired long-history focal accuracy")
    return row


def language_row(record: dict, config: dict) -> dict:
    row = common_row(record, config)
    for part, index in (("dev", 1), ("test", 2)):
        metric = record["evaluation"][part]
        expected_targets = config["lm_split_offsets"][index + 1] - \
            config["lm_split_offsets"][index] - 1
        assert_equal(metric["scored_bytes"], expected_targets,
                     f"All {part} next-byte targets scored")
        assert_equal(metric["context"], config["lm_context"], f"{part} context")
        assert_equal(metric["reset_between_blocks"], True, f"{part} block resets")
        for name in ("bits_per_byte", "nll_nats", "scored_bytes", "blocks", "context"):
            row[f"{part}_{name}"] = number(metric[name], f"{part}/{name}")
        if not math.isclose(metric["bits_per_byte"], metric["nll_nats"] / math.log(2),
                            rel_tol=1e-12, abs_tol=1e-12):
            raise ValueError(f"Inconsistent {part} NLL and bits per byte")
    return row


def aggregate(rows: list[dict], group_fields: tuple[str, ...],
              metric_fields: tuple[str, ...], seeds: list[int]) -> list[dict]:
    """Equal-weight seed statistics within one task/group, never across tasks."""
    groups = defaultdict(list)
    for row in rows:
        groups[tuple(row[field] for field in group_fields)].append(row)
    result = []
    for key, group in groups.items():
        observed_seeds = [row["seed"] for row in group]
        assert_equal(sorted(observed_seeds), sorted(seeds),
                     f"One complete configured seed set for {key}")
        for metric in metric_fields:
            values = [number(row[metric], metric) for row in group]
            result.append({
                **dict(zip(group_fields, key)), "metric": metric,
                "n_seeds": len(values), "mean": statistics.fmean(values),
                "min": min(values), "max": max(values),
            })
    return result


def gate_tables(rows: list[dict], config: dict):
    per_seed, summaries, verdicts = [], [], []
    index = {(row["arm"], row["seed"]): row for row in rows}
    for arm in config["arms"]:
        arm_passes = []
        passed_by_seed = {seed: True for seed in config["seeds"]}
        for gate, metric in GATE_METRICS.items():
            threshold = accuracy(config["gates"][gate], f"Gate {gate}")
            observations = []
            failed = []
            for seed in config["seeds"]:
                observed = index[arm, seed][metric]
                passed = observed >= threshold
                observations.append(observed)
                passed_by_seed[seed] &= passed
                if not passed:
                    failed.append(seed)
                per_seed.append({
                    "arm": arm, "seed": seed, "gate": gate, "metric": metric,
                    "threshold": threshold, "observed": observed, "passed": passed,
                })
            all_seeds_passed = not failed
            arm_passes.append(all_seeds_passed)
            summaries.append({
                "arm": arm, "gate": gate, "metric": metric, "threshold": threshold,
                "all_seeds_passed": all_seeds_passed, "n_seeds": len(observations),
                "mean": statistics.fmean(observations),
                "min": min(observations), "max": max(observations),
                "failed_seeds": ",".join(map(str, failed)),
            })
        verdicts.append({
            "arm": arm, "all_seeds_all_gates_passed": all(arm_passes),
            "passed_gate_count": sum(arm_passes), "required_gate_count": len(arm_passes),
            "passing_seed_count": sum(passed_by_seed.values()),
            "required_seed_count": len(config["seeds"]),
        })
    return per_seed, summaries, verdicts


def ablation_tables(task_rows: dict[str, list[dict]], config: dict):
    rows = []
    for task in TASKS:
        index = {(row["arm"], row["seed"]): row for row in task_rows[task]}
        metrics = (STRUCTURED_METRICS if task == "structured" else LM_METRICS) + COST_METRICS
        for ablation in ABLATIONS:
            for seed in config["seeds"]:
                full, control = index["rewrite", seed], index[ablation, seed]
                for metric in metrics:
                    rows.append({
                        "task": task, "ablation": ablation, "seed": seed,
                        "metric": metric, "rewrite": full[metric],
                        "ablated": control[metric],
                        "rewrite_minus_ablated": full[metric] - control[metric],
                    })
    # Keep task and outcome in each group, and retain the outcome metric name
    # separately from the name of its paired difference.
    groups = defaultdict(list)
    for row in rows:
        groups[row["task"], row["ablation"], row["metric"]].append(row)
    summary = []
    for (task, ablation, metric), group in groups.items():
        assert_equal(sorted(row["seed"] for row in group), sorted(config["seeds"]),
                     f"Paired ablation seeds for {task}/{ablation}/{metric}")
        values = [number(row["rewrite_minus_ablated"], metric) for row in group]
        summary.append({
            "task": task, "ablation": ablation, "metric": metric,
            "difference": "rewrite_minus_ablated", "n_seeds": len(values),
            "mean": statistics.fmean(values), "min": min(values), "max": max(values),
        })
    return rows, summary


def intervention_tables(records: list[dict], config: dict):
    rows = []
    for record in records:
        if record["task"] != "structured":
            continue
        conditions = record["evaluation"]["interventions"]
        ordinary = conditions["ordinary_subset"]
        for condition, result in conditions.items():
            assert_equal(result["examples"], ordinary["examples"],
                         "Matched intervention query presentations")
            assert_equal(result["worlds"], ordinary["worlds"],
                         "Matched intervention families")
            rows.append({
                "arm": record["arm"], "seed": record["seed"], "condition": condition,
                "examples": result["examples"], "worlds": result["worlds"],
                "accuracy": accuracy(result["accuracy"], condition),
                "complete_world_accuracy": accuracy(result["complete_world_accuracy"], condition),
                "answer_nll_nats": number(result["answer_nll_nats"], condition),
                "accuracy_difference_from_ordinary":
                    result["accuracy"] - ordinary["accuracy"],
                "complete_world_accuracy_difference_from_ordinary":
                    result["complete_world_accuracy"] - ordinary["complete_world_accuracy"],
                "answer_nll_difference_from_ordinary":
                    result["answer_nll_nats"] - ordinary["answer_nll_nats"],
            })
    return rows, aggregate(rows, ("arm", "condition"), INTERVENTION_METRICS,
                           config["seeds"])


def last_write_diagnostic(root: Path, records: list[dict], config: dict):
    """Supplementary diagnosis only; this metadata never enters a learned model."""
    data_path = root / "data" / "registers" / "iid.jsonl"
    with data_path.open() as handle:
        examples = [json.loads(line) for line in handle]
    metadata = {}
    for example in examples:
        query = example["metadata"]["query_register"]
        destination = f"r{query}"
        last = next(op for op in reversed(example["metadata"]["program"])
                    if op[1] == destination)
        if last[0] not in {"set", "copy", "sub"}:
            raise ValueError(f"Unexpected last-writing operation: {last}")
        metadata[example["id"]] = {
            "operation": last[0].upper(), "family_id": example["family_id"],
            "answer_id": example["answer_id"], "query_register": query,
        }
    assert_equal(len(metadata), len(examples), "Unique IID example IDs")
    rows = []
    for record in records:
        if record["task"] != "structured":
            continue
        groups, seen = defaultdict(list), set()
        with (record["directory"] / "predictions.jsonl").open() as handle:
            for line in handle:
                prediction = json.loads(line)
                if prediction["panel"] != "iid" or prediction["condition"] != "ordinary":
                    continue
                example_id = prediction["id"]
                if example_id in seen:
                    raise ValueError(f"Duplicate ordinary IID prediction: {example_id}")
                seen.add(example_id)
                source = metadata[example_id]
                for field in ("family_id", "answer_id", "query_register"):
                    assert_equal(prediction[field], source[field], f"IID join {field}")
                correct = prediction["prediction_id"] == prediction["answer_id"]
                assert_equal(prediction["correct"], correct, "Recorded prediction correctness")
                groups[source["operation"]].append({
                    "correct": correct, "family_id": source["family_id"],
                    "nll": number(prediction["nll_nats"], "Diagnostic answer NLL"),
                })
        assert_equal(seen, set(metadata), "Complete ordinary IID diagnostic predictions")
        pooled = [row for group in groups.values() for row in group]
        main_iid = record["evaluation"]["panels"]["iid"]
        assert_equal(len(pooled), main_iid["examples"], "Diagnostic/main IID count")
        assert_equal(sum(row["correct"] for row in pooled) / len(pooled),
                     main_iid["accuracy"], "Diagnostic/main IID accuracy")
        if not math.isclose(statistics.fmean(row["nll"] for row in pooled),
                            main_iid["answer_nll_nats"],
                            rel_tol=1e-10, abs_tol=1e-10):
            raise ValueError("Diagnostic predictions disagree with the main IID NLL")
        for operation in ("SET", "COPY", "SUB"):
            group = groups.get(operation, [])
            if not group:
                continue
            correct = sum(row["correct"] for row in group)
            rows.append({
                "arm": record["arm"], "seed": record["seed"],
                "last_write_operation": operation,
                "examples": len(group), "families": len({row["family_id"] for row in group}),
                "correct": correct, "accuracy": correct / len(group),
                "answer_nll_nats": statistics.fmean(row["nll"] for row in group),
            })
    summary = aggregate(rows, ("arm", "last_write_operation"),
                        ("accuracy", "answer_nll_nats"), config["seeds"])
    return rows, summary, {
        "status": "supplementary_descriptive_not_registered_qualification",
        "scope": "ordinary IID queries only",
        "grouping": "last program operation whose destination is the queried register",
        "metadata_use": "post-evaluation join only; not supplied to any learned model",
        "dependence": "Queries can share a family; no independence or confidence claim.",
        "dataset_source": str(data_path.relative_to(root)),
        "dataset_sha256": sha(data_path),
    }


def print_table(title: str, headers: list[str], rows: list[list[str]]):
    widths = [max(len(headers[i]), *(len(row[i]) for row in rows))
              for i in range(len(headers))]
    print(f"\n{title}")
    for row in [headers, *rows]:
        print("  ".join(value.ljust(width) for value, width in zip(row, widths)))


def print_summary(summary: dict, output: Path):
    structured = {(row["arm"], row["metric"]): row
                  for row in summary["structured"]["seed_summary"]}
    language = {(row["arm"], row["metric"]): row
                for row in summary["lm"]["seed_summary"]}
    gates = {row["arm"]: row for row in summary["structured"]["arm_gate_verdicts"]}

    def interval(values, scale=1, decimals=3):
        return (f"{scale * values['mean']:.{decimals}f} "
                f"[{scale * values['min']:.{decimals}f},"
                f"{scale * values['max']:.{decimals}f}]")

    arms = summary["arms"]
    quality = ("iid_accuracy", "iid_complete_world_accuracy",
               "composition_focal_accuracy", "correction_focal_accuracy",
               "long_focal_accuracy", "counterfactual_complete_quartet_accuracy")
    print_table(
        "Structured accuracy %: seed mean [min,max]; gates require every seed",
        ["Arm", "IID", "World", "Composition", "Correction", "Long", "Quartet", "All gates"],
        [[arm, *(interval(structured[arm, metric], 100, 1) for metric in quality),
          "PASS" if gates[arm]["all_seeds_all_gates_passed"] else "FAIL"] for arm in arms],
    )
    print_table(
        "Language and implementation cost: seed mean [min,max]",
        ["Arm", "Test BPB", "Full forward ms", "Stream step ms", "Fit seconds"],
        [[arm, *(interval(language[arm, metric]) for metric in
                 ("test_bits_per_byte", "full_sequence_forward_ms_p50",
                  "observed_token_incremental_step_ms_p50", "training_seconds"))]
         for arm in arms],
    )
    ablations = {(row["task"], row["ablation"], row["metric"]): row
                 for row in summary["ablation_differences"]["seed_summary"]}
    print_table(
        "Structured ablation differences: rewrite minus ablated, percentage points",
        ["Ablation", "IID", "Composition", "Correction", "Quartet"],
        [[arm, *(interval(ablations["structured", arm, metric], 100, 1)
                 for metric in ("iid_accuracy", "composition_focal_accuracy",
                                "correction_focal_accuracy",
                                "counterfactual_complete_quartet_accuracy"))]
         for arm in ABLATIONS],
    )
    print(f"\nSummary: {output / 'summary.json'}")
    print(f"Tables: {output / 'tables'}")
    print(f"Compact evidence: {output / 'evidence'}")


def analyze(root: Path, output: Path):
    for name in ("summary.json", "tables", "evidence"):
        if (output / name).exists():
            raise FileExistsError(
                f"Refusing to overwrite {output / name}; choose a new --output-dir")
    config, freeze, closure, records, provenance = load_closed_evaluations(root)
    task_rows = {
        task: [(structured_row if task == "structured" else language_row)(record, config)
               for record in records if record["task"] == task]
        for task in TASKS
    }
    seed_summaries = {
        task: aggregate(task_rows[task], ("arm",),
                        (STRUCTURED_METRICS if task == "structured" else LM_METRICS)
                        + COST_METRICS, config["seeds"])
        for task in TASKS
    }
    gates, gate_summary, verdicts = gate_tables(task_rows["structured"], config)
    ablations, ablation_summary = ablation_tables(task_rows, config)
    interventions, intervention_summary = intervention_tables(records, config)
    diagnostic, diagnostic_summary, diagnostic_scope = last_write_diagnostic(root, records, config)
    summary = {
        "schema_version": 1, "experiment": config["experiment"],
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "analyzer_sha256": sha(Path(__file__)),
        "arms": config["arms"], "seeds": config["seeds"],
        "provenance": provenance,
        "aggregation": {
            "source": "Main tables tabulate the frozen evaluator aggregates; this is not an independent checkpoint replay.",
            "seed_summary": "Arithmetic mean, minimum and maximum across registered seeds within each task, arm and metric.",
            "tasks_pooled": False, "combined_quality_score": None,
            "accuracy_unit": "fraction in JSON/CSV; percent in the console table",
            "uncertainty": "Seed ranges are descriptive, not confidence intervals.",
            "latency": "Full forward includes output projection; streaming samples span different positions in one pass.",
            "state_bytes": "Retained tensors only; capacity is distinct from the measured sequence length.",
        },
        "structured": {
            "per_seed": task_rows["structured"],
            "seed_summary": seed_summaries["structured"],
            "gate_thresholds": config["gates"],
            "gates_per_seed": gates, "gate_summary": gate_summary,
            "arm_gate_verdicts": verdicts,
        },
        "lm": {"per_seed": task_rows["lm"], "seed_summary": seed_summaries["lm"]},
        "ablation_differences": {
            "definition": "rewrite minus ablated, paired within task and seed",
            "accuracy_difference_unit": "fraction, not percentage points",
            "direction": "Positive accuracy differences favor rewrite; negative NLL, BPB, time or memory differences favor rewrite. No composite score.",
            "per_seed": ablations, "seed_summary": ablation_summary,
        },
        "interventions": {
            "definition": "Intervened result minus ordinary_subset on the same frozen model and queries; ordinary_subset has zero difference.",
            "per_seed": interventions, "seed_summary": intervention_summary,
        },
        "supplementary_iid_last_write_diagnostic": {
            **diagnostic_scope, "per_seed": diagnostic, "seed_summary": diagnostic_summary,
        },
    }
    tables = {
        "structured_per_seed": task_rows["structured"],
        "structured_seed_summary": seed_summaries["structured"],
        "lm_per_seed": task_rows["lm"], "lm_seed_summary": seed_summaries["lm"],
        "gates_per_seed": gates, "gate_summary": gate_summary,
        "arm_gate_verdicts": verdicts,
        "ablations_per_seed": ablations, "ablation_seed_summary": ablation_summary,
        "interventions_per_seed": interventions,
        "intervention_seed_summary": intervention_summary,
        "supplementary_iid_last_write_per_seed": diagnostic,
        "supplementary_iid_last_write_seed_summary": diagnostic_summary,
    }
    # Prepare every payload before creating output files, so schema failures do
    # not leave an apparently complete partial report.
    payloads = {f"tables/{name}.csv": csv_bytes(rows) for name, rows in tables.items()}
    snapshots = {
        "evidence/frozen_manifest.json": freeze,
        "evidence/training_closed.json": closure,
    }
    for record in records:
        prefix = f"evidence/{record['task']}/{record['arm']}/{record['seed']}"
        snapshots[f"{prefix}/evaluation.json"] = record["evaluation"]
        snapshots[f"{prefix}/completed.json"] = record["receipt"]
    payloads.update({name: json_bytes(value, compact=True) for name, value in snapshots.items()})
    evidence_manifest = {
        "schema_version": 1, "experiment": config["experiment"],
        "source_provenance": provenance,
        "snapshot_encoding": "Compact JSON; every source evaluation and receipt field is preserved.",
        "snapshot_sha256": {
            name: hashlib.sha256(payloads[name]).hexdigest() for name in snapshots
        },
    }
    payloads["evidence/manifest.json"] = json_bytes(evidence_manifest)
    summary["artifact_sha256"] = {
        name: hashlib.sha256(value).hexdigest() for name, value in payloads.items()
    }
    payloads["summary.json"] = json_bytes(summary)
    for name, contents in payloads.items():
        destination = output / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as handle:
            handle.write(contents)
    print_summary(summary, output)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT,
                        help="Experiment directory containing the frozen cohort")
    parser.add_argument("--output-dir", type=Path,
                        help="Destination; defaults to the experiment directory")
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output_dir.resolve() if args.output_dir else root
    analyze(root, output)


if __name__ == "__main__":
    main()
