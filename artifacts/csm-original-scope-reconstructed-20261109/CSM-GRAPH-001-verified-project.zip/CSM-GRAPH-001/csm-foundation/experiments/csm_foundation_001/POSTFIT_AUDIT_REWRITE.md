# Independent postfit audit: CSM-FOUNDATION-001 rewrite

This is an integrity audit and a supplementary diagnosis. No weights were trained or changed, and no registered gate was modified.

## Integrity outcome

PASS: 12 frozen sources, 15 inputs, and all 30 closed fit receipts/checkpoints/update logs match their recorded hashes.

All 1536 IID and counterfactual examples for rewrite seed11 were replayed directly through the model. Predictions matched exactly. Maximum NLL discrepancy using independent FP64 logsumexp arithmetic was 2.43922318e-07 nats (tolerance 5e-06).

Independent raw arithmetic reconciled 114 metric cells covering 29952 saved ordinary/intervention predictions across rewrite/no-links and three seeds, plus all six long-pair conditions. Public-token labels were independently interpreted for 3328 held-out/development examples.

## Structured qualification

| Arm | Seed | IID | Composition focal | Correction focal | Complete focal quartets | Distinct IID predictions |
|---|---:|---:|---:|---:|---:|---:|
| rewrite | 11 | 13.4766% | 15.6250% | 16.4062% | 0.0000% | 1 |
| rewrite | 23 | 10.7422% | 16.4062% | 13.2812% | 0.0000% | 1 |
| rewrite | 37 | 12.1094% | 15.6250% | 18.7500% | 0.0000% | 1 |
| no_links | 11 | 13.4766% | 15.6250% | 16.4062% | 0.0000% | 1 |
| no_links | 23 | 10.7422% | 16.4062% | 13.2812% | 0.0000% | 1 |
| no_links | 37 | 12.1094% | 15.6250% | 18.7500% | 0.0000% | 1 |

The rewrite checkpoints do not pass the registered capability screens. Identical accuracy to a no-links model is not evidence of a useful link mechanism. The per-model frozen links-off intervention and trace counts are reported below; nonzero link use alone is not semantic reasoning.

## Supplementary route diagnosis

These traces use the fixed first32 IID families (128 independently issued queries). They are post-evaluation diagnostics, not a new qualification criterion.

### Seed 11

All-token steps: 4744. Destination counts: `{'0': 4616, '2': 128}`. Value-edit counts: `{'1': 4744}`. Link-use counts: `{'0': 1376, '1': 3368}`. Operator counts: `{'2': 4744}`.

Final nonzero-slot count range: `[2, 2]`. Mean slot norms: `[5.554864, 0.0, 3.024717, 0.0, 0.0, 0.0, 0.0, 0.0]`. Answer prediction counts (token IDs): `{'13': 128}`. Maximum logit range across these examples: 0.00136804581.

### Seed 23

All-token steps: 4744. Destination counts: `{'0': 1360, '3': 3384}`. Value-edit counts: `{'1': 4744}`. Link-use counts: `{'1': 4744}`. Operator counts: `{'2': 4744}`.

Final nonzero-slot count range: `[2, 2]`. Mean slot norms: `[5.575358, 0.0, 0.0, 5.58221, 0.0, 0.0, 0.0, 0.0]`. Answer prediction counts (token IDs): `{'17': 128}`. Maximum logit range across these examples: 0.00105333328.

### Seed 37

All-token steps: 4744. Destination counts: `{'1': 720, '5': 3896, '6': 128}`. Value-edit counts: `{'0': 128, '1': 4616}`. Link-use counts: `{'0': 4616, '1': 128}`. Operator counts: `{'1': 128, '2': 4616}`.

Final nonzero-slot count range: `[2, 2]`. Mean slot norms: `[0.0, 5.54176, 0.0, 0.0, 0.0, 5.517634, 0.0, 0.0]`. Answer prediction counts (token IDs): `{'14': 128}`. Maximum logit range across these examples: 0.0308589935.

## Limits

Exact replay checks the frozen implementation and saved results; it does not prove architecture competence or optimal training. The route sample does not cover every possible input. A constant answer with nonconstant logits is a degenerate answer policy, not proof of literally input-independent computation. The one-link-per-slot machine and its straight-through optimizer remain only one implementation/training recipe. Registered conventional controls must also be considered before attributing failure to the structural hypothesis.

The JSON artifact retains per-phase route counts, slot norms, intervention scores, checkpoint identities, provenance and all independently recomputed metrics.
