"""Reproduce CSM-001 integrity and mechanism checks without fitting a model.

Run with the experiment's torch environment::

    python experiments/csm_foundation_001/verification.py

The script prints one JSON report and exits nonzero on failure. ``--output``
also saves that report. Dataset checks may inspect every symbolic label, but
neural checks use only random token tensors (seed 49001), fresh random weights,
and controlled-head fixtures. No checkpoint, training loop, optimizer, neural
benchmark score, or TEST capability evaluation is used.

The public-token parser and interpreter below do not call data.execute,
data.parse_input, data.serialize, or data.canonical_program. Generating the
fixture uses data.build_dataset; its labels are then independently checked.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from dataclasses import asdict, replace
import hashlib
import json
from pathlib import Path
import platform
import traceback

import torch
from torch.nn import functional as F

from baselines import build_matched_gru, build_matched_transformer
from data import build_dataset
from model import Config, RecordRewrite, hard_choice


ROOT = Path(__file__).resolve().parent
DATASET_SEED = 1701
RANDOM_SEED = 49001
TOLERANCE = 3e-5
PANEL_FAMILIES = {
    "train": 512, "dev": 64, "iid": 128, "composition": 128,
    "correction": 128, "long": 128, "counterfactual": 64,
}
REGISTERS = ("r0", "r1", "r2", "r3")
VALUES = tuple(f"v{i}" for i in range(8))


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stable_json(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def digest(value):
    return hashlib.sha256(stable_json(value).encode()).hexdigest()


def public_program(input_ids, vocabulary):
    """Strictly parse the visible input, without any evaluator metadata."""
    inverse = {value: key for key, value in vocabulary.items()}
    require(all(type(i) is int and i in inverse for i in input_ids), "Invalid input token ID")
    words = [inverse[i] for i in input_ids]
    require(len(words) >= 5 and words[0] == "<bos>", "Missing input BOS")
    require(words[-3] == "ask" and words[-1] == "?", "Input does not end before the answer")
    require(words[-2] in REGISTERS and words.count("ask") == 1, "Invalid or repeated query")
    require("<pad>" not in words and words.count("<bos>") == 1, "Unexpected special token")
    program, instruction = [], []
    for word in words[1:-3]:
        if word == ";":
            require(bool(instruction), "Empty instruction")
            program.append(tuple(instruction))
            instruction = []
        else:
            instruction.append(word)
    require(not instruction, "Instruction missing terminating semicolon")
    return tuple(program), words[-2]


def interpret(program):
    """Independent interpreter: dictionary state, public strings, modulo eight."""
    memory = {}
    for instruction in program:
        op = instruction[0]
        require(op in {"set", "copy", "sub"}, "Unknown public operator")
        require(len(instruction) == (4 if op == "sub" else 3), "Invalid operator arity")
        dst = instruction[1]
        require(dst in REGISTERS, "Invalid destination")
        if op == "set":
            require(instruction[2] in VALUES, "Invalid value literal")
            value = VALUES.index(instruction[2])
        elif op == "copy":
            require(instruction[2] in memory, "COPY reads uninitialized register")
            value = memory[instruction[2]]
        else:
            left, right = instruction[2:]
            require(left in memory and right in memory, "SUB reads uninitialized register")
            value = (memory[left] - memory[right]) % 8
        memory[dst] = value
    require(set(memory) == set(REGISTERS), "Incomplete initialization")
    return tuple(memory[name] for name in REGISTERS)


def canonical(program):
    names, rows = {}, []
    for instruction in program:
        row = []
        for word in instruction:
            if word in REGISTERS:
                if word not in names:
                    names[word] = f"r{len(names)}"
                word = names[word]
            row.append(word)
        rows.append(row)
    return rows


def check_dataset():
    dataset = build_dataset(DATASET_SEED)
    vocabulary = dataset.vocabulary
    public_tokens = ("<pad>", "<bos>", "set", "copy", "sub", ";", "ask", "?") + REGISTERS + VALUES
    require(vocabulary == {word: i for i, word in enumerate(public_tokens)}, "Unexpected public vocabulary")
    require(set(dataset.splits) == set(PANEL_FAMILIES), "Unexpected panels")
    owners = {name: {} for name in ("exact", "canonical", "family")}
    labels, counts, focal_counts = 0, {}, {}
    long_worlds, composition_worlds, correction_worlds = set(), set(), set()
    counterfactual_families = 0
    all_ids = set()
    final_states = {}
    for panel, rows in dataset.splits.items():
        families, worlds = defaultdict(list), defaultdict(list)
        focal = Counter()
        final_states[panel] = set()
        for row in rows:
            require(row.id not in all_ids, "Repeated example ID")
            all_ids.add(row.id)
            require(row.panel == panel, "Row panel mismatch")
            program, query = public_program(row.input_ids, vocabulary)
            state = interpret(program)
            query_index = REGISTERS.index(query)
            expected = state[query_index]
            require(row.answer_id == vocabulary[f"v{expected}"], f"Independent answer mismatch: {row.id}")
            require(tuple(row.metadata["final_state"]) == state, "Final state metadata mismatch")
            require(tuple(row.metadata["initial_state"]) == interpret(program[:4]), "Initial state metadata mismatch")
            require(row.metadata["query_register"] == query_index, "Query metadata mismatch")
            require(row.metadata["expected_value"] == expected, "Expected-value metadata mismatch")
            require(tuple(map(tuple, row.metadata["program"])) == program, "Program metadata mismatch")
            require(row.metadata["variant"] == row.metadata["variant_index"], "Variant aliases disagree")
            exact, normalized = digest(program), digest(canonical(program))
            require(exact == row.metadata["history_sha256"], "History hash mismatch")
            require(normalized == row.metadata["canonical_program_sha256"], "Canonical history hash mismatch")
            for kind, key in (("exact", exact), ("canonical", normalized), ("family", row.family_id)):
                previous = owners[kind].setdefault(key, panel)
                require(previous == panel, f"Cross-panel {kind} leakage")
            world = row.metadata["world_id"]
            variant = row.metadata["variant"]
            expected_world = f"{row.family_id}:v{variant}" if panel == "counterfactual" else row.family_id
            require(world == expected_world, "World grouping convention mismatch")
            target = row.metadata["target_register"]
            require(row.metadata["focus_register"] == (None if target is None else REGISTERS[target]),
                    "Target aliases disagree")
            if target == query_index:
                focal[f"v{expected}"] += 1
            entry = {"row": row, "program": program, "query": query_index, "state": state,
                     "canonical_hash": normalized}
            families[row.family_id].append(entry)
            worlds[world].append(entry)
            final_states[panel].add(state)
            labels += 1
            if panel in {"train", "dev", "iid"}:
                require(not any(a[0] == "copy" and b[0] == "sub" for a, b in zip(program, program[1:])),
                        "Held-out COPY->SUB order appears in training-family panels")
            if panel == "composition":
                copy, sub = program[-2:]
                require(copy[0] == "copy" and sub[0] == "sub" and copy[1] in sub[2:],
                        "Composition does not consume the copied value")
                require(target == REGISTERS.index(sub[1]), "Composition target is not SUB destination")
                swapped = program[:-1] + (("sub", sub[1], sub[3], sub[2]),)
                require(interpret(swapped)[target] != state[target], "SUB operand swap is nondiscriminating")
                copied = interpret(program[:-1])[REGISTERS.index(copy[1])]
                altered = program[:-2] + (("set", copy[1], f"v{(copied + 1) % 8}"), sub)
                require(interpret(altered)[target] != state[target], "Composition lacks causal COPY dependence")
                composition_worlds.add(world)
            if panel == "correction":
                copy, overwrite = program[-2:]
                require(copy[0] == "copy" and overwrite[0] == "set" and overwrite[1] == copy[2],
                        "Correction is not COPY followed by source overwrite")
                require(target == REGISTERS.index(copy[1]), "Correction target is not COPY destination")
                old = interpret(program[:-2])[REGISTERS.index(copy[2])]
                require(state[target] == old and state[REGISTERS.index(copy[2])] != old,
                        "Correction does not preserve the old copied value")
                correction_worlds.add(world)
            if panel == "long":
                require(row.metadata["distractor_count"] == 16 and len(program) == 24,
                        "Unexpected long-panel length")
                require(all(op[0] == "set" and op[1] != REGISTERS[target] for op in program[-16:]),
                        "Long-tail instruction affects focal register")
                require(interpret(program[:-16])[target] == state[target], "Paired long-base answer changed")
                long_worlds.add(world)
        require(len(families) == PANEL_FAMILIES[panel], "Wrong family count")
        expected_rows = PANEL_FAMILIES[panel] * (16 if panel == "counterfactual" else 4)
        require(len(rows) == expected_rows, "Wrong panel row count")
        for world_entries in worlds.values():
            require(len(world_entries) == 4 and {e["query"] for e in world_entries} == set(range(4)),
                    "World does not contain all four independent queries")
            require(len({e["program"] for e in world_entries}) == 1, "Queries within a world use different histories")
        for family_id, entries in families.items():
            require(len(entries) == (16 if panel == "counterfactual" else 4), "Incomplete family")
            normalized_hashes = sorted({e["canonical_hash"] for e in entries})
            require(digest(normalized_hashes) == family_id, "Family hash does not describe its programs")
            if panel != "counterfactual":
                require({e["row"].metadata["variant"] for e in entries} == {0}, "Unexpected ordinary variant")
                continue
            target = entries[0]["row"].metadata["target_register"]
            require(all(e["row"].metadata["target_register"] == target for e in entries), "CF target changes")
            focal_entries = sorted((e for e in entries if e["query"] == target),
                                   key=lambda e: e["row"].metadata["variant"])
            require(len(focal_entries) == 4, "CF does not have four focal examples")
            require({e["row"].metadata["variant"] for e in focal_entries} == set(range(4)), "Missing CF variant")
            require(len({e["state"][target] for e in focal_entries}) == 4, "CF quartet has repeated focal answers")
            programs = [e["program"] for e in focal_entries]
            require(len({p[4:] for p in programs}) == 1, "CF variants changed an instruction tail")
            changed = [i for i in range(4) if len({p[i] for p in programs}) > 1]
            require(len(changed) == 1, "CF does not vary exactly one initial SET")
            initial_index = changed[0]
            copy, sub, overwrite_source, overwrite_other = programs[0][4:]
            require(copy[0] == "copy" and sub[0] == "sub", "CF operators are malformed")
            source, copied, output, unrelated = copy[2], copy[1], sub[1], sub[3]
            require(len({source, copied, output, unrelated}) == 4 and sub[2] == copied,
                    "CF introduces register aliasing or lacks the COPY dependency")
            require(target == REGISTERS.index(output), "CF target is not computed output")
            require(all(p[initial_index][1] == source for p in programs), "CF changes an unrelated initial value")
            require(overwrite_source[:2] == ("set", source) and overwrite_other[:2] == ("set", unrelated),
                    "CF does not overwrite both original operands later")
            unchanged = {REGISTERS.index(source), REGISTERS.index(unrelated)}
            for register in unchanged:
                require(len({e["state"][register] for e in focal_entries}) == 1, "CF overwrite is not fixed")
            for register in {REGISTERS.index(copied), target}:
                require(len({e["state"][register] for e in focal_entries}) == 4, "CF expected state effect missing")
            counterfactual_families += 1
        counts[panel] = {"families": len(families), "worlds": len(worlds), "examples": len(rows)}
        focal_counts[panel] = {word: focal[word] for word in VALUES}
        require(focal_counts[panel] == dataset.manifest["validation"]["counts"][panel]["focal_answer_counts"],
                "Manifest focal counts disagree with independent counts")
        payload = "".join(stable_json(asdict(row)) + "\n" for row in rows).encode()
        require(hashlib.sha256(payload).hexdigest() == dataset.manifest["panel_sha256"][panel],
                "Manifest panel hash mismatch")
    require(labels == 5376 and counterfactual_families == 64, "Unexpected dataset total")
    require(len(long_worlds) == len(composition_worlds) == len(correction_worlds) == 128,
            "Missing focal diagnostic worlds")
    panels = list(dataset.splits)
    overlaps = {f"{a}:{b}": len(final_states[a] & final_states[b])
                for i, a in enumerate(panels) for b in panels[i + 1:]}
    require(overlaps == dataset.manifest["validation"]["final_state_overlap_counts"], "State overlap report mismatch")
    rebuilt = build_dataset(DATASET_SEED)
    require(rebuilt.manifest == dataset.manifest, "Same-seed build is not deterministic")
    saved_dir = ROOT / "data" / "registers"
    saved_verified = False
    if saved_dir.exists():
        for panel, rows in dataset.splits.items():
            payload = "".join(stable_json(asdict(row)) + "\n" for row in rows).encode()
            require((saved_dir / f"{panel}.jsonl").read_bytes() == payload, "Saved rows differ from generated fixture")
        require(json.loads((saved_dir / "manifest.json").read_text()) == dataset.manifest,
                "Saved data manifest differs from generated fixture")
        saved_verified = True
    return {"independently_interpreted_labels": labels, "panels": counts,
            "cross_panel_exact_history_overlap": 0, "cross_panel_canonical_program_overlap": 0,
            "cross_panel_family_overlap": 0, "counterfactual_distinct_answer_quartets": counterfactual_families,
            "composition_causal_and_order_checks": len(composition_worlds),
            "copy_source_overwrite_checks": len(correction_worlds), "paired_long_base_checks": len(long_worlds),
            "focal_answer_counts": focal_counts, "final_state_disjoint": not any(overlaps.values()),
            "deterministic_rebuild": True, "saved_dataset_verified": saved_verified}


def record_config(mode="rewrite"):
    options = json.loads((ROOT / "config.json").read_text())
    return Config(vocab_size=20, width=options["width"], slots=options["slots"],
                  operators=options["operators"], inner=options["inner"], mode=mode,
                  temperature=options["temperature"])


def models():
    configuration = record_config()
    primary = RecordRewrite(configuration)
    target = primary.parameter_count()
    return {"rewrite": primary,
            "ring_write": RecordRewrite(replace(configuration, mode="ring_write")),
            "no_links": RecordRewrite(replace(configuration, mode="no_links")),
            "gru": build_matched_gru(target, configuration.vocab_size, configuration.width),
            "transformer": build_matched_transformer(target, configuration.vocab_size, configuration.width)}


def difference(actual, expected, name, *, exact=False):
    error = float((actual - expected).abs().max())
    if exact:
        require(torch.equal(actual, expected), f"{name}: exact equality failed (max abs {error})")
    else:
        require(torch.allclose(actual, expected, atol=TOLERANCE, rtol=TOLERANCE),
                f"{name}: tolerance exceeded (max abs {error})")
    return error


def one_hot(tensor, name):
    require(bool(((tensor == 0) | (tensor == 1)).all()), f"{name} contains nonbinary weights")
    require(bool((tensor.sum(-1) == 1).all()), f"{name} is not exactly one-hot")


def force(head, selected):
    with torch.no_grad():
        head.weight.zero_()
        head.bias.fill_(-20)
        head.bias[selected] = 20


def check_hard_choice():
    logits = torch.randn(7, 8, requires_grad=True)
    chosen = hard_choice(logits)
    one_hot(chosen, "hard_choice")
    require(torch.equal(chosen.argmax(-1), logits.argmax(-1)), "Hard choice does not select argmax")
    tie = hard_choice(torch.zeros(2, 8))
    require(bool((tie.argmax(-1) == 0).all()), "Tie rule changed")
    (chosen * torch.arange(8, dtype=chosen.dtype)).sum().backward()
    require(logits.grad is not None and bool(torch.isfinite(logits.grad).all()), "Surrogate gradient is not finite")
    require(float(logits.grad.abs().sum()) > 0, "Surrogate gradient is absent")
    return {"exact_one_hot": True, "argmax_and_tie_rule": True,
            "finite_nonzero_surrogate_gradient": True, "optimizer_steps": 0}


def check_causality_and_modes():
    result = {}
    tokens = torch.randint(20, (2, 41))
    prefix = 19
    changed = tokens.clone()
    changed[:, prefix:] = (changed[:, prefix:] + 1) % 20
    with torch.no_grad():
        for name, model in models().items():
            model.eval()
            full = model(tokens)
            future = model(changed)
            short = model(tokens[:, :prefix])
            exact = name != "transformer"
            future_error = difference(full[:, :prefix], future[:, :prefix], name + " changed future", exact=exact)
            short_error = difference(full[:, :prefix], short, name + " short prefix", exact=exact)
            model.train()
            training = model(tokens)
            mode_error = difference(full, training, name + " train/eval", exact=True)
            result[name] = {"changed_future_max_abs": future_error, "short_prefix_max_abs": short_error,
                            "train_eval_max_abs": mode_error}
    return result


def check_record_state():
    results = {}
    with torch.no_grad():
        for mode in ("rewrite", "ring_write", "no_links"):
            model = RecordRewrite(record_config(mode)).eval()
            cfg = model.config
            state = model.init_state(2, "cpu")
            state.values.uniform_(-0.5, 0.5)
            state.history.normal_()
            state.links = state.links.roll(1, -1)
            steps = 2 * cfg.slots + 5
            tokens = torch.randint(20, (2, steps))
            for index, token in enumerate(tokens.unbind(1)):
                previous_values, previous_links = state.values.clone(), state.links.clone()
                _, state, trace = model.step(token, state, return_trace=True)
                destination = trace["destination"]
                untouched = torch.arange(cfg.slots)[None, :] != destination[:, None]
                require(torch.equal(previous_values[untouched], state.values[untouched]), "Unselected value row changed")
                require(torch.equal(previous_links[untouched], state.links[untouched]), "Unselected link row changed")
                one_hot(state.cursor, "record cursor")
                one_hot(state.links, "record link rows")
                require(torch.equal(state.cursor.argmax(-1), destination), "Cursor differs from destination")
                require(state.position == index + 1, "Record position counter mismatch")
                require(bool((state.values.abs() <= 1).all()), "Convex bounded update left [-1,1]")
                for name in ("first", "second", "destination"):
                    require(bool(((trace[name] >= 0) & (trace[name] < cfg.slots)).all()), "Pointer out of bounds")
                if mode == "ring_write":
                    require(bool((destination == index % cfg.slots).all()), "Ring destination sequence mismatch")
            logical_elements = sum(t.numel() for t in (state.values, state.links, state.cursor, state.history))
            require(logical_elements == 2 * model.state_numel(), "Record logical state accounting mismatch")
            results[mode] = {"steps": steps, "one_hot_links_and_cursor": True,
                             "only_destination_storage_rows_change": True,
                             "bounded_values": True, "logical_elements_batch2": logical_elements}
    return results


def check_noops_and_link_following():
    with torch.no_grad():
        model = RecordRewrite(record_config()).eval()
        cfg = model.config
        require(cfg.slots >= 7, "Controlled fixture requires at least seven slots")
        force(model.first_address, 0)
        force(model.second_address, 1)
        force(model.destination, 2)
        force(model.use_link, 0)
        model.write_gate.weight.zero_()
        model.write_gate.bias.zero_()
        model.transform[0].weight.zero_()
        model.transform[0].bias.zero_()
        model.transform[2].weight.zero_()
        model.transform[2].bias.fill_(0.8)
        for value_edit, link_edit in ((0, 0), (0, 1), (1, 0), (1, 1)):
            force(model.value_edit, value_edit)
            force(model.link_edit, link_edit)
            state = model.init_state(2, "cpu")
            state.values.uniform_(-0.5, 0.5)
            state.history.normal_()
            old_values, old_links = state.values.clone(), state.links.clone()
            _, after, trace = model.step(torch.randint(20, (2,)), state, return_trace=True)
            require(bool((trace["edits_value"] == value_edit).all()), "Controlled value-edit head failed")
            require(bool((trace["edits_link"] == link_edit).all()), "Controlled link-edit head failed")
            if value_edit == 0:
                require(torch.equal(after.values, old_values), "Value no-op is not exact")
                require(bool((trace["gate"] == 0).all()), "Value no-op gate is nonzero")
            else:
                require(not torch.equal(after.values[:, 2], old_values[:, 2]), "Positive value-write fixture did not write")
            if link_edit == 0:
                require(torch.equal(after.links, old_links), "Link no-op is not exact")
            else:
                require(bool((after.links[:, 2].argmax(-1) == 1).all()), "Controlled link edit did not persist")
            require(after.position == 1 and bool((after.cursor.argmax(-1) == 2).all()),
                    "No-op fixture should still advance cursor/position")
        # Write a link to slot 2 into row 4, then follow that persisted link.
        force(model.destination, 4)
        force(model.second_address, 2)
        force(model.link_edit, 1)
        force(model.value_edit, 0)
        state = model.init_state(2, "cpu")
        state.values.uniform_(-0.5, 0.5)
        _, state, _ = model.step(torch.randint(20, (2,)), state, return_trace=True)
        require(bool((state.links[:, 4].argmax(-1) == 2).all()), "Link was not stored in selected destination")
        force(model.first_address, 4)
        force(model.second_address, 6)
        force(model.destination, 5)
        force(model.use_link, 1)
        force(model.link_edit, 0)
        observed = []
        hook = model.transform.register_forward_pre_hook(lambda module, inputs: observed.append(inputs[0].clone()))
        try:
            _, after, trace = model.step(torch.randint(20, (2,)), state, return_trace=True)
        finally:
            hook.remove()
        require(bool((trace["second"] == 2).all()), "Linked read ignored stored link")
        require(torch.equal(observed[0][:, 2 * cfg.width:3 * cfg.width], state.values[:, 2]),
                "Transform did not receive the linked record's value")
        require(torch.equal(after.links, state.links), "Following a link with link-edit off changed links")
    return {"value_link_edit_combinations": 4, "exact_storage_noops": True,
            "positive_value_and_link_write_controls": True, "persisted_link_following": True,
            "linked_payload_reaches_transform": True,
            "noop_scope": "values and links only; cursor, token history and position may advance"}


def check_no_links_equivalence():
    with torch.no_grad():
        rewrite = RecordRewrite(record_config()).eval()
        disabled = RecordRewrite(record_config("no_links")).eval()
        disabled.load_state_dict(rewrite.state_dict())
        tokens = torch.randint(20, (2, 29))
        error = difference(disabled(tokens), rewrite(tokens, {"links_off": True}),
                           "no_links versus rewrite+links_off", exact=True)
        left = disabled.init_state(2, "cpu")
        right = rewrite.init_state(2, "cpu")
        for token in tokens.unbind(1):
            _, left = disabled.step(token, left)
            _, right = rewrite.step(token, right, {"links_off": True})
            for field in ("values", "links", "cursor", "history"):
                require(torch.equal(getattr(left, field), getattr(right, field)), "Disabled-link state mismatch")
            require(left.position == right.position, "Disabled-link position mismatch")
    return {"max_abs": error, "all_explicit_state_equal": True, "identical_parameter_tensors": True}


def check_full_cached_and_reset():
    results = {}
    with torch.no_grad():
        all_models = models()
        window = all_models["transformer"].config.max_context
        length, reset_at = 2 * window + 17, window + 5
        tokens = torch.randint(20, (2, length))
        for name, model in all_models.items():
            model.eval()
            cases = {}
            for reset in (None, reset_at):
                intervention = {} if reset is None else {"reset_at": reset}
                full = model(tokens, intervention)
                state = model.init_state(2, "cpu")
                reference = model.init_state(2, "cpu")
                cached, manual = [], []
                for index, token in enumerate(tokens.unbind(1)):
                    if name in {"rewrite", "ring_write", "no_links"}:
                        # RecordRewrite.forward owns reset handling; its step is
                        # deliberately a primitive receiving an explicit state.
                        if index == reset:
                            state = model.init_state(2, "cpu")
                            state.position = index
                        logits, state = model.step(token, state)
                    else:
                        logits, state = model.step(token, state, intervention)
                    if index == reset:
                        reference = model.init_state(2, "cpu")
                        if isinstance(reference, dict):
                            reference["position"] = index
                        else:
                            reference.position = index
                    ref_logits, reference = model.step(token, reference)
                    cached.append(logits)
                    manual.append(ref_logits)
                cached = torch.stack(cached, 1)
                manual = torch.stack(manual, 1)
                exact = name != "transformer"
                full_error = difference(full, cached, name + " full/cache", exact=exact)
                reset_error = difference(cached, manual, name + " explicit reset reference", exact=True)
                position = state["position"] if isinstance(state, dict) else state.position
                require(position == length, "Cached absolute position changed after reset")
                case = {"full_cache_max_abs": full_error, "explicit_reset_reference_max_abs": reset_error,
                        "final_absolute_position": position}
                if name == "transformer":
                    expected_length = min(length - (reset or 0), window)
                    require(all(k.shape[-2] == v.shape[-2] == expected_length for k, v in state["kv"]),
                            "Transformer KV cache length mismatch")
                    expected_numel = 2 * 2 * model.config.layers * expected_length * model.config.width
                    require(model.state_numel(state) == expected_numel, "Transformer logical state accounting mismatch")
                    case.update({"cache_length": expected_length, "logical_elements_batch2": expected_numel})
                cases["no_reset" if reset is None else f"reset_at_{reset}"] = case
            results[name] = cases
    return {"random_batch": 2, "sequence_length": length, "transformer_window": window,
            "reset_at": reset_at, "post_reset_length_exceeds_window": length - reset_at > window,
            "models": results}


def check_frozen_snapshot():
    path = ROOT / "frozen_manifest.json"
    if not path.exists():
        return {"present": False, "checked": False, "reason": "Freeze has not been written"}
    frozen = json.loads(path.read_text())
    for section in ("source_sha256", "input_sha256"):
        for name, expected in frozen[section].items():
            require(sha(ROOT / name) == expected, f"Frozen artifact changed: {name}")
    return {"present": True, "checked": True, "freeze_sha256": sha(path),
            "source_files": len(frozen["source_sha256"]), "input_files": len(frozen["input_sha256"])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Optional JSON report path; stdout always receives JSON")
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    checks = []
    routines = (
        ("independent_public_token_dataset_integrity", check_dataset),
        ("hard_choice_and_surrogate_gradient", check_hard_choice),
        ("causal_prefix_and_hard_train_eval_equality", check_causality_and_modes),
        ("record_pointer_destination_and_ring_invariants", check_record_state),
        ("exact_storage_noops_and_persisted_link_following", check_noops_and_link_following),
        ("no_links_matches_rewrite_with_links_off", check_no_links_equivalence),
        ("full_cached_and_explicit_reset_parity", check_full_cached_and_reset),
        ("frozen_snapshot_unchanged", check_frozen_snapshot),
    )
    for name, routine in routines:
        torch.manual_seed(RANDOM_SEED)
        try:
            checks.append({"name": name, "passed": True, "details": routine()})
        except Exception as exc:
            checks.append({"name": name, "passed": False, "error": str(exc),
                           "traceback": traceback.format_exc()})
    passed = all(check["passed"] for check in checks)
    report = {
        "experiment": "CSM-FOUNDATION-001", "verification_version": 1,
        "passed": passed, "checks_passed": sum(check["passed"] for check in checks),
        "checks_total": len(checks), "dataset_seed": DATASET_SEED, "random_neural_seed": RANDOM_SEED,
        "neural_inputs": "random tokens only; no dataset example is passed to a neural model",
        "neural_capability_scoring": False, "optimizer_steps": 0,
        "environment": {"python": platform.python_version(), "torch": torch.__version__,
                        "device": "cpu", "torch_threads": torch.get_num_threads()},
        "comparison_tolerance": {"transformer_atol": TOLERANCE, "transformer_rtol": TOLERANCE,
                                 "record_and_gru": "exact"},
        "source_sha256": {name: sha(ROOT / name) for name in
                          ("verification.py", "data.py", "model.py", "baselines.py", "config.json")},
        "checks": checks,
    }
    output = json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(output)
    print(output, end="")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
