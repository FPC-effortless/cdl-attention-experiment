"""Run the registered jobs, retaining subprocess output and exit codes."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "config.json").read_text())


def jobs():
    for task in ("structured", "lm"):
        for seed in CONFIG["seeds"]:
            for arm in CONFIG["arms"]:
                yield task, arm, seed


def invoke(command, job):
    task, arm, seed = job
    logs = ROOT / "orchestration"
    logs.mkdir(exist_ok=True)
    output = logs / f"{command}-{task}-{arm}-{seed}.txt"
    if output.exists():
        raise RuntimeError(f"Refusing to overwrite process receipt: {output}")
    start = datetime.now(timezone.utc).isoformat()
    with output.open("w") as stream:
        result = subprocess.run([sys.executable, str(ROOT / "run.py"), command,
                                 "--task", task, "--arm", arm, "--seed", str(seed)],
                                stdout=stream, stderr=subprocess.STDOUT, cwd=ROOT)
    receipt = {"command": command, "task": task, "arm": arm, "seed": seed,
               "start_utc": start, "finish_utc": datetime.now(timezone.utc).isoformat(),
               "exit_code": result.returncode, "console": str(output.relative_to(ROOT))}
    print(json.dumps(receipt), flush=True)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("train-all", "evaluate-all"))
    args = parser.parse_args()
    receipts = []
    if args.command == "train-all":
        with ThreadPoolExecutor(max_workers=3) as workers:
            futures = [workers.submit(invoke, "train", job) for job in jobs()]
            for future in as_completed(futures):
                receipts.append(future.result())
    else:
        # Fixed prospective order, rotated by two arms per seed to reduce a
        # single arm always receiving the earliest/latest measurement.
        for task in ("structured", "lm"):
            for seed_index, seed in enumerate(CONFIG["seeds"]):
                arms = CONFIG["arms"]
                shift = 2 * seed_index % len(arms)
                for arm in arms[shift:] + arms[:shift]:
                    receipts.append(invoke("evaluate", (task, arm, seed)))
    target = ROOT / "orchestration" / f"{args.command}.json"
    target.write_text(json.dumps(receipts, indent=2) + "\n")
    if any(row["exit_code"] != 0 for row in receipts):
        raise SystemExit("One or more registered subprocesses failed; inspect preserved receipts")


if __name__ == "__main__":
    main()
