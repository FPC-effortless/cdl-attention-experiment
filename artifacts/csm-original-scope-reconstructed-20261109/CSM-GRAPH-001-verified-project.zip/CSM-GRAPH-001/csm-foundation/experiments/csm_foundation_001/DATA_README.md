# CSM Foundation 001 data contract

This is a finite-register **answer-focused diagnostic**, not a natural-language
benchmark. The model receives only raw word-token IDs ending in `ask rN ?`.
Its label is the next value-token ID. It receives no parsed instruction, hidden
register address, event boundary metadata, gold intermediate state, or support
record. Visible words such as `copy` and `r0` are part of the declared input
language, shared by all models.

There are four registers and eight values. SET replaces one value, COPY copies
the source value at that moment, and SUB reads both ordered source values then
writes their difference modulo eight. Source/destination aliasing follows that
read-before-write rule. Every history initializes all four registers. All four
queries are serialized independently; earlier gold QA pairs never enter later
queries. The symbolic interpreter is an evaluator-only privileged reference.

## Panels

| Panel | Families | Examples | Purpose |
|---|---:|---:|---|
| train | 512 | 2,048 | Four operations after four initialization SETs |
| dev | 64 | 256 | Same distribution, separate program families |
| iid | 128 | 512 | Fresh ordinary program families |
| composition | 128 | 512 | Final dependent COPY then SUB; ordered operands change the focal result |
| correction | 128 | 512 | COPY then overwrite its source; copied destination must retain the old value |
| long | 128 | 512 | Add 16 SET distractors to other registers; one focal register is unchanged |
| counterfactual | 64 | 1,024 | Four variants and four independent queries per family |

Every immediately adjacent COPY→SUB order is absent throughout train, dev and
IID, whether dependent or not. Composition cases require actual dependence on
the copied result. Individual primitives are familiar. Longer indirect dependency
chains may occur in training, so the composition claim is limited to this held-
out adjacent motif, not arbitrary novel programs or unsupplied operators.

Composition, correction and long panels identify one evaluator-only focal query.
Report focal accuracy separately: the other three queries may not require the
specific mechanism under test. Whole-world exactness uses all four queries.

All 64 counterfactual families vary one relevant initial value, changing the
copied/intermediate results even after that source is overwritten. Four distinct
valid values yield four distinct expected answers to the designated target query.
SUB uses distinct destination, left-source, and right-source registers, matching
the training convention. Both source registers can subsequently be overwritten
without retroactively changing the computed result.
Quartet exactness uses just that query across four variants; whole-world exactness
uses all four queries within each variant. The long panel separately checks that
irrelevant SET updates preserve the focal register. Counterfactual values are not
selected using any trained model result.

## Split guarantees and limits

The generator excludes exact history duplicates and canonical programs equal
under register renaming across all panels. All queries and counterfactual
variants stay in their family. These checks are rerun by parsing the serialized
model input and interpreting it without trusting stored answer labels.

**Final-state disjointness is not guaranteed.** There are only 8^4 = 4,096
possible final states. The manifest reports every pairwise panel overlap and
unique-state count. These data test execution over distinct histories and a
held-out operation pattern, not unseen ontologies or wholly unseen state space.

Answer frequencies are sampled and disclosed, not forced to balance after
observing outcomes. The manifest provides every value count and the largest
class fraction. A query-only majority baseline is fit only on training queries;
a last-explicit-value baseline, a train-fitted most-frequent-value baseline,
and the exact interpreter are also reported.

Counts and shortcut baselines are additionally reported on focal queries only.
Composition focal answers exclude values zero and four by design, because those
are exactly the modular differences unchanged by operand reversal; a uniform
eight-value guess is therefore not a sufficient contextual baseline. The
manifest includes focal class frequencies and their largest fraction. That
largest fraction is a descriptive, label-informed oracle constant upper bound,
not a train-fitted model. `train_fitted_most_frequent_value_accuracy` always uses
the global training majority; `train_fitted_query_only_accuracy` uses training
majorities conditioned only on the query register. The additional
`most_frequent_literal_value_accuracy` predicts the most frequent explicit value
token in that history, breaking ties by the lowest value. It does not execute
COPY/SUB. Focal denominators are 128 per composition/correction/long panel and
256 for the 64 counterfactual target quartets. Panels without a designated target
have null focal rates rather than a zero or perfect score.

## API and preservation

`build_dataset(seed=1701)` returns a Dataset with `splits`, `vocabulary`, and
`manifest`. `panels` and `vocab` are aliases; `dataset["train"]` is supported.
Examples expose `id`, `family_id`, `panel`, `input_ids`, `answer_id`, and evaluator-
only `metadata`. Trainers must explicitly extract the first five required fields
and never forward metadata to a model.

Metadata uses integer `query_register` (0–3), integer-or-null `target_register`,
integer `variant` (also `variant_index`), `world_id`, integer `expected_value`,
`initial_state`, `final_state`, and `program`. Ordinary `world_id` equals
`family_id`; counterfactual `world_id` is `family_id + ':v' + variant`. The older
human-readable `focus_register` string is retained as a convenience only.

`dataset.save_dataset(directory)` or `save_dataset(directory, dataset)` writes
seven JSONL files and a manifest. Panel SHA-256 hashes cover exact serialized
rows; the source hash is retained. Mutating rows after manifest generation is
rejected on save. No training, model selection, or asynchronous job is started.

Run a deterministic generation/validation smoke with:

```bash
python experiments/csm_foundation_001/data.py --seed 1701 --output /tmp/csm-data
```
