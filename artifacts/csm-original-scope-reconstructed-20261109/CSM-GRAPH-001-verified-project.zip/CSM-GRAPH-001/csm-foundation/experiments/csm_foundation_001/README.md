# CSM-FOUNDATION-001

A complete experimental autoregressive backbone based on persistent records and learned local edits, together with a prospectively specified, bounded CPU experiment.

**Status:** all 30 fits and evaluations completed; the proposed model failed the registered execution screens and collapsed to constant answers. Independent checkpoint replay reproduced the failure. Byte prediction improved over its own ablations but remained substantially worse than the GRU and Transformer controls. See `RESULTS.md`. The name Compositional State Model is provisional.

## What the machine does

Imagine eight small working notes and one arrow on each note. For every input token, the machine chooses two notes, applies a learned ordered operation, and decides which note and arrow to change. Its next computation starts from this changed workspace. The notes, arrows and choices are learned; the generator's symbolic registers and operations are never handed to the model.

The implementation has no Transformer or SSM block. It is a nonlinear recurrent machine with clear ancestry in neural production systems. Hard forward selection is trained with a biased straight-through gradient, and the current implementation uses dense tensors rather than a sparse execution kernel.

## Experiment

Five approximately parameter-matched arms are trained with seeds 11, 23, 37:

- Proposed record rewriting.
- Fixed ring destinations, isolating learned write-location selection.
- Disabled link traversal, isolating explicit pointer use.
- Conventional GRU.
- Conventional two-layer Transformer.

Two separate objectives are used:

1. **Controlled state execution:** learn from serialized SET/COPY/SUB programs and a final answer label.512 updates, batch 16. Tests cover held-out operator order, copied values after source changes, irrelevant writes and complete counterfactual quartets.
2. **Ordinary byte prediction:** next-token cross-entropy on pinned TinyShakespeare.256 updates, batch 16, context 64. Every held-out target after the first byte is scored.

All30 final checkpoints are frozen before neural held-out scoring. See `PROTOCOL.md` for gates, controls, limitations and exact computation, and `PREFIT_REVIEW.md` for prospective review findings.

## Files

| File | Purpose |
|---|---|
| `model.py` | Complete learned record backbone and mechanistic ablations |
| `baselines.py` | Conventional GRU and causal Transformer, including real cached stepping |
| `data.py`, `DATA_README.md` | Finite-register generator, validation, documented supervision |
| `config.json`, `PROTOCOL.md` | Fixed budget and prospective interpretation |
| `run.py`, `launch.py` | Preparation, immutable fits, training closure and evaluation |
| `verification.py` | Independent label interpreter and mechanism integrity checks |
| `corpus_manifest.json` | Pinned upstream source, hashes and split provenance |
| `frozen_manifest.json` | Exact source/data/schedule hashes and environment |
| `training_closed.json` | Hashes of all registered training evidence before TEST opens |
| `runs/` | Per-update logs, checkpoints, per-example or per-block outcomes |
| `RESULTS.md`, `summary.json`, `tables/` | Complete results, interpretation and per-seed tables |
| `evidence/` | Compact evaluation and completion receipts |
| `POSTFIT_AUDIT_*.md`, `replay_*_audit.py` | Independent checkpoint replay and diagnostic evidence |

## Reproduction

Use Python3.12 and the versions in `requirements.txt`. Install the CPU Torch wheel with its index:

```bash
python -m pip install numpy==2.3.5
python -m pip install torch==2.5.1+cpu --index-url https://download.pytorch.org/whl/cpu
```

From a clean checkout of the preregistration commit (before `runs/` or `training_closed.json` exist), change into this experiment directory:

```bash
python verification.py
# The preregistration commit already includes the frozen inputs and schedules.
# For a genuinely new registration only: python run.py prepare
python launch.py train-all
python run.py close-training
python launch.py evaluate-all
python analyze.py
```

The runner deliberately refuses overwriting an existing fit, freeze or evaluation. Keep failed attempts and new experiments in separate reviewed directories; do not silently modify this registration after observing outcomes.

Training uses three subprocesses, each with one Torch CPU thread. Evaluation and latency measurements are sequential. A new machine can produce different timing and small numerical differences; the saved original checkpoints and per-example evidence support independent replay.

The branch is unpublished pending explicit publication approval. The review archive contains the unpublished Git commits and full raw evidence. Checkpoints and process logs are excluded from ordinary Git tracking; restore the archive's raw evidence under this experiment directory before running the replay or analysis commands on the completed run.

## Research boundaries

The synthetic tokenizer, finite grammar, register symbols and operations are supplied. Their answer-only objective is not language-model training. Final semantic states can overlap across panels even though histories and complete families do not. Every graph slot has one untyped pointer; there is no dynamic structure growth or typed relation discovery.

This budget does not establish convergence or optimally tuned baselines. If all arms fail the behavioral screen, optimization, data and capacity remain possible explanations. If no-links matches the complete model, links have not demonstrated a contribution. Do not combine these tasks into one headline score or promote low memory use before checking quality.

Close prior art: [Neural Production Systems](https://arxiv.org/abs/2103.01937); [Graph Rewriting for Graph Neural Networks](https://arxiv.org/abs/2305.18632). This is not an exhaustive novelty review.
