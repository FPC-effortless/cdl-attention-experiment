# CSM-FOUNDATION-001: implemented, tested, not qualified

**The proposed record-rewriting backbone is executable, but this version did not learn the controlled state-execution task. It should not yet be adopted as a new architecture foundation.** All30 registered fits and all 30 held-out evaluations completed without a process error. The full model averaged12.11% IID answer accuracy and solved no complete counterfactual quartet. Its two structural ablations had exactly the same answer accuracies.

There is a limited positive result on ordinary byte prediction: the full model beat both its own ablations in each of the three seeds. However, approximately parameter-matched GRU and Transformer controls were substantially better. The experiment therefore supplies a working implementation and a bounded negative qualification result, not evidence of a competitive new model family.

The conventional controls also failed the strict execution screens. This small experiment does not distinguish the best possible expressivity of these architectures from difficulties caused by optimization, data, capacity or the short training budget.

## 1. What was built

Imagine a machine with eight working notes. Each note contains a learned numerical representation and one arrow pointing to another note. At each input token, it selects notes, applies a learned operation, and changes a selected note or arrow. The next input is processed using the altered workspace.

This is a complete autoregressive backbone: token embedding, causal local frontend, state transition and vocabulary output. It is not a memory module attached to a separate Transformer. It contains no conventional Transformer or structured/selective SSM block. It remains a nonlinear recurrent model in the broad sense: information is carried forward in state.

The implemented primitive is:

1. Read the current input and active record.
2. Select a first record.
3. Select a second record directly or follow the first record's pointer.
4. Select one of four learned operation codes and transform the ordered values.
5. Select a destination; optionally edit its value and outgoing pointer.
6. Predict the next token from the resulting destination value.

The internal operation codes are not supplied SET/COPY/SUB labels. The model receives register names and operation symbols as input tokens. It receives no supervised mapping from those names to internal slots, no intermediate register values, and no target read or write addresses. The synthetic vocabulary is supplied; the model must learn how to use it.

```mermaid
flowchart TD
    I["Input token"] --> C["Choose records and operation"]
    M["Persistent records and links"] --> C
    C --> T["Transform ordered values"]
    T --> U["Edit selected record or link"]
    U --> M
    U --> O["Predict next token"]
```

### Relation to LRC and existing architectures

The intended change from the occurrence-memory LRC previously inspected is persistent modification of the working representation. Reading old records and composing a representation is useful; here, composition can change the records and links that later computation will encounter. The practical question is whether those edits become useful learned computation.

This difference should not be promoted into an unsupported novelty claim. [Neural Production Systems](https://arxiv.org/abs/2103.01937) already studies slots, rule selection and selected entity updates. [Graph Rewriting for Graph Neural Networks](https://arxiv.org/abs/2305.18632) studies graph rewriting as a formalization and engineering approach for neural computation. The prototype belongs near this existing research, and its distinct contribution would need sharper evidence and a fuller prior-art comparison.

| System | Relevant computational emphasis | What this pilot can say |
|---|---|---|
| Standard causal Transformer | Token representations interact through causal attention | A conventional control is implemented and measured |
| Conventional structured/selective SSM | State evolves through a structured transition | No such core is used here; no SSM comparison was run |
| Earlier occurrence-memory LRC | Address stored occurrences and compose retrieved information | Motivates the addressing/composition distinction, not a baseline result in this experiment |
| CSM-001 | Hard-select records and persist selected value/pointer edits | Implemented; useful structured behavior was not learned at this budget |

In the very broad mathematical sense, any recurrent machine can be represented as a state-space system. The architectural claim concerns the actual computational primitive and implementation, not escaping that general mathematical description.

### Exact scope of the graph

There are eight fixed slots, each with 32 learned features and one untyped outgoing pointer. A pointer names a current mutable slot, not an immutable historical occurrence. Overwriting the slot changes what existing pointers observe. There is no dynamic graph growth, explicit semantic role inventory, multiple typed relations per node or adaptive number of reasoning steps.

The model has exact value and link no-op choices. Categorical decisions are hard in both training and evaluation, with a biased softmax straight-through gradient used for learning. The current implementation executes dense tensors for selection and masking; it does not demonstrate sparse memory traffic as capacity grows.

The persistent logical FP32 tensors occupy1,568 bytes per example, including record values, dense one-hot links, cursor and two previous embeddings. This is not peak RAM or training-memory consumption.

## 2. How the experiment was controlled

The preregistration commit is `dc9a262859c60be7ad67902a46439cd0f377fdeb`, based on main `c26ff92b8ecec74045bd2393cdaf956c99a0d9d5`. Frozen manifest SHA256:

```text
66decc423fc8849515213acf1ddd409c3f203507a1c9d955a864611dc16e8282
```

Five arms were fit with seeds 11, 23, 37 on two separate tasks:30 fits total. The three record arms start from identical parameter tensors within each seed. Every arm receives the same frozen example IDs or byte offsets within each task and seed. All models use final fixed-update checkpoints. There was no selected successful seed, early stopping, test-guided extension or checkpoint selection.

| Arm | Controlled-task parameters | Byte-LM parameters | Purpose |
|---|---:|---:|---|
| Full rewrite |18,359|33,764|Proposed mechanism|
| Fixed ring destination |18,359|33,764|Remove learned write-location selection|
| Links disabled |18,359|33,764|Remove pointer traversal|
| GRU |18,205|33,610|Conventional recurrent comparison|
| Transformer |18,322|33,727|Conventional attention comparison|

The ring and links-disabled controls retain allocated but inactive heads. In the controlled task their active parameter counts are18,095 and 18,227. State capacity, active parameters, FLOPs and wall time are not all matched by matching allocated parameters.

### Controlled execution task

The model receives serialized programs over four register names and eight values, followed by a question. SET changes a value; COPY preserves the source's current value; SUB computes ordered subtraction modulo 8. The answer is excluded from model input. Four questions about a world are issued independently, with no previous gold answers in the next query's history.

Example of the property being tested:

```text
set r0 v3 ;
copy r1 r0 ;
set r0 v7 ;
ask r1 ?
```

The correct answer is still `v3`. This requires preserving the copied value when its source changes. The model is not given the interpreter that establishes that answer.

Training uses 512 worlds and 512 updates at batch 16:8,192 answer labels. The objective is answer-position cross-entropy over the entire20-token vocabulary. This is an answer-supervised execution diagnostic, not ordinary language modeling.

Held-out panels include familiar operation distributions, a dependent adjacent COPY→SUB order excluded from training, source-overwrite correction,16 irrelevant writes, and 64 counterfactual quartets whose focal answers must all differ. Whole-world exactness requires all four independently issued answers to be right. A complete counterfactual quartet requires all four focal variants to be right.

Histories, register-renaming-canonicalized programs and whole families are separated across panels. Final semantic states can overlap because only 4,096 final register states exist. The composition panel excludes focal results0 and 4 so operand reversal changes the answer; its focal answer frequencies and shortcuts are reported separately.

### Ordinary language task

The independent language test uses pinned TinyShakespeare, byte+1 tokenization,257 output classes, ordinary causal next-token cross-entropy,256 updates, batch 16 and context 64. Each fit receives262,144 byte targets sampled from the training partition. Both held-out partitions have55,769 scored next-byte targets; all targets after the first byte, including the short final block, are counted exactly once.

This is a small trainability comparison. It neither establishes convergence nor tests natural-language long-term structure discovery. Its corpus, split and hash provenance are in `corpus_manifest.json`.

### Test closure and review

All30 training receipts, checkpoints and update logs were verified and frozen before neural TEST scoring opened. No further fit can be started through the registered runner after that closure. Twelve source files and 15 input files were hashed before fitting.

Independent prefit checks passed eight groups, including5,376 independently interpreted labels, no-answer leakage, held-out composition rules, no-op behavior, actual pointer following, unchanged unselected records, causal execution and full/cached parity. These establish execution integrity, not learned competence. The complete receipts and limitations are in `PREFIT_REVIEW.md` and `prefit_verification.json`.

## 3. Controlled execution results

The following percentages are means across the three registered seeds. Composition and correction columns use the focal query that exercises the defining mechanism. Detailed per-seed results are preserved in `tables/structured_per_seed.csv` and `summary.json`.

| Model | IID answers | Whole IID world | Held-out composition | Copy survives source change | Complete counterfactual quartet |
|---|---:|---:|---:|---:|---:|
| Full rewrite |12.11%|0.52%|15.89%|16.15%|0.00%|
| Fixed ring destination |12.11%|0.52%|15.89%|16.15%|0.00%|
| Links disabled |12.11%|0.52%|15.89%|16.15%|0.00%|
| GRU |23.63%|1.82%|16.93%|16.15%|0.00%|
| Transformer |27.21%|1.30%|16.15%|18.49%|0.00%|

The prospective screens required every seed to achieve at least 95% IID answers,90% focal composition,90% focal correction and 90% complete quartets. **Every arm failed.** For the full model, IID scores were13.48%,10.74%,12.11%; complete quartet accuracy was0% in all three seeds.

The full model and its structural controls have identical answer accuracies in every registered panel. Removing links or forcing operation 0 on the fixed IID probe subset also leaves its answer accuracy unchanged. These observations do not support successful structured execution or a contribution from links to that task.

### Independent replay found a concrete collapse

The postfit reviewer independently replayed all 512 IID and all 1,024 counterfactual examples for rewrite seed 11. Every predicted answer matched; the largest NLL discrepancy was 2.44e-7 nats. Across all saved IID and counterfactual examples, each rewrite seed always predicts one value:

| Seed | Answer to every IID/counterfactual query |
|---|---|
|11|`v1`|
|23|`v5`|
|37|`v2`|

This is constant classification. Internal values and logits vary slightly, so it is not literally input-independent computation.

Supplementary traces on the first 32 IID families,128 query presentations and 4,744 token steps per seed, show nearly fixed routing. Seeds 11 and 23 read the same slot twice on every step and never edit links. Seed 37 edits links but follows one only on the initial BOS token; later it uses direct reads, one of which points to a slot that remains zero. The sampled episodes finish with only two nonzero records. One operation code dominates all noninitial steps.

This identifies a concrete failure of the learning recipe: the availability of addressable records and graph edits did not lead to useful learned address selection or execution. It is not evidence that graph rewriting is intrinsically unable to work. These traces concern the structured-task checkpoints; the separately trained language checkpoints are a different result.

The conventional replay independently reproduced Transformer seed 11's full language test within 6.97e-10 bits per byte, including its 25-target tail, and matched all 128 predictions in a structured subset. Replay scripts, exact checks and limitations are in `POSTFIT_AUDIT_REWRITE.md` and `POSTFIT_AUDIT_BASELINE.md`.

### Why unchanged answers are not successful memory

For the full model, predictions before and after16 irrelevant writes agree100% of the time. But both paired answers are correct only 14.06%,11.72%,10.94% across seeds. Agreement alone would have produced a misleading success claim. The paired-correct metric shows that the required behavior was not learned.

### Failure is already visible on simpler query types

A supplementary analysis groups IID queries by the last operation writing the queried register. This was added after registration for diagnosis; it does not alter the screens.

| Model | Last writer SET | Last writer COPY | Last writer SUB |
|---|---:|---:|---:|
| Full rewrite |12.14%|12.43%|11.58%|
| GRU |27.03%|25.93%|10.18%|
| Transformer |31.39%|28.57%|12.63%|

The record model's difficulty is not confined to unfamiliar compositions or subtraction. It also fails to recover ordinary assigned values reliably. Its last 32 mean training losses were2.0817,2.0941,2.0963 nats, close to the 2.0794 nats of an eight-value uniform distribution. This is evidence of a learning/optimization failure in this setup, not merely a held-out generalization failure.

The controls were also weak, particularly on subtraction. The training budget and learning problem have not been calibrated to a competent conventional executor. The results cannot isolate an intrinsic expressive limitation of record rewriting.

## 4. Byte-language results

Bits per byte measures predictive uncertainty; lower is better. The table contains all three seeds, not a selected checkpoint.

| Model | Seed 11 | Seed 23 | Seed 37 | Mean |
|---|---:|---:|---:|---:|
| Full rewrite |4.5711|4.5552|4.2154|4.4472|
| Fixed ring destination |4.8603|4.8721|4.8718|4.8680|
| Links disabled |4.6468|4.5669|4.4311|4.5483|
| GRU |3.4368|3.3819|3.3961|3.4049|
| Transformer |3.6245|3.6429|3.6326|3.6333|

The full model improves on links-disabled by 0.0757,0.0117,0.2157 bits per byte and on fixed-ring writes by 0.2892,0.3169,0.6564. The consistent direction is a limited positive signal for those choices in this implementation's byte-prediction task.

It does not establish learned semantic roles or useful graph reasoning. The full model remains about1.04 bits per byte worse than the GRU on the seed mean, and 0.81 worse than the Transformer. Three seeds and a small common optimizer budget do not establish the best achievable result of any architecture.

### Measured implementation cost

These are seed means of the recorded batch 1 medians for64-byte sequences. Incremental execution supplies observed tokens and measures positions after the first three; it is not free-running generation or repeated fixed-context latency.

| Model | Full sequence forward | Observed-token incremental step | Retained logical tensor state at 64 tokens |
|---|---:|---:|---:|
| Full rewrite |26.32 ms|0.307 ms|1,568 bytes|
| Fixed ring destination |35.70 ms|0.391 ms|1,568 bytes|
| Links disabled |35.60 ms|0.359 ms|1,568 bytes|
| GRU |5.61 ms|0.050 ms|452 bytes|
| Transformer |0.971 ms|0.390 ms|32,768 bytes|

The Transformer full-sequence measurement does not return a retained cache; its incremental measurement uses the real KV cache. The row's retained state is measured after actual stepping. Full-sequence and incremental measurements answer different implementation questions.

The record model uses less persistent state than this Transformer's64-token KV cache, but more than the GRU. The simple PyTorch implementation is substantially slower than the GRU. Dense routing, Python iteration and unoptimized kernels limit generalization of these timings to a production implementation. Training fit times also involved concurrent CPU workers. No quality-gated efficiency score is promoted after failure of the execution screen.

## 5. What follows from the evidence

**Established:** the proposed local-update mechanism can be implemented as a complete causal model, its software invariants hold under the recorded checks, and its parameters can be fit on a byte-language objective. The full configuration outperforms its two structural ablations on that small language run.

**Not established:** reliable state editing from input tokens, meaningful learned object/role records, semantic pointer composition, robust generalization, architectural novelty, competitive language quality, or a favorable quality/cost tradeoff.

I would keep the code as an experimental reference and avoid making this version the foundation for a larger model. The next hypothesis should address the observed route and constant-answer collapse before adding graph types or model size. The evidence identifies the collapse; it does not isolate its cause among hard routing, the surrogate gradient, supervision, initialization and budget.

A defensible next experiment would separate learning the address from learning the transformation. First require reliable token-driven SET and delayed recall; then COPY with later source overwrite; then ordered arithmetic and composition. A supplied-address diagnostic can measure the update kernel's capacity, but must remain explicitly privileged and separate from the raw-token result. Only after a competent raw-token baseline exists should link benefits be interpreted as evidence of the intended compositional mechanism.

That is a proposed next experiment, not a result obtained here. The current registration remains closed and unchanged.

## 6. Evidence, reproduction and publication status

The local review branch is `research/csm-foundation-001-20261109`. Source, configuration, data generation, frozen inputs, summaries, per-seed tables and compact receipts are versioned there. Full checkpoints, optimizer/RNG states, update logs, per-example outcomes, per-block language losses and process receipts are preserved in the accompanying evidence archive.

For the registered source and fixed fits, follow `README.md`. To regenerate the summary after evaluation, run `python analyze.py`. The analyzer verifies provenance and reconciles its supplementary diagnostic with the authoritative IID metrics. Independent checkpoint replay findings are recorded in the postfit audit files alongside this report.

Automatic approval review rejected publishing the branch because explicit permission to disclose this research payload to the GitHub destination was not present. A read-only check found no branch at that remote name. No alternate publication route was attempted. The complete unpublished changes and evidence are provided for review; publication can be a separate final approval.

### Primary evidence files

- `PROTOCOL.md`, `config.json`, `frozen_manifest.json` — prospective design and immutable inputs.
- `training_closed.json` — all 30 training identities and checkpoint/log hashes before TEST.
- `summary.json`, `tables/` — complete per-seed metrics, screens, ablations and supplementary diagnostics.
- `evidence/` — compact copies of all 30 evaluation and completion receipts.
- `runs/` in the separate evidence archive — raw predictions/loss blocks, checkpoints and update logs.
- `verification.py`, `prefit_verification.json`, and postfit replay scripts/receipts — reproducible integrity and replay evidence.

### External primary sources

- [Neural Production Systems: Learning Rule-Governed Visual Dynamics](https://arxiv.org/abs/2103.01937).
- [Graph Rewriting for Graph Neural Networks](https://arxiv.org/abs/2305.18632).
- [Pinned TinyShakespeare corpus](https://github.com/karpathy/char-rnn/blob/6f9487a6fe5b420b7ca9afb0d7c078e37c1d1b4e/data/tinyshakespeare/input.txt).
- [Previously inspected occurrence-memory LRC implementation](https://github.com/FPC-effortless/cdl-attention-experiment/blob/b50e1615e16410b06af34081e83762460c0f9de3/relational_composition/model.py).
