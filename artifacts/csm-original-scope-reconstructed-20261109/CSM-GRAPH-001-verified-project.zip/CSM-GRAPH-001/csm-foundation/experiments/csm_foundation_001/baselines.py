"""Conventional raw-token baselines for the CSM foundation pilot.

These implementations are new experiment code, not imported LRC implementations.
GRULM uses PyTorch's standard GRUCell, with the same three-token embedding
frontend specified for the CSM comparison. TransformerLM is a conventional
pre-normalized causal Transformer with sinusoidal positions and a sliding window.
Neither model receives parser output, entity identities, or structural labels.

All recurrent/cache state is passed explicitly. ``forward`` starts fresh;
``step`` preserves gradients through its supplied state. Transformer full-sequence
evaluation and cached stepping use identical sliding-window semantics. The full
implementation uses an ordinary dense attention mask for long sequences; it is
not an optimized sparse-attention implementation.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import torch
from torch import nn
from torch.nn import functional as F


def parameter_count(model: nn.Module) -> int:
    """Allocated model parameters, including inactive parameters if any."""
    return sum(p.numel() for p in model.parameters())


def state_numel(state: Any) -> int:
    """Logical tensor elements in explicit state; not RSS or peak allocation."""
    seen: set[int] = set()

    def count(value: Any) -> int:
        if id(value) in seen:
            return 0
        seen.add(id(value))
        if isinstance(value, torch.Tensor):
            return value.numel()
        if isinstance(value, dict):
            return sum(count(v) for v in value.values())
        if isinstance(value, (tuple, list)):
            return sum(count(v) for v in value)
        return 0

    return count(state)


def _check_interventions(interventions: Any, *, gru: bool = False) -> None:
    allowed = {"reset_at", "corrupt_at", "permute_hidden"} if gru else {"reset_at"}
    unknown = set(interventions or {}) - allowed
    if unknown:
        raise ValueError(f"Unsupported baseline interventions: {sorted(unknown)}")
    for key in ("reset_at", "corrupt_at"):
        value = (interventions or {}).get(key)
        if value is not None and (not isinstance(value, int) or value < 0):
            raise ValueError(f"{key} must be a nonnegative integer or None")


def _check_sequence(input_ids: torch.Tensor) -> None:
    if input_ids.ndim != 2 or input_ids.shape[0] < 1 or input_ids.shape[1] < 1:
        raise ValueError("Expected nonempty input_ids of shape [batch, time]")
    if input_ids.dtype != torch.long:
        raise TypeError("input_ids must have dtype torch.long")


def _check_token(token_ids: torch.Tensor) -> None:
    if token_ids.ndim != 1 or token_ids.shape[0] < 1:
        raise ValueError("Expected token_ids of shape [batch]")
    if token_ids.dtype != torch.long:
        raise TypeError("token_ids must have dtype torch.long")


@dataclass(frozen=True)
class GRUConfig:
    vocab_size: int = 257
    width: int = 32
    hidden_size: int = 48
    local_kernel: int = 3

    def __post_init__(self) -> None:
        if min(self.vocab_size, self.width, self.hidden_size) < 1:
            raise ValueError("All dimensions must be positive")
        if self.local_kernel != 3:
            raise ValueError("This comparison fixes the frontend to three tokens")


class GRULM(nn.Module):
    """Causal 3-token frontend -> conventional GRU -> next-token logits."""

    def __init__(self, config: GRUConfig | int | None = None, **kwargs: Any):
        super().__init__()
        if isinstance(config, int):
            if "vocab_size" in kwargs:
                raise ValueError("vocab_size was supplied twice")
            kwargs["vocab_size"], config = config, None
        if config is not None and kwargs:
            raise ValueError("Provide a config or keyword dimensions, not both")
        self.config = config if config is not None else GRUConfig(**kwargs)
        c = self.config
        self.embedding = nn.Embedding(c.vocab_size, c.width)
        self.frontend = nn.Linear(3 * c.width, c.width)
        self.cell = nn.GRUCell(c.width, c.hidden_size)
        self.projection = nn.Linear(c.hidden_size, c.width)
        self.output = nn.Linear(c.width, c.vocab_size)
        self.width = c.width
        self.hidden_size = c.hidden_size

    def init_state(self, batch_size: int, device=None) -> dict[str, Any]:
        if batch_size < 1:
            raise ValueError("batch_size must be positive")
        c = self.config
        reference = self.embedding.weight
        device = reference.device if device is None else device
        return {
            "position": 0,
            "history": torch.zeros(batch_size, 2, c.width, device=device,
                                   dtype=reference.dtype),
            "hidden": torch.zeros(batch_size, c.hidden_size, device=device,
                                  dtype=reference.dtype),
        }

    def step(self, token_ids, state=None, interventions=None):
        _check_interventions(interventions, gru=True)
        _check_token(token_ids)
        if state is None:
            state = self.init_state(token_ids.shape[0], token_ids.device)
        intervention = interventions or {}
        position = state["position"]
        if intervention.get("reset_at") == position:
            state = self.init_state(token_ids.shape[0], token_ids.device)
            state["position"] = position
        if (intervention.get("corrupt_at") == position
                and intervention.get("permute_hidden", False)):
            # Feature permutation is a GRU-specific corruption, not the same
            # intervention as permuting identity-bearing CSM records.
            state = {**state, "hidden": state["hidden"].roll(1, dims=-1)}
        c = self.config
        if state["history"].shape != (token_ids.shape[0], 2, c.width):
            raise ValueError("Frontend state shape does not match the token batch")
        if state["hidden"].shape != (token_ids.shape[0], c.hidden_size):
            raise ValueError("GRU state shape does not match the token batch")
        embedded = self.embedding(token_ids)
        window = torch.cat((state["history"], embedded[:, None, :]), dim=1)
        local = torch.tanh(self.frontend(window.flatten(1)))
        hidden = self.cell(local, state["hidden"])
        logits = self.output(self.projection(hidden))
        new_state = {"history": window[:, 1:, :].clone(), "hidden": hidden,
                     "position": position + 1}
        return logits, new_state

    def forward(self, input_ids, interventions=None):
        _check_interventions(interventions, gru=True)
        _check_sequence(input_ids)
        state = self.init_state(input_ids.shape[0], input_ids.device)
        outputs = []
        for token in input_ids.unbind(1):
            logits, state = self.step(token, state, interventions)
            outputs.append(logits)
        return torch.stack(outputs, dim=1)

    def parameter_count(self) -> int:
        return parameter_count(self)

    def active_parameter_count(self) -> int:
        return self.parameter_count()

    def state_numel(self, state=None, *, batch_size: int = 1,
                    sequence_length: int | None = None) -> int:
        if isinstance(state, int):
            state = None  # Sequence length does not affect GRU state capacity.
        if state is not None:
            return state_numel(state)
        return batch_size * (2 * self.config.width + self.config.hidden_size)

    def specification(self) -> dict[str, Any]:
        return {"architecture": "conventional_gru", **asdict(self.config),
                "parameters": self.parameter_count(),
                "active_parameters": self.active_parameter_count(),
                "state_elements_per_sequence": self.state_numel(),
                "state_float32_bytes_per_example": 4 * self.state_numel(),
                "state_position_integer": True}


def _gru_parameters(vocab_size: int, width: int, hidden_size: int) -> int:
    # Both GRUCell bias vectors are included. No random initialization is needed
    # while choosing a size, so matching does not consume extra RNG draws.
    return (2 * vocab_size * width + vocab_size + 3 * width * width + 2 * width
            + 3 * hidden_size * hidden_size + (4 * width + 6) * hidden_size)


def build_matched_gru(target_params: int, vocab_size: int = 257, width: int = 32,
                      min_hidden: int = 1, max_hidden: int = 512) -> GRULM:
    """Nearest allocated-parameter match; ties choose the smaller hidden size."""
    if target_params < 1 or min_hidden < 1 or max_hidden < min_hidden:
        raise ValueError("Invalid target parameter count or hidden-size interval")
    hidden = min(range(min_hidden, max_hidden + 1),
                 key=lambda h: (abs(_gru_parameters(vocab_size, width, h)
                                    - target_params), h))
    model = GRULM(GRUConfig(vocab_size, width, hidden))
    model.match_target_params = int(target_params)
    model.match_relative_error = (model.parameter_count() - target_params) / target_params
    return model


@dataclass(frozen=True)
class TransformerConfig:
    vocab_size: int = 257
    width: int = 32
    layers: int = 2
    heads: int = 4
    ff_width: int = 64
    max_context: int = 128

    def __post_init__(self) -> None:
        if min(self.vocab_size, self.width, self.layers, self.heads,
               self.ff_width, self.max_context) < 1:
            raise ValueError("All dimensions must be positive")
        if self.width % self.heads or self.width % 2:
            raise ValueError("width must be even and divisible by heads")


class _TransformerLayer(nn.Module):
    def __init__(self, config: TransformerConfig):
        super().__init__()
        self.config = config
        d = config.width
        self.norm1 = nn.LayerNorm(d)
        self.qkv = nn.Linear(d, 3 * d)
        self.attention_output = nn.Linear(d, d)
        self.norm2 = nn.LayerNorm(d)
        self.feedforward = nn.Sequential(nn.Linear(d, config.ff_width), nn.GELU(),
                                         nn.Linear(config.ff_width, d))

    def _project(self, x):
        b, t, d = x.shape
        c = self.config
        return self.qkv(self.norm1(x)).reshape(
            b, t, 3, c.heads, d // c.heads).permute(2, 0, 3, 1, 4).unbind(0)

    def _finish(self, x, attention):
        x = x + self.attention_output(attention.transpose(1, 2).reshape_as(x))
        return x + self.feedforward(self.norm2(x))

    def forward(self, x):
        q, k, v = self._project(x)
        length = x.shape[1]
        if length <= self.config.max_context:
            attention = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        else:
            positions = torch.arange(length, device=x.device)
            distance = positions[:, None] - positions[None, :]
            mask = (distance >= 0) & (distance < self.config.max_context)
            attention = F.scaled_dot_product_attention(q, k, v, attn_mask=mask)
        return self._finish(x, attention)

    def step(self, x, cache):
        q, k, v = self._project(x)
        old_k, old_v = cache
        k = torch.cat((old_k, k), dim=-2)[:, :, -self.config.max_context:, :].clone()
        v = torch.cat((old_v, v), dim=-2)[:, :, -self.config.max_context:, :].clone()
        # A single current query sees only previously cached tokens and itself.
        attention = F.scaled_dot_product_attention(q, k, v)
        return self._finish(x, attention), (k, v)


class TransformerLM(nn.Module):
    """Standard causal Transformer, with exact bounded-window cached stepping."""

    def __init__(self, config: TransformerConfig | int | None = None, **kwargs: Any):
        super().__init__()
        if isinstance(config, int):
            if "vocab_size" in kwargs:
                raise ValueError("vocab_size was supplied twice")
            kwargs["vocab_size"], config = config, None
        if config is not None and kwargs:
            raise ValueError("Provide a config or keyword dimensions, not both")
        self.config = config if config is not None else TransformerConfig(**kwargs)
        c = self.config
        self.embedding = nn.Embedding(c.vocab_size, c.width)
        self.layers = nn.ModuleList(_TransformerLayer(c) for _ in range(c.layers))
        self.norm = nn.LayerNorm(c.width)
        self.output = nn.Linear(c.width, c.vocab_size)
        self.width = c.width

    def _positions(self, length: int, start: int, device, dtype):
        positions = torch.arange(start, start + length, device=device,
                                 dtype=torch.float32)[:, None]
        frequencies = torch.exp(-torch.log(torch.tensor(10000.0, device=device))
                                * torch.arange(0, self.config.width, 2,
                                               device=device, dtype=torch.float32)
                                / self.config.width)
        angles = positions * frequencies[None, :]
        return torch.stack((angles.sin(), angles.cos()), dim=-1).flatten(-2).to(dtype)

    def init_state(self, batch_size: int, device=None) -> dict[str, Any]:
        if batch_size < 1:
            raise ValueError("batch_size must be positive")
        c = self.config
        reference = self.embedding.weight
        device = reference.device if device is None else device
        shape = (batch_size, c.heads, 0, c.width // c.heads)
        return {"position": 0, "kv": [
            (torch.empty(shape, device=device, dtype=reference.dtype),
             torch.empty(shape, device=device, dtype=reference.dtype))
            for _ in range(c.layers)]}

    def step(self, token_ids, state=None, interventions=None):
        _check_interventions(interventions)
        _check_token(token_ids)
        if state is None:
            state = self.init_state(token_ids.shape[0], token_ids.device)
        if (interventions or {}).get("reset_at") == state["position"]:
            position = state["position"]
            state = self.init_state(token_ids.shape[0], token_ids.device)
            state["position"] = position
        if len(state["kv"]) != self.config.layers:
            raise ValueError("KV cache layer count mismatch")
        h = self.embedding(token_ids[:, None])
        h = h + self._positions(1, state["position"], h.device, h.dtype)[None, :, :]
        caches = []
        for layer, cache in zip(self.layers, state["kv"]):
            if cache[0].shape[0] != token_ids.shape[0]:
                raise ValueError("KV cache batch size mismatch")
            h, new_cache = layer.step(h, cache)
            caches.append(new_cache)
        logits = self.output(self.norm(h))[:, 0, :]
        return logits, {"position": state["position"] + 1, "kv": caches}

    def forward(self, input_ids, interventions=None):
        _check_interventions(interventions)
        _check_sequence(input_ids)
        reset_at = (interventions or {}).get("reset_at")
        if reset_at is not None and 0 < reset_at < input_ids.shape[1]:
            # Clear memory at the requested input position while preserving
            # absolute sinusoidal positions, isolating history removal.
            return torch.cat((self._forward_segment(input_ids[:, :reset_at], 0),
                              self._forward_segment(input_ids[:, reset_at:], reset_at)), dim=1)
        return self._forward_segment(input_ids, 0)

    def _forward_segment(self, input_ids, start_position):
        h = self.embedding(input_ids)
        h = h + self._positions(input_ids.shape[1], start_position,
                               h.device, h.dtype)[None, :, :]
        for layer in self.layers:
            h = layer(h)
        return self.output(self.norm(h))

    def parameter_count(self) -> int:
        return parameter_count(self)

    def active_parameter_count(self) -> int:
        return self.parameter_count()

    def state_numel(self, state=None, *, batch_size: int = 1,
                    context_length: int | None = None,
                    sequence_length: int | None = None) -> int:
        if isinstance(state, int):
            sequence_length, state = state, None
        if state is not None:
            return state_numel(state)
        if sequence_length is not None:
            context_length = sequence_length
        context = (self.config.max_context if context_length is None
                   else min(context_length, self.config.max_context))
        if context < 0:
            raise ValueError("context_length must be nonnegative")
        return 2 * batch_size * self.config.layers * context * self.config.width

    def specification(self) -> dict[str, Any]:
        return {"architecture": "standard_causal_transformer", **asdict(self.config),
                "positions": "sinusoidal", "parameters": self.parameter_count(),
                "active_parameters": self.active_parameter_count(),
                "maximum_state_elements_per_sequence": self.state_numel(),
                "maximum_state_float32_bytes_per_example": 4 * self.state_numel(),
                "state_position_integer": True}


def build_matched_transformer(target_params: int, vocab_size: int = 257,
                              width: int = 32, layers: int = 2, heads: int = 4,
                              max_context: int = 128, min_ff: int = 8,
                              max_ff: int = 512) -> TransformerLM:
    """Match allocated parameters by feedforward width; attention width fixed."""
    if target_params < 1 or min_ff < 1 or max_ff < min_ff:
        raise ValueError("Invalid target or feedforward-width interval")

    def count(ff):
        return (2 * vocab_size * width + vocab_size + 2 * width
                + layers * (4 * width * width + 9 * width + (2 * width + 1) * ff))

    ff = min(range(min_ff, max_ff + 1), key=lambda f: (abs(count(f) - target_params), f))
    model = TransformerLM(TransformerConfig(vocab_size, width, layers, heads,
                                            ff, max_context))
    model.match_target_params = int(target_params)
    model.match_relative_error = (model.parameter_count() - target_params) / target_params
    return model


# Explicit aliases for callers that prefer comparison-oriented class names.
GRUBaseline = GRULM
TransformerBaseline = TransformerLM
GRUModel = GRULM
TransformerModel = TransformerLM
