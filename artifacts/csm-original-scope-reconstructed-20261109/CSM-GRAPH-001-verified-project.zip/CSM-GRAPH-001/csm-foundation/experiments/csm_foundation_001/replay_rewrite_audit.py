"""Independent postfit audit; no fitting and no import of the frozen runner.

Replays all IID and counterfactual examples for structured/rewrite/11, checks
saved arithmetic for all rewrite/no_links seeds, and records a supplementary
route-usage diagnosis on the first 32 IID families. Existing outputs are never
overwritten. The diagnosis is post-evaluation and is not a registered gate.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics

import torch

from model import Config, RecordRewrite


ROOT = Path(__file__).resolve().parent
TOLERANCE = 5e-6
PANELS = ("dev", "iid", "composition", "correction", "long", "counterfactual")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def rows(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line]


def close(a, b, label, tolerance=1e-12):
    if not math.isclose(a, b, rel_tol=0, abs_tol=tolerance):
        raise AssertionError(f"{label}: {a!r} != {b!r}")


def verify_provenance():
    frozen = load(ROOT / "frozen_manifest.json")
    config = load(ROOT / "config.json")
    closure = load(ROOT / "training_closed.json")
    freeze_hash = sha(ROOT / "frozen_manifest.json")
    assert frozen["configuration"] == config
    assert closure["freeze_sha256"] == freeze_hash
    checked = []
    for group in ("source_sha256", "input_sha256"):
        for name, expected in frozen[group].items():
            assert sha(ROOT / name) == expected, (group, name)
            checked.append(f"{group}/{name}")
    expected_ids = {f"{task}/{arm}/{seed}" for task in ("structured", "lm")
                    for arm in config["arms"] for seed in config["seeds"]}
    assert set(closure["completed_fits"]) == expected_ids
    for run_id, sealed in closure["completed_fits"].items():
        directory = ROOT / "runs" / run_id
        receipt = load(directory / "completed.json")
        assert sha(directory / "completed.json") == sealed["completed_sha256"]
        assert receipt["freeze_sha256"] == freeze_hash
        task, arm, seed = run_id.split("/")
        assert (receipt["task"], receipt["arm"], receipt["seed"]) == (task, arm, int(seed))
        assert receipt["updates"] == config[f"{task}_updates"]
        assert receipt["model"] == frozen["model_specifications"][task][arm]
        for file, field in (("checkpoint.pt", "checkpoint_sha256"),
                            ("updates.jsonl", "updates_sha256")):
            assert receipt[field] == sealed[field] == sha(directory / file)
        assert receipt["finish_utc"] == sealed["finish_utc"]
        assert datetime.fromisoformat(receipt["finish_utc"]) <= datetime.fromisoformat(closure["closed_at_utc"])
        schedule = ROOT / "data" / "schedules" / f"{task}-{seed}.npy"
        assert sha(schedule) == receipt["schedule_sha256"]
        evaluation = load(directory / "evaluation.json")
        assert evaluation["training"] == receipt
        assert evaluation["checkpoint_sha256"] == receipt["checkpoint_sha256"]
        assert datetime.fromisoformat(evaluation["evaluation_utc"]) >= datetime.fromisoformat(closure["closed_at_utc"])
    return config, frozen, {
        "freeze_sha256": freeze_hash,
        "closure_sha256": sha(ROOT / "training_closed.json"),
        "verified_sources": len(frozen["source_sha256"]),
        "verified_inputs": len(frozen["input_sha256"]),
        "verified_closed_fits": len(expected_ids),
        "closed_at_utc": closure["closed_at_utc"],
    }


def independent_answer(example, token_names):
    """Public-token interpreter, independently implemented for this audit."""
    words = [token_names[i] for i in example["input_ids"]]
    assert words[0] == "<bos>" and words[-3] == "ask" and words[-1] == "?"
    query = words[-2]
    memory = {}
    statement = []
    for word in words[1:-3]:
        if word != ";":
            statement.append(word)
            continue
        op, destination, *operands = statement
        if op == "set":
            assert len(operands) == 1 and operands[0][0] == "v"
            value = int(operands[0][1:])
        elif op == "copy":
            assert len(operands) == 1
            value = memory[operands[0]]
        else:
            assert op == "sub" and len(operands) == 2
            value = (memory[operands[0]] - memory[operands[1]]) % 8
        memory[destination] = value
        statement = []
    assert not statement and set(memory) == {"r0", "r1", "r2", "r3"}
    return token_names.index(f"v{memory[query]}")


def own_metrics(predictions):
    correct = [int(p["prediction_id"] == p["answer_id"]) for p in predictions]
    worlds = defaultdict(list)
    focal, quartets = [], defaultdict(list)
    for p, hit in zip(predictions, correct):
        assert bool(hit) == p["correct"]
        worlds[p["world_id"]].append(hit)
        if p["query_register"] == p["target_register"]:
            focal.append(hit)
            quartets[p["family_id"]].append(hit)
    assert all(len(v) == 4 for v in worlds.values())
    result = {
        "examples": len(predictions), "worlds": len(worlds),
        "accuracy": sum(correct) / len(correct),
        "answer_nll_nats": statistics.fmean(p["nll_nats"] for p in predictions),
        "complete_world_accuracy": sum(all(v) for v in worlds.values()) / len(worlds),
    }
    if focal:
        result.update(focal_accuracy=sum(focal) / len(focal), focal_examples=len(focal))
    if predictions[0]["panel"] == "counterfactual":
        assert all(len(v) == 4 for v in quartets.values())
        result.update(complete_quartet_accuracy=sum(all(v) for v in quartets.values()) / len(quartets),
                      quartets=len(quartets))
    return result


def compare_metrics(actual, expected, label, tolerance=1e-12):
    assert set(actual) == set(expected), (label, set(actual), set(expected))
    for key in actual:
        close(actual[key], expected[key], f"{label}/{key}", tolerance)


def saved_arithmetic(config, token_names):
    source_rows = {panel: {e["id"]: e for e in rows(ROOT / "data" / "registers" / f"{panel}.jsonl")}
                   for panel in PANELS}
    validated_labels = 0
    for examples in source_rows.values():
        for example in examples.values():
            assert independent_answer(example, token_names) == example["answer_id"]
            validated_labels += 1
    results, metric_cells, prediction_count = [], 0, 0
    for arm in ("rewrite", "no_links"):
        for seed in config["seeds"]:
            directory = ROOT / "runs" / "structured" / arm / str(seed)
            evaluation = load(directory / "evaluation.json")
            saved = rows(directory / "predictions.jsonl")
            ordinary = {}
            for panel in PANELS:
                selected = [p for p in saved if p["panel"] == panel and p["condition"] == "ordinary"]
                assert len({p["id"] for p in selected}) == len(selected)
                assert {p["id"] for p in selected} == set(source_rows[panel])
                for p in selected:
                    example = source_rows[panel][p["id"]]
                    assert p["answer_id"] == example["answer_id"]
                    for field in ("world_id", "query_register", "target_register"):
                        assert p[field] == example["metadata"][field]
                    assert p["family_id"] == example["family_id"]
                actual = own_metrics(selected)
                compare_metrics(actual, evaluation["panels"][panel], f"{arm}/{seed}/{panel}")
                ordinary[panel] = actual
                prediction_count += len(selected)
                metric_cells += 1
            interventions = {}
            for condition, expected in evaluation["interventions"].items():
                selected = [p for p in saved if p["condition"] == condition]
                actual = own_metrics(selected)
                compare_metrics(actual, expected, f"{arm}/{seed}/{condition}")
                interventions[condition] = actual
                prediction_count += len(selected)
                metric_cells += 1
            all_pred = {p["id"]: p for p in saved if p["condition"] == "ordinary" and p["panel"] == "long"}
            base_pred = {p["id"].removesuffix("-base"): p for p in saved if p["condition"] == "long_pair_base"}
            pairs = [(p, all_pred[key]) for key, p in base_pred.items()]
            assert len(pairs) == 128
            pair_metrics = {
                "families": len(pairs),
                "both_correct_accuracy": sum(a["correct"] and b["correct"] for a, b in pairs) / len(pairs),
                "prediction_unchanged_fraction": sum(a["prediction_id"] == b["prediction_id"] for a, b in pairs) / len(pairs),
                "base_accuracy": sum(a["correct"] for a, b in pairs) / len(pairs),
                "with_distractors_accuracy": sum(b["correct"] for a, b in pairs) / len(pairs),
            }
            compare_metrics(pair_metrics, evaluation["irrelevant_update_pairs"], f"{arm}/{seed}/long_pairs")
            iid_predictions = [p for p in saved if p["panel"] == "iid" and p["condition"] == "ordinary"]
            cf_predictions = [p for p in saved if p["panel"] == "counterfactual" and p["condition"] == "ordinary"]
            def diversity(selected):
                count = Counter(token_names[p["prediction_id"]] for p in selected)
                return {"unique_predictions": len(count), "counts": dict(sorted(count.items()))}
            results.append({
                "arm": arm, "seed": seed, "panels": ordinary,
                "iid_prediction_diversity": diversity(iid_predictions),
                "cf_prediction_diversity": diversity(cf_predictions),
                "interventions": interventions, "irrelevant_update_pairs": pair_metrics,
                "evaluation_sha256": sha(directory / "evaluation.json"),
                "predictions_sha256": sha(directory / "predictions.jsonl"),
            })
    return results, {"independent_token_labels_checked": validated_labels,
                     "ordinary_and_intervention_metric_cells": metric_cells,
                     "ordinary_and_intervention_predictions_checked": prediction_count,
                     "paired_long_conditions_checked": 6}


def load_rewrite(seed, config, frozen):
    directory = ROOT / "runs" / "structured" / "rewrite" / str(seed)
    checkpoint = torch.load(directory / "checkpoint.pt", map_location="cpu", weights_only=False)
    assert checkpoint["configuration"] == config
    assert checkpoint["source_sha256"] == frozen["source_sha256"]
    assert checkpoint["update"] == config["structured_updates"]
    model = RecordRewrite(Config(20, config["width"], config["slots"], config["operators"],
                                 config["inner"], "rewrite", config["temperature"]))
    model.load_state_dict(checkpoint["model_state"], strict=True)
    model.eval()
    return model, directory


@torch.inference_mode()
def replay_seed11(config, frozen):
    model, directory = load_rewrite(11, config, frozen)
    saved = {(p["panel"], p["id"]): p for p in rows(directory / "predictions.jsonl")
             if p["condition"] == "ordinary"}
    results = {}
    differences = []
    mismatches = []
    for panel in ("iid", "counterfactual"):
        examples = rows(ROOT / "data" / "registers" / f"{panel}.jsonl")
        groups = defaultdict(list)
        for example in examples:
            groups[len(example["input_ids"])].append(example)
        replayed = []
        for length, group in sorted(groups.items()):
            for begin in range(0, len(group), config["eval_batch_size"]):
                batch = group[begin:begin + config["eval_batch_size"]]
                x = torch.tensor([e["input_ids"] for e in batch], dtype=torch.long)
                logits = model(x)[:, -1]
                # Different loss arithmetic from frozen evaluator: FP64 logsumexp.
                z = logits.double()
                for k, e in enumerate(batch):
                    prediction = int(logits[k].argmax())
                    nll = float(torch.logsumexp(z[k], dim=0) - z[k, e["answer_id"]])
                    old = saved[panel, e["id"]]
                    if prediction != old["prediction_id"]:
                        mismatches.append(e["id"])
                    difference = abs(nll - old["nll_nats"])
                    differences.append(difference)
                    replayed.append({**old, "prediction_id": prediction, "nll_nats": nll,
                                     "correct": prediction == e["answer_id"]})
        actual = own_metrics(replayed)
        expected = load(directory / "evaluation.json")["panels"][panel]
        compare_metrics(actual, expected, f"replay/{panel}", TOLERANCE)
        results[panel] = actual
    assert not mismatches
    assert max(differences) <= TOLERANCE
    return {"seed": 11, "checkpoint_sha256": sha(directory / "checkpoint.pt"),
            "replayed_examples": len(differences), "prediction_mismatches": mismatches,
            "max_absolute_nll_difference_nats": max(differences),
            "nll_tolerance_nats": TOLERANCE, "loss_method": "FP64 logsumexp minus target logit",
            "panels": results}


@torch.inference_mode()
def route_diagnosis(seed, config, frozen):
    model, directory = load_rewrite(seed, config, frozen)
    examples = rows(ROOT / "data" / "registers" / "iid.jsonl")[:128]
    assert len({e["family_id"] for e in examples}) == 32
    groups = defaultdict(list)
    for example in examples:
        groups[len(example["input_ids"])].append(example)
    counts = {phase: defaultdict(Counter) for phase in ("history", "query", "all")}
    gate_sums = Counter()
    steps = Counter()
    final_norms, final_logits = [], []
    for length, group in sorted(groups.items()):
        x = torch.tensor([e["input_ids"] for e in group], dtype=torch.long)
        state = model.init_state(len(group), "cpu")
        for position in range(length):
            logits, state, trace = model.step(x[:, position], state, return_trace=True)
            phase = "history" if position < length - 3 else "query"
            for target in (phase, "all"):
                steps[target] += len(group)
                gate_sums[target] += float(trace["gate"].double().sum())
                for name in ("first", "second", "destination", "operator", "uses_link", "edits_link", "edits_value"):
                    counts[target][name].update(trace[name].to(torch.int64).tolist())
        final_norms.extend(state.values.double().norm(dim=-1).tolist())
        final_logits.extend(logits.double().tolist())
    norms = torch.tensor(final_norms, dtype=torch.float64)
    logits = torch.tensor(final_logits, dtype=torch.float64)
    result = {"seed": seed, "checkpoint_sha256": sha(directory / "checkpoint.pt"),
              "scope": "supplementary post-evaluation trace, first32 IID families/all4 queries",
              "examples": len(examples), "families": 32, "per_phase": {}}
    for phase in ("history", "query", "all"):
        result["per_phase"][phase] = {
            "token_steps": steps[phase],
            "counts": {name: {str(k): v for k, v in sorted(value.items())}
                       for name, value in counts[phase].items()},
            "mean_interpolation_gate": gate_sums[phase] / steps[phase],
        }
    result.update({
        "final_slot_mean_l2_norm": norms.mean(0).tolist(),
        "final_slot_max_l2_norm": norms.max(0).values.tolist(),
        "final_nonzero_slots_per_example_min_max": [int((norms > 1e-8).sum(-1).min()), int((norms > 1e-8).sum(-1).max())],
        "answer_prediction_counts": {str(k): v for k, v in sorted(Counter(logits.argmax(-1).tolist()).items())},
        "maximum_answer_logit_range_across_subset": float((logits.max(0).values - logits.min(0).values).max()),
    })
    return result


def markdown(report):
    replay = report["checkpoint_replay"]
    lines = ["# Independent postfit audit: CSM-FOUNDATION-001 rewrite", "",
             "This is an integrity audit and a supplementary diagnosis. No weights were trained or changed, and no registered gate was modified.", "",
             "## Integrity outcome", "",
             f"PASS: {report['provenance']['verified_sources']} frozen sources, {report['provenance']['verified_inputs']} inputs, and all {report['provenance']['verified_closed_fits']} closed fit receipts/checkpoints/update logs match their recorded hashes.", "",
             f"All {replay['replayed_examples']} IID and counterfactual examples for rewrite seed11 were replayed directly through the model. Predictions matched exactly. Maximum NLL discrepancy using independent FP64 logsumexp arithmetic was {replay['max_absolute_nll_difference_nats']:.9g} nats (tolerance {TOLERANCE:g}).", "",
             f"Independent raw arithmetic reconciled {report['saved_arithmetic']['ordinary_and_intervention_metric_cells']} metric cells covering {report['saved_arithmetic']['ordinary_and_intervention_predictions_checked']} saved ordinary/intervention predictions across rewrite/no-links and three seeds, plus all six long-pair conditions. Public-token labels were independently interpreted for {report['saved_arithmetic']['independent_token_labels_checked']} held-out/development examples.", "",
             "## Structured qualification", "",
             "| Arm | Seed | IID | Composition focal | Correction focal | Complete focal quartets | Distinct IID predictions |",
             "|---|---:|---:|---:|---:|---:|---:|"]
    for row in report["structural_rows"]:
        p = row["panels"]
        lines.append(f"| {row['arm']} | {row['seed']} | {p['iid']['accuracy']:.4%} | {p['composition']['focal_accuracy']:.4%} | {p['correction']['focal_accuracy']:.4%} | {p['counterfactual']['complete_quartet_accuracy']:.4%} | {row['iid_prediction_diversity']['unique_predictions']} |")
    lines += ["", "The rewrite checkpoints do not pass the registered capability screens. Identical accuracy to a no-links model is not evidence of a useful link mechanism. The per-model frozen links-off intervention and trace counts are reported below; nonzero link use alone is not semantic reasoning.", "",
              "## Supplementary route diagnosis", "",
              "These traces use the fixed first32 IID families (128 independently issued queries). They are post-evaluation diagnostics, not a new qualification criterion.", ""]
    for trace in report["route_diagnoses"]:
        c = trace["per_phase"]["all"]
        lines += [f"### Seed {trace['seed']}", "",
                  f"All-token steps: {c['token_steps']}. Destination counts: `{c['counts']['destination']}`. Value-edit counts: `{c['counts']['edits_value']}`. Link-use counts: `{c['counts']['uses_link']}`. Operator counts: `{c['counts']['operator']}`.", "",
                  f"Final nonzero-slot count range: `{trace['final_nonzero_slots_per_example_min_max']}`. Mean slot norms: `{[round(v,6) for v in trace['final_slot_mean_l2_norm']]}`. Answer prediction counts (token IDs): `{trace['answer_prediction_counts']}`. Maximum logit range across these examples: {trace['maximum_answer_logit_range_across_subset']:.9g}.", ""]
    lines += ["## Limits", "",
              "Exact replay checks the frozen implementation and saved results; it does not prove architecture competence or optimal training. The route sample does not cover every possible input. A constant answer with nonconstant logits is a degenerate answer policy, not proof of literally input-independent computation. The one-link-per-slot machine and its straight-through optimizer remain only one implementation/training recipe. Registered conventional controls must also be considered before attributing failure to the structural hypothesis.", "",
              "The JSON artifact retains per-phase route counts, slot norms, intervention scores, checkpoint identities, provenance and all independently recomputed metrics.", ""]
    return "\n".join(lines)


def main():
    outputs = [ROOT / "POSTFIT_AUDIT_REWRITE.json", ROOT / "POSTFIT_AUDIT_REWRITE.md"]
    assert not any(path.exists() for path in outputs), "Refusing to overwrite audit artifacts"
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    config, frozen, provenance = verify_provenance()
    vocabulary = load(ROOT / "data" / "registers" / "manifest.json")["vocabulary"]
    token_names = [None] * len(vocabulary)
    for token, index in vocabulary.items():
        token_names[index] = token
    structural, arithmetic = saved_arithmetic(config, token_names)
    replay = replay_seed11(config, frozen)
    traces = [route_diagnosis(seed, config, frozen) for seed in config["seeds"]]
    # Confirm that the audit did not change the frozen inputs or training evidence.
    assert verify_provenance()[2] == provenance
    report = {"audit": "CSM-FOUNDATION-001 independent rewrite replay and diagnosis",
              "generated_at_utc": datetime.now(timezone.utc).isoformat(),
              "audit_source_sha256": sha(__file__), "optimizer_steps": 0,
              "provenance": provenance, "checkpoint_replay": replay,
              "saved_arithmetic": arithmetic, "structural_rows": structural,
              "route_diagnoses": traces, "token_names": token_names,
              "passed": True,
              "scope": "integrity PASS does not imply registered capability PASS"}
    outputs[0].write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n")
    outputs[1].write_text(markdown(report))
    print(json.dumps({"passed": True, "checkpoint_replay": replay,
                      "saved_arithmetic": arithmetic, "route_diagnoses": traces}, indent=2))


if __name__ == "__main__":
    main()
