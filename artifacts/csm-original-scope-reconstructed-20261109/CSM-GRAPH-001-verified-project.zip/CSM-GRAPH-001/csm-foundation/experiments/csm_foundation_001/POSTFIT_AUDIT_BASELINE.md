# Post-fit baseline replay audit

**Status: PASS**

Arm: transformer; initialization seed: 11. LM and structured checkpoints are separately fitted models.

Checks passed: 206/206. No fitting or checkpoint selection occurred.

## Full language test replay

| Quantity | Result |
|---|---:|
| Saved bits per byte | 3.6244633596025 |
| Replayed bits per byte | 3.62446335890558 |
| Absolute BPB difference | 6.96920743337e-10 |
| Next-byte targets | 55,769 |
| Full 64-target blocks | 871 |
| Final partial-block targets | 25 |
| Largest block-sum NLL difference | 2.47285450428e-05 |
| Saved block-arithmetic BPB difference | 0 |
| Full/cached maximum logit difference | 2.38418579102e-06 |
| Retained tensor bytes at 64 tokens | 32,768 |

The independent loop slices bytes directly, covers the tail with the same range as full blocks, resets per block, and uses batches of 17 instead of 128. It uses FP64 log-softmax and accumulation; the registered evaluator uses FP32 cross-entropy and block sums.

## Structured IID subset replay

| Quantity | Result |
|---|---:|
| Query presentations / complete worlds | 128 / 32 |
| Matching predicted token IDs | 128 / 128 |
| Saved / replayed accuracy | 0.22656250 / 0.22656250 |
| Saved / replayed world accuracy | 0.00000000 / 0.00000000 |
| Saved / replayed mean NLL | 1.81869663671 / 1.81869663144 |
| Largest per-example NLL difference | 1.94015193689e-07 |

Each of the first 128 IID questions runs individually without padding. These are all four questions from the first 32 families and match the saved ordinary-subset control.

## Integrity and tolerances

Frozen manifest SHA256: 66decc423fc8849515213acf1ddd409c3f203507a1c9d955a864611dc16e8282.

All 12 frozen source files and 15 frozen input files match. The two replayed checkpoints, update logs and completion receipts match the training closure. Model dimensions and final update counts match the registered specifications.

- lm checkpoint SHA256: 319d7036d32f50c18caa8139df8af2671d469ffb06a3a12fecb44815b5f62bf1.
- structured checkpoint SHA256: f9cfa64a31a00f64855a151429c433bf5c903296102e00dd51bfd50576b1b042.

Tolerances were specified in the script before replay:

- test_bits_per_byte_absolute: 1e-06.
- block_sum_nll_absolute: 0.0001.
- structured_example_nll_absolute: 1e-05.
- saved_metric_arithmetic_absolute: 1e-12.
- forward_cached_logit_absolute: 1e-05.

## Limits

This audit shares the frozen Transformer implementation and fitted weights. It independently checks slicing, scoring, reductions, saved predictions and metric arithmetic; it does not independently reimplement the model, retrain it, audit all arms/seeds, or reproduce latency. Structured coverage is limited to this IID subset. Reproducibility within this scope does not establish competence, novelty or superiority.

The JSON companion preserves every check, all language-block comparisons, all structured-example comparisons and artifact hashes.

## Reproduction

Run python replay_baseline_audit.py in the recorded PyTorch environment. The script refuses to overwrite an existing audit; move previous audit artifacts aside before deliberately replaying again.
