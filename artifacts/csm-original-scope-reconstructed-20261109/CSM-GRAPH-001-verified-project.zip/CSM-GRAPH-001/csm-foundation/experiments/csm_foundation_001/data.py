"""Frozen finite-register binding assay; no semantic metadata enters a model.

This is an answer-supervised synthetic diagnostic, not a language benchmark.
SET writes a value; COPY copies the source's current value; SUB computes the
ordered source difference modulo eight before writing its destination.
"""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import random
from typing import Any


VERSION = "csm-foundation-001-registers-v1"
REGISTER_COUNT = 4
VALUE_COUNT = 8
TOKENS = ("<pad>", "<bos>", "set", "copy", "sub", ";", "ask", "?") + tuple(
    f"r{i}" for i in range(REGISTER_COUNT)
) + tuple(f"v{i}" for i in range(VALUE_COUNT))
VOCABULARY = {token: index for index, token in enumerate(TOKENS)}
PANEL_FAMILIES = {
    "train": 512, "dev": 64, "iid": 128, "composition": 128,
    "correction": 128, "long": 128, "counterfactual": 64,
}
Instruction = tuple[str, ...]


def _json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _sha(value: Any) -> str:
    return hashlib.sha256(_json(value).encode()).hexdigest()


@dataclass(frozen=True)
class Example:
    id: str
    family_id: str
    panel: str
    input_ids: list[int]
    answer_id: int
    metadata: dict[str, Any]


@dataclass
class Dataset:
    splits: dict[str, list[Example]]
    vocabulary: dict[str, int]
    manifest: dict[str, Any]

    @property
    def panels(self) -> dict[str, list[Example]]:
        return self.splits

    @property
    def vocab(self) -> dict[str, int]:
        return self.vocabulary

    def __getitem__(self, panel: str) -> list[Example]:
        return self.splits[panel]

    def save_dataset(self, directory: str | Path) -> dict[str, str]:
        return save_dataset(directory, dataset=self)


def execute(program: list[Instruction]) -> tuple[int, ...]:
    """Evaluator-only interpreter; validates exact operator arity and domains."""
    state: list[int | None] = [None] * REGISTER_COUNT

    def register(token: str) -> int:
        if token not in {f"r{i}" for i in range(REGISTER_COUNT)}:
            raise ValueError(f"invalid register: {token!r}")
        return int(token[1:])

    def read(token: str) -> int:
        value = state[register(token)]
        if value is None:
            raise ValueError("read before initialization")
        return value

    for operation in program:
        if not operation:
            raise ValueError("empty operation")
        op = operation[0]
        if op == "set" and len(operation) == 3:
            _, dst, token = operation
            if token not in {f"v{i}" for i in range(VALUE_COUNT)}:
                raise ValueError("invalid value")
            state[register(dst)] = int(token[1:])
        elif op == "copy" and len(operation) == 3:
            _, dst, src = operation
            state[register(dst)] = read(src)
        elif op == "sub" and len(operation) == 4:
            _, dst, left, right = operation
            # Both sources are read before destination mutation, including aliasing.
            value = (read(left) - read(right)) % VALUE_COUNT
            state[register(dst)] = value
        else:
            raise ValueError(f"invalid instruction: {operation!r}")
    if any(value is None for value in state):
        raise ValueError("incomplete register initialization")
    return tuple(int(value) for value in state)


def serialize(program: list[Instruction], query: str) -> list[int]:
    if query not in {f"r{i}" for i in range(REGISTER_COUNT)}:
        raise ValueError("invalid query register")
    words = ["<bos>"]
    for operation in program:
        words.extend(operation)
        words.append(";")
    words.extend(("ask", query, "?"))
    return [VOCABULARY[word] for word in words]


def parse_input(input_ids: list[int]) -> tuple[list[Instruction], str]:
    """Strict public-text parser for validation only, never called by models."""
    if any(type(token) is not int or not 0 <= token < len(TOKENS) for token in input_ids):
        raise ValueError("invalid token ID")
    words = [TOKENS[token] for token in input_ids]
    if len(words) < 5 or words[0] != "<bos>" or words[-3] != "ask" or words[-1] != "?":
        raise ValueError("malformed serialized history/query")
    query = words[-2]
    body = words[1:-3]
    program, current = [], []
    for word in body:
        if word == ";":
            if not current:
                raise ValueError("empty instruction")
            program.append(tuple(current))
            current = []
        else:
            current.append(word)
    if current:
        raise ValueError("unterminated instruction")
    if query not in {f"r{i}" for i in range(REGISTER_COUNT)}:
        raise ValueError("invalid query register")
    execute(program)
    return program, query


def canonical_program(program: list[Instruction]) -> list[list[str]]:
    """Rename visible register symbols by first occurrence, preserving values."""
    names: dict[str, str] = {}
    result = []
    for operation in program:
        row = []
        for word in operation:
            if word.startswith("r") and word[1:].isdigit():
                if word not in names:
                    names[word] = f"r{len(names)}"
                word = names[word]
            row.append(word)
        result.append(row)
    return result


def dependent_copy_sub(program: list[Instruction]) -> bool:
    """The held-out motif: an immediately preceding COPY feeds a SUB source."""
    return any(
        left[0] == "copy" and right[0] == "sub" and left[1] in right[2:]
        for left, right in zip(program, program[1:])
    )


def _initial(rng: random.Random) -> list[Instruction]:
    registers = list(range(REGISTER_COUNT))
    rng.shuffle(registers)
    return [("set", f"r{r}", f"v{rng.randrange(VALUE_COUNT)}") for r in registers]


def _operation(rng: random.Random) -> Instruction:
    op = rng.choice(("set", "copy", "sub"))
    if op == "set":
        return op, f"r{rng.randrange(4)}", f"v{rng.randrange(8)}"
    if op == "copy":
        dst, src = rng.sample(range(4), 2)
        return op, f"r{dst}", f"r{src}"
    dst, left, right = rng.sample(range(4), 3)
    return op, f"r{dst}", f"r{left}", f"r{right}"


def _ordinary(rng: random.Random) -> list[Instruction]:
    # Fixed four post-initialization operations. Every primitive occurs across
    # the corpus; the adjacent COPY->SUB order is held out, dependent or not.
    while True:
        program = _initial(rng) + [_operation(rng) for _ in range(4)]
        if not any(left[0] == "copy" and right[0] == "sub"
                   for left, right in zip(program, program[1:])):
            return program


def _make_family(rng: random.Random, panel: str, index: int) -> tuple[list[list[Instruction]], dict]:
    if panel in ("train", "dev", "iid"):
        return [_ordinary(rng)], {"case_type": "ordinary", "focus_register": None}
    if panel == "composition":
        # All primitives are familiar, but this adjacent dependent motif is
        # absent from train/dev. Source difference cannot be 0 or 4, so swapping
        # the ordered operands necessarily changes the focal answer modulo 8.
        while True:
            program = _ordinary(rng)[:6]
            source, copied, other, output = rng.sample(range(4), 4)
            state = execute(program)
            if (state[source] - state[other]) % 8 not in (0, 4):
                program.extend((("copy", f"r{copied}", f"r{source}"),
                                ("sub", f"r{output}", f"r{copied}", f"r{other}")))
                return [program], {"case_type": "dependent_copy_sub", "focus_register": f"r{output}"}
    if panel == "correction":
        program = _ordinary(rng)[:6]
        source, copied = rng.sample(range(4), 2)
        old = execute(program)[source]
        new = rng.choice([value for value in range(8) if value != old])
        program.extend((("copy", f"r{copied}", f"r{source}"), ("set", f"r{source}", f"v{new}")))
        return [program], {"case_type": "copy_then_source_overwrite", "focus_register": f"r{copied}",
                           "copied_value": old, "overwritten_source": f"r{source}"}
    if panel == "long":
        program = _ordinary(rng)
        focus = rng.randrange(4)
        distractors = [r for r in range(4) if r != focus]
        for _ in range(16):
            program.append(("set", f"r{rng.choice(distractors)}", f"v{rng.randrange(8)}"))
        return [program], {"case_type": "sixteen_irrelevant_sets", "focus_register": f"r{focus}",
                           "distractor_count": 16}
    if panel != "counterfactual":
        raise ValueError(f"unknown panel: {panel}")
    initial = _initial(rng)
    source, copied, output, unrelated = rng.sample(range(4), 4)
    case_type = "relevant_value"
    varied = source
    variants = []
    values = rng.sample(range(8), 4)
    # SUB destination and both sources are distinct, matching training. The
    # source and unrelated register are later overwritten; intermediates remain.
    tail = [("copy", f"r{copied}", f"r{source}"),
            ("sub", f"r{output}", f"r{copied}", f"r{unrelated}"),
            ("set", f"r{source}", f"v{rng.randrange(8)}"),
            ("set", f"r{unrelated}", f"v{rng.randrange(8)}")]
    for value in values:
        altered = [(op, dst, f"v{value}" if dst == f"r{varied}" else old)
                   for op, dst, old in initial]
        variants.append(altered + tail)
    return variants, {"case_type": case_type, "focus_register": f"r{output}",
                      "varied_initial_register": f"r{varied}", "varied_values": values}


def _rows_bytes(examples: list[Example]) -> bytes:
    return "".join(_json(asdict(example)) + "\n" for example in examples).encode()


def validate_dataset(dataset: Dataset) -> dict[str, Any]:
    """Independent text re-parsing validates labels and split boundaries."""
    owner_exact, owner_canonical, owner_family = {}, {}, {}
    signatures: dict[str, set[tuple[int, ...]]] = {}
    counts, baseline, focal_baselines = {}, {}, {}
    train_majorities: dict[str, int] = {}
    train_answers = Counter(e.answer_id for e in dataset.splits["train"])
    most_frequent = min(train_answers, key=lambda v: (-train_answers[v], v))
    for r in range(4):
        values = [e.answer_id for e in dataset.splits["train"] if e.metadata["query_register"] == r]
        train_majorities[f"r{r}"] = min(Counter(values), key=lambda v: (-values.count(v), v))
    for panel, examples in dataset.splits.items():
        families: dict[str, list[Example]] = {}
        answers, focal_answers = Counter(), Counter()
        signatures[panel] = set()
        query_hits = last_hits = oracle_hits = focal_count = most_frequent_hits = 0
        literal_frequency_hits = 0
        focal_hits = Counter()
        for example in examples:
            program, query = parse_input(example.input_ids)
            state = execute(program)
            answer = VOCABULARY[f"v{state[int(query[1:])]}" ]
            if answer != example.answer_id or tuple(example.metadata["final_state"]) != state:
                raise AssertionError("label does not follow serialized text")
            if serialize(program, query) != example.input_ids:
                raise AssertionError("serialization roundtrip mismatch")
            if example.metadata["query_register"] != int(query[1:]):
                raise AssertionError("query metadata mismatch")
            if example.metadata["expected_value"] != state[int(query[1:])]:
                raise AssertionError("expected-value metadata mismatch")
            if panel in ("train", "dev", "iid") and any(
                    left[0] == "copy" and right[0] == "sub"
                    for left, right in zip(program, program[1:])):
                raise AssertionError("held-out COPY->SUB operation order leaked")
            if panel == "composition":
                copy, sub = program[-2:]
                if copy[0] != "copy" or sub[0] != "sub" or copy[1] not in sub[2:]:
                    raise AssertionError("composition does not read copied result")
                focus = int(sub[1][1:])
                swapped = program[:-1] + [("sub", sub[1], sub[3], sub[2])]
                if execute(swapped)[focus] == state[focus]:
                    raise AssertionError("SUB ordering is not discriminating")
                before = execute(program[:-1])
                changed_copy = ("set", copy[1], f"v{(before[int(copy[1][1:])] + 1) % 8}")
                if execute(program[:-2] + [changed_copy, sub])[focus] == state[focus]:
                    raise AssertionError("composition lacks causal copy dependence")
            if panel == "correction":
                copy, overwrite = program[-2:]
                old = execute(program[:-2])[int(copy[2][1:])]
                if (copy[0] != "copy" or overwrite[0] != "set" or overwrite[1] != copy[2]
                        or state[int(copy[1][1:])] != old or state[int(copy[2][1:])] == old):
                    raise AssertionError("source-overwrite preservation failed")
            if panel == "long":
                focus = example.metadata["target_register"]
                if execute(program[:-16])[focus] != state[focus]:
                    raise AssertionError("long distractors changed focal register")
            if panel == "counterfactual":
                sub = program[-3]
                if sub[0] != "sub" or len(set(sub[1:])) != 3:
                    raise AssertionError("counterfactual SUB introduces operand/destination aliasing")
            exact, canonical = _sha(program), _sha(canonical_program(program))
            for table, key in ((owner_exact, exact), (owner_canonical, canonical),
                               (owner_family, example.family_id)):
                previous = table.setdefault(key, panel)
                if previous != panel:
                    raise AssertionError(f"cross-panel program/family leakage: {previous}, {panel}")
            answers[answer] += 1
            signatures[panel].add(state)
            oracle_hits += int(answer == example.answer_id)
            query_hits += int(train_majorities[query] == answer)
            most_frequent_hits += int(most_frequent == answer)
            last_value = next(word for op in reversed(program) for word in reversed(op)
                              if word.startswith("v"))
            last_hits += int(VOCABULARY[last_value] == answer)
            literal_counts = Counter(word for op in program for word in op if word.startswith("v"))
            literal_mode = min(literal_counts, key=lambda word: (-literal_counts[word], int(word[1:])))
            literal_frequency_hits += int(VOCABULARY[literal_mode] == answer)
            if query == example.metadata.get("focus_register"):
                focal_count += 1
                focal_answers[answer] += 1
                focal_hits["symbolic_interpreter_accuracy"] += int(answer == example.answer_id)
                focal_hits["train_fitted_query_only_accuracy"] += int(train_majorities[query] == answer)
                focal_hits["train_fitted_most_frequent_value_accuracy"] += int(most_frequent == answer)
                focal_hits["last_explicit_value_accuracy"] += int(VOCABULARY[last_value] == answer)
                focal_hits["most_frequent_literal_value_accuracy"] += int(VOCABULARY[literal_mode] == answer)
            families.setdefault(example.family_id, []).append(example)
        expected_families = PANEL_FAMILIES[panel]
        if len(families) != expected_families:
            raise AssertionError("wrong family count")
        for rows in families.values():
            expected = 16 if panel == "counterfactual" else 4
            if len(rows) != expected:
                raise AssertionError("incomplete independently queried world")
            for variant in sorted({e.metadata["variant_index"] for e in rows}):
                queries = {e.metadata["query_register"] for e in rows if e.metadata["variant_index"] == variant}
                if queries != {0, 1, 2, 3}:
                    raise AssertionError("missing full-state query")
            if panel == "counterfactual":
                focus = rows[0].metadata["target_register"]
                focal = [e.answer_id for e in rows if e.metadata["query_register"] == focus]
                kind = rows[0].metadata["case_type"]
                if len(set(focal)) != (4 if kind == "relevant_value" else 1):
                    raise AssertionError("counterfactual target invariant violated")
                final_states = {tuple(e.metadata["final_state"]) for e in rows}
                if kind == "unrelated_edit" and len(final_states) != 1:
                    raise AssertionError("unrelated initial edit changed final state")
        n = len(examples)
        counts[panel] = {
            "families": len(families), "examples": n, "focal_examples": focal_count,
            "min_input_tokens": min(len(e.input_ids) for e in examples),
            "max_input_tokens": max(len(e.input_ids) for e in examples),
            "answer_counts": {f"v{i}": answers[VOCABULARY[f"v{i}"]] for i in range(8)},
            "max_answer_fraction": max(answers.values()) / n,
            "focal_answer_counts": {f"v{i}": focal_answers[VOCABULARY[f"v{i}"]] for i in range(8)},
            "focal_max_answer_fraction": (max(focal_answers.values()) / focal_count if focal_count else None),
            "unique_final_states": len(signatures[panel]),
        }
        baseline[panel] = {"symbolic_interpreter_accuracy": oracle_hits / n,
                           "train_fitted_query_only_accuracy": query_hits / n,
                           "train_fitted_most_frequent_value_accuracy": most_frequent_hits / n,
                           "most_frequent_literal_value_accuracy": literal_frequency_hits / n,
                           "last_explicit_value_accuracy": last_hits / n}
        focal_baselines[panel] = ({"examples": focal_count, **{
            name: focal_hits[name] / focal_count for name in (
                "symbolic_interpreter_accuracy", "train_fitted_query_only_accuracy",
                "train_fitted_most_frequent_value_accuracy", "last_explicit_value_accuracy",
                "most_frequent_literal_value_accuracy")}} if focal_count else None)
    overlaps = {}
    panels = list(dataset.splits)
    for i, left in enumerate(panels):
        for right in panels[i + 1:]:
            overlaps[f"{left}:{right}"] = len(signatures[left] & signatures[right])
    return {"counts": counts, "shortcut_baselines": baseline, "focal_shortcut_baselines": focal_baselines,
            "exact_history_cross_panel_overlap": 0, "canonical_program_cross_panel_overlap": 0,
            "family_cross_panel_overlap": 0, "final_state_overlap_counts": overlaps,
            "final_state_disjoint": not any(overlaps.values())}


def build_dataset(seed: int = 1701) -> Dataset:
    """Build deterministically; fresh queries never consume earlier gold answers."""
    if type(seed) is not int:
        raise ValueError("seed must be an integer")
    rng = random.Random(seed)
    splits: dict[str, list[Example]] = {}
    used_exact, used_canonical, used_families = set(), set(), set()
    for panel, count in PANEL_FAMILIES.items():
        examples = []
        for number in range(count):
            for attempt in range(10_000):
                programs, info = _make_family(rng, panel, number)
                exacts = {_sha(program) for program in programs}
                canonicals = {_sha(canonical_program(program)) for program in programs}
                family_hash = _sha(sorted(canonicals))
                if (not exacts & used_exact and not canonicals & used_canonical
                        and family_hash not in used_families):
                    break
            else:
                raise RuntimeError("failed to generate distinct family")
            used_exact.update(exacts)
            used_canonical.update(canonicals)
            used_families.add(family_hash)
            family_id = family_hash
            for variant, program in enumerate(programs):
                state = execute(program)
                for query_index in range(4):
                    query = f"r{query_index}"
                    metadata = dict(info)
                    metadata.update({"program": [list(op) for op in program], "final_state": list(state),
                                     "initial_state": list(execute(program[:4])),
                                     "query_register": query_index, "variant_index": variant,
                                     "variant": variant, "expected_value": state[query_index],
                                     "target_register": (int(info["focus_register"][1:])
                                                         if info["focus_register"] is not None else None),
                                     "world_id": (f"{family_id}:v{variant}" if panel == "counterfactual"
                                                  else family_id),
                                     "history_sha256": _sha(program),
                                     "canonical_program_sha256": _sha(canonical_program(program)),
                                     "family_number": number})
                    examples.append(Example(
                        id=f"{panel}-{number:04d}-v{variant}-q{query_index}",
                        family_id=family_id, panel=panel, input_ids=serialize(program, query),
                        answer_id=VOCABULARY[f"v{state[query_index]}"], metadata=metadata))
        splits[panel] = examples
    dataset = Dataset(splits, dict(VOCABULARY), {})
    validation = validate_dataset(dataset)
    dataset.manifest = {
        "version": VERSION, "seed": seed, "vocabulary": dataset.vocabulary,
        "register_count": 4, "value_count": 8, "panel_families": PANEL_FAMILIES,
        "objective": "answer-focused synthetic diagnostic; no language-model competence claim",
        "model_inputs": ["input_ids"], "training_labels": ["answer_id"],
        "metadata_access": "evaluator only; no addresses, operation labels, or state passed to models",
        "composition_holdout": "all adjacent COPY->SUB orders absent in train/dev/iid; composition panel requires actual copy dependence; longer indirect chains may occur",
        "split_unit": "complete program family including all four independent queries and counterfactual variants",
        "final_state_limit": "Programs/families are disjoint, but final 4-register states may overlap across panels; only 4096 states exist. No final-state-disjoint or unseen-ontology claim.",
        "answer_balance": "All frequencies reported without outcome-dependent resampling; majority baseline fitted on train only.",
        "counterfactual_design": "64 relevant-value quartets with four distinct focal answers; four queries per variant. Long-panel irrelevant updates provide a separate preservation test.",
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "panel_sha256": {panel: hashlib.sha256(_rows_bytes(rows)).hexdigest() for panel, rows in splits.items()},
        "validation": validation,
    }
    return dataset


def save_dataset(directory: str | Path, dataset: Dataset | None = None, seed: int = 1701) -> dict[str, str]:
    dataset = build_dataset(seed) if dataset is None else dataset
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    paths = {}
    for panel, rows in dataset.splits.items():
        path = directory / f"{panel}.jsonl"
        content = _rows_bytes(rows)
        if hashlib.sha256(content).hexdigest() != dataset.manifest["panel_sha256"][panel]:
            raise ValueError("dataset was mutated after manifest creation")
        path.write_bytes(content)
        paths[panel] = str(path.resolve())
    manifest_path = directory / "manifest.json"
    manifest_path.write_text(json.dumps(dataset.manifest, indent=2, sort_keys=True) + "\n")
    paths["manifest"] = str(manifest_path.resolve())
    return paths


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=1701)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    data = build_dataset(args.seed)
    if args.output is not None:
        save_dataset(args.output, data)
    print(json.dumps(data.manifest["validation"], indent=2, sort_keys=True))
