"""Dense CSM inference with explicit within-token fork/join scheduling.

This bridge borrows the frozen model's tensor submodules and parameters. It does
not replace masked storage, use indexed reads, pack affine heads, or introduce a
training rule. The serialized and fork/join schedules use the same helpers.

Actual asynchronous execution requires torch.jit.script(RuntimeBridge(model)).
Eager Python calls to torch.jit.fork are not parallel. The verified environment
is PyTorch 2.5.1+cpu; TorchScript is a pinned-runtime verification mechanism here.
"""
from typing import Dict, List, Tuple

import torch
from torch import Tensor, nn
from torch.nn import functional as F


State = Tuple[Tensor, Tensor, Tensor, Tensor, int]
StepResult = Tuple[Tensor, State, Dict[str, Tensor]]


def hard_choice(logits: Tensor, temperature: float) -> Tensor:
    probabilities = (logits / temperature).softmax(-1)
    chosen = F.one_hot(probabilities.argmax(-1), probabilities.shape[-1]).to(logits.dtype)
    return chosen + (probabilities - probabilities.detach())


def read(address: Tensor, values: Tensor) -> Tensor:
    return torch.bmm(address.unsqueeze(1), values).squeeze(1)


class RuntimeBridge(nn.Module):
    """Pure dense transition; every returned state tensor has fresh storage."""

    __constants__ = ["slots", "width", "temperature", "mode", "vocab_size"]

    def __init__(self, original: nn.Module):
        super().__init__()
        config = original.config
        self.slots, self.width = config.slots, config.width
        self.temperature, self.vocab_size = float(config.temperature), config.vocab_size
        self.mode = {"rewrite": 0, "ring_write": 1, "no_links": 2}[config.mode]
        if self.temperature <= 0:
            raise ValueError("The verified bridge requires positive temperature")
        # Borrow existing parameter tensors; no initialization or fitting occurs.
        self.embedding = original.embedding
        self.frontend = original.frontend
        self.controller = original.controller
        self.first_address = original.first_address
        self.second_address = original.second_address
        self.destination = original.destination
        self.use_link = original.use_link
        self.link_edit = original.link_edit
        self.operator = original.operator
        self.operator_embedding = original.operator_embedding
        self.transform = original.transform
        self.write_gate = original.write_gate
        self.value_edit = original.value_edit
        self.output = original.output

    @torch.jit.export
    def init_state(self, batch: int, device: torch.device) -> State:
        dtype = self.embedding.weight.dtype
        values = torch.zeros((batch, self.slots, self.width), dtype=dtype, device=device)
        links = torch.eye(self.slots, dtype=dtype, device=device).unsqueeze(0).repeat(batch, 1, 1)
        cursor = torch.zeros((batch, self.slots), dtype=dtype, device=device)
        cursor[:, 0] = 1
        history = torch.zeros((batch, 2, self.width), dtype=dtype, device=device)
        return values, links, cursor, history, 0

    def _front(self, tokens: Tensor, history: Tensor) -> Tuple[Tensor, Tensor]:
        raw = self.embedding(tokens)
        front = torch.tanh(self.frontend(torch.cat((history.flatten(1), raw), -1)))
        return front, torch.stack((history[:, 1], raw), 1)

    def _route(self, control: Tensor, values: Tensor, links: Tensor
               ) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
        first = hard_choice(self.first_address(control), self.temperature)
        value_a = read(first, values)
        direct_second = hard_choice(
            self.second_address(torch.cat((control, value_a), -1)), self.temperature)
        linked_second = read(first, links)
        link_choice = hard_choice(self.use_link(control), self.temperature)
        if self.mode == 2:
            second = direct_second
        else:
            second = link_choice[:, :1] * direct_second + link_choice[:, 1:] * linked_second
        value_b = read(second, values)
        return first, second, value_a, value_b, link_choice

    def _operation(self, control: Tensor) -> Tuple[Tensor, Tensor]:
        operation = hard_choice(self.operator(control), self.temperature)
        return operation, operation @ self.operator_embedding

    def _write_controls(self, control: Tensor, values: Tensor, position: int
                        ) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
        destination = hard_choice(self.destination(control), self.temperature)
        if self.mode == 1:
            destination = torch.zeros_like(destination)
            destination[:, position % self.slots] = 1
        previous = read(destination, values)
        value_edit = hard_choice(self.value_edit(control), self.temperature)[:, 1:]
        gate = value_edit * torch.sigmoid(self.write_gate(control))
        edit = hard_choice(self.link_edit(control), self.temperature)[:, 1:]
        return destination, previous, gate, value_edit, edit

    def _links(self, links: Tensor, destination: Tensor, edit: Tensor,
               second: Tensor) -> Tensor:
        edge_mask = destination.unsqueeze(-1) * edit.unsqueeze(-1)
        return links * (1 - edge_mask) + edge_mask * second.unsqueeze(1)

    def _values(self, values: Tensor, destination: Tensor, updated: Tensor) -> Tensor:
        return (values * (1 - destination.unsqueeze(-1))
                + destination.unsqueeze(-1) * updated.unsqueeze(1))

    def _trace(self, first: Tensor, second: Tensor, destination: Tensor,
               operation: Tensor, link_choice: Tensor, edit: Tensor,
               gate: Tensor, value_edit: Tensor) -> Dict[str, Tensor]:
        return {
            "first": first.argmax(-1), "second": second.argmax(-1),
            "destination": destination.argmax(-1), "operator": operation.argmax(-1),
            "uses_link": link_choice.argmax(-1), "edits_link": edit.squeeze(-1),
            "gate": gate.squeeze(-1), "edits_value": value_edit.squeeze(-1),
        }

    @torch.jit.export
    def step_serial(self, tokens: Tensor, state: State) -> StepResult:
        values, links, cursor, history, position = state
        front, next_history = self._front(tokens, history)
        active = read(cursor, values)
        control = torch.tanh(self.controller(torch.cat((front, active), -1)))
        first, second, value_a, value_b, link_choice = self._route(control, values, links)
        operation, operation_vector = self._operation(control)
        destination, previous, gate, value_edit, edit = self._write_controls(
            control, values, position)
        next_links = self._links(links, destination, edit, second)
        proposal = self.transform(torch.cat((front, value_a, value_b, operation_vector), -1))
        updated = previous + gate * (proposal - previous)
        logits = self.output(updated)
        next_values = self._values(values, destination, updated)
        trace = self._trace(first, second, destination, operation, link_choice,
                            edit, gate, value_edit)
        return logits, (next_values, next_links, destination, next_history, position + 1), trace

    @torch.jit.export
    def step_parallel(self, tokens: Tensor, state: State) -> StepResult:
        values, links, cursor, history, position = state
        # Join 1: independent local-token frontend and old-state active read.
        front_future = torch.jit.fork(self._front, tokens, history)
        active = read(cursor, values)
        front, next_history = torch.jit.wait(front_future)
        control = torch.tanh(self.controller(torch.cat((front, active), -1)))
        # Join 2: three pure branches sharing only immutable old state/control.
        route_future = torch.jit.fork(self._route, control, values, links)
        operation_future = torch.jit.fork(self._operation, control)
        write_future = torch.jit.fork(self._write_controls, control, values, position)
        first, second, value_a, value_b, link_choice = torch.jit.wait(route_future)
        operation, operation_vector = torch.jit.wait(operation_future)
        destination, previous, gate, value_edit, edit = torch.jit.wait(write_future)
        # Link storage is independent of the proposal/value update.
        links_future = torch.jit.fork(self._links, links, destination, edit, second)
        proposal = self.transform(torch.cat((front, value_a, value_b, operation_vector), -1))
        updated = previous + gate * (proposal - previous)
        # Join 3: vocabulary projection and value storage are independent.
        output_future = torch.jit.fork(self.output, updated)
        next_values = self._values(values, destination, updated)
        next_links = torch.jit.wait(links_future)
        logits = torch.jit.wait(output_future)
        trace = self._trace(first, second, destination, operation, link_choice,
                            edit, gate, value_edit)
        return logits, (next_values, next_links, destination, next_history, position + 1), trace

    def forward(self, tokens: Tensor) -> Tensor:
        state = self.init_state(tokens.shape[0], tokens.device)
        output = torch.jit.annotate(List[Tensor], [])
        # Tokens remain recurrently ordered; only each transition contains forks.
        for position in range(tokens.shape[1]):
            logits, state, _ = self.step_parallel(tokens[:, position], state)
            output.append(logits)
        return torch.stack(output, 1)

    @torch.jit.export
    def forward_serial(self, tokens: Tensor) -> Tensor:
        state = self.init_state(tokens.shape[0], tokens.device)
        output = torch.jit.annotate(List[Tensor], [])
        for position in range(tokens.shape[1]):
            logits, state, _ = self.step_serial(tokens[:, position], state)
            output.append(logits)
        return torch.stack(output, 1)
