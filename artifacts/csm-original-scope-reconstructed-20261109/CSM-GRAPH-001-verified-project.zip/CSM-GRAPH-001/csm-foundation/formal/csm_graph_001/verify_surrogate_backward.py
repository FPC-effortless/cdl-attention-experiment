"""Compare the existing straight-through surrogate backward graph without fitting.

This checks autograd through original, scripted serial, and scripted fork/join
transitions. It is not a derivative test for discrete argmax. Initial links and
cursors are one-hot at the forward point; their coordinate gradients refer to
the implemented continuous surrogate representation, not discrete derivatives.
"""
import copy
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time

import torch
from torch.nn import functional as F


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
EXPERIMENT = REPO / "experiments" / "csm_foundation_001"
sys.path.insert(0, str(EXPERIMENT))
from model import Config, RecordRewrite, RecordState
from runtime_bridge import RuntimeBridge


MODES = ("rewrite", "ring_write", "no_links")
SHAPES_AND_OBJECTIVES = ((1, 3, "outputs"), (3, 5, "outputs_and_state"),
                         (2, 7, "outputs_and_state"))
GRAD_ATOL, GRAD_RTOL = 2e-6, 2e-5


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def tensor_sha(tensor):
    return hashlib.sha256(tensor.detach().contiguous().cpu().numpy().tobytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def sources_and_models(report):
    freeze = read_json(EXPERIMENT / "frozen_manifest.json")
    closure = read_json(EXPERIMENT / "training_closed.json")
    freeze_hash = sha(EXPERIMENT / "frozen_manifest.json")
    require(closure["freeze_sha256"] == freeze_hash, "Closure freeze mismatch")
    for name, expected in freeze["source_sha256"].items():
        require(sha(EXPERIMENT / name) == expected, f"Frozen source changed: {name}")
    report["frozen_manifest_sha256"] = freeze_hash
    report["frozen_sources_verified"] = len(freeze["source_sha256"])
    cases = []
    for index, mode in enumerate(MODES):
        torch.manual_seed(49001 + index)
        cases.append((f"random/{mode}", RecordRewrite(Config(37, mode=mode)).eval(),
                      {"kind": "random", "seed": 49001 + index}))
    for task in ("structured", "lm"):
        for mode in MODES:
            directory = EXPERIMENT / "runs" / task / mode / "11"
            closed = closure["completed_fits"][f"{task}/{mode}/11"]
            require(sha(directory / "checkpoint.pt") == closed["checkpoint_sha256"],
                    f"Checkpoint hash mismatch: {task}/{mode}")
            require(sha(directory / "completed.json") == closed["completed_sha256"],
                    f"Receipt hash mismatch: {task}/{mode}")
            receipt = read_json(directory / "completed.json")
            specification = receipt["model"]
            config = Config(**{key: specification[key] for key in
                               ("vocab_size", "width", "slots", "operators", "inner",
                                "mode", "temperature")})
            model = RecordRewrite(config)
            checkpoint = torch.load(directory / "checkpoint.pt", map_location="cpu",
                                    weights_only=False)
            model.load_state_dict(checkpoint["model_state"], strict=True)
            model.eval()
            cases.append((f"{task}/{mode}/11", model, {
                "kind": "frozen_checkpoint", "checkpoint_sha256": closed["checkpoint_sha256"],
                "completed_sha256": closed["completed_sha256"],
            }))
    return cases


def trial_inputs(model, batch, length, seed):
    generator = torch.Generator().manual_seed(seed)
    c = model.config
    x = torch.randint(c.vocab_size, (batch, length), generator=generator)
    values = 1.4 * torch.rand((batch, c.slots, c.width), generator=generator) - 0.7
    pointers = torch.randint(c.slots, (batch, c.slots), generator=generator)
    links = F.one_hot(pointers, c.slots).float()
    cursor = F.one_hot(torch.randint(c.slots, (batch,), generator=generator), c.slots).float()
    history_tokens = torch.randint(c.vocab_size, (batch, 2), generator=generator)
    history = model.embedding(history_tokens).detach()
    state = values, links, cursor, history, 5
    coefficients = {
        "outputs": torch.randn((batch, length, c.vocab_size), generator=generator),
        "values": torch.randn(values.shape, generator=generator),
        "links": torch.randn(links.shape, generator=generator),
        "cursor": torch.randn(cursor.shape, generator=generator),
        "history": torch.randn(history.shape, generator=generator),
    }
    return x, state, coefficients


def differentiate(model, method, tokens, initial, coefficients, objective_kind):
    differentiable = [tensor.detach().clone().requires_grad_(True) for tensor in initial[:4]]
    state = tuple(differentiable) + (initial[4],)
    outputs, traces = [], []
    for position in range(tokens.shape[1]):
        if method == "original":
            result = model.step(tokens[:, position], RecordState(*state), return_trace=True)
            logits, next_state, trace = result
            state = (next_state.values, next_state.links, next_state.cursor,
                     next_state.history, next_state.position)
        else:
            function = model.step_serial if method == "serial" else model.step_parallel
            logits, state, trace = function(tokens[:, position], state)
        outputs.append(logits)
        traces.append({key: value.detach().clone() for key, value in trace.items()})
    stacked = torch.stack(outputs, 1)
    objective = ((stacked * coefficients["outputs"]).sum() / math.sqrt(stacked.numel())
                 + 0.03 * stacked.square().mean())
    if objective_kind == "outputs_and_state":
        for name, tensor in zip(("values", "links", "cursor", "history"), state[:4]):
            objective = objective + 0.05 * (
                tensor * coefficients[name]).sum() / math.sqrt(tensor.numel())
    parameters = dict(model.named_parameters())
    names = ["parameter/" + name for name in parameters]
    names += ["initial_state/" + name for name in ("values", "links", "cursor", "history")]
    targets = list(parameters.values()) + differentiable
    gradients = torch.autograd.grad(objective, targets, allow_unused=True)
    return {
        "objective": float(objective.detach()), "logits": stacked.detach(),
        "state": tuple(tensor.detach() for tensor in state[:4]) + (state[4],),
        "traces": traces, "gradients": dict(zip(names, gradients)),
    }


def gradient_comparison(actual, expected):
    require(set(actual) == set(expected), "Gradient name sets differ")
    rows = []
    for name in expected:
        reference, candidate = expected[name], actual[name]
        if reference is None or candidate is None:
            matched = reference is None and candidate is None
            rows.append({
                "name": name, "passed": matched,
                "reference_is_none": reference is None, "candidate_is_none": candidate is None,
                "all_exact": matched, "max_absolute_difference": None,
                "max_tolerance_fraction": None,
            })
            continue
        require(reference.shape == candidate.shape and reference.dtype == candidate.dtype,
                f"Gradient shape/dtype mismatch: {name}")
        finite = bool(torch.isfinite(reference).all() and torch.isfinite(candidate).all())
        difference = (candidate - reference).abs()
        tolerance = GRAD_ATOL + GRAD_RTOL * reference.abs()
        fraction = difference / tolerance
        rows.append({
            "name": name, "passed": finite and bool((difference <= tolerance).all()),
            "reference_is_none": False, "candidate_is_none": False,
            "shape": list(reference.shape), "all_exact": torch.equal(reference, candidate),
            "max_absolute_difference": float(difference.max()),
            "max_tolerance_fraction": float(fraction.max()),
            "reference_max_absolute": float(reference.abs().max()),
            "candidate_max_absolute": float(candidate.abs().max()),
            "reference_nonzero_elements": int(torch.count_nonzero(reference)),
            "candidate_nonzero_elements": int(torch.count_nonzero(candidate)),
            "reference_l2_norm": float(reference.double().norm()),
            "candidate_l2_norm": float(candidate.double().norm()),
            "reference_sha256": tensor_sha(reference), "candidate_sha256": tensor_sha(candidate),
        })
    return rows


def compare_trial(actual, expected, method):
    forward_exact = torch.equal(actual["logits"], expected["logits"])
    state_exact = (actual["state"][4] == expected["state"][4]
                   and all(torch.equal(a, b) for a, b in zip(actual["state"][:4],
                                                            expected["state"][:4])))
    routes_exact = all(
        set(a) == set(b) and all(torch.equal(a[key], b[key]) for key in a)
        for a, b in zip(actual["traces"], expected["traces"])
    )
    gradients = gradient_comparison(actual["gradients"], expected["gradients"])
    meaningful = any(
        row.get("reference_nonzero_elements", 0) > 0
        for row in gradients if row["name"].startswith("parameter/"))
    numeric = [row for row in gradients if row["max_absolute_difference"] is not None]
    return {
        "method": method,
        "status": "PASS" if (forward_exact and state_exact and routes_exact and meaningful
                             and all(row["passed"] for row in gradients)) else "FAIL",
        "forward_logits_exact": forward_exact, "final_state_exact": state_exact,
        "all_route_gate_traces_exact": routes_exact,
        "objective_absolute_difference": abs(actual["objective"] - expected["objective"]),
        "gradients_compared": len(gradients),
        "none_gradients_matched": all(row["reference_is_none"] == row["candidate_is_none"]
                                    for row in gradients),
        "reference_none_gradient_count": sum(row["reference_is_none"] for row in gradients),
        "nontrivial_parameter_gradients": meaningful,
        "max_absolute_gradient_difference": max(row["max_absolute_difference"] for row in numeric),
        "max_tolerance_fraction": max(row["max_tolerance_fraction"] for row in numeric),
        "gradient_comparisons": gradients,
    }


def main():
    output = HERE / "SURROGATE_BACKWARD_VERIFICATION.json"
    if output.exists():
        raise FileExistsError("Existing surrogate-backward evidence will not be overwritten")
    torch.set_num_threads(1)
    torch.set_num_interop_threads(4)
    torch.use_deterministic_algorithms(True)
    report = {
        "schema_version": 1, "status": "RUNNING", "optimizer_steps": 0,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "bridge_sha256": sha(HERE / "runtime_bridge.py"),
        "verifier_sha256": sha(Path(__file__)),
        "environment": {"python": platform.python_version(), "torch": torch.__version__,
                        "device": "cpu", "dtype": "float32", "intraop_threads": 1,
                        "interop_threads": 4, "model_mode": "eval with gradients enabled"},
        "gradient_tolerance": {"absolute": GRAD_ATOL, "relative_to_reference": GRAD_RTOL},
        "initial_state": {
            "values": "Uniform in [-0.7,0.7], nonzero",
            "links": "Random one-hot row per slot",
            "cursor": "Random one-hot slot",
            "history": "Detached embeddings of two random vocabulary tokens",
            "position": 5,
            "interpretation": "Structurally valid forward points; not claimed reachable histories. Four initial float tensors are independent differentiable leaves.",
        },
        "objective": {
            "outputs": "sum(logits*fixed_random_coefficients)/sqrt(numel) + 0.03*mean(logits**2)",
            "outputs_and_state": "outputs + 0.05*sum_over_state_fields(sum(final_field*fixed_random_coefficients)/sqrt(field_numel))",
        },
        "scope": "Equality of the implemented straight-through surrogate autograd program, not a true derivative of discrete argmax and not an optimization run.",
        "cases": [],
    }
    started = time.perf_counter()
    try:
        require(torch.__version__ == "2.5.1+cpu", "Verification is pinned to PyTorch 2.5.1+cpu")
        with torch.enable_grad():
            for identifier, original, provenance in sources_and_models(report):
                original.requires_grad_(True)
                weights_before = {key: value.clone().detach()
                                  for key, value in original.state_dict().items()}
                bridge_source = copy.deepcopy(original).eval().requires_grad_(True)
                scripted = torch.jit.script(RuntimeBridge(bridge_source).eval())
                trials = []
                for index, (batch, length, objective) in enumerate(SHAPES_AND_OBJECTIVES):
                    tokens, initial, coefficients = trial_inputs(original, batch, length,
                                                                 80113 + index)
                    reference = differentiate(original, "original", tokens, initial,
                                              coefficients, objective)
                    comparisons = []
                    for method in ("serial", "parallel"):
                        result = differentiate(scripted, method, tokens, initial,
                                               coefficients, objective)
                        comparisons.append(compare_trial(result, reference, method))
                    trials.append({
                        "batch": batch, "length": length, "objective_kind": objective,
                        "reference_objective": reference["objective"],
                        "comparisons": comparisons,
                    })
                for key, value in original.state_dict().items():
                    require(torch.equal(value, weights_before[key]),
                            f"Original weight mutation: {identifier}/{key}")
                    require(torch.equal(scripted.state_dict()[key], weights_before[key]),
                            f"Bridge weight mutation: {identifier}/{key}")
                status = "PASS" if all(
                    row["status"] == "PASS" for trial in trials
                    for row in trial["comparisons"]) else "FAIL"
                report["cases"].append({"case": identifier, "status": status,
                                        "provenance": provenance, "weights_unchanged": True,
                                        "trials": trials})
                print(json.dumps({"case": identifier, "status": status,
                                  "max_gradient_difference": max(
                                      row["max_absolute_gradient_difference"]
                                      for trial in trials for row in trial["comparisons"])}),
                      flush=True)
        require(len(report["cases"]) == 9, "Incomplete backward verification cohort")
        report["status"] = "PASS" if all(row["status"] == "PASS"
                                         for row in report["cases"]) else "FAIL"
    except Exception as error:
        report["status"] = "FAIL"
        report["error"] = f"{type(error).__name__}: {error}"
    report["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
    report["wall_seconds"] = time.perf_counter() - started
    all_comparisons = [comparison for case in report["cases"] for trial in case["trials"]
                       for comparison in trial["comparisons"]]
    report["gradient_tensor_comparisons"] = sum(row["gradients_compared"] for row in all_comparisons)
    report["max_absolute_gradient_difference"] = max(
        (row["max_absolute_gradient_difference"] for row in all_comparisons), default=None)
    report["max_tolerance_fraction"] = max(
        (row["max_tolerance_fraction"] for row in all_comparisons), default=None)
    output.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: report[key] for key in
                     ("status", "gradient_tensor_comparisons",
                      "max_absolute_gradient_difference", "max_tolerance_fraction",
                      "wall_seconds")} | {"error": report.get("error")}), flush=True)
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
