import Std

/-!
The entire hard-forward CSM cell, parameterized by its pure neural kernels.
`Feature`, `Control`, `Hidden`, `Strength`, and `Logits` may be finite vectors.
This file verifies wiring and scheduling, not implementations of floating-point
affine maps, tanh, sigmoid, softmax, or their surrogate pullbacks.
The finite-address representation assumes valid hard one-hot routing.
-/
namespace CSM.Model

inductive Mode where
  | rewrite | ringWrite | noLinks
  deriving DecidableEq, Repr

abbrev Store (slots : Nat) (α : Type) := Fin slots → α

structure State (slots : Nat) (Feature : Type) where
  values : Store slots Feature
  links : Store slots (Fin slots)
  cursor : Fin slots
  older : Feature
  recent : Feature
  position : Nat

structure Kernels (slots operators : Nat)
    (Token Feature Control Hidden Strength Logits : Type) where
  embed : Token → Feature
  frontend : Feature → Feature → Feature → Feature
  controller : Feature → Feature → Control
  firstAddress : Control → Fin slots
  secondAddress : Control → Feature → Fin slots
  destination : Control → Fin slots
  useLink : Control → Bool
  linkEdit : Control → Bool
  valueEdit : Control → Bool
  writeStrength : Control → Strength
  operatorChoice : Control → Fin operators
  operatorEmbedding : Fin operators → Feature
  transformHidden : Feature → Feature → Feature → Feature → Hidden
  transformOutput : Hidden → Feature
  /-- For the intended real-valued instantiation: old + g * (proposal - old). -/
  blend : Strength → Feature → Feature → Feature
  output : Feature → Logits

variable {S O : Nat} {Token Feature Control Hidden Strength Logits : Type}

def writeAt (store : Store S α) (destination : Fin S) (value : α) : Store S α :=
  fun i => if i = destination then value else store i

@[simp] theorem writeAt_same (store : Store S α) (d : Fin S) (v : α) :
    writeAt store d v d = v := by simp [writeAt]

theorem writeAt_other (store : Store S α) (d i : Fin S) (v : α) (h : i ≠ d) :
    writeAt store d v i = store i := by simp [writeAt, h]

@[simp] theorem writeAt_existing (store : Store S α) (d : Fin S) :
    writeAt store d (store d) = store := by
  funext i
  by_cases h : i = d
  · subst i; simp
  · simp [writeAt, h]

def ringIndex (position : Nat) (witness : Fin S) : Fin S :=
  ⟨position % S, Nat.mod_lt _ (by have := witness.isLt; omega)⟩

def chooseDestination
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (control : Control) : Fin S :=
  match mode with
  | .ringWrite => ringIndex s.position s.cursor
  | _ => k.destination control

def chooseSecond (mode : Mode) (useLink : Bool)
    (linked direct : Fin S) : Fin S :=
  match mode with
  | .noLinks => direct
  | _ => if useLink then linked else direct

structure Plan (slots operators : Nat) (Feature Control Strength : Type) where
  embedding : Feature
  control : Control
  first : Fin slots
  second : Fin slots
  destination : Fin slots
  operation : Fin operators
  editValue : Bool
  editLink : Bool
  strength : Strength
  proposal : Feature
  updated : Feature

/- Exact source-style order of the named neural maps and reads. -/
def serialPlan
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (x : Token) :
    Plan S O Feature Control Strength :=
  let e := k.embed x
  let f := k.frontend s.older s.recent e
  let active := s.values s.cursor
  let u := k.controller f active
  let first := k.firstAddress u
  let a := s.values first
  let direct := k.secondAddress u a
  let linked := s.links first
  let second := chooseSecond mode (k.useLink u) linked direct
  let b := s.values second
  let operation := k.operatorChoice u
  let opVector := k.operatorEmbedding operation
  let hidden := k.transformHidden f a b opVector
  let proposal := k.transformOutput hidden
  let d := chooseDestination k mode s u
  let previous := s.values d
  let editValue := k.valueEdit u
  let strength := k.writeStrength u
  let updated := if editValue then k.blend strength previous proposal else previous
  { embedding := e, control := u, first := first, second := second,
    destination := d, operation := operation, editValue := editValue,
    editLink := k.linkEdit u, strength := strength, proposal := proposal,
    updated := updated }

structure Heads (slots operators : Nat) (Strength : Type) where
  first : Fin slots
  destination : Fin slots
  operation : Fin operators
  useLink : Bool
  editValue : Bool
  editLink : Bool
  strength : Strength

/- These seven heads share the controller, but do not depend on one another. -/
def parallelHeads
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (u : Control) : Heads S O Strength :=
  { first := k.firstAddress u, destination := chooseDestination k mode s u,
    operation := k.operatorChoice u, useLink := k.useLink u,
    editValue := k.valueEdit u, editLink := k.linkEdit u,
    strength := k.writeStrength u }

/- A legal dependency-level schedule. Tuples describe ready parallel branches;
Lean's evaluator is not claimed to run these tuples on multiple processors. -/
def parallelPlan
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (x : Token) :
    Plan S O Feature Control Strength :=
  let initial := (k.embed x, s.values s.cursor)
  let f := k.frontend s.older s.recent initial.1
  let u := k.controller f initial.2
  let heads := parallelHeads k mode s u
  let reads := (s.values heads.first, s.links heads.first,
                s.values heads.destination, k.operatorEmbedding heads.operation)
  let direct := k.secondAddress u reads.1
  let second := chooseSecond mode heads.useLink reads.2.1 direct
  let b := s.values second
  let hidden := k.transformHidden f reads.1 b reads.2.2.2
  let proposal := k.transformOutput hidden
  let updated := if heads.editValue then
      k.blend heads.strength reads.2.2.1 proposal else reads.2.2.1
  { embedding := initial.1, control := u, first := heads.first, second := second,
    destination := heads.destination, operation := heads.operation,
    editValue := heads.editValue, editLink := heads.editLink,
    strength := heads.strength, proposal := proposal, updated := updated }

theorem parallelPlan_eq_serialPlan
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (x : Token) :
    parallelPlan k mode s x = serialPlan k mode s x := by rfl

def commit
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (s : State S Feature) (p : Plan S O Feature Control Strength) :
    State S Feature × Logits :=
  ({ values := writeAt s.values p.destination p.updated,
     links := if p.editLink then writeAt s.links p.destination p.second else s.links,
     cursor := p.destination, older := s.recent, recent := p.embedding,
     position := s.position + 1 }, k.output p.updated)

def step
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (x : Token) :=
  commit k s (serialPlan k mode s x)

def parallelStep
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (x : Token) :=
  commit k s (parallelPlan k mode s x)

/-- Whole-state AND output equivalence, for every state, token, and pure kernel. -/
theorem parallelStep_eq_step
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (x : Token) :
    parallelStep k mode s x = step k mode s x := by rfl

theorem commit_value_frame
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (s : State S Feature) (p : Plan S O Feature Control Strength)
    (i : Fin S) (h : i ≠ p.destination) :
    (commit k s p).1.values i = s.values i := by simp [commit, writeAt, h]

theorem commit_link_frame
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (s : State S Feature) (p : Plan S O Feature Control Strength)
    (i : Fin S) (h : i ≠ p.destination) :
    (commit k s p).1.links i = s.links i := by
  cases hp : p.editLink <;> simp [commit, writeAt, h, hp]

theorem commit_active_is_updated
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (s : State S Feature) (p : Plan S O Feature Control Strength) :
    (commit k s p).1.values (commit k s p).1.cursor = p.updated := by
  simp [commit]

/-- The next token's active read is exactly this token's computed value. -/
theorem step_active_is_updated
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (x : Token) :
    (step k mode s x).1.values (step k mode s x).1.cursor =
      (serialPlan k mode s x).updated := by
  exact commit_active_is_updated k s (serialPlan k mode s x)

theorem step_position
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (x : Token) :
    (step k mode s x).1.position = s.position + 1 := by rfl

theorem step_history
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (x : Token) :
    (step k mode s x).1.older = s.recent ∧
    (step k mode s x).1.recent = k.embed x := by exact ⟨rfl, rfl⟩

theorem disabled_link_edit_preserves_links
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (s : State S Feature) (p : Plan S O Feature Control Strength)
    (h : p.editLink = false) :
    (commit k s p).1.links = s.links := by simp [commit, h]

theorem disabled_value_edit_preserves_values
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (x : Token)
    (h : k.valueEdit (serialPlan k mode s x).control = false) :
    (step k mode s x).1.values = s.values := by
  simp [serialPlan] at h
  simp [step, commit, serialPlan, h]

/-- A storage no-op cannot be called a whole-state identity: time advances. -/
theorem step_not_state_identity
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (x : Token) :
    (step k mode s x).1 ≠ s := by
  intro h
  have hp := congrArg State.position h
  simp [step_position] at hp

def run
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) : State S Feature → List Token → State S Feature × List Logits
  | s, [] => (s, [])
  | s, x :: xs =>
    let first := step k mode s x
    let rest := run k mode first.1 xs
    (rest.1, first.2 :: rest.2)

def initialState (zero : Feature) (first : Fin S) : State S Feature :=
  { values := fun _ => zero, links := fun i => i, cursor := first,
    older := zero, recent := zero, position := 0 }

theorem initialState_links (zero : Feature) (first i : Fin S) :
    (initialState zero first).links i = i := by rfl

def parallelRun
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) : State S Feature → List Token → State S Feature × List Logits
  | s, [] => (s, [])
  | s, x :: xs =>
    let first := parallelStep k mode s x
    let rest := parallelRun k mode first.1 xs
    (rest.1, first.2 :: rest.2)

/-- The within-step parallel schedule preserves every output and final state. -/
theorem parallelRun_eq_run
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (xs : List Token) :
    parallelRun k mode s xs = run k mode s xs := by
  induction xs generalizing s with
  | nil => rfl
  | cons x xs ih => simp [parallelRun, run, parallelStep_eq_step, ih]

theorem run_position
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (xs : List Token) :
    (run k mode s xs).1.position = s.position + xs.length := by
  induction xs generalizing s with
  | nil => simp [run]
  | cons x xs ih => simp [run, ih, step_position]; omega

theorem run_append
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (xs ys : List Token) :
    run k mode s (xs ++ ys) =
      let left := run k mode s xs
      let right := run k mode left.1 ys
      (right.1, left.2 ++ right.2) := by
  induction xs generalizing s with
  | nil => simp [run]
  | cons x xs ih => simp [run, ih]

theorem run_output_length
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (xs : List Token) :
    (run k mode s xs).2.length = xs.length := by
  induction xs generalizing s with
  | nil => rfl
  | cons x xs ih => simp [run, ih]

/-- No suffix can change the already-produced output prefix. -/
theorem causal_prefix
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (s : State S Feature) (xs ys : List Token) :
    (run k mode s (xs ++ ys)).2.take xs.length = (run k mode s xs).2 := by
  rw [run_append]
  change ((run k mode s xs).2 ++ _).take xs.length = _
  rw [← run_output_length k mode s xs]
  simp

def batchStep {batch : Nat}
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (states : Fin batch → State S Feature)
    (inputs : Fin batch → Token) :=
  fun i => step k mode (states i) (inputs i)

/-- Independent examples share parameters, not mutable recurrent state. -/
theorem batch_noninterference {batch : Nat}
    (k : Kernels S O Token Feature Control Hidden Strength Logits)
    (mode : Mode) (a b : Fin batch → State S Feature)
    (x y : Fin batch → Token) (i : Fin batch)
    (hs : a i = b i) (hx : x i = y i) :
    batchStep k mode a x i = batchStep k mode b y i := by simp [batchStep, hs, hx]

def encodeLinks (links : Store S (Fin S)) : Fin S → Fin S → Bool :=
  fun row col => decide (links row = col)

/-- The finite pointer representation always has exactly one selected column. -/
theorem encoded_links_one_hot (links : Store S (Fin S)) (row : Fin S) :
    ∃ col, encodeLinks links row col = true ∧
      ∀ other, encodeLinks links row other = true → other = col := by
  refine ⟨links row, ?_, ?_⟩
  · simp [encodeLinks]
  · intro other h
    simpa [encodeLinks, eq_comm] using h

theorem stored_self_loops_allowed (row : Fin S) :
    (fun i : Fin S => i) row = row := by rfl

end CSM.Model
