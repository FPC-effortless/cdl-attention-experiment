import Std

/-!
# Safe parallel record edits

This module concerns finite record storage, with routes already fixed.  An
`Edit` carries a fixed destination and a proposal whose dependence on the store
is bounded by an explicit read footprint.  Proposals committed in parallel are
computed from one frozen snapshot.

`SafePair` excludes write/write and both read/write hazards.  Under those
sufficient conditions the two serial orders agree with the snapshot commit.
`SafeBatch` extends the conditions to a list, and gives serial/snapshot
equivalence for that list.  The conditions are sufficient, not necessary:
conservative footprints may report a hazard even when particular values happen
to agree.

These theorems do not commute complete CSM token steps.  They neither reorder
the shared cursor/frontend history nor establish that recomputing a controller
would choose the same routes.  Such state and route stability need separate
assumptions.  There are no admitted axioms, unproved declarations, external
decision procedures, or floating-point claims in this module.
-/

namespace CSM.Parallel

universe u

/-- A finite, total store.  An address is in bounds by construction. -/
abbrev Store (n : Nat) (Value : Type u) := Fin n → Value

/-- A record can carry an arbitrary payload and an in-bounds link. -/
structure Record (n : Nat) (Payload : Type u) where
  payload : Payload
  link : Fin n

variable {n : Nat} {Value : Type u}

/-- Replace exactly one record; all other records retain their old values. -/
def writeAt (store : Store n Value) (destination : Fin n) (value : Value) :
    Store n Value :=
  fun address => if address = destination then value else store address

@[simp] theorem writeAt_same (store : Store n Value) (destination : Fin n)
    (value : Value) :
    writeAt store destination value destination = value := by
  simp [writeAt]

theorem writeAt_other (store : Store n Value) (destination address : Fin n)
    (value : Value) (different : address ≠ destination) :
    writeAt store destination value address = store address := by
  simp [writeAt, different]

/-- Frozen writes to distinct records commute, irrespective of payload type. -/
theorem writeAt_commute (store : Store n Value) (a b : Fin n)
    (va vb : Value) (different : a ≠ b) :
    writeAt (writeAt store a va) b vb = writeAt (writeAt store b vb) a va := by
  funext address
  by_cases ha : address = a
  · subst address
    simp [writeAt, different]
  · by_cases hb : address = b
    · subst address
      simp [writeAt, ha]
    · simp [writeAt, ha, hb]

/-- Every typed record link remains in bounds, including after a store edit. -/
theorem written_record_link_in_bounds {Payload : Type u}
    (store : Store n (Record n Payload)) (destination address : Fin n)
    (value : Record n Payload) :
    ((writeAt store destination value address).link).val < n :=
  ((writeAt store destination value address).link).isLt

/-- Equality of two stores on the specified read footprint. -/
def AgreesOn (reads : Fin n → Prop) (left right : Store n Value) : Prop :=
  ∀ address, reads address → left address = right address

/-- A frozen-route edit, including a proof of its declared read dependence. -/
structure Edit (n : Nat) (Value : Type u) where
  destination : Fin n
  reads : Fin n → Prop
  proposal : Store n Value → Value
  respects : ∀ left right, AgreesOn reads left right → proposal left = proposal right

/-- Serial application recomputes this fixed edit's proposal on its input store. -/
def applyEdit (edit : Edit n Value) (store : Store n Value) : Store n Value :=
  writeAt store edit.destination (edit.proposal store)

/-- Commit a proposal from `snapshot` into the possibly already edited `current`. -/
def commitFrom (snapshot : Store n Value) (edit : Edit n Value)
    (current : Store n Value) : Store n Value :=
  writeAt current edit.destination (edit.proposal snapshot)

/-- Both proposals use the same snapshot.  The written order is `a`, then `b`. -/
def parallelPair (a b : Edit n Value) (snapshot : Store n Value) : Store n Value :=
  commitFrom snapshot b (commitFrom snapshot a snapshot)

/-- The explicit sufficient hazard conditions for independent record edits. -/
structure SafePair (a b : Edit n Value) : Prop where
  distinctDestinations : a.destination ≠ b.destination
  aDoesNotReadB : ¬ a.reads b.destination
  bDoesNotReadA : ¬ b.reads a.destination

theorem SafePair.symm {a b : Edit n Value} (safe : SafePair a b) : SafePair b a :=
  ⟨Ne.symm safe.distinctDestinations, safe.bDoesNotReadA, safe.aDoesNotReadB⟩

theorem writeAt_agreesOn (reads : Fin n → Prop) (store : Store n Value)
    (destination : Fin n) (value : Value) (outside : ¬ reads destination) :
    AgreesOn reads (writeAt store destination value) store := by
  intro address read
  have different : address ≠ destination := by
    intro equal
    apply outside
    simpa [equal] using read
  exact writeAt_other store destination address value different

/-- A proposal is unchanged by a write outside its declared footprint. -/
theorem proposal_after_noninterfering_write (edit : Edit n Value)
    (store : Store n Value) (destination : Fin n) (value : Value)
    (outside : ¬ edit.reads destination) :
    edit.proposal (writeAt store destination value) = edit.proposal store :=
  edit.respects _ _ (writeAt_agreesOn edit.reads store destination value outside)

/-- Directional serial/snapshot equivalence only needs the later read hazard absent. -/
theorem serial_pair_eq_snapshot (a b : Edit n Value) (store : Store n Value)
    (outside : ¬ b.reads a.destination) :
    applyEdit b (applyEdit a store) = parallelPair a b store := by
  unfold applyEdit parallelPair commitFrom
  rw [proposal_after_noninterfering_write b store a.destination (a.proposal store) outside]

/-- Frozen commits commute when their destinations are distinct. -/
theorem commitFrom_commute (snapshot current : Store n Value) (a b : Edit n Value)
    (different : a.destination ≠ b.destination) :
    commitFrom snapshot b (commitFrom snapshot a current) =
      commitFrom snapshot a (commitFrom snapshot b current) := by
  exact writeAt_commute current a.destination b.destination
    (a.proposal snapshot) (b.proposal snapshot) different

theorem parallelPair_commute (a b : Edit n Value) (store : Store n Value)
    (different : a.destination ≠ b.destination) :
    parallelPair a b store = parallelPair b a store :=
  commitFrom_commute store store a b different

/-- Under all pair hazards excluded, the two actual serial executions commute. -/
theorem applyEdit_commute (a b : Edit n Value) (store : Store n Value)
    (safe : SafePair a b) :
    applyEdit b (applyEdit a store) = applyEdit a (applyEdit b store) := by
  calc
    applyEdit b (applyEdit a store) = parallelPair a b store :=
      serial_pair_eq_snapshot a b store safe.bDoesNotReadA
    _ = parallelPair b a store := parallelPair_commute a b store safe.distinctDestinations
    _ = applyEdit a (applyEdit b store) :=
      (serial_pair_eq_snapshot b a store safe.aDoesNotReadB).symm

/-- Both safe serial orders equal the same frozen-snapshot result. -/
theorem safe_pair_serial_snapshot (a b : Edit n Value) (store : Store n Value)
    (safe : SafePair a b) :
    applyEdit b (applyEdit a store) = parallelPair a b store ∧
      applyEdit a (applyEdit b store) = parallelPair a b store := by
  constructor
  · exact serial_pair_eq_snapshot a b store safe.bDoesNotReadA
  · calc
      applyEdit a (applyEdit b store) = applyEdit b (applyEdit a store) :=
        (applyEdit_commute a b store safe).symm
      _ = parallelPair a b store := serial_pair_eq_snapshot a b store safe.bDoesNotReadA

/-- All unordered pairs in the list satisfy the explicit hazard conditions. -/
def SafeBatch : List (Edit n Value) → Prop
  | [] => True
  | edit :: rest => (∀ later, later ∈ rest → SafePair edit later) ∧ SafeBatch rest

/-- The current store agrees with the snapshot on every remaining read footprint. -/
def AgreesFor (edits : List (Edit n Value)) (current snapshot : Store n Value) : Prop :=
  ∀ edit, edit ∈ edits → AgreesOn edit.reads current snapshot

def runAll (current : Store n Value) : List (Edit n Value) → Store n Value
  | [] => current
  | edit :: rest => runAll (applyEdit edit current) rest

def commitAll (snapshot current : Store n Value) : List (Edit n Value) → Store n Value
  | [] => current
  | edit :: rest => commitAll snapshot (commitFrom snapshot edit current) rest

/--
The list-level proof exposes its invariant: all remaining proposals see the
same records as in the frozen snapshot.  Distinct writes and absent cross-read
hazards in `SafeBatch` preserve that invariant after each commit.
-/
theorem runAll_eq_commitAll_of_agreement (snapshot current : Store n Value)
    (edits : List (Edit n Value)) (safe : SafeBatch edits)
    (agreement : AgreesFor edits current snapshot) :
    runAll current edits = commitAll snapshot current edits := by
  induction edits generalizing current with
  | nil => rfl
  | cons edit rest inductionHypothesis =>
    rcases safe with ⟨headSafe, tailSafe⟩
    have proposalEqual : edit.proposal current = edit.proposal snapshot :=
      edit.respects current snapshot (agreement edit (by simp))
    have headEqual : applyEdit edit current = commitFrom snapshot edit current := by
      simp only [applyEdit, commitFrom, proposalEqual]
    change runAll (applyEdit edit current) rest =
      commitAll snapshot (commitFrom snapshot edit current) rest
    rw [headEqual]
    apply inductionHypothesis _ tailSafe
    intro later member address read
    have outside : ¬ later.reads edit.destination := (headSafe later member).bDoesNotReadA
    have different : address ≠ edit.destination := by
      intro equal
      apply outside
      simpa [equal] using read
    calc
      commitFrom snapshot edit current address = current address := by
        exact writeAt_other current edit.destination address (edit.proposal snapshot) different
      _ = snapshot address := agreement later (by simp [member]) address read

/-- A safe batch's serial evaluation equals committing all proposals from its initial snapshot. -/
theorem safe_batch_serial_snapshot (store : Store n Value) (edits : List (Edit n Value))
    (safe : SafeBatch edits) :
    runAll store edits = commitAll store store edits := by
  apply runAll_eq_commitAll_of_agreement store store edits safe
  intro edit member address read
  rfl

/-- A useful edit with an empty read footprint. -/
def constantEdit (destination : Fin n) (value : Value) : Edit n Value where
  destination := destination
  reads := fun _ => False
  proposal := fun _ => value
  respects := by intro left right agreement; rfl

/-- A copy edit has a singleton read footprint and a fixed destination. -/
def copyEdit (destination source : Fin n) : Edit n Value where
  destination := destination
  reads := fun address => address = source
  proposal := fun store => store source
  respects := by
    intro left right agreement
    exact agreement source rfl

namespace Counterexamples

def zeros : Store 2 Nat := fun _ => 0
def writeOne : Edit 2 Nat := constantEdit 0 1
def writeTwo : Edit 2 Nat := constantEdit 0 2
def copyZeroToOne : Edit 2 Nat := copyEdit 1 0

/-- With a write/write hazard, even constant proposals can give different serial results. -/
theorem write_write_not_commutative :
    applyEdit writeTwo (applyEdit writeOne zeros) ≠
      applyEdit writeOne (applyEdit writeTwo zeros) := by
  intro equal
  have atZero := congrFun equal (0 : Fin 2)
  simp [applyEdit, writeAt, writeOne, writeTwo, constantEdit, zeros] at atZero

/-- The read/write counterexample has distinct destinations, so it is not a write/write case. -/
theorem read_write_destinations_distinct :
    writeOne.destination ≠ copyZeroToOne.destination := by
  decide

/-- Writing slot zero before copying it changes the answer at slot one. -/
theorem read_write_not_commutative :
    applyEdit copyZeroToOne (applyEdit writeOne zeros) ≠
      applyEdit writeOne (applyEdit copyZeroToOne zeros) := by
  intro equal
  have atOne := congrFun equal (1 : Fin 2)
  simp [applyEdit, writeAt, writeOne, copyZeroToOne, constantEdit, copyEdit, zeros] at atOne

/-- Freezing the copy proposal at the old snapshot is not the same as a hazardous serial copy. -/
theorem read_write_serial_not_snapshot :
    applyEdit copyZeroToOne (applyEdit writeOne zeros) ≠
      parallelPair writeOne copyZeroToOne zeros := by
  intro equal
  have atOne := congrFun equal (1 : Fin 2)
  simp [applyEdit, parallelPair, commitFrom, writeAt, writeOne, copyZeroToOne,
    constantEdit, copyEdit, zeros] at atOne

end Counterexamples

end CSM.Parallel
