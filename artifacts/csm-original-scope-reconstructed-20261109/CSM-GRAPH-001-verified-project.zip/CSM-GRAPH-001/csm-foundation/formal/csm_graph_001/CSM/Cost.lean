import Std

/-!
# CSM-001 dense arithmetic and storage counts

The terms below are a manual transcription of the frozen implementation:
`experiments/csm_foundation_001/model.py`, SHA256
`f496837236ea1f53939d29776255bfba8f1d02512a8b52f581a79d94134a4234`.

`S` is the number of slots, `d` the feature width, `O` the number of operation
embeddings, `h` the transformation's hidden width, and `V` vocabulary size.

The MAC convention counts one nominal multiply-accumulate term for each scalar
product term in every dense affine matrix-vector product and dense read. It
includes the dense operation-embedding product even though its selector is
one-hot. It counts all such operations executed by the source, including heads
whose result is subsequently discarded in an ablation. It excludes bias adds,
softmax, argmax/one-hot construction, tanh, sigmoid, pointwise address mixtures,
value/link masks, interpolation, embedding lookup, data movement, allocation,
and the position counter. Consequently this is NOT an exact total FLOP count,
machine-instruction count, runtime model, or backward-pass count.

Parameter totals count all allocated learnable scalars, including inactive
ablation heads. State totals count the retained floating tensors of one example:
values, dense pointer rows, cursor, and two embedding-history rows. They exclude
the position integer, parameters, saved outputs, temporary tensors, autograd,
gradients, optimizer state, object overhead, and allocator/process memory.

The proofs establish equality of the component sums with the closed formulas,
and the stated concrete arithmetic results. They do not establish a compiler
extraction from PyTorch, asymptotic bounds, work/span bounds, or speedups.
-/

namespace CSM.Cost

/-- Per-example, per-token dense MAC components in the source implementation.
The normalized dimensions make the algebra explicit; e.g. the second-address
map has `S` outputs and `2*d` inputs, hence `2*(S*d)` terms. -/
def denseMACTerms (S d O h V : Nat) : List Nat := [
  3 * (d * d),   -- frontend: Linear(3*d, d)
  2 * (d * d),   -- controller: Linear(2*d, d)
  S * d,         -- first-address head: Linear(d, S)
  2 * (S * d),   -- direct-second-address head: Linear(2*d, S)
  S * d,         -- destination head: Linear(d, S)
  2 * d,         -- use-link head: Linear(d, 2)
  2 * d,         -- link-edit head: Linear(d, 2)
  O * d,         -- operator-choice head: Linear(d, O)
  4 * (d * h),   -- transformation input map: Linear(4*d, h)
  d * h,         -- transformation output map: Linear(h, d)
  d,             -- write-strength head: Linear(d, 1)
  2 * d,         -- value-edit head: Linear(d, 2)
  d * V,         -- vocabulary projection: Linear(d, V)
  O * d,         -- operation @ operator_embedding: (1,O) @ (O,d)
  S * d,         -- active value: cursor @ values
  S * d,         -- first value: first @ values
  S * d,         -- second value: second @ values
  S * d,         -- old destination value: destination @ values
  S * S          -- linked address: first @ dense links
]

def denseMACs (S d O h V : Nat) : Nat := (denseMACTerms S d O h V).sum

def denseMACFormula (S d O h V : Nat) : Nat :=
  5 * d * d + 8 * S * d + 2 * O * d + 5 * d * h + d * V + S * S + 7 * d

/-- Exact algebra for the explicitly declared dense-MAC convention. -/
theorem denseMACs_formula (S d O h V : Nat) :
    denseMACs S d O h V = denseMACFormula S d O h V := by
  simp only [denseMACs, denseMACTerms, List.sum_cons, List.sum_nil,
    denseMACFormula, Nat.mul_assoc]
  omega

/-- Every learned tensor, with each affine map's bias included once.
The final projection and token embedding have separate parameter tensors. -/
def parameterTerms (S d O h V : Nat) : List Nat := [
  V * d,               -- token embedding
  3 * (d * d) + d,     -- frontend weight and bias
  2 * (d * d) + d,     -- controller weight and bias
  S * d + S,           -- first-address head
  2 * (S * d) + S,     -- direct-second-address head
  S * d + S,           -- destination head
  2 * d + 2,           -- use-link head
  2 * d + 2,           -- link-edit head
  O * d + O,           -- operator-choice head
  O * d,               -- operation embedding table
  4 * (d * h) + h,     -- transformation input map
  d * h + d,           -- transformation output map
  d + 1,               -- write-strength head
  2 * d + 2,           -- value-edit head
  V * d + V            -- vocabulary output map
]

def parameterScalars (S d O h V : Nat) : Nat := (parameterTerms S d O h V).sum

def parameterFormula (S d O h V : Nat) : Nat :=
  2 * V * d + V + 5 * d * d + 4 * S * d + 3 * S + 2 * O * d + O +
  5 * d * h + h + 10 * d + 7

theorem parameterScalars_formula (S d O h V : Nat) :
    parameterScalars S d O h V = parameterFormula S d O h V := by
  simp only [parameterScalars, parameterTerms, List.sum_cons, List.sum_nil,
    parameterFormula, Nat.mul_assoc]
  omega

/-- Four retained floating tensors; the natural-number position is separate. -/
def stateScalarTerms (S d : Nat) : List Nat := [
  S * d,   -- values: S by d
  S * S,   -- one-hot pointer rows stored densely: S by S
  S,       -- one-hot cursor stored densely
  2 * d    -- embedding history: 2 by d
]

def stateScalars (S d : Nat) : Nat := (stateScalarTerms S d).sum

def stateFormula (S d : Nat) : Nat := S * d + S * S + S + 2 * d

theorem stateScalars_formula (S d : Nat) : stateScalars S d = stateFormula S d := by
  simp only [stateScalars, stateScalarTerms, List.sum_cons, List.sum_nil, stateFormula]
  omega

/-- Logical bytes for the declared four-byte scalar representation only. -/
def stateBytesFP32 (S d : Nat) : Nat := 4 * stateScalars S d

theorem byteLM_denseMACs : denseMACs 8 32 4 64 257 = 26176 := by decide

theorem byteLM_parameters : parameterScalars 8 32 4 64 257 = 33764 := by decide

theorem structured_parameters : parameterScalars 8 32 4 64 20 = 18359 := by decide

theorem structured_denseMACs : denseMACs 8 32 4 64 20 = 18592 := by decide

theorem retained_state_scalars : stateScalars 8 32 = 392 := by decide

theorem retained_state_bytes_fp32 : stateBytesFP32 8 32 = 1568 := by decide

end CSM.Cost
