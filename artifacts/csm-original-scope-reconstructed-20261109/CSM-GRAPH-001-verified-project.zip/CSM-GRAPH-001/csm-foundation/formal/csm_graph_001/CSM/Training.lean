import Std

/-!
Forward values and supplied reverse rules are separate contracts. This permits
the hard-forward / soft-backward categorical primitive used by CSM. It does NOT
certify a supplied rule as an analytic derivative. In particular, the surrogate
for argmax is intentionally not the ordinary derivative of its hard forward map.

These compositional contracts complement the CSM forward proof. This module is
not a proof that PyTorch implements automatic differentiation correctly, nor a
proof that the full CSM graph has been extracted into these combinators.
-/
namespace CSM.Training

structure Primitive (A B dA dB : Type) where
  forward : A → B
  pullback : A → dB → dA

variable {A B C D dA dB dC dD : Type}

def compose (f : Primitive A B dA dB) (g : Primitive B C dB dC) :
    Primitive A C dA dC :=
  { forward := fun x => g.forward (f.forward x),
    pullback := fun x dz => f.pullback x (g.pullback (f.forward x) dz) }

/-- Reassociation of a chain preserves both the forward and supplied reverse rule. -/
theorem compose_assoc (f : Primitive A B dA dB) (g : Primitive B C dB dC)
    (h : Primitive C D dC dD) :
    compose (compose f g) h = compose f (compose g h) := by rfl

def replacePullback (f : Primitive A B dA dB) (rule : A → dB → dA) :
    Primitive A B dA dB := { f with pullback := rule }

theorem replacePullback_preserves_forward (f : Primitive A B dA dB)
    (rule : A → dB → dA) (x : A) :
    (replacePullback f rule).forward x = f.forward x := by rfl

def stopGradient (zero : dA) : Primitive A A dA dA :=
  { forward := id, pullback := fun _ _ => zero }

theorem stopGradient_forward (zero : dA) (x : A) :
    (stopGradient zero).forward x = x := by rfl

theorem stopGradient_reverse (zero : dA) (x : A) (dx : dA) :
    (stopGradient zero).pullback x dx = zero := by rfl

/-- A hard choice together with an explicitly supplied surrogate rule.
No relationship between `select` and `surrogate` is asserted by this type. -/
def hardSurrogate {n : Nat} (select : A → Fin n)
    (surrogate : A → (Fin n → dB) → dA) :
    Primitive A (Fin n) dA (Fin n → dB) :=
  { forward := select, pullback := surrogate }

theorem hardSurrogate_forward_independent {n : Nat} (select : A → Fin n)
    (left right : A → (Fin n → dB) → dA) (x : A) :
    (hardSurrogate select left).forward x =
      (hardSurrogate select right).forward x := by rfl

def forkJoin (add : dA → dA → dA)
    (f : Primitive A B dA dB) (g : Primitive A C dA dC) :
    Primitive A (B × C) dA (dB × dC) :=
  { forward := fun x => (f.forward x, g.forward x),
    pullback := fun x dy => add (f.pullback x dy.1) (g.pullback x dy.2) }

def forkJoinReverseAccumulation (add : dA → dA → dA)
    (f : Primitive A B dA dB) (g : Primitive A C dA dC) :
    Primitive A (B × C) dA (dB × dC) :=
  { forward := fun x => (f.forward x, g.forward x),
    pullback := fun x dy => add (g.pullback x dy.2) (f.pullback x dy.1) }

/-- Independent reverse branches may be accumulated in either order when the
specified accumulator is commutative. This is an explicit algebraic hypothesis,
not a blanket promise of bitwise agreement for floating-point reductions. -/
theorem forkJoin_reverse_order
    (add : dA → dA → dA) (comm : ∀ a b, add a b = add b a)
    (f : Primitive A B dA dB) (g : Primitive A C dA dC)
    (x : A) (dy : dB × dC) :
    (forkJoin add f g).pullback x dy =
      (forkJoinReverseAccumulation add f g).pullback x dy := by
  exact comm _ _

/-- Forward equality alone cannot justify a surrogate-backward equivalence. -/
theorem forward_equality_does_not_imply_pullback_equality :
    ∃ f g : Primitive Nat Nat Nat Nat,
      f.forward = g.forward ∧ f.pullback ≠ g.pullback := by
  refine ⟨⟨id, fun _ _ => 0⟩, ⟨id, fun _ _ => 1⟩, rfl, ?_⟩
  intro same
  have h := congrArg (fun rule => rule 0 0) same
  cases h

end CSM.Training
