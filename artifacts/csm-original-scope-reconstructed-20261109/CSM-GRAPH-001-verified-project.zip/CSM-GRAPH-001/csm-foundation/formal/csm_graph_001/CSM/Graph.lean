import Std

/-!
# CSM-001 computation graph

This is the dependency graph of a *single hard-forward* token transition in
`experiments/csm_foundation_001/model.py`, followed by its temporal unrolling.
Nodes are whole tensor operations, not floating-point instructions. The three
variants retain operations that the implementation computes and subsequently
discards, but do not give a discarded result a spurious downstream edge.

This graph is distinct from the mutable slot-pointer graph. Slot pointers may
cycle. The rank proofs below concern computation dependencies only. Reversing
these edges gives an acyclic dependency schedule; it does not prove that a
particular backward rule is a derivative, including the straight-through rule.

The ordinary token input is supplied externally. Sampling a new token from an
output and the diagnostic reset/corruption hooks are outside this graph.
-/

namespace CSM.Graph

inductive Variant where
  | rewrite
  | ringWrite
  | noLinks
  deriving DecidableEq, Repr

def Variant.name : Variant → String
  | .rewrite => "rewrite"
  | .ringWrite => "ring_write"
  | .noLinks => "no_links"

def variants : List Variant := [.rewrite, .ringWrite, .noLinks]

inductive Node where
  | parameters | token | values | links | cursor | history | position
  | embedding | frontend | active | controller
  | firstHead | destinationHead | operatorHead | useLinkHead
  | valueEditHead | writeStrengthHead | linkEditHead
  | firstRead | linkedRead | destination | destinationRead | operatorEmbedding
  | gate | secondHead | selectedAddress | secondRead | transform | updated
  | valuesCommit | linksCommit | cursorCommit | historyCommit | positionCommit
  | output | nextState
  deriving DecidableEq, Repr

def allNodes : List Node := [
  .parameters, .token, .values, .links, .cursor, .history, .position,
  .embedding, .frontend, .active, .controller,
  .firstHead, .destinationHead, .operatorHead, .useLinkHead,
  .valueEditHead, .writeStrengthHead, .linkEditHead,
  .firstRead, .linkedRead, .destination, .destinationRead, .operatorEmbedding,
  .gate, .secondHead, .selectedAddress, .secondRead, .transform, .updated,
  .valuesCommit, .linksCommit, .cursorCommit, .historyCommit, .positionCommit,
  .output, .nextState
]

def Node.name : Node → String
  | .parameters => "parameters"
  | .token => "token"
  | .values => "values"
  | .links => "links"
  | .cursor => "cursor"
  | .history => "history"
  | .position => "position"
  | .embedding => "embedding"
  | .frontend => "frontend"
  | .active => "active_read"
  | .controller => "controller"
  | .firstHead => "first_address_head"
  | .destinationHead => "destination_head"
  | .operatorHead => "operator_head"
  | .useLinkHead => "use_link_head"
  | .valueEditHead => "value_edit_head"
  | .writeStrengthHead => "write_strength_head"
  | .linkEditHead => "link_edit_head"
  | .firstRead => "first_value_read"
  | .linkedRead => "linked_address_read"
  | .destination => "destination_selection"
  | .destinationRead => "previous_destination_read"
  | .operatorEmbedding => "operator_embedding"
  | .gate => "value_gate"
  | .secondHead => "direct_second_address_head"
  | .selectedAddress => "second_address_selection"
  | .secondRead => "second_value_read"
  | .transform => "transform"
  | .updated => "updated_value"
  | .valuesCommit => "values_commit"
  | .linksCommit => "links_commit"
  | .cursorCommit => "cursor_commit"
  | .historyCommit => "history_commit"
  | .positionCommit => "position_commit"
  | .output => "vocabulary_output"
  | .nextState => "next_state"

/-- Parents are data dependencies, directed from a parent to this node.
Affine maps include their activation or hard choice where appropriate. -/
def dependencies (variant : Variant) : Node → List Node
  | .parameters | .token | .values | .links | .cursor | .history | .position => []
  | .embedding => [.parameters, .token]
  | .frontend => [.parameters, .history, .embedding]
  | .active => [.cursor, .values]
  | .controller => [.parameters, .frontend, .active]
  | .firstHead | .destinationHead | .operatorHead | .useLinkHead
    | .valueEditHead | .writeStrengthHead | .linkEditHead => [.parameters, .controller]
  | .firstRead => [.firstHead, .values]
  | .linkedRead => [.firstHead, .links]
  | .destination => match variant with
      | .ringWrite => [.position]
      | .rewrite | .noLinks => [.destinationHead]
  | .destinationRead => [.destination, .values]
  | .operatorEmbedding => [.operatorHead, .parameters]
  | .gate => [.valueEditHead, .writeStrengthHead]
  | .secondHead => [.parameters, .controller, .firstRead]
  | .selectedAddress => match variant with
      | .noLinks => [.secondHead]
      | .rewrite | .ringWrite => [.secondHead, .linkedRead, .useLinkHead]
  | .secondRead => [.selectedAddress, .values]
  | .transform => [.parameters, .frontend, .firstRead, .secondRead, .operatorEmbedding]
  | .updated => [.destinationRead, .gate, .transform]
  | .valuesCommit => [.values, .destination, .updated]
  | .linksCommit => [.links, .destination, .linkEditHead, .selectedAddress]
  | .cursorCommit => [.destination]
  | .historyCommit => [.history, .embedding]
  | .positionCommit => [.position]
  | .output => [.parameters, .updated]
  | .nextState => [.valuesCommit, .linksCommit, .cursorCommit, .historyCommit, .positionCommit]

/-- A shared valid level assignment, not a hardware latency model. -/
def rank : Node → Nat
  | .parameters | .token | .values | .links | .cursor | .history | .position => 0
  | .embedding | .active | .positionCommit => 1
  | .frontend | .historyCommit => 2
  | .controller => 3
  | .firstHead | .destinationHead | .operatorHead | .useLinkHead
    | .valueEditHead | .writeStrengthHead | .linkEditHead => 4
  | .firstRead | .linkedRead | .destination | .operatorEmbedding | .gate => 5
  | .destinationRead | .secondHead | .cursorCommit => 6
  | .selectedAddress => 7
  | .secondRead | .linksCommit => 8
  | .transform => 9
  | .updated => 10
  | .valuesCommit | .output => 11
  | .nextState => 12

def controlHeads : List Node := [
  .firstHead, .destinationHead, .operatorHead, .useLinkHead,
  .valueEditHead, .writeStrengthHead, .linkEditHead
]

def Edge (variant : Variant) (source target : Node) : Prop :=
  source ∈ dependencies variant target

theorem allNodes_complete (node : Node) : node ∈ allNodes := by
  cases node <;> decide

theorem allNodes_unique : allNodes.Nodup := by decide

theorem allNames_unique : (allNodes.map Node.name).Nodup := by decide

private theorem dependencies_below (variant : Variant) (target : Node) :
    (dependencies variant target).all (fun source => decide (rank source < rank target)) = true := by
  cases variant <;> cases target <;> decide

theorem edge_rank_increases (variant : Variant) (source target : Node)
    (edge : Edge variant source target) : rank source < rank target := by
  have checked := List.all_eq_true.mp (dependencies_below variant target)
  exact of_decide_eq_true (checked source edge)

theorem same_level_nonedge (variant : Variant) (source target : Node)
    (level : rank source = rank target) : ¬ Edge variant source target := by
  intro edge
  have strict := edge_rank_increases variant source target edge
  rw [level] at strict
  exact Nat.lt_irrefl _ strict

theorem control_heads_level (node : Node) (member : node ∈ controlHeads) : rank node = 4 := by
  cases node <;> simp_all [controlHeads, rank]

universe u

/-- At least one directed edge: a cycle cannot be a zero-length path. -/
inductive NonemptyPath {α : Type u} (relation : α → α → Prop) : α → α → Prop where
  | single {a b} : relation a b → NonemptyPath relation a b
  | cons {a b c} : relation a b → NonemptyPath relation b c → NonemptyPath relation a c

def Acyclic {α : Type u} (relation : α → α → Prop) : Prop :=
  ∀ a, ¬ NonemptyPath relation a a

theorem path_rank_increases {α : Type u} (relation : α → α → Prop) (level : α → Nat)
    (step : ∀ a b, relation a b → level a < level b) {a b : α}
    (path : NonemptyPath relation a b) : level a < level b := by
  induction path with
  | single edge => exact step _ _ edge
  | cons edge _ rest => exact Nat.lt_trans (step _ _ edge) rest

theorem acyclic_of_increasing_rank {α : Type u} (relation : α → α → Prop) (level : α → Nat)
    (step : ∀ a b, relation a b → level a < level b) : Acyclic relation := by
  intro a cycle
  exact Nat.lt_irrefl _ (path_rank_increases relation level step cycle)

theorem path_rank_decreases {α : Type u} (relation : α → α → Prop) (level : α → Nat)
    (step : ∀ a b, relation a b → level b < level a) {a b : α}
    (path : NonemptyPath relation a b) : level b < level a := by
  induction path with
  | single edge => exact step _ _ edge
  | cons edge _ rest => exact Nat.lt_trans rest (step _ _ edge)

theorem acyclic_of_decreasing_rank {α : Type u} (relation : α → α → Prop) (level : α → Nat)
    (step : ∀ a b, relation a b → level b < level a) : Acyclic relation := by
  intro a cycle
  exact Nat.lt_irrefl _ (path_rank_decreases relation level step cycle)

theorem forward_acyclic (variant : Variant) : Acyclic (Edge variant) :=
  acyclic_of_increasing_rank (Edge variant) rank (edge_rank_increases variant)

theorem same_level_no_path (variant : Variant) (source target : Node)
    (level : rank source = rank target) : ¬ NonemptyPath (Edge variant) source target := by
  intro path
  have strict := path_rank_increases (Edge variant) rank (edge_rank_increases variant) path
  rw [level] at strict
  exact Nat.lt_irrefl _ strict

/-- Thus the seven controller heads have no dependency path between each other.
This asserts a scheduling possibility, not a measured runtime improvement. -/
theorem control_heads_independent (variant : Variant) (a b : Node)
    (ha : a ∈ controlHeads) (hb : b ∈ controlHeads) :
    ¬ NonemptyPath (Edge variant) a b :=
  same_level_no_path variant a b ((control_heads_level a ha).trans (control_heads_level b hb).symm)

def ReverseEdge (variant : Variant) (source target : Node) : Prop := Edge variant target source

/-- Only a reversed-dependency scheduling statement, not gradient correctness. -/
theorem reverse_acyclic (variant : Variant) : Acyclic (ReverseEdge variant) :=
  acyclic_of_decreasing_rank (ReverseEdge variant) rank
    (fun source target edge => edge_rank_increases variant target source edge)

/-- Carry each state field independently; do not insert an artificial barrier
through the assembled `nextState` node. Parameters remain fixed for the run. -/
def recurrencePairs : List (Node × Node) := [
  (.valuesCommit, .values), (.linksCommit, .links), (.cursorCommit, .cursor),
  (.historyCommit, .history), (.positionCommit, .position)
]

def Recurrence (source target : Node) : Prop := (source, target) ∈ recurrencePairs

structure TimedNode where
  time : Nat
  node : Node
  deriving DecidableEq, Repr

def stride : Nat := 13

theorem rank_lt_stride (node : Node) : rank node < stride := by
  cases node <;> decide

def timeRank (node : TimedNode) : Nat := node.time * stride + rank node.node

def UnrolledEdge (variant : Variant) (source target : TimedNode) : Prop :=
  (source.time = target.time ∧ Edge variant source.node target.node) ∨
  (target.time = source.time + 1 ∧ Recurrence source.node target.node)

theorem unrolled_edge_rank_increases (variant : Variant) (source target : TimedNode)
    (edge : UnrolledEdge variant source target) : timeRank source < timeRank target := by
  rcases edge with ⟨time, localEdge⟩ | ⟨time, _⟩
  · have strict := edge_rank_increases variant source.node target.node localEdge
    unfold timeRank
    rw [time]
    exact Nat.add_lt_add_left strict _
  · have bound := rank_lt_stride source.node
    unfold timeRank
    rw [time]
    simp only [stride] at bound ⊢
    omega

theorem unrolled_acyclic (variant : Variant) : Acyclic (UnrolledEdge variant) :=
  acyclic_of_increasing_rank (UnrolledEdge variant) timeRank (unrolled_edge_rank_increases variant)

def ReverseUnrolledEdge (variant : Variant) (source target : TimedNode) : Prop :=
  UnrolledEdge variant target source

/-- Reverse-mode scheduling remains acyclic on the complete temporal graph.
The mathematical validity of any local VJP is a separate obligation. -/
theorem reverse_unrolled_acyclic (variant : Variant) : Acyclic (ReverseUnrolledEdge variant) :=
  acyclic_of_decreasing_rank (ReverseUnrolledEdge variant) timeRank
    (fun source target edge => unrolled_edge_rank_increases variant target source edge)

end CSM.Graph
