"""Reproduce three FP32 boundaries of the finite-store abstraction, on CPU.

These are existing arithmetic counterexamples documenting refinement premises,
not tests of registered model capability or requests to change frozen sources.
The first fixture calls the frozen model's actual static _read method. The other
two evaluate its unchanged update/commit expressions on minimal fixed tensors.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys

import torch


ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT.parents[1] / "experiments" / "csm_foundation_001" / "model.py"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def describe(tensor: torch.Tensor) -> dict:
    """Record FP32 values and raw bits; never serialize a JSON NaN number."""
    if tensor.device.type != "cpu" or tensor.dtype != torch.float32:
        raise TypeError("Boundary fixtures must be CPU FP32 tensors")
    flat = tensor.detach().contiguous().reshape(-1)
    signed = flat.view(torch.int32).tolist()
    return {
        "shape": list(tensor.shape),
        "dtype": "torch.float32",
        "values_flat_as_strings": [repr(value) for value in flat.tolist()],
        "bits_flat_hex": [f"0x{value & 0xffffffff:08x}" for value in signed],
        "bits_flat_signed_int32": signed,
    }


def load_frozen_model():
    name = "csm_numeric_boundary_frozen_model"
    spec = importlib.util.spec_from_file_location(name, MODEL_PATH)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load frozen model source at {MODEL_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=ROOT / "NUMERIC_BOUNDARY_VERIFICATION.json")
    args = parser.parse_args()
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    module = load_frozen_model()
    checks = []

    with torch.no_grad():
        address = torch.tensor([[1.0, 0.0]], dtype=torch.float32)
        values = torch.tensor([[[2.0], [float("nan")]]], dtype=torch.float32)
        selected = values[:, 0, :].clone()
        dense_read = module.RecordRewrite._read(address, values)
        checks.append({
            "name": "unselected_nan_contaminates_dense_one_hot_read",
            "expected_boundary_reproduced": bool(
                torch.isnan(dense_read).all() and (selected == 2).all()),
            "operation": "Frozen RecordRewrite._read: bmm(address.unsqueeze(1), values).squeeze(1)",
            "address": describe(address), "records": describe(values),
            "functional_selection": describe(selected), "dense_read": describe(dense_read),
            "interpretation": "Valid one-hot addressing alone does not exclude contamination by an unselected NaN.",
        })

        previous = torch.tensor([2.0], dtype=torch.float32)
        gate = torch.tensor([0.0], dtype=torch.float32)
        proposal = torch.tensor([float("nan")], dtype=torch.float32)
        updated = previous + gate * (proposal - previous)
        checks.append({
            "name": "zero_gate_does_not_suppress_nan_proposal",
            "expected_boundary_reproduced": bool(torch.isnan(updated).all()),
            "operation": "previous + gate * (proposal - previous)",
            "previous": describe(previous), "gate": describe(gate),
            "proposal": describe(proposal), "updated": describe(updated),
            "interpretation": "Conditional preservation of the old value requires a numerical refinement premise.",
        })

        state = torch.tensor([[[-0.0], [1.0]]], dtype=torch.float32)
        destination = torch.tensor([[0.0, 1.0]], dtype=torch.float32)
        replacement = torch.tensor([[2.0]], dtype=torch.float32)
        committed = (state * (1 - destination.unsqueeze(-1))
                     + destination.unsqueeze(-1) * replacement.unsqueeze(1))
        old_unselected = state[:, 0, :].clone()
        new_unselected = committed[:, 0, :].clone()
        numerically_equal = torch.equal(old_unselected, new_unselected)
        bits_equal = torch.equal(old_unselected.view(torch.int32), new_unselected.view(torch.int32))
        before_bits = int(old_unselected.reshape(-1).view(torch.int32)[0])
        after_bits = int(new_unselected.reshape(-1).view(torch.int32)[0])
        checks.append({
            "name": "masked_commit_changes_unselected_negative_zero_bits",
            "expected_boundary_reproduced": bool(
                numerically_equal and not bits_equal
                and before_bits == -2147483648 and after_bits == 0),
            "operation": "state * (1 - destination.unsqueeze(-1)) + destination.unsqueeze(-1) * replacement.unsqueeze(1)",
            "state_before": describe(state), "destination": describe(destination),
            "replacement": describe(replacement), "state_after": describe(committed),
            "unselected_before": describe(old_unselected), "unselected_after": describe(new_unselected),
            "torch_equal_on_unselected": numerically_equal,
            "int32_bit_patterns_equal_on_unselected": bits_equal,
            "interpretation": "Numerical equality of storage values is weaker than floating-point bit-pattern identity.",
        })

    passed = all(check["expected_boundary_reproduced"] for check in checks)
    report = {
        "verification": "CSM numeric refinement boundary observations",
        "version": 1, "passed": passed,
        "checks_passed": sum(check["expected_boundary_reproduced"] for check in checks),
        "checks_total": 3,
        "pass_meaning": "All three expected arithmetic boundary counterexamples were reproduced.",
        "scope": "Minimal fixed CPU FP32 expressions; no claim that registered fits encountered these states.",
        "randomness_used": False, "models_initialized": False, "optimizer_steps": 0,
        "neural_capability_scoring": False,
        "environment": {"python": platform.python_version(), "torch": torch.__version__,
                        "device": "cpu", "dtype": "torch.float32", "threads": torch.get_num_threads(),
                        "machine": platform.machine(), "byte_order": sys.byteorder},
        "bit_pattern_method": "Reinterpret contiguous float32 storage as int32; mask signed integers with 0xffffffff for hex.",
        "nan_check_method": "torch.isnan; values are strings to avoid nonstandard JSON NaN literals.",
        "source_sha256": {"model.py": sha(MODEL_PATH), "verify_numeric_boundary.py": sha(Path(__file__))},
        "checks": checks,
    }
    content = json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(content)
    print(content, end="")
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
