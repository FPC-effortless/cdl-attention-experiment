"""Verify and measure the dense scripted CSM fork/join bridge without fitting.

Parity precedes all warm benchmarks. The script preserves failed evidence too.
It configures four inter-op workers and one intra-op thread before tensor work.
"""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import statistics
import sys
import time

import torch


HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
EXPERIMENT = REPO / "experiments" / "csm_foundation_001"
sys.path.insert(0, str(EXPERIMENT))
from model import Config, RecordRewrite
from runtime_bridge import RuntimeBridge


MODES = ("rewrite", "ring_write", "no_links")
PARITY_SHAPES = ((1, 1), (1, 7), (3, 9), (16, 32), (32, 64))
BENCHMARK_SHAPES = ((1, 32), (1, 64), (16, 32), (32, 64))
TOLERANCES = {"logits_absolute": 1e-5, "state_absolute": 1e-6}
WARMUPS, REPETITIONS = 3, 20


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text())


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def graph_counts(graph):
    counts = Counter()

    def visit(block):
        for node in block.nodes():
            counts[node.kind()] += 1
            for child in node.blocks():
                visit(child)
            for attribute in node.attributeNames():
                if node.kindOf(attribute) == "g":
                    visit(node.g(attribute))

    visit(graph)
    return dict(counts)


def state_tuple(state):
    return state.values, state.links, state.cursor, state.history, state.position


def compare_tensor(stats, name, actual, expected, tolerance=0.0):
    require(actual.shape == expected.shape, f"{name}: shape mismatch")
    require(actual.dtype == expected.dtype, f"{name}: dtype mismatch")
    exact = torch.equal(actual, expected)
    if actual.is_floating_point():
        require(bool(torch.isfinite(actual).all() and torch.isfinite(expected).all()),
                f"{name}: nonfinite tensor")
        error = float((actual - expected).abs().max()) if actual.numel() else 0.0
    else:
        error = 0.0 if exact else float("inf")
    require(error <= tolerance, f"{name}: error {error} exceeds {tolerance}")
    bucket = stats.setdefault(name, {"comparisons": 0, "all_exact": True,
                                    "max_absolute_difference": 0.0})
    bucket["comparisons"] += 1
    bucket["all_exact"] &= exact
    bucket["max_absolute_difference"] = max(bucket["max_absolute_difference"], error)


def check_fresh_unchanged(previous, snapshots, current, label):
    for index in range(4):
        require(torch.equal(previous[index], snapshots[index]),
                f"{label}: input state tensor {index} mutated")
        require(previous[index].data_ptr() != current[index].data_ptr(),
                f"{label}: new state tensor {index} aliases old storage")
    require(current[4] == previous[4] + 1, f"{label}: incorrect position")


def compare_step(stats, label, actual, expected):
    logits, state, trace = actual
    expected_logits, expected_state, expected_trace = expected
    compare_tensor(stats, f"{label}/logits", logits, expected_logits,
                   TOLERANCES["logits_absolute"])
    require(state[4] == expected_state[4], f"{label}: position mismatch")
    for index, name in enumerate(("values", "links", "cursor", "history")):
        tolerance = TOLERANCES["state_absolute"] if name == "values" else 0.0
        compare_tensor(stats, f"{label}/state/{name}", state[index],
                       expected_state[index], tolerance)
    require(set(trace) == set(expected_trace), f"{label}: trace fields mismatch")
    for name in trace:
        # All discrete decisions must match exactly, including forward edit bits.
        tolerance = TOLERANCES["state_absolute"] if name == "gate" else 0.0
        compare_tensor(stats, f"{label}/trace/{name}", trace[name],
                       expected_trace[name], tolerance)


def timed_call(function, argument):
    begin = time.perf_counter_ns()
    result = function(argument)
    return result, (time.perf_counter_ns() - begin) / 1e6


@torch.inference_mode()
def verify_case(original, scripted, identifier):
    generator = torch.Generator().manual_seed(70113)
    statistics_by_tensor, shape_rows = {}, []
    cold = {}
    for batch, length in PARITY_SHAPES:
        x = torch.randint(original.config.vocab_size, (batch, length), generator=generator)
        reference_state = original.init_state(batch, x.device)
        serial_state = scripted.init_state(batch, x.device)
        parallel_state = scripted.init_state(batch, x.device)
        reference_outputs = []
        for position in range(length):
            token = x[:, position]
            ref_logits, reference_next, ref_trace = original.step(
                token, reference_state, return_trace=True)
            expected = ref_logits, state_tuple(reference_next), ref_trace
            previous_serial = tuple(t.clone() for t in serial_state[:4])
            previous_parallel = tuple(t.clone() for t in parallel_state[:4])
            tick = time.perf_counter_ns()
            serial = scripted.step_serial(token, serial_state)
            serial_ms = (time.perf_counter_ns() - tick) / 1e6
            tick = time.perf_counter_ns()
            parallel = scripted.step_parallel(token, parallel_state)
            parallel_ms = (time.perf_counter_ns() - tick) / 1e6
            if not cold:
                cold = {
                    "first_serial_step_verification_ms": serial_ms,
                    "first_parallel_step_verification_ms": parallel_ms,
                    "input_batch": batch, "input_length": 1,
                    "note": "First verification calls include lazy JIT setup; not a steady-state comparison.",
                }
            compare_step(statistics_by_tensor, "serial", serial, expected)
            compare_step(statistics_by_tensor, "parallel", parallel, expected)
            check_fresh_unchanged(serial_state, previous_serial, serial[1], "serial")
            check_fresh_unchanged(parallel_state, previous_parallel, parallel[1], "parallel")
            reference_state, serial_state, parallel_state = reference_next, serial[1], parallel[1]
            reference_outputs.append(ref_logits)
        expected_sequence = torch.stack(reference_outputs, 1)
        for label, function in (("original", original), ("serial", scripted.forward_serial),
                                ("parallel", scripted)):
            actual, elapsed = timed_call(function, x)
            compare_tensor(statistics_by_tensor, f"{label}/full_sequence", actual,
                           expected_sequence, TOLERANCES["logits_absolute"])
            if (batch, length) == PARITY_SHAPES[0]:
                cold[f"first_{label}_sequence_verification_ms"] = elapsed
        shape_rows.append({"batch": batch, "length": length, "status": "PASS"})

    # Alter future tokens and one independent example, keeping all other inputs.
    x = torch.randint(original.config.vocab_size, (3, 11), generator=generator)
    future_changed = x.clone()
    future_changed[:, 5:] = (future_changed[:, 5:] + 3) % original.config.vocab_size
    other_example_changed = x.clone()
    other_example_changed[1] = (other_example_changed[1] + 5) % original.config.vocab_size
    permutation = torch.tensor([2, 0, 1])
    for label, function in (("original", original), ("serial", scripted.forward_serial),
                            ("parallel", scripted)):
        baseline = function(x)
        compare_tensor(statistics_by_tensor, f"{label}/causal_prefix",
                       function(future_changed)[:, :5], baseline[:, :5],
                       TOLERANCES["logits_absolute"])
        compare_tensor(statistics_by_tensor, f"{label}/independent_examples",
                       function(other_example_changed)[[0, 2]], baseline[[0, 2]],
                       TOLERANCES["logits_absolute"])
        compare_tensor(statistics_by_tensor, f"{label}/batch_permutation",
                       function(x[permutation]), baseline[permutation],
                       TOLERANCES["logits_absolute"])
        individual = torch.cat([function(x[index:index + 1]) for index in range(3)], 0)
        compare_tensor(statistics_by_tensor, f"{label}/batch_vs_individual",
                       individual, baseline, TOLERANCES["logits_absolute"])
    return {"case": identifier, "status": "PASS", "shapes": shape_rows,
            "input_state_unchanged_and_fresh_outputs": True,
            "tensor_comparisons": statistics_by_tensor, "first_call_setup": cold}


def work_counts(config):
    d, s, o, h, v = config.width, config.slots, config.operators, config.inner, config.vocab_size
    return {
        "dimensions": {"width_d": d, "slots_s": s, "operators_o": o, "inner_h": h, "vocabulary_v": v},
        "per_example_per_token": {
            "linear_layers": 13, "record_bmm_reads": 4, "pointer_bmm_reads": 1,
            "operator_embedding_matmuls": 1, "categorical_choices": 7,
            "tanh_applications": 4, "sigmoid_applications": 1,
            "macs_dense_affines_reads_and_operator_embedding":
                5 * d * d + 8 * s * d + 2 * o * d + 5 * d * h + d * v + s * s + 7 * d,
            "value_commit_multiply_add_scalar_operations": 3 * s * d,
            "link_commit_multiply_add_scalar_operations": 3 * s * s,
            "persistent_state_fp32_elements": s * d + s * s + s + 2 * d,
            "persistent_state_fp32_bytes": 4 * (s * d + s * s + s + 2 * d),
            "forks_in_parallel_schedule": 6, "waits_in_parallel_schedule": 6,
        },
        "notes": [
            "A MAC is one multiply-accumulate, not one FLOP or elapsed-time unit.",
            "Biases, nonlinearities, choices, copies, and mask preparation are additional.",
            "Counts describe executed dense operations, including heads whose result an ablation overrides.",
            "No indexed reads, sparse writes, or fused affine heads are implemented in this bridge.",
        ],
    }


def percentile(values, probability):
    values = sorted(values)
    position = (len(values) - 1) * probability
    lower, upper = math.floor(position), math.ceil(position)
    return values[lower] + (position - lower) * (values[upper] - values[lower])


@torch.inference_mode()
def benchmarks(original, scripted):
    generator = torch.Generator().manual_seed(9701)
    methods = [("original_eager", original), ("scripted_serial", scripted.forward_serial),
               ("scripted_fork_join", scripted)]
    rows = []
    for batch, length in BENCHMARK_SHAPES:
        x = torch.randint(original.config.vocab_size, (batch, length), generator=generator)
        for _, method in methods:
            for _ in range(WARMUPS):
                method(x)
        samples = {name: [] for name, _ in methods}
        for repetition in range(REPETITIONS):
            for offset in range(len(methods)):
                name, method = methods[(repetition + offset) % len(methods)]
                _, elapsed = timed_call(method, x)
                samples[name].append(elapsed)
        summaries = {
            name: {"p50_ms": statistics.median(values), "p95_ms": percentile(values, .95),
                   "min_ms": min(values), "max_ms": max(values), "raw_ms": values}
            for name, values in samples.items()
        }
        rows.append({
            "batch": batch, "length": length, "warmups_per_method": WARMUPS,
            "repetitions_per_method": REPETITIONS, "order": "rotating interleave",
            "methods": summaries,
            "fork_join_speedup_over_scripted_serial":
                summaries["scripted_serial"]["p50_ms"] / summaries["scripted_fork_join"]["p50_ms"],
        })
    return rows


@torch.inference_mode()
def profile_parallel(scripted):
    x = torch.arange(16 * 4, dtype=torch.long).reshape(16, 4) % scripted.vocab_size
    scripted(x)
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU]) as profile:
        scripted(x)
    trace = HERE / "runtime_parallel_trace.json"
    profile.export_chrome_trace(str(trace))
    selected = {"aten::addmm", "aten::bmm", "aten::mm", "aten::tanh",
                "aten::mul", "aten::add", "aten::softmax", "aten::sigmoid"}
    events = [{"name": event.name, "thread": event.thread,
               "start_us": event.time_range.start, "end_us": event.time_range.end}
              for event in profile.events() if event.name in selected]
    events.sort(key=lambda event: event["start_us"])
    latest = {}
    overlaps = []
    for event in events:
        for thread, previous in latest.items():
            if thread != event["thread"] and previous["end_us"] > event["start_us"]:
                if len(overlaps) < 12:
                    overlaps.append({"first": previous, "second": event,
                                     "overlap_us": min(previous["end_us"], event["end_us"])
                                                   - event["start_us"]})
        previous = latest.get(event["thread"])
        if previous is None or event["end_us"] > previous["end_us"]:
            latest[event["thread"]] = event
    threads = dict(Counter(event["thread"] for event in events))
    return {
        "batch": 16, "length": 4, "selected_operator_events": len(events),
        "operator_thread_counts": threads,
        "distinct_operator_threads": len(threads),
        "overlap_witnesses": overlaps,
        "observed_cross_thread_operator_overlap": bool(overlaps),
        "trace_file": trace.name, "trace_sha256": sha(trace),
        "interpretation": "Operator intervals on distinct runtime threads overlap; this is execution evidence, not a hardware speedup guarantee.",
    }


def registered_models(report):
    freeze_path = EXPERIMENT / "frozen_manifest.json"
    freeze = read_json(freeze_path)
    closure = read_json(EXPERIMENT / "training_closed.json")
    freeze_hash = sha(freeze_path)
    require(closure["freeze_sha256"] == freeze_hash, "Training closure freeze mismatch")
    for name, expected in freeze["source_sha256"].items():
        require(sha(EXPERIMENT / name) == expected, f"Frozen source changed: {name}")
    report["frozen_manifest_sha256"] = freeze_hash
    report["frozen_source_hashes_verified"] = len(freeze["source_sha256"])
    cases = []
    for index, mode in enumerate(MODES):
        torch.manual_seed(49001 + index)
        original = RecordRewrite(Config(37, mode=mode)).eval().requires_grad_(False)
        cases.append((f"random/{mode}", original, {"kind": "random", "seed": 49001 + index}))
    for task in ("structured", "lm"):
        for mode in MODES:
            directory = EXPERIMENT / "runs" / task / mode / "11"
            closed = closure["completed_fits"][f"{task}/{mode}/11"]
            require(sha(directory / "completed.json") == closed["completed_sha256"],
                    f"Receipt hash mismatch: {task}/{mode}")
            require(sha(directory / "checkpoint.pt") == closed["checkpoint_sha256"],
                    f"Checkpoint hash mismatch: {task}/{mode}")
            receipt = read_json(directory / "completed.json")
            require(receipt["freeze_sha256"] == freeze_hash, "Receipt freeze mismatch")
            specification = receipt["model"]
            config = Config(**{name: specification[name] for name in
                               ("vocab_size", "width", "slots", "operators", "inner",
                                "mode", "temperature")})
            original = RecordRewrite(config)
            checkpoint = torch.load(directory / "checkpoint.pt", map_location="cpu",
                                    weights_only=False)
            original.load_state_dict(checkpoint["model_state"], strict=True)
            original.eval().requires_grad_(False)
            cases.append((f"{task}/{mode}/11", original, {
                "kind": "frozen_checkpoint", "checkpoint_sha256": closed["checkpoint_sha256"],
                "completed_sha256": closed["completed_sha256"],
            }))
    return cases


def main():
    output = HERE / "RUNTIME_VERIFICATION.json"
    if output.exists() or (HERE / "runtime_parallel_trace.json").exists():
        raise FileExistsError("Existing runtime evidence will not be overwritten")
    # This must precede tensor work or the first inter-op execution.
    torch.set_num_threads(1)
    torch.set_num_interop_threads(4)
    torch.use_deterministic_algorithms(True)
    report = {
        "schema_version": 1, "status": "RUNNING", "optimizer_steps": 0,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "environment": {"python": platform.python_version(), "torch": torch.__version__,
                        "platform": platform.platform(), "cpu_count": os.cpu_count(),
                        "intraop_threads": torch.get_num_threads(),
                        "interop_threads": torch.get_num_interop_threads(),
                        "device": "cpu", "dtype": "float32",
                        "load_average_before": os.getloadavg()},
        "bridge_sha256": sha(HERE / "runtime_bridge.py"),
        "verifier_sha256": sha(Path(__file__)), "tolerances": TOLERANCES, "cases": [],
        "scope": "Pure inference scheduling parity, not training-gradient equivalence, new fits, or model quality evaluation.",
    }
    started = time.perf_counter()
    try:
        require(torch.__version__ == "2.5.1+cpu", "This evidence is pinned to PyTorch 2.5.1+cpu")
        selected = None
        for identifier, original, provenance in registered_models(report):
            weights_before = {name: value.clone() for name, value in original.state_dict().items()}
            tick = time.perf_counter_ns()
            bridge = RuntimeBridge(original).eval()
            wrapper_ms = (time.perf_counter_ns() - tick) / 1e6
            tick = time.perf_counter_ns()
            scripted = torch.jit.script(bridge)
            compile_ms = (time.perf_counter_ns() - tick) / 1e6
            parallel_counts = graph_counts(scripted.step_parallel.inlined_graph)
            serial_counts = graph_counts(scripted.step_serial.inlined_graph)
            require(parallel_counts.get("prim::fork", 0) == 6, "Expected six real fork graph nodes")
            require(parallel_counts.get("aten::wait", 0) == 6, "Expected six wait graph nodes")
            require(serial_counts.get("prim::fork", 0) == 0, "Serial schedule unexpectedly forks")
            row = verify_case(original, scripted, identifier)
            for name, value in original.state_dict().items():
                require(torch.equal(value, weights_before[name]), f"Weight mutation: {name}")
                require(torch.equal(scripted.state_dict()[name], value),
                        f"Scripted parameter mismatch: {name}")
            row.update({
                "provenance": provenance, "wrapper_construction_ms": wrapper_ms,
                "torchscript_compilation_ms": compile_ms, "weights_unchanged": True,
                "parallel_graph_node_counts": parallel_counts,
                "serial_graph_node_counts": serial_counts,
                "parallel_graph_sha256": hashlib.sha256(
                    str(scripted.step_parallel.inlined_graph).encode()).hexdigest(),
                "work_counts": work_counts(original.config),
            })
            report["cases"].append(row)
            print(json.dumps({"verified": identifier, "status": "PASS",
                              "fork_nodes": parallel_counts["prim::fork"]}), flush=True)
            if identifier == "lm/rewrite/11":
                selected = original, scripted
        require(len(report["cases"]) == 9 and selected is not None, "Incomplete parity cohort")
        report["all_parity_completed_before_benchmark"] = True
        report["benchmarked_case"] = "lm/rewrite/11"
        report["benchmarks"] = benchmarks(*selected)
        report["profiler"] = profile_parallel(selected[1])
        require(report["profiler"]["observed_cross_thread_operator_overlap"],
                "Profiler did not establish cross-thread operator overlap")
        report["status"] = "PASS"
    except Exception as error:
        report["status"] = "FAIL"
        report["error"] = f"{type(error).__name__}: {error}"
    report["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
    report["total_wall_seconds"] = time.perf_counter() - started
    report["environment"]["load_average_after"] = os.getloadavg()
    output.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({
        "status": report["status"], "verified_cases": len(report["cases"]),
        "cross_thread_overlap": report.get("profiler", {}).get("observed_cross_thread_operator_overlap"),
        "total_wall_seconds": report["total_wall_seconds"], "error": report.get("error"),
        "warm_speedups": [{"batch": row["batch"], "length": row["length"],
                          "serial_over_parallel":
                              row["fork_join_speedup_over_scripted_serial"]}
                         for row in report.get("benchmarks", [])],
    }), flush=True)
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
