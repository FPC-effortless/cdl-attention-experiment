#!/usr/bin/env python3
"""Rebuild every project proof, audit all theorem axioms, and run negative controls.

Uses only the Python standard library and the pinned official Lean distribution.
An optional, documented app-path launcher handles this environment's process-path
incompatibility. It does not replace any Lean proof-checking operation.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--lean", default="lean")
    parser.add_argument("--explicit-path-launcher", type=Path)
    parser.add_argument("--distribution-archive", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    resolved = shutil.which(args.lean)
    if resolved is None:
        raise SystemExit(f"Lean executable unavailable: {args.lean}")
    # Preserve an elan proxy's executable name: resolving a symlink to `elan`
    # would change its argv[0] dispatch instead of invoking Lean.
    lean = Path(resolved).absolute()
    command = [str(lean)]
    if args.explicit_path_launcher:
        command = [str(args.explicit_path_launcher.resolve()), str(lean)]
    build = root / ".verification" / "olean"
    if build.exists():
        shutil.rmtree(build)
    (build / "CSM").mkdir(parents=True)
    evidence = root / "verification"
    evidence.mkdir(exist_ok=True)
    environment = dict(os.environ, LEAN_PATH=str(build))
    runs: list[dict] = []
    started = time.perf_counter()

    def invoke(arguments: list[str], *, expected_success: bool = True,
               stdin: str | None = None) -> subprocess.CompletedProcess:
        cmd = command + arguments
        start = time.perf_counter()
        result = subprocess.run(cmd, input=stdin, text=True, cwd=root,
                                env=environment, capture_output=True, timeout=180)
        runs.append({"command": cmd, "exit_code": result.returncode,
                     "seconds": time.perf_counter() - start,
                     "expected_success": expected_success,
                     "stdout": result.stdout, "stderr": result.stderr})
        if (result.returncode == 0) != expected_success:
            (evidence / "failed_run.json").write_text(json.dumps(runs, indent=2))
            raise RuntimeError(f"Unexpected Lean result: {cmd}\n{result.stdout}\n{result.stderr}")
        if expected_success and ("warning:" in result.stdout or "warning:" in result.stderr):
            raise RuntimeError(f"Lean warning rejected: {result.stdout}\n{result.stderr}")
        return result

    version = invoke(["--version"]).stdout.strip()
    if "version 4.19.0," not in version:
        raise RuntimeError(f"Expected Lean 4.19.0, received {version}")
    toolchain_root = Path(invoke(["--print-prefix"]).stdout.strip())
    module_files = [root / "CSM" / f"{name}.lean" for name in
                    ["Model", "Graph", "Parallel", "Training", "Cost"]]
    module_files.append(root / "CSM.lean")
    for source in module_files:
        relative = source.relative_to(root)
        output = build / relative.with_suffix(".olean")
        invoke(["--trust=0", "-o", str(output), str(relative)])

    audit = invoke(["--trust=0", "Audit.lean"])
    audit_text = audit.stdout + audit.stderr
    matches = re.findall(r"AUDIT_COUNT (\d+)", audit_text)
    if len(matches) != 1 or int(matches[0]) == 0:
        raise RuntimeError("Missing nonempty compiled theorem audit")
    (evidence / "axioms.log").write_text(audit_text)
    used_axioms: set[str] = set()
    for line in audit_text.splitlines():
        match = re.match(r"AUDIT .+: \[(.*)\]$", line)
        if match and match[1].strip():
            used_axioms.update(item.strip() for item in match[1].split(","))
    if not used_axioms <= {"propext", "Classical.choice", "Quot.sound"}:
        raise RuntimeError(f"Unapproved axiom dependency: {used_axioms}")

    exported = invoke(["--trust=0", "--run", "ExportGraph.lean"])
    graph = json.loads(exported.stdout)
    (root / "graph.json").write_text(json.dumps(graph, indent=2) + "\n")

    controls = {
        "false_arithmetic": "import Std\nexample : (0 : Nat) = 1 := by decide\n",
        "backward_rank_edge": (
            "import CSM.Graph\n"
            "example : CSM.Graph.rank .updated < CSM.Graph.rank .controller := by decide\n"
        ),
    }
    negative_results = {}
    for name, source in controls.items():
        result = invoke(["--trust=0", "--stdin"], expected_success=False, stdin=source)
        if "error:" not in result.stdout + result.stderr:
            raise RuntimeError(f"Negative control failed without a Lean error: {name}")
        negative_results[name] = {"exit_code": result.returncode,
                                  "source": source,
                                  "output": result.stdout + result.stderr}

    source_files = sorted(root.glob("CSM/*.lean")) + [root / "CSM.lean", root / "Audit.lean",
                    root / "ExportGraph.lean", root / "lean-toolchain", root / "lakefile.toml",
                    root / "tooling/lean_explicit_path.c", Path(__file__).resolve()]
    source_hashes = {str(path.relative_to(root)): sha256(path) for path in source_files}
    declared_theorems = sum(len(re.findall(
        r"^\s*(?:@\[[^\]]*\]\s*)?(?:private\s+)?theorem\s+", file.read_text(), re.M))
        for file in root.glob("CSM/*.lean"))
    toolchain_files = [lean, toolchain_root / "bin/lean", toolchain_root / "lib/lean/libleanshared.so",
                       toolchain_root / "lib/lean/Init.olean", toolchain_root / "lib/lean/Std.olean"]
    toolchain_hashes = {str(path): sha256(path) for path in toolchain_files if path.exists()}
    if args.explicit_path_launcher:
        toolchain_hashes[str(args.explicit_path_launcher.resolve())] = sha256(args.explicit_path_launcher)
    if args.distribution_archive:
        toolchain_hashes[str(args.distribution_archive.resolve())] = sha256(args.distribution_archive)
    report = {
        "status": "PASS", "finished_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "lean_version": version, "lean_trust_flag": 0,
        "declared_theorems": declared_theorems,
        "audited_theorem_constants_including_generated": int(matches[0]),
        "axiom_dependencies": sorted(used_axioms),
        "all_project_theorem_axioms_audited": True,
        "negative_controls": negative_results,
        "source_sha256": source_hashes, "toolchain_sha256": toolchain_hashes,
        "graph_sha256": sha256(root / "graph.json"),
        "application_path_launcher_used": bool(args.explicit_path_launcher),
        "launcher_scope": "Supplies known own executable path; unmodified official lean_main and shared proof kernel.",
        "official_distribution_url": "https://github.com/leanprover/lean4/releases/download/v4.19.0/lean-4.19.0-linux.tar.zst",
        "seconds": time.perf_counter() - started,
        "scope": "Specified graph/transition properties and supplied-pullback contracts; not numeric kernels, PyTorch compiler, optimizer convergence, or learning quality.",
    }
    (evidence / "build_runs.json").write_text(json.dumps(runs, indent=2) + "\n")
    (root / "LEAN_VERIFICATION.json").write_text(json.dumps(report, indent=2) + "\n")
    (evidence / "failed_run.json").unlink(missing_ok=True)
    print(json.dumps({key: report[key] for key in ["status", "lean_version", "declared_theorems",
                     "audited_theorem_constants_including_generated", "axiom_dependencies", "seconds"]}, indent=2))


if __name__ == "__main__":
    main()
