import Lean
import CSM

open Lean Elab Command

/- Use the same dependency collector as `#print axioms`, for every project
theorem in the compiled environment, including private/generated theorems. -/
run_cmd do
  let env ← getEnv
  let mut count := 0
  for (name, info) in env.constants.toList do
    let text := name.toString
    if text.startsWith "CSM." || text.startsWith "_private.CSM." then
      match info with
      | .axiomInfo val =>
        -- Lean's compiler emits unsafe runtime-only lambda-lifting placeholders.
        -- They cannot serve as safe proofs; every theorem dependency is still
        -- checked below. Reject every logical axiom or other project placeholder.
        if val.isUnsafe && Compiler.isEagerLambdaLiftingName name then
          logInfo m!"COMPILER_RUNTIME_AUX {name}"
        else
          throwError "Project logical axiom rejected: {name}"
      | .thmInfo _ =>
        let axioms ← collectAxioms name
        for ax in axioms do
          unless ax == ``propext || ax == ``Classical.choice || ax == ``Quot.sound do
            throwError "Unapproved axiom {ax} in {name}"
        logInfo m!"AUDIT {name}: {axioms.qsort Name.lt |>.toList}"
        count := count + 1
      | _ => pure ()
  logInfo m!"AUDIT_COUNT {count}"
