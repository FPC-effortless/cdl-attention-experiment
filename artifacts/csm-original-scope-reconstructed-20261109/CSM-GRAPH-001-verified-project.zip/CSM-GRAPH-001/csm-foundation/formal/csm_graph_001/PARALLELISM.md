# CSM work/span and executable parallel scheduling

## Results

The complete ordinary CSM transition has useful independence **within a token**.
The bridge executes that independence with six scripted fork/join tasks while
retaining the original dense operators and parameter tensors.

- Forward verification: **PASS**, on nine models, all three modes, and five
  batch/length shapes. Same-shape logits, every state tensor, and all route/gate
  traces matched the original exactly.
- Actual concurrency: **observed**, with six fork nodes, six wait nodes, and
  overlapping operator intervals on different profiler threads.
- Requested fork/join surrogate backward: **PASS**, on 27 multi-step cases and
  864 parameter/initial-state gradient comparisons, including None matching.
- Additional scripted-serial backward control: **FAIL** on gradient presence in
  ablations. Forty-two unused gradients were zero tensors instead of None.
  This discrepancy is preserved; the combined backward suite remains FAIL.
- Runtime benefit: **not observed against the scripted serial control**.
  Fork/join was 1.55–2.82 times slower in the measured workloads.

No fitting or optimizer step occurred. No indexed storage, fused affine heads,
GPU implementation, or parallel execution of dependent tokens was introduced.
The bridge covers the ordinary transition and the three configured modes; it
does not expose any optional intervention, including corruption, reset,
links_off, or constant_operator.

## Complete per-token dependency graph

For one example, the state is values \(M\in\mathbb R^{s\times d}\), pointers
\(L\in\mathbb R^{s\times s}\), cursor \(c\in\mathbb R^s\), two previous input
embeddings \(H\in\mathbb R^{2\times d}\), and integer position \(p\).

With input embedding \(r=E[x]\), the frontend and controller are

\[
f=\tanh(W_f[H_0;H_1;r]+b_f),\qquad
q=\tanh(W_c[f;c^\top M]+b_c).
\]

The first address selects \(A=\alpha^\top M\). The second direct address depends
on \([q;A]\); the alternative linked address is \(\alpha^\top L\). A binary
selection head chooses between them, yielding \(\beta\) and \(B=\beta^\top M\).
The operator head selects an embedding \(\omega^\top U\). The proposal is

\[
z=\tanh(W_2\tanh(W_1[f;A;B;\omega^\top U]+b_1)+b_2).
\]

Destination \(\delta\), value-edit bit \(\epsilon_v\), scalar gate and link-edit
bit \(\epsilon_\ell\) depend only on \(q\). The previous destination value and
new value are

\[
m_{\rm old}=\delta^\top M,\quad
\gamma=\epsilon_v\sigma(w_g^\top q+b_g),\quad
m_{\rm new}=m_{\rm old}+\gamma(z-m_{\rm old}).
\]

The complete commit and readout are

\[
\begin{aligned}
M'_{ij}&=(1-\delta_i)M_{ij}+\delta_i(m_{\rm new})_j,\\
L'_{ij}&=(1-\delta_i\epsilon_\ell)L_{ij}
            +\delta_i\epsilon_\ell\beta_j,\\
c'&=\delta,\quad H'=[H_1;r],\quad p'=p+1,\quad
y=W_y m_{\rm new}+b_y.
\end{aligned}
\]

All categorical heads retain the original softmax/argmax/one-hot expression,
including its straight-through surrogate path. No argmax-of-logits shortcut
replaces it. In no_links mode the direct second address is used. In ring_write
mode the destination is position modulo slot count.

These are mathematical macro levels, not single CPU instructions or kernels:

| Level | Newly available computations |
|---:|---|
| 1 | Token embedding and independent old active-record read |
| 2 | Local frontend and next embedding history |
| 3 | Controller |
| 4 | First-address, destination, operator, link-selection, link-edit, value-edit, and write-gate heads |
| 5 | First value, linked pointer, previous destination value, operator embedding, scalar gate |
| 6 | Direct second-address head, which requires the first value |
| 7 | Direct/linked address selection |
| 8 | Second value read; link update can proceed |
| 9 | First proposal affine layer and tanh |
| 10 | Second proposal affine layer and tanh |
| 11 | Gated destination value |
| 12 | Independent vocabulary projection and value-store update |

Cursor/history/position can be prepared when their operands exist. The bridge
groups small operations into larger pure tasks:

```mermaid
flowchart TD
    F["Embedding and frontend"] --> C["Controller"]
    A["Active record read"] --> C
    C --> R["Addresses and record reads"]
    C --> O["Operator embedding"]
    C --> W["Destination and gates"]
    R --> P["Proposal MLP"]
    O --> P
    F --> P
    R --> L["Link update"]
    W --> L
    P --> U["Gated new value"]
    W --> U
    U --> Y["Output projection"]
    U --> M["Value update"]
    W --> M
    M --> S["New state"]
    L --> S
```

History/cursor/position wires are omitted from the diagram for readability,
but those fields are returned and verified. The six forks launch frontend,
routing, operator embedding, write controls, link update, and output projection.
The maximum deliberately forked group contains three branches after the
controller. Four workers do not imply four useful tasks throughout the step.
This is not asserted to be an optimal schedule of the finer mathematical DAG.

## Dense work, storage, and unit counts

Let \(v,d,s,o,h\) denote vocabulary size, width, slots, operators, and inner
transform width. A MAC is one multiply-accumulate, not one FLOP or wall-time unit.

| Component | Per-example dense MAC count per token |
|---|---:|
| Frontend, \(3d\to d\) | \(3d^2\) |
| Controller, \(2d\to d\) | \(2d^2\) |
| First, second, destination address heads | \(4sd\) |
| Three binary heads and scalar write gate | \(7d\) |
| Operator head and dense embedding selection | \(2od\) |
| Transform, \(4d\to h\to d\) | \(5dh\) |
| Vocabulary projection | \(dv\) |
| Four record reads: active, first, second, previous destination | \(4sd\) |
| Dense outgoing-pointer read | \(s^2\) |
| **Total** | **\(5d^2+8sd+2od+5dh+dv+s^2+7d\)** |

The source-level transition has 13 affine layers, five bmm reads, one operator
embedding matrix multiply, seven categorical choices, four tanh applications,
and one sigmoid application. The binary heads are use_link, link_edit, and
value_edit. The scalar write gate is separate.

Additional work includes \(3sd\) multiply/add operations in value commit and
\(3s^2\) in link commit, plus masks, gate arithmetic, biases, softmax/argmax,
embedding gathers, concatenations, history copies, allocations and trace
construction. Therefore

\[
W_{\rm dense}=\Theta(d^2+dh+dv+sd+s^2+od).
\]

These are analytic counts for the frozen eager source, not profiler-derived
kernel totals. TorchScript may eliminate unused ablation work.

This assumes positive dimensions and constant-cost scalar nonlinearities.
Batch size \(b\) and length \(t\) multiply work by \(bt\). Dense reads and masks
do not skip arithmetic because an address is one-hot.

At \(s=8,d=32,o=4,h=64,v=257\), the table gives **26,176 MACs**, plus
**960** value/link commit multiply/add operations and the other listed work.
These figures are not a complete FLOP total. The bridge does not promise that
compiler optimization preserves the exact number of primitive hardware
instructions implied by a source-level operation count.

Persistent tensor state has \(sd+s^2+s+2d=392\) FP32 elements:
**1,568 bytes per example**, plus a Python position integer. This excludes
weights, temporary tensors, autograd history, allocator overhead and process RSS.
Forked tasks retain their live inputs and temporary outputs until joins.

The full parameter count, including biases, is

\[
2vd+v+5d^2+4sd+2od+5dh+10d+3s+o+h+7.
\]

This gives 33,764 parameters for the byte model and 18,359 when \(v=20\).
Scheduling does not change these counts.

## Span and the recurrence boundary

In an ideal scalar work/span model, assume exact real arithmetic, sufficient
processors, constant-cost coordinatewise nonlinearities, and balanced
reductions. A length-\(n\) reduction has \(O(1+\log n)\) span. The fixed-depth
token graph then has

\[
D_{\rm token}=O(1+\log d+\log s+\log o+\log h),
\]

with nontrivial serial constants represented by the dependency table. Real
kernel launch costs, memory bandwidth, task scheduling and processor counts do
not disappear from hardware execution.

The chosen sequence graph retains a recurrent path of length \(\Omega(t)\):
the next controller and reads depend on state produced by the preceding token.
A straightforward upper bound is \(O(tD_{\rm token})\). This concerns this graph,
not every conceivable alternative algorithm.

Abstract function composition is associative. It does not automatically give
a bounded-size, bounded-cost representation for composing these state-dependent
routes and nonlinear proposals into an efficient parallel prefix scan. No such
scan is implemented or proved here.

Separate examples have independent states and can be batched. Given all input
tokens, raw embeddings and three-token frontend windows could be precomputed,
and output projections could be batched after recurrent new values exist.
Those transformations are not performed in this bridge. During generation,
the next input token also depends on the preceding output.

## Indexed hard inference remains a separate proposal

In the exact real-arithmetic model, one-hot invariants permit a possible
representation with \(s\) integer pointers, one integer cursor and indexed
record/operator reads. Refining the floating-point program requires additional
conditions: unselected records and all relevant intermediate values must remain
finite, and equality must be scoped to numerical values rather than signed-zero
bit patterns. One-hot structure alone does not suffice: dense zero-times-NaN
terms can contaminate a read, and masked commits can change signed zero. See
REVIEW.md and NUMERIC_BOUNDARY_VERIFICATION.json for concrete boundary cases.
No unrestricted floating-point indexed-equivalence claim is made here.

An owned mutable state
could write one record and one pointer. This can remove dense \(s^2\) pointer
traffic and replace four \(sd\)-work reads with \(d\)-work gathers. The learned
address heads still produce \(s\) scores and still cost \(\Theta(sd)\).

\[
W_{\rm indexed}=\Theta(d^2+dh+dv+sd+od).
\]

Cloning all records before a functional indexed write still costs
\(\Theta(sd)\); an \(O(d)\) write claim requires explicit mutation/ownership or
another persistent representation. With current dimensions, FP32
records/history plus int64 links/cursor would use
\(320\cdot4+9\cdot8=1,352\) tensor bytes per example, plus position. This is a
representation calculation, not a measured implementation.

The verified bridge retains dense storage and fresh immutable state outputs.
No indexed-memory or sparse-kernel benefit belongs to its results.

## Executed forward and concurrency verification

RUNTIME_VERIFICATION.json records the following:

| Coverage | Executed scope |
|---|---|
| Random models | Three modes, seeds 49001–49003 |
| Frozen checkpoints | Structured and LM, seed 11, all three modes |
| Batch/length shapes | (1,1), (1,7), (3,9), (16,32), (32,64) |
| Per-step comparison | Logits; values, links, cursor, history, position; eight trace fields |
| Ownership | Old inputs unchanged; four new state tensors use fresh storage |
| Sequence checks | Full sequence equals repeated steps; future changes preserve prefix |
| Example checks | Other-example mutation and batch permutation |
| Shape variation | Batched computation compared with separate one-example calls |
| Graph evidence | Six prim::fork and six aten::wait nodes; no forks in serial step |
| Profiler evidence | 212 selected operator events across five thread IDs, with overlap |

Same-shape comparisons, causal prefixes, batch permutations and unaffected
examples were **exact under torch.equal**, with maximum difference zero. This
means numerical tensor equality, not a comparison of signed-zero or NaN bit
patterns; all tested values were finite. Changing a batch of
three into separate calls produced differences up to
\(2.384185791015625\times10^{-6}\), including in the original model. These stayed
within the predeclared \(10^{-5}\) logit tolerance. State tolerance was
\(10^{-6}\); discrete routes/edit bits required exact equality.

One profiler witness contains addmm intervals on distinct threads overlapping
by 7.344 microseconds. This establishes overlapping runtime work, not execution
on particular physical cores or a speed advantage. The trace is saved in
runtime_parallel_trace.json.

## Surrogate backward verification and preserved discrepancy

The separate gradient script runs with gradients enabled, no optimizer, and
unchanged weights. It uses the same nine models and three trials per model:
(batch 1, length 3) with an output objective, and (batch 3, length 5) and
(batch 2, length 7) with output-plus-final-state objectives.

Each initial state has nonzero values in [-0.7,0.7], random one-hot pointer rows
and cursor, history equal to two detached token embeddings, and position 5.
These are structurally valid forward points, not claimed reachable histories.
The four float state tensors are independent differentiable leaves.

The objective contains a fixed random weighted logit sum and a squared-logit
term; the second objective adds random weighted final-state terms. The
comparison covers all 28 named parameter tensors and all four initial-state
tensors, with explicit None matching. Tolerance was declared before execution:

\[
|g_{\rm candidate}-g_{\rm reference}|
\le 2\times10^{-6}+2\times10^{-5}|g_{\rm reference}|.
\]

| Requested fork/join comparison | Result |
|---|---:|
| Multi-step trials passing | 27/27 |
| Parameter-gradient comparisons passing | 756/756 |
| Initial-state-gradient comparisons passing | 108/108 |
| Matched None gradients | 42 parameter + 3 initial-state cases |
| Maximum parameter-gradient absolute difference | \(1.7881393432617188\times10^{-7}\) |
| Maximum initial-state-gradient absolute difference | \(1.1920928955078125\times10^{-7}\) |
| Maximum fraction of allowed tolerance | 0.03041665 |
| Forward logits, final state, route/gate traces | Exact |

This verifies the **implemented straight-through surrogate program**. It does
not claim a derivative of discrete argmax or justify the surrogate as unbiased.

The added scripted-serial control passed only 9/27 strict trials. Its numerical
gradients passed tolerance, but 42 unused parameter gradients were tensors where
eager autograd returned None: destination parameters in ring_write, and use_link
parameters plus output-only link_edit parameters in no_links. A separate
diagnostic replay confirmed that all 42 tensors are **exact zero**.

None and a zero tensor were not normalized into equivalence. Their gradient
presence differs, so optimizer-equivalence of this serial control is not
established. The inference timing comparisons remain forward-valid. No
optimizer behavior was tested.

SURROGATE_BACKWARD_VERIFICATION.json preserves the combined suite's **FAIL**
verdict and every comparison. The requested fork/join target passes within
that report; the additional serial control does not.
SURROGATE_UNUSED_GRADIENT_DIAGNOSTIC.json preserves the zero-tensor diagnosis.

## Observed CPU cost

Environment: Python 3.12.14, PyTorch 2.5.1+cpu, FP32, one intra-op thread, four
inter-op workers. All nine forward parity cases passed before warm benchmarking.
The benchmark uses the frozen LM rewrite seed-11 model, three warmups per method
and 20 repetitions with rotating method order.

Times include state initialization, the supplied sequence's transitions, output
projection and output stacking. They exclude tokenization, disk reads,
checkpoint loading and fitting.

| Batch | Length | Eager median ms | Scripted serial ms | Scripted fork/join ms | Serial / fork/join |
|---:|---:|---:|---:|---:|---:|
| 1 | 32 | 10.806 | 5.678 | 16.004 | 0.355 |
| 1 | 64 | 21.979 | 12.138 | 29.821 | 0.407 |
| 16 | 32 | 14.285 | 9.090 | 18.635 | 0.488 |
| 32 | 64 | 44.343 | 24.735 | 38.442 | 0.643 |

Fork/join took 1.55–2.82 times the scripted serial median. Its largest case beat
eager Python, but serial scripting was faster still; this does not establish
that task parallelism caused the eager-to-scripted improvement.

Compilation ranged from 41.421 to 167.651 ms across cases. The first parallel
step verification call ranged from 10.932 to 58.732 ms; the first parallel
sequence call ranged from 14.334 to 37.059 ms. These are module-first setup
observations inside one process with shared runtime caches, not independent
fresh-process startup benchmarks. Raw setup times, warm samples, p95 values and
host load observations remain in the JSON.

At these small dimensions, scheduling, synchronization, allocation and memory
traffic can outweigh concurrent arithmetic. These measurements do not establish
a crossover point for larger models or other hardware.

## Proof boundary and reproduction

Mathematical schedule proofs and execution checks have different scopes. The
runtime evidence does not formally verify PyTorch, its C++ scheduler, IEEE-754,
BLAS, or compiler transformations. It checks concrete executions against the
unchanged original program. The work/span analysis explicitly states its
idealized arithmetic and processor assumptions.

Run verify_runtime_bridge.py, verify_surrogate_backward.py, and
diagnose_surrogate_unused.py in the pinned environment. They preserve evidence
and refuse to overwrite existing results. The backward verifier intentionally
exits nonzero because the additional serial control fails strict gradient
presence, even though the fork/join target passes.

The wrapper must be scripted: eager Python torch.jit.fork does not run tasks
asynchronously. Forked helpers only read their inputs, parameters and attributes.
The pinned installed API documentation records these conditions.

Official references:

- [Fork/join introduction](https://pytorch.org/blog/pytorch-1-6-released/)
- [Profiler documentation](https://docs.pytorch.org/tutorials/recipes/recipes/profiler_recipe.html)
- [Current TorchScript parallelism page](https://docs.pytorch.org/tutorials/advanced/torch-script-parallelism.html)
- [Inter-op thread configuration](https://docs.pytorch.org/docs/2.15/generated/torch.set_num_interop_threads.html)

Current documentation marks TorchScript as deprecated. It is used here as an
available pinned-runtime mechanism for executable scheduling verification, not
as a deployment recommendation.
