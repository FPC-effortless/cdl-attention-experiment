# CSM-GRAPH-001

A mathematical and executable study of the frozen CSM record-rewrite backbone.

Start with [REPORT.md](REPORT.md) for the full mathematical specification and
interpretation. [PARALLELISM.md](PARALLELISM.md) explains the executable schedule
and cost model. [REVIEW.md](REVIEW.md) records an independent semantic review.

## Results

- Lean 4.19.0: the full structural proof project compiles and its axiom audit passes.
- Forward fork/join bridge: passes the recorded conformance checks.
- Fork/join surrogate backward target: passes 27/27 multi-step trials.
- Additional scripted serial gradient control: fails None-versus-zero equivalence;
  the combined backward report deliberately remains FAIL.
- CPU fork/join timing: slower than scripted serial in all four measured workloads.
- Numerical boundary examples: all three expected counterexamples reproduced.

These are distinct verdicts. There is no overall claim that learning succeeds,
that the entire PyTorch runtime is formally verified, or that hardware speedup
has been established. The frozen experiment source and checkpoints are unchanged.

## Formal build

Requires Lean **4.19.0**, with `Std` from the same official distribution. There is
no Mathlib or third-party Lean package dependency. From this directory:

```bash
python verify_lean.py
```

The verifier compiles each module freshly into `.verification/olean`, always with
`--trust=0`. It audits all project theorem dependencies, including private and
generated theorems; exports `graph.json`; and confirms that two invalid proof
controls are rejected. It writes `LEAN_VERIFICATION.json`,
`verification/build_runs.json`, and `verification/axioms.log`. Existing local
`.olean` files in source directories are not used by this verification run.

For ordinary development, `lake build` compiles the `CSM` library. The separate
verifier adds the complete audit and negative controls. `lean-toolchain` pins the
version. The proof sources are `CSM/{Model,Graph,Parallel,Training,Cost}.lean`.

## Optional application-path compatibility launcher

The managed environment used for the recorded run has a PID/proc-namespace
mismatch. The official Lean launcher fails while discovering its own executable
path. The disclosed launcher supplies the already known path for that specific
request, while executing the official shared library's `lean_main` and kernel.
It performs no alternative proc read and changes no sandbox settings.

**Normal environments should use the ordinary Lean executable.** Only if the
same application-path failure occurs, build the supplied compatibility launcher:

```bash
CSM_LEAN_ROOT=/absolute/path/to/lean-4.19.0-linux
cc -O2 -std=c11 -Wl,--export-dynamic tooling/lean_explicit_path.c \
  -L "$CSM_LEAN_ROOT/lib/lean" \
  -Wl,-rpath,"$CSM_LEAN_ROOT/lib/lean" \
  -lleanshared -ldl -o /absolute/path/to/lean-explicit-path

python verify_lean.py \
  --lean "$CSM_LEAN_ROOT/bin/lean" \
  --explicit-path-launcher /absolute/path/to/lean-explicit-path
```

The optional `--distribution-archive /absolute/path/to/archive.tar.zst` records
the release archive's SHA256. It does not download or install software. The
recorded run used the official release at:

https://github.com/leanprover/lean4/releases/download/v4.19.0/lean-4.19.0-linux.tar.zst

The toolchain receipt identifies this as an adapted launcher and records hashes
of the unmodified official executable, shared kernel, standard modules, archive,
and compatibility launcher. It is not an independent-kernel-checker result.

## Runtime checks

Keep this directory at `formal/csm_graph_001` within the accompanying repository
snapshot. The scripts read the frozen experiment manifest and checkpoints under
`experiments/csm_foundation_001`; they reject changed frozen source hashes.
Use the prototype's pinned Python/PyTorch requirements. Recorded environment:
Python 3.12.14, PyTorch 2.5.1+cpu, FP32, one intra-operation thread and four
inter-operation workers. From this directory:

```bash
mkdir retained_original_evidence
mv RUNTIME_VERIFICATION.json runtime_parallel_trace.json \
  SURROGATE_BACKWARD_VERIFICATION.json SURROGATE_UNUSED_GRADIENT_DIAGNOSTIC.json \
  NUMERIC_BOUNDARY_VERIFICATION.json retained_original_evidence/
python verify_runtime_bridge.py
python verify_surrogate_backward.py
python diagnose_surrogate_unused.py
python verify_numeric_boundary.py
```

Run this in a working copy of the delivered snapshot. The first two commands
preserve the recorded evidence because the runtime verifiers deliberately refuse
to overwrite prior results. For subsequent repetitions, use a fresh working copy
or a new preservation directory. The archive includes the six frozen seed-11
checkpoints and their receipts required by these checks; the Git bundle alone
does not include those untracked model weights.

The backward verifier intentionally exits nonzero while the serial-control
gradient-presence discrepancy remains. The fork/join target can be inspected
separately in its per-candidate records. Do not replace `None` with zero to turn
this control green. None of these commands performs optimizer steps or fitting.

TorchScript is a pinned experimental bridge here; current PyTorch documentation
marks it deprecated. A production implementation needs a separately evaluated
execution backend and correctness/performance evidence.

## Evidence

- `LEAN_VERIFICATION.json`: exact version, source/toolchain hashes, theorem counts,
  allowed standard axiom dependencies, and negative-control results.
- `RUNTIME_VERIFICATION.json`: inference parity, state integrity, causal/batch
  checks, timings, profiler evidence, frozen provenance, and source hashes.
- `SURROGATE_BACKWARD_VERIFICATION.json`: requested parallel target plus the
  failing serial gradient control; full gradient comparison records.
- `SURROGATE_UNUSED_GRADIENT_DIAGNOSTIC.json`: all 42 materialized-zero cases.
- `NUMERIC_BOUNDARY_VERIFICATION.json`: NaN and signed-zero refinement boundaries.
- `runtime_parallel_trace.json`: profiler trace for inspection.
- `graph.json`: graph exported from the compiled Lean definitions for all modes.

The archive also contains a repository snapshot and a Git bundle, with a separate
delivery manifest identifying their commit and hashes. No remote publication or
merge was performed for this task.
