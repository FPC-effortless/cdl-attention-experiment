# Semantic review of the CSM formal model

## Conclusion

The review found no invalid internal Lean equivalence and no missing forward
value dependency in `CSM/Graph.lean` for the fixed-shape, unintervened transition
in `experiments/csm_foundation_001/model.py`. `CSM/Model.lean` represents the
complete abstract state transition: its three modes, initialization, history,
cursor, position, storage commits, output, and sequence execution.

The supported description is **a complete parameterized model of the hard-forward
transition, with proved structural invariants and schedule equivalence,
accompanied by empirical PyTorch conformance checks**. This is not a formal
verification of the complete PyTorch system or its numerical kernels.

The review did not modify the Python model or the core Lean modules. The numerical
examples below document the boundary of the abstraction; they are not requests
to modify the frozen experiment, evidence of failures in its registered fits, or
neural capability evaluations.

## Correspondence checked

- The frontend consumes the older history item, the recent item, and the current
  embedding in the Python order. The controller also reads the current cursor's
  value.
- The first read feeds the direct second-address head. The selected second
  address can instead follow the first record's link. The transform receives
  frontend, first value, second value, and operator embedding in the correct
  order.
- The destination read, edit gate, update, record commits, and output wiring
  correspond to the Python transition. The vocabulary output uses the updated
  value.
- `ringWrite` uses position modulo the slot count. `noLinks` chooses the direct
  second address while still allowing the link state to be written, as Python
  does.
- The new cursor is the destination; history becomes `(recent, embedding)`;
  position increments. Sequence execution retains these temporal dependencies.
- The graph includes the necessary head, read, gate, transform, commit, and
  temporal carry dependencies. It retains heads computed and subsequently
  discarded by the Python modes without assigning their discarded values false
  downstream value dependencies.

## Abstraction assumptions and limits

### Finite addresses are an assumed representation of tensor routing

`Fin` addresses and function-valued stores replace one-hot tensors, dense `bmm`
reads, and masked arithmetic writes. `encoded_links_one_hot` proves a property of
the Lean encoding. It does not prove that the Python softmax, straight-through
expression, or tensor states always satisfy that representation.

A correspondence theorem would need an explicit relation between the tensor
state and the Lean state, valid hard one-hot routing, and conditions that exclude
nonfinite intermediate contamination. Finite input tensors alone are not a
general proof that every later floating-point intermediate remains finite.

`initialState` matches Python when its feature is the zero vector and its cursor
is index zero. The generic Lean definition also permits other initial choices.

### Conditional no-op and dense floating-point arithmetic differ outside that domain

The abstract model directly returns the old value when editing is disabled.
Python still evaluates `previous + gate * (proposal - previous)`. Dense reads and
commits also evaluate products for unselected records. These expressions are not
unconditional IEEE-754 implementations of functional selection and replacement.

The three existing observations are reproduced by `verify_numeric_boundary.py`;
its output is `NUMERIC_BOUNDARY_VERIFICATION.json`:

| Boundary fixture | Observed Python behavior | Consequence for the formal claim |
|---|---|---|
| One-hot address `[1, 0]`, records `[2, NaN]` | The dense read is NaN, although the selected record is 2. | An unselected nonfinite record can contaminate a dense read. |
| Previous value 2, gate 0, proposal NaN | The arithmetic update is NaN. | A zero gate is not an unconditional numerical no-op. |
| An unselected record contains `-0.0`; a different record is replaced | The unselected record becomes `+0.0`. | Numerical equality does not establish identical floating-point bit patterns. |

For the third fixture, FP32 negative zero has bit pattern `0x80000000` (signed
int32 reinterpretation `-2147483648`), and positive zero has `0x00000000` (signed
int32 0). `torch.equal` considers these two values equal. The verifier therefore
records both numerical equality and integer-reinterpreted bit equality. It uses
`torch.isnan` to check NaN outcomes, records their actual bit patterns, and emits
string value representations so its JSON contains no nonstandard NaN literals.

These counterexamples do not refute the abstract Lean theorems. They identify
premises needed to relate those theorems to unrestricted floating-point tensor
states. Exact numerical equality and bit-pattern identity must not be used as
interchangeable terms.

### The declared graph is not a formally verified extraction

`Graph.lean` is a manually specified graph of macro operations. Its rank and
acyclicity proofs verify that declared graph. They do not prove that it was
correctly extracted from `Model.lean` or Python. Deleting a necessary dependency
could leave the acyclicity proof valid. Manual semantic review and runtime
tracing provide evidence for the current correspondence; they have different
guarantees from a formal extraction theorem.

Dimensions, dtype, device, and parameter values are fixed for this graph. For
example, the ring destination's numerical value is independent of the discarded
learned destination, although Python's `zeros_like` still uses tensor metadata.

### Pure function equality is not equality of execution details

The structural proofs quantify over pure neural kernels. In `ringWrite` and
`noLinks`, the Lean expression may erase computations whose results are unused,
whereas Python computes some of them before discarding their results. The
equivalence concerns abstract state and output, not identical operation counts,
call order, tensor allocation, or hardware execution.

The parallel plan is a dependency-respecting schedule. Its mathematical equality
does not itself establish concurrent execution, thread safety of an arbitrary
backend, or a runtime improvement.

## Excluded behavior

The present Lean transition and graph exclude reset/corruption hooks,
`links_off`, `constant_operator`, free-running token sampling, optimizer updates,
and implementation-level numerical or memory semantics. Ordinary externally
supplied token sequences and fixed parameters are the sequence proof's scope.

Affine maps, nonlinearities, softmax, hard-choice implementation, and their
pullbacks remain kernel parameters or implementation obligations. The backward
graph's acyclicity establishes a dependency scheduling property, not correctness
of a local VJP. It does not make the straight-through estimator the true
derivative of hard selection.

The proofs do not establish predictive competence, architectural novelty, or a
performance advantage. Those require separate evidence.

## Reproduction of the numerical boundary observations

With the experiment's PyTorch environment, from the repository root:

```sh
python formal/csm_graph_001/verify_numeric_boundary.py
```

The script runs exactly the three small CPU fixtures above, writes
`formal/csm_graph_001/NUMERIC_BOUNDARY_VERIFICATION.json`, and prints the same
JSON. Exit code zero means all three expected boundary behaviors were
reproduced. It initializes no model weights, uses no dataset or random inputs,
and performs no fitting or capability scoring.
# Independent runtime-evidence review

A separate review inspected the bridge, both parity verifiers, diagnostic code,
and stored receipts without running additional model computations. It found no
blocking defect in the bounded inference or concurrency claims.

All 44 checked source/provenance/receipt and speed-ratio conditions passed. The
review independently reconstructed each benchmark median, percentile, range,
and speed ratio from the recorded samples. The methods use the same checkpoint,
input shapes, inference mode, process, warmup count and interleaved repetition
protocol. Every measured fork/join median is slower than scripted serial.

The runtime report includes 26,685 tensor comparisons. Same-shape comparisons
match under `torch.equal`; the largest batch-versus-individual discrepancy is
2.384185791015625e-6 and is also observed in the original implementation. The
source confirms that forked helpers read shared prior state and construct fresh
outputs; in-place initializations operate only on newly allocated tensors.

The exported trace independently contains overlapping operator intervals across
five thread IDs. Its selected Chrome `X` intervals total 220, while the PyTorch
profiler API report counts 212 selected events. These are distinct profiler views,
not contradictory physical-core counts. Neither establishes acceleration.

The requested fork/join backward target passes 27/27 trials and 864 gradient
comparisons. The scripted-serial control fails 18/27 trials, with 42 exact-zero
versus absent-gradient discrepancies. The combined report correctly remains
FAIL. Numerical agreement does not establish optimizer equivalence when gradient
presence differs. No additional optimizer, training, or performance runs were
performed during this review.
