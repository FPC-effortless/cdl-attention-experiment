"""Inspect, without normalizing, None-versus-tensor backward discrepancies."""
import copy
from datetime import datetime, timezone
import json
from pathlib import Path
import time

import torch

from runtime_bridge import RuntimeBridge
from verify_surrogate_backward import (
    HERE, SHAPES_AND_OBJECTIVES, differentiate, read_json, require, sha,
    sources_and_models, tensor_sha, trial_inputs,
)


def main():
    output = HERE / "SURROGATE_UNUSED_GRADIENT_DIAGNOSTIC.json"
    if output.exists():
        raise FileExistsError("Existing diagnostic evidence will not be overwritten")
    torch.set_num_threads(1)
    torch.set_num_interop_threads(4)
    torch.use_deterministic_algorithms(True)
    prior_path = HERE / "SURROGATE_BACKWARD_VERIFICATION.json"
    prior = read_json(prior_path)
    report = {
        "schema_version": 1, "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "prior_report_sha256": sha(prior_path), "script_sha256": sha(Path(__file__)),
        "optimizer_steps": 0, "observations": [],
        "scope": "Classify existing None-versus-tensor discrepancies; do not normalize them or change the failed control verdict.",
    }
    started = time.perf_counter()
    models = {identifier: model for identifier, model, _ in sources_and_models(report)}
    with torch.enable_grad():
        for case in prior["cases"]:
            failures = [
                (index, trial, comparison)
                for index, trial in enumerate(case["trials"])
                for comparison in trial["comparisons"]
                if comparison["method"] == "serial" and comparison["status"] == "FAIL"
            ]
            if not failures:
                continue
            original = models[case["case"]]
            scripted = torch.jit.script(RuntimeBridge(copy.deepcopy(original)).eval())
            for index, trial, comparison in failures:
                batch, length, objective = SHAPES_AND_OBJECTIVES[index]
                tokens, initial, coefficients = trial_inputs(original, batch, length, 80113 + index)
                reference = differentiate(original, "original", tokens, initial, coefficients, objective)
                serial = differentiate(scripted, "serial", tokens, initial, coefficients, objective)
                for entry in comparison["gradient_comparisons"]:
                    if entry["passed"]:
                        continue
                    name = entry["name"]
                    expected, candidate = reference["gradients"][name], serial["gradients"][name]
                    require(expected is None and candidate is not None,
                            f"Discrepancy changed kind: {case['case']}/{name}")
                    nonzero = int(torch.count_nonzero(candidate))
                    report["observations"].append({
                        "case": case["case"], "batch": batch, "length": length,
                        "objective": objective, "gradient": name,
                        "eager_is_none": True, "scripted_serial_is_none": False,
                        "candidate_shape": list(candidate.shape),
                        "candidate_nonzero_elements": nonzero,
                        "candidate_max_absolute": float(candidate.abs().max()),
                        "candidate_sha256": tensor_sha(candidate),
                        "candidate_is_exact_zero_tensor": nonzero == 0,
                    })
    report["mismatches_inspected"] = len(report["observations"])
    report["all_materialized_tensors_are_exact_zero"] = all(
        row["candidate_is_exact_zero_tensor"] for row in report["observations"])
    report["gradient_presence_equivalence"] = False
    report["original_control_verdict_remains"] = "FAIL"
    report["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
    report["wall_seconds"] = time.perf_counter() - started
    output.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({key: report[key] for key in
                     ("mismatches_inspected", "all_materialized_tensors_are_exact_zero",
                      "gradient_presence_equivalence", "wall_seconds")}), flush=True)
    require(report["mismatches_inspected"] == 42, "Expected all 42 recorded discrepancies")


if __name__ == "__main__":
    main()
