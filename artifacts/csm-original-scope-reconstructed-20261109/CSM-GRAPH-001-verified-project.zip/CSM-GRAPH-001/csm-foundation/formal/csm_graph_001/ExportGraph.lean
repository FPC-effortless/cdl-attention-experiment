import Lean
import CSM.Graph

/-! JSON export of the graph definitions checked in `CSM.Graph`.
Run from this directory with `lean --run ExportGraph.lean` after compiling the
imported module (or use `lake env lean --run ExportGraph.lean` in the project).
-/

open Lean CSM.Graph

private def nodeJson (variant : Variant) (node : Node) : Json :=
  Json.mkObj [
    ("name", toJson node.name),
    ("rank", toJson (rank node)),
    ("dependencies", toJson ((dependencies variant node).map Node.name))
  ]

private def variantJson (variant : Variant) : Json :=
  Json.mkObj [
    ("variant", toJson variant.name),
    ("nodes", Json.arr ((allNodes.map (nodeJson variant)).toArray))
  ]

private def recurrenceJson (pair : Node × Node) : Json :=
  Json.mkObj [
    ("source", toJson pair.1.name),
    ("target", toJson pair.2.name),
    ("time_delta", toJson (1 : Nat))
  ]

def main : IO Unit := do
  let document := Json.mkObj [
    ("schema_version", toJson (1 : Nat)),
    ("model", toJson "CSM-001"),
    ("scope", toJson "Hard-forward tensor-operation dependencies; supplied tokens; no reset/corruption hooks or token sampler"),
    ("default_variant", toJson "rewrite"),
    ("time_rank_stride", toJson stride),
    ("node_count_per_variant", toJson allNodes.length),
    ("independent_controller_heads", toJson (controlHeads.map Node.name)),
    ("variants", Json.arr ((variants.map variantJson).toArray)),
    ("recurrence_edges", Json.arr ((recurrencePairs.map recurrenceJson).toArray)),
    ("proof_scope", toJson [
      "Every forward edge strictly increases rank",
      "Forward and temporally unrolled computation graphs are acyclic",
      "Equal-rank nodes have no directed path between them",
      "Reversed dependency graphs are acyclic; no derivative-correctness claim"
    ])
  ]
  IO.println document.pretty
