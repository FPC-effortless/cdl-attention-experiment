import random
import torch
from torch.nn import functional as F

def auxiliaries(out,support,combined=False):
 """Same support indices, two explicitly different policy surrogates.

 Conditional routing targets are stop-gradient model-generated writer codes.
 Agreement loss additionally credits writers; it is not runtime soft retrieval.
 """
 b=len(support);row=torch.arange(b);terms=[];agreement=[]
 wr=out.decisions[0,'write_relation'][:,:16];wa=out.decisions[0,'write_address'][:,:16]
 prw=out.policies[0,'write_relation'][:,:16].softmax(-1);paw=out.policies[0,'write_address'][:,:16].softmax(-1)
 for hop,name in enumerate(['first','second']):
  gold=support[:,hop];r=wr[row,gold];a=wa[row,gold]
  same=(wr==r[:,None])&(wa==a[:,None]);rank=(same&(torch.arange(16)[None]>gold[:,None])).sum(-1);pages=(same.sum(-1)+1)//2;page=rank//2;slot=rank%2
  route=out.policies[0,'routes'][:,-1,hop];query=out.policies[0,'query_'+name][:,-1]
  terms.extend([F.cross_entropy(route,r),F.cross_entropy(query,a),F.cross_entropy(out.policies[0,'rank_'+name][:,-1],slot)])
  bits=(page[:,None]>>torch.arange(3))&1;mask=pages[:,None]>(2**torch.arange(3))[None];z=out.policies[0,'page_'+name][:,-1];ce=F.cross_entropy(z.flatten(0,1),bits.flatten(),reduction='none').reshape(b,3)
  terms.append((ce*mask).sum()/mask.sum().clamp_min(1))
  if combined:
   score=(prw*route.softmax(-1)[:,None]).sum(-1)*(paw*query.softmax(-1)[:,None]).sum(-1)
   agreement.append(F.nll_loss((score/score.sum(-1,keepdim=True)).clamp_min(1e-12).log(),gold))
 conditional=torch.stack(terms).mean();agree=torch.stack(agreement).mean() if agreement else conditional.new_zeros(())
 return (.5*(conditional+agree) if combined else conditional),conditional,agree

def update(m,opt,batch,arm,seed):
 m.train();opt.zero_grad(set_to_none=True);out=m(batch['records'],batch['query'],sample=True);per=F.cross_entropy(out.logits[:,-1],batch['answer'],reduction='none');aux=cond=agree=per.new_zeros(())
 if arm!='lrc_answer':
  support=batch['support']
  if arm=='lrc_shuffled':
   perm=list(range(len(support)));random.Random(seed^81291).shuffle(perm);support=support[torch.tensor(perm)]
  aux,cond,agree=auxiliaries(out,support,combined=arm in ['lrc_agreement','lrc_shuffled'])
 rng=random.Random(seed);eligible=[]
 for key,z in out.policies.items():
  name=key[1]
  if name=='continuation' or z.shape[-1]<2:continue
  if name.startswith('write_'):coords=[(r,t) for r in range(len(per)) for t in range(16)]
  elif name=='routes':coords=[(r,16,h) for r in range(len(per)) for h in range(3)]
  elif name.startswith('page_'):coords=[(r,16,k) for r in range(len(per)) for k in range(3) if out.active_page_bits[key][r,16,k]]
  else:coords=[(r,16) for r in range(len(per))]
  if coords:eligible.append((key,coords))
 key,coords=rng.choice(eligible);coord=rng.choice(coords);z=out.policies[key][coord];chosen=int(out.decisions[key][coord]);alt=rng.randrange(z.numel()-1);alt+=alt>=chosen;changed=out.decisions[key].clone();changed[coord]=alt
 with torch.no_grad():other=m(batch['records'],batch['query'],sample=True,noise=out.noise,overrides={key:changed});alternative=F.cross_entropy(other.logits[:,-1],batch['answer'],reduction='none')[coord[0]]
 base=per[coord[0]].detach()
 if key[1].startswith('page_'):policy=((alternative-base) if chosen==0 else (base-alternative))*z.softmax(-1)[1]
 else:lp=z.log_softmax(-1);policy=(base-alternative).clamp(-1,1)*(lp[chosen]-lp[alt])
 total=per.mean()+aux+policy;total.backward();norm=torch.nn.utils.clip_grad_norm_(m.parameters(),1.);assert torch.isfinite(norm);opt.step()
 return dict(answer=float(per.mean().detach()),auxiliary=float(aux.detach()),conditional=float(cond.detach()),agreement=float(agree.detach()),policy=float(policy.detach()),gradient_norm=float(norm),field=str(key),coordinate=coord,forwards=2)
