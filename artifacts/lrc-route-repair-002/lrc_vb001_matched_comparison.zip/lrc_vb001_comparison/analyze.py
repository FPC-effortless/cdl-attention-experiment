"""Post-completion arithmetic only. No models loaded, fits, or new predictions."""
import hashlib,json,math,statistics
from collections import defaultdict
from pathlib import Path
P=Path(__file__).resolve().parent;O=P/'output'
ARMS=['transformer_answer','transformer_support','memnet_answer','memnet_support','query_only','lrc_answer','lrc_support','lrc_agreement','lrc_shuffled']
SEEDS=[301,302,303];SPLITS=['iid','heldout_pairs','fresh_iid','fresh_heldout_pairs']
def main():
 required=['results.json','timings.json','checkpoint_hashes.json','parity.json','manifest.json','timing_panel.json']
 if any(not (O/n).exists() for n in required):raise SystemExit('Complete results/timings/checkpoint closure required; no partial aggregation.')
 load=lambda n:json.loads((O/n).read_text())
 rows=load('results.json');timings=load('timings.json');hashes=load('checkpoint_hashes.json');parity=load('parity.json');panel=load('timing_panel.json')
 expected={(a,s) for a in ARMS for s in SEEDS};indexed={(r['arm'],r['seed']):r for r in rows}
 assert len(rows)==27 and set(indexed)==expected,'Incomplete/duplicate result matrix'
 assert len(parity)==12 and {(x['arm'],x['seed']) for x in parity}=={(a,s) for a in ARMS[5:] for s in SEEDS}
 assert all(math.isfinite(x['error']) and x['error']<=1e-5 for x in parity)
 assert len(panel)==32 and len(set(panel))==32
 assert set(hashes)=={f'{a}_{s}.pt' for a,s in expected}
 for name,h in hashes.items():assert hashlib.sha256((O/name).read_bytes()).hexdigest()==h,name
 receipts={};groups=defaultdict(list)
 for a,s in expected:
  receipt=load(f'{a}_{s}.json');assert receipt['arm']==a and receipt['seed']==s and receipt['steps']==2000
  assert math.isfinite(receipt['train_seconds']) and receipt['train_seconds']>0;receipts[a,s]=receipt
 for s in SEEDS:assert len({receipts[a,s]['batch_order_sha256'] for a in ARMS})==1
 for t in timings:groups[t['arm'],t['seed']].append(t)
 assert len(timings)==810 and set(groups)==expected
 cost=[]
 for a,s in sorted(expected):
  block=groups[a,s];assert len(block)==30 and {t['repeat'] for t in block}==set(range(30))
  assert all(math.isfinite(t['seconds_per_call']) and t['seconds_per_call']>0 for t in block)
  latency=statistics.median(t['seconds_per_call'] for t in block)
  ref=statistics.median(t['seconds_per_call'] for t in groups['memnet_support',s]);train=receipts[a,s]['train_seconds'];rt=receipts['memnet_support',s]['train_seconds']
  cost.append(dict(arm=a,seed=s,median_seconds_per_call=latency,train_seconds=train,inference_ratio=latency/ref,training_ratio=train/rt,J=12*math.log(latency/ref)+math.log(train/rt)))
 gates={};violations={}
 for a in ARMS:
  fails=[]
  for s in SEEDS:
   r=indexed[a,s]
   for split in SPLITS:
    x=r[split];assert x['n']==1024
    for metric in ['accuracy','quartet_accuracy','old_accuracy','latest_accuracy']:
     assert math.isfinite(x[metric]) and 0<=x[metric]<=1
    assert math.isfinite(x['nll'])
    if x['accuracy']<.95:fails.append(f'{s}/{split}/accuracy')
    if x['quartet_accuracy']<.90:fails.append(f'{s}/{split}/quartet_accuracy')
    assert r[split+'_memory_off']['accuracy']==.25
    if a=='query_only':assert x['accuracy']==.25 and x['quartet_accuracy']==0
  gates[a]=not fails;violations[a]=fails
 gain=statistics.mean(indexed['lrc_agreement',s]['fresh_heldout_pairs']['accuracy']-indexed['lrc_shuffled',s]['fresh_heldout_pairs']['accuracy'] for s in SEEDS)
 macro=[]
 for a in ARMS:
  c=[r for r in cost if r['arm']==a]
  macro.append(dict(arm=a,competence_gate=gates[a],mean_train_seconds=statistics.mean(r['train_seconds'] for r in c),mean_seed_median_seconds_per_call=statistics.mean(r['median_seconds_per_call'] for r in c),mean_J=statistics.mean(r['J'] for r in c),splits={split:{metric:statistics.mean(indexed[a,s][split][metric] for s in SEEDS) for metric in ['accuracy','nll','quartet_accuracy','old_accuracy','latest_accuracy']+([] if a=='query_only' else ['hop1','hop2','both_supports'])} for split in SPLITS}))
 summary=dict(results=rows,per_seed_cost=cost,arm_means=macro,competence_gate=gates,gate_failures=violations,combined_label_gain_fresh_heldout=gain,combined_label_gate=gain>=.10,combined_joint_gate=gates['lrc_agreement'] and gain>=.10,checkpoint_hashes_verified=len(hashes),parity_checks=len(parity),timing_panel=panel)
 lines=['# LRC sentence-adapter versus VB-001','', 'This administrative aggregation script was prepared around launch and may not be included in the prefit source manifest. It implements the existing prospective PROTOCOL thresholds without changing criteria. No frozen scientific file is modified.', '', 'Arithmetic report from completed27fit/810timing-block records; no new scoring or fitting. All27 checkpoint hashes verified. Every arm/seed retained. Original evaluation sets were previously exposed; fresh evaluation is the separately locked same-task replication, not a new domain.','',f"Combined LRC label benefit versus shuffled on mean fresh withheld accuracy: {100*gain:+.2f}pp; >=10pp gate: {gain>=.10}; combined competence+label gate: {summary['combined_joint_gate']}.",'','## Every seed and split','', '| Arm | Seed | Split | Acc% | Quartet% | NLL | Old% | Latest% | Hop1% | Hop2% | Both% |','|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|']
 for a in ARMS:
  for s in SEEDS:
   for split in SPLITS:
    x=indexed[a,s][split];support=[f"{100*x[k]:.2f}" if k in x else 'N/A' for k in ['hop1','hop2','both_supports']]
    lines.append(f"| {a} | {s} | {split} | {100*x['accuracy']:.2f} | {100*x['quartet_accuracy']:.2f} | {x['nll']:.4f} | {100*x['old_accuracy']:.2f} | {100*x['latest_accuracy']:.2f} | {' | '.join(support)} |")
 lines+=['','## Cost: per-seed medians','', '| Arm | Seed | Fit seconds | Median call ms | J vs same-seed supervised MemNet |','|---|---:|---:|---:|---:|']
 for x in cost:lines.append(f"| {x['arm']} | {x['seed']} | {x['train_seconds']:.3f} | {1000*x['median_seconds_per_call']:.4f} | {x['J']:.4f} |")
 lines+=['','## Arm means and competence gate','', '| Arm | Mean fit seconds | Mean seed-median call ms | Mean J | All-seed/all4split gate |','|---|---:|---:|---:|---|']
 for x in macro:lines.append(f"| {x['arm']} | {x['mean_train_seconds']:.3f} | {1000*x['mean_seed_median_seconds_per_call']:.4f} | {x['mean_J']:.4f} | {x['competence_gate']} |")
 lines+=['','Gate: accuracy>=95% AND quartet>=90% in everyseed on each of4splits. Failure details and all memoryoff/hardattention diagnostics remain in summary.json; no failing model is promoted on cost. Zero-record accuracy is25% throughout; queryonly quartet accuracy0%.','', '## Limits','', 'Same two support-occurrence labels, but different objectives: conventional attentionNLL versus LRC conditional hard-policy surrogate; combined LRC additionally uses dense training-only occurrence agreement. Agreement is not the runtime hardlookup probability. No extra semantic/write labels; no goldoperand injected in forward. Parameter counts approximate, allocated unusedcontinuation parameters included, and positional inductive biases differ. LRC has two trainingforwards perupdate versusone inbaselines; equalupdates are not equalcompute.','', 'Timing is complete batch1 fixed16record classification, including sentenceencoding/index construction, on the same32TRAIN-fixture panel. Each reported seedmedian summarizes30blockmean calllatencies after32warmups. It is not a populationaverage, autoregressive throughput, independent32dataset replications, physicalDRAM bandwidth, or deployment-memory benchmark. J=12ln(I/I_ref)+ln(T/T_ref), with same-seed supervisedMemNet reference; dimensionless preference, not requestvolume amortization. Quality gates precede cost selection.','', 'No architecture-superiority claim follows from merely matching100%, passing this arbitrary competence screen, or three seeds. No significance/noninferiority/equivalence claim. Strong supervised baselines, not only weakquerycontrol, are the relevant comparison. This is a supplied-boundary, knownvocabulary, structured-template sentence adaptation, not unchangedbyteLRC, natural-language modeling, open-domain identityresolution or proof of generalmultihop reasoning. Counterfactualquartets and supportviews are dependent; fresh taskinstances are not unseen semanticclasses. Conventional hardattention is descriptive intervention, not an indexedexecution kernel.']
 (O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(O/'REPORT.md').write_text('\n'.join(lines)+'\n');print('Wrote summary.json and REPORT.md; all matrices complete.')
if __name__=='__main__':main()
