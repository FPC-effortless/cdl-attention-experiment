# Decision: do not promote the current LRC training recipes

The supervised conventional memory network solved every original and fresh test in every seed. The LRC sentence adapter did not. Correct support labels plus writer agreement helped relative to shuffled labels, but fell far short of reliable two-hop execution.

Fresh withheld-pair answer accuracy, seeds 301 / 302 / 303:

| Training/model | Accuracy |
|---|---|
| Memory network, support supervision | **100 / 100 / 100%** |
| Transformer, support supervision | 79.88 / 52.73 / 72.56% |
| LRC, answers only | 25.00 / 25.00 / 25.20% |
| LRC, conditional support supervision | 30.37 / 33.01 / 32.03% |
| LRC, support plus writer agreement | 48.14 / 41.41 / 41.41% |
| LRC, shuffled combined labels | 28.91 / 30.08 / 26.66% |

The agreement arm gains 15.10 percentage points over shuffled labels on average, but selects **both** intended supports on only 12.89%, 5.47% and 7.03% of fresh withheld cases. Answer accuracy alone therefore does not establish reliable execution of the intended dependent two-hop path.

At this fixed 16-record workload, the agreement arm takes 1.2108 ms per complete call and 35.70 seconds per fit, versus 0.2953 ms and 8.30 seconds for the supervised memory network. Its mean normalized 12:1 cost score is +18.39 relative to that baseline, while also failing quality requirements. Sparse logical reads did not produce a runtime advantage in this Python/PyTorch implementation. These measurements do not establish an asymptotic advantage or disadvantage at much larger memory sizes.

This is a direct comparison on the exact frozen VB-001 task, with the same training examples, minibatch order, two support labels, updates and approximately matched parameter totals. It is **not** identical optimization: LRC uses a hard-policy surrogate and two forwards per update, while the conventional baselines use differentiable attention and one. The results reject these particular LRC adapters/training recipes under the stated budget, not every possible hard-index learning algorithm.

Original baseline source/data/minibatch hashes match; some answer-only rerun scores differ from the published values. This is a new execution under PyTorch 2.10 rather than the published 2.15 environment, not a claim of bit-identical baseline checkpoint replication. Support-supervised memory-network success reproduced throughout.

No additional fitting, threshold tuning, pushes, merges or deployment followed evaluation. Full arithmetic tables follow.

---

# LRC sentence-adapter versus VB-001

This administrative aggregation script was prepared around launch and may not be included in the prefit source manifest. It implements the existing prospective PROTOCOL thresholds without changing criteria. No frozen scientific file is modified.

Arithmetic report from completed27fit/810timing-block records; no new scoring or fitting. All27 checkpoint hashes verified. Every arm/seed retained. Original evaluation sets were previously exposed; fresh evaluation is the separately locked same-task replication, not a new domain.

Combined LRC label benefit versus shuffled on mean fresh withheld accuracy: +15.10pp; >=10pp gate: True; combined competence+label gate: False.

## Every seed and split

| Arm | Seed | Split | Acc% | Quartet% | NLL | Old% | Latest% | Hop1% | Hop2% | Both% |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|
| transformer_answer | 301 | iid | 97.27 | 93.36 | 0.1002 | 97.32 | 97.20 | 89.45 | 96.39 | 88.57 |
| transformer_answer | 301 | heldout_pairs | 28.91 | 2.34 | 3.4376 | 31.30 | 26.55 | 45.70 | 3.52 | 3.52 |
| transformer_answer | 301 | fresh_iid | 95.31 | 91.80 | 0.1722 | 92.05 | 98.62 | 86.33 | 93.55 | 84.96 |
| transformer_answer | 301 | fresh_heldout_pairs | 27.93 | 1.56 | 3.6061 | 26.95 | 28.91 | 51.17 | 2.73 | 2.73 |
| transformer_answer | 302 | iid | 100.00 | 100.00 | 0.0003 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| transformer_answer | 302 | heldout_pairs | 50.59 | 28.52 | 3.6412 | 47.64 | 53.49 | 84.38 | 33.50 | 32.81 |
| transformer_answer | 302 | fresh_iid | 100.00 | 100.00 | 0.0004 | 100.00 | 100.00 | 98.83 | 100.00 | 98.83 |
| transformer_answer | 302 | fresh_heldout_pairs | 50.00 | 28.52 | 3.7833 | 50.59 | 49.41 | 86.33 | 32.62 | 32.62 |
| transformer_answer | 303 | iid | 100.00 | 100.00 | 0.0004 | 100.00 | 100.00 | 99.22 | 99.80 | 99.02 |
| transformer_answer | 303 | heldout_pairs | 57.71 | 35.55 | 3.0074 | 57.68 | 57.75 | 82.81 | 42.29 | 41.60 |
| transformer_answer | 303 | fresh_iid | 100.00 | 100.00 | 0.0004 | 100.00 | 100.00 | 99.22 | 99.80 | 99.02 |
| transformer_answer | 303 | fresh_heldout_pairs | 53.61 | 32.42 | 3.2425 | 51.37 | 55.86 | 87.50 | 36.91 | 36.82 |
| transformer_support | 301 | iid | 100.00 | 100.00 | 0.0001 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| transformer_support | 301 | heldout_pairs | 84.08 | 76.17 | 1.4295 | 87.20 | 81.01 | 100.00 | 78.22 | 78.22 |
| transformer_support | 301 | fresh_iid | 100.00 | 100.00 | 0.0001 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| transformer_support | 301 | fresh_heldout_pairs | 79.88 | 69.92 | 1.8132 | 79.10 | 80.66 | 100.00 | 73.14 | 73.14 |
| transformer_support | 302 | iid | 100.00 | 100.00 | 0.0001 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| transformer_support | 302 | heldout_pairs | 56.35 | 36.72 | 3.9063 | 47.64 | 64.92 | 99.22 | 43.46 | 43.07 |
| transformer_support | 302 | fresh_iid | 100.00 | 100.00 | 0.0001 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| transformer_support | 302 | fresh_heldout_pairs | 52.73 | 32.81 | 4.3734 | 40.04 | 65.43 | 99.61 | 37.30 | 37.30 |
| transformer_support | 303 | iid | 100.00 | 100.00 | 0.0001 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| transformer_support | 303 | heldout_pairs | 71.97 | 60.55 | 2.4979 | 59.65 | 84.11 | 100.00 | 62.79 | 62.79 |
| transformer_support | 303 | fresh_iid | 100.00 | 100.00 | 0.0001 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| transformer_support | 303 | fresh_heldout_pairs | 72.56 | 57.42 | 2.3737 | 61.72 | 83.40 | 100.00 | 62.99 | 62.99 |
| memnet_answer | 301 | iid | 52.73 | 17.97 | 0.9693 | 51.43 | 54.31 | 0.00 | 29.59 | 0.00 |
| memnet_answer | 301 | heldout_pairs | 27.34 | 0.00 | 2.0733 | 27.17 | 27.52 | 0.00 | 2.25 | 0.00 |
| memnet_answer | 301 | fresh_iid | 55.86 | 17.19 | 0.9238 | 54.26 | 57.48 | 0.00 | 31.25 | 0.00 |
| memnet_answer | 301 | fresh_heldout_pairs | 27.64 | 0.00 | 2.0745 | 27.93 | 27.34 | 0.00 | 2.15 | 0.00 |
| memnet_answer | 302 | iid | 54.98 | 19.14 | 0.9536 | 52.50 | 57.97 | 0.00 | 35.84 | 0.00 |
| memnet_answer | 302 | heldout_pairs | 27.73 | 0.00 | 2.0595 | 27.76 | 27.71 | 0.00 | 2.54 | 0.00 |
| memnet_answer | 302 | fresh_iid | 54.69 | 16.41 | 0.9797 | 52.91 | 56.50 | 0.00 | 32.03 | 0.00 |
| memnet_answer | 302 | fresh_heldout_pairs | 26.95 | 0.00 | 2.0664 | 26.95 | 26.95 | 0.00 | 3.03 | 0.00 |
| memnet_answer | 303 | iid | 100.00 | 100.00 | 0.0002 | 100.00 | 100.00 | 99.61 | 100.00 | 99.61 |
| memnet_answer | 303 | heldout_pairs | 43.85 | 19.53 | 4.4050 | 45.47 | 42.25 | 64.45 | 21.78 | 21.48 |
| memnet_answer | 303 | fresh_iid | 100.00 | 100.00 | 0.0006 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| memnet_answer | 303 | fresh_heldout_pairs | 44.24 | 20.70 | 4.2760 | 49.02 | 39.45 | 69.53 | 25.59 | 25.20 |
| memnet_support | 301 | iid | 100.00 | 100.00 | 0.0000 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| memnet_support | 301 | heldout_pairs | 100.00 | 100.00 | 0.0000 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| memnet_support | 301 | fresh_iid | 100.00 | 100.00 | 0.0000 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| memnet_support | 301 | fresh_heldout_pairs | 100.00 | 100.00 | 0.0000 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| memnet_support | 302 | iid | 100.00 | 100.00 | 0.0000 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| memnet_support | 302 | heldout_pairs | 100.00 | 100.00 | 0.0000 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| memnet_support | 302 | fresh_iid | 100.00 | 100.00 | 0.0000 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| memnet_support | 302 | fresh_heldout_pairs | 100.00 | 100.00 | 0.0000 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| memnet_support | 303 | iid | 100.00 | 100.00 | 0.0000 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| memnet_support | 303 | heldout_pairs | 100.00 | 100.00 | 0.0000 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| memnet_support | 303 | fresh_iid | 100.00 | 100.00 | 0.0000 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| memnet_support | 303 | fresh_heldout_pairs | 100.00 | 100.00 | 0.0000 | 100.00 | 100.00 | 100.00 | 100.00 | 100.00 |
| query_only | 301 | iid | 25.00 | 0.00 | 1.3870 | 25.00 | 25.00 | N/A | N/A | N/A |
| query_only | 301 | heldout_pairs | 25.00 | 0.00 | 1.3870 | 25.00 | 25.00 | N/A | N/A | N/A |
| query_only | 301 | fresh_iid | 25.00 | 0.00 | 1.3870 | 25.00 | 25.00 | N/A | N/A | N/A |
| query_only | 301 | fresh_heldout_pairs | 25.00 | 0.00 | 1.3870 | 25.00 | 25.00 | N/A | N/A | N/A |
| query_only | 302 | iid | 25.00 | 0.00 | 1.3865 | 25.00 | 25.00 | N/A | N/A | N/A |
| query_only | 302 | heldout_pairs | 25.00 | 0.00 | 1.3865 | 25.00 | 25.00 | N/A | N/A | N/A |
| query_only | 302 | fresh_iid | 25.00 | 0.00 | 1.3865 | 25.00 | 25.00 | N/A | N/A | N/A |
| query_only | 302 | fresh_heldout_pairs | 25.00 | 0.00 | 1.3865 | 25.00 | 25.00 | N/A | N/A | N/A |
| query_only | 303 | iid | 25.00 | 0.00 | 1.3865 | 25.00 | 25.00 | N/A | N/A | N/A |
| query_only | 303 | heldout_pairs | 25.00 | 0.00 | 1.3865 | 25.00 | 25.00 | N/A | N/A | N/A |
| query_only | 303 | fresh_iid | 25.00 | 0.00 | 1.3866 | 25.00 | 25.00 | N/A | N/A | N/A |
| query_only | 303 | fresh_heldout_pairs | 25.00 | 0.00 | 1.3866 | 25.00 | 25.00 | N/A | N/A | N/A |
| lrc_answer | 301 | iid | 25.00 | 0.00 | 1.3912 | 25.00 | 25.00 | 7.03 | 0.00 | 0.00 |
| lrc_answer | 301 | heldout_pairs | 25.00 | 0.00 | 1.3911 | 25.00 | 25.00 | 8.50 | 0.00 | 0.00 |
| lrc_answer | 301 | fresh_iid | 25.00 | 0.00 | 1.3912 | 25.00 | 25.00 | 6.25 | 0.00 | 0.00 |
| lrc_answer | 301 | fresh_heldout_pairs | 25.00 | 0.00 | 1.3912 | 25.00 | 25.00 | 10.45 | 0.00 | 0.00 |
| lrc_answer | 302 | iid | 25.00 | 0.00 | 1.3867 | 25.00 | 25.00 | 0.00 | 0.00 | 0.00 |
| lrc_answer | 302 | heldout_pairs | 25.00 | 0.00 | 1.3867 | 25.00 | 25.00 | 0.00 | 0.00 | 0.00 |
| lrc_answer | 302 | fresh_iid | 25.00 | 0.00 | 1.3867 | 25.00 | 25.00 | 0.00 | 0.00 | 0.00 |
| lrc_answer | 302 | fresh_heldout_pairs | 25.00 | 0.00 | 1.3867 | 25.00 | 25.00 | 0.00 | 0.00 | 0.00 |
| lrc_answer | 303 | iid | 25.29 | 0.00 | 1.3822 | 25.36 | 25.22 | 0.00 | 3.81 | 0.00 |
| lrc_answer | 303 | heldout_pairs | 25.39 | 0.00 | 1.3851 | 25.39 | 25.39 | 0.00 | 4.20 | 0.00 |
| lrc_answer | 303 | fresh_iid | 25.49 | 0.00 | 1.3817 | 25.97 | 25.00 | 0.00 | 4.88 | 0.00 |
| lrc_answer | 303 | fresh_heldout_pairs | 25.20 | 0.00 | 1.3802 | 25.20 | 25.20 | 0.00 | 4.49 | 0.00 |
| lrc_support | 301 | iid | 29.49 | 0.00 | 1.3780 | 26.61 | 32.97 | 11.23 | 7.23 | 1.07 |
| lrc_support | 301 | heldout_pairs | 30.86 | 0.00 | 1.3735 | 26.97 | 34.69 | 12.79 | 8.40 | 1.56 |
| lrc_support | 301 | fresh_iid | 31.35 | 0.39 | 1.3637 | 28.68 | 34.06 | 9.86 | 10.55 | 0.98 |
| lrc_support | 301 | fresh_heldout_pairs | 30.37 | 0.39 | 1.3703 | 26.56 | 34.18 | 13.09 | 10.94 | 1.17 |
| lrc_support | 302 | iid | 33.50 | 1.95 | 1.3631 | 31.79 | 35.56 | 17.58 | 7.13 | 0.98 |
| lrc_support | 302 | heldout_pairs | 32.32 | 2.73 | 1.3710 | 30.91 | 33.72 | 9.86 | 6.05 | 0.00 |
| lrc_support | 302 | fresh_iid | 30.76 | 0.39 | 1.3757 | 29.84 | 31.69 | 20.90 | 5.18 | 0.88 |
| lrc_support | 302 | fresh_heldout_pairs | 33.01 | 2.73 | 1.3659 | 33.40 | 32.62 | 17.97 | 5.37 | 0.00 |
| lrc_support | 303 | iid | 37.11 | 3.91 | 1.3413 | 37.14 | 37.07 | 13.77 | 12.79 | 1.17 |
| lrc_support | 303 | heldout_pairs | 34.57 | 1.95 | 1.3619 | 35.63 | 33.53 | 17.38 | 8.59 | 1.17 |
| lrc_support | 303 | fresh_iid | 32.91 | 1.95 | 1.3610 | 33.14 | 32.68 | 17.48 | 9.57 | 0.88 |
| lrc_support | 303 | fresh_heldout_pairs | 32.03 | 1.17 | 1.3714 | 33.01 | 31.05 | 16.31 | 7.23 | 1.46 |
| lrc_agreement | 301 | iid | 42.87 | 23.83 | 1.3187 | 42.68 | 43.10 | 58.98 | 23.83 | 15.23 |
| lrc_agreement | 301 | heldout_pairs | 43.16 | 24.22 | 1.3177 | 43.90 | 42.44 | 51.56 | 24.22 | 12.89 |
| lrc_agreement | 301 | fresh_iid | 45.80 | 27.73 | 1.2943 | 44.77 | 46.85 | 62.89 | 27.73 | 17.58 |
| lrc_agreement | 301 | fresh_heldout_pairs | 48.14 | 30.86 | 1.2792 | 47.27 | 49.02 | 48.05 | 30.86 | 12.89 |
| lrc_agreement | 302 | iid | 41.70 | 22.27 | 1.3353 | 41.61 | 41.81 | 21.09 | 22.27 | 5.86 |
| lrc_agreement | 302 | heldout_pairs | 41.99 | 22.66 | 1.3283 | 45.08 | 38.95 | 25.00 | 22.66 | 6.64 |
| lrc_agreement | 302 | fresh_iid | 45.21 | 26.95 | 1.2984 | 44.19 | 46.26 | 23.83 | 26.95 | 7.81 |
| lrc_agreement | 302 | fresh_heldout_pairs | 41.41 | 21.88 | 1.3352 | 42.58 | 40.23 | 20.70 | 21.88 | 5.47 |
| lrc_agreement | 303 | iid | 39.06 | 18.75 | 1.3424 | 39.46 | 38.58 | 37.11 | 18.75 | 7.81 |
| lrc_agreement | 303 | heldout_pairs | 45.51 | 27.34 | 1.2916 | 48.03 | 43.02 | 35.55 | 27.34 | 7.81 |
| lrc_agreement | 303 | fresh_iid | 40.82 | 21.09 | 1.3251 | 43.02 | 38.58 | 33.20 | 21.09 | 6.64 |
| lrc_agreement | 303 | fresh_heldout_pairs | 41.41 | 21.88 | 1.3259 | 46.68 | 36.13 | 35.16 | 21.88 | 7.03 |
| lrc_shuffled | 301 | iid | 28.22 | 0.00 | 1.3860 | 28.57 | 27.80 | 4.69 | 6.25 | 0.00 |
| lrc_shuffled | 301 | heldout_pairs | 28.32 | 0.00 | 1.3864 | 29.53 | 27.13 | 3.91 | 6.64 | 0.00 |
| lrc_shuffled | 301 | fresh_iid | 27.64 | 0.00 | 1.3897 | 27.91 | 27.36 | 4.69 | 4.69 | 0.00 |
| lrc_shuffled | 301 | fresh_heldout_pairs | 28.91 | 0.00 | 1.3864 | 29.49 | 28.32 | 4.30 | 6.25 | 0.00 |
| lrc_shuffled | 302 | iid | 30.47 | 6.64 | 1.3780 | 26.61 | 35.13 | 5.86 | 5.96 | 0.00 |
| lrc_shuffled | 302 | heldout_pairs | 29.88 | 6.25 | 1.3789 | 25.39 | 34.30 | 4.69 | 6.25 | 0.00 |
| lrc_shuffled | 302 | fresh_iid | 29.10 | 5.47 | 1.3841 | 26.16 | 32.09 | 5.47 | 4.69 | 0.00 |
| lrc_shuffled | 302 | fresh_heldout_pairs | 30.08 | 6.25 | 1.3779 | 26.37 | 33.79 | 6.25 | 5.86 | 0.00 |
| lrc_shuffled | 303 | iid | 26.76 | 0.00 | 1.3945 | 25.00 | 28.88 | 5.86 | 5.08 | 0.00 |
| lrc_shuffled | 303 | heldout_pairs | 26.56 | 0.00 | 1.3936 | 25.00 | 28.10 | 6.25 | 4.39 | 0.00 |
| lrc_shuffled | 303 | fresh_iid | 26.27 | 0.00 | 1.3954 | 25.00 | 27.56 | 5.37 | 3.81 | 0.00 |
| lrc_shuffled | 303 | fresh_heldout_pairs | 26.66 | 0.00 | 1.3918 | 25.00 | 28.32 | 6.15 | 4.69 | 0.00 |

## Cost: per-seed medians

| Arm | Seed | Fit seconds | Median call ms | J vs same-seed supervised MemNet |
|---|---:|---:|---:|---:|
| lrc_agreement | 301 | 34.826 | 1.2117 | 18.1726 |
| lrc_agreement | 302 | 36.898 | 1.2424 | 18.7102 |
| lrc_agreement | 303 | 35.382 | 1.1782 | 18.2805 |
| lrc_answer | 301 | 29.922 | 1.1853 | 17.7557 |
| lrc_answer | 302 | 29.068 | 1.1712 | 17.7636 |
| lrc_answer | 303 | 30.245 | 1.1987 | 18.3299 |
| lrc_shuffled | 301 | 36.652 | 1.1823 | 17.9286 |
| lrc_shuffled | 302 | 36.439 | 1.2080 | 18.3613 |
| lrc_shuffled | 303 | 36.937 | 1.1894 | 18.4364 |
| lrc_support | 301 | 34.900 | 1.2153 | 18.2099 |
| lrc_support | 302 | 34.863 | 1.1744 | 17.9788 |
| lrc_support | 303 | 33.519 | 1.2340 | 18.7815 |
| memnet_answer | 301 | 7.995 | 0.2995 | -0.0729 |
| memnet_answer | 302 | 8.173 | 0.2933 | -0.1191 |
| memnet_answer | 303 | 8.145 | 0.2941 | 0.1574 |
| memnet_support | 301 | 8.261 | 0.3005 | 0.0000 |
| memnet_support | 302 | 8.231 | 0.2961 | 0.0000 |
| memnet_support | 303 | 8.422 | 0.2895 | 0.0000 |
| query_only | 301 | 2.009 | 0.0773 | -17.7102 |
| query_only | 302 | 2.019 | 0.0725 | -18.2897 |
| query_only | 303 | 2.123 | 0.0739 | -17.7584 |
| transformer_answer | 301 | 9.963 | 0.5163 | 6.6839 |
| transformer_answer | 302 | 10.746 | 0.4933 | 6.3935 |
| transformer_answer | 303 | 10.971 | 0.4892 | 6.5614 |
| transformer_support | 301 | 10.503 | 0.5075 | 6.5313 |
| transformer_support | 302 | 10.838 | 0.4903 | 6.3281 |
| transformer_support | 303 | 10.880 | 0.4928 | 6.6420 |

## Arm means and competence gate

| Arm | Mean fit seconds | Mean seed-median call ms | Mean J | All-seed/all4split gate |
|---|---:|---:|---:|---|
| transformer_answer | 10.560 | 0.4996 | 6.5463 | False |
| transformer_support | 10.740 | 0.4969 | 6.5005 | False |
| memnet_answer | 8.104 | 0.2956 | -0.0115 | False |
| memnet_support | 8.304 | 0.2953 | 0.0000 | True |
| query_only | 2.050 | 0.0746 | -17.9194 | False |
| lrc_answer | 29.745 | 1.1850 | 17.9497 | False |
| lrc_support | 34.427 | 1.2079 | 18.3234 | False |
| lrc_agreement | 35.702 | 1.2108 | 18.3878 | False |
| lrc_shuffled | 36.676 | 1.1932 | 18.2421 | False |

Gate: accuracy>=95% AND quartet>=90% in everyseed on each of4splits. Failure details and all memoryoff/hardattention diagnostics remain in summary.json; no failing model is promoted on cost. Zero-record accuracy is25% throughout; queryonly quartet accuracy0%.

## Limits

Same two support-occurrence labels, but different objectives: conventional attentionNLL versus LRC conditional hard-policy surrogate; combined LRC additionally uses dense training-only occurrence agreement. Agreement is not the runtime hardlookup probability. No extra semantic/write labels; no goldoperand injected in forward. Parameter counts approximate, allocated unusedcontinuation parameters included, and positional inductive biases differ. LRC has two trainingforwards perupdate versusone inbaselines; equalupdates are not equalcompute.

Timing is complete batch1 fixed16record classification, including sentenceencoding/index construction, on the same32TRAIN-fixture panel. Each reported seedmedian summarizes30blockmean calllatencies after32warmups. It is not a populationaverage, autoregressive throughput, independent32dataset replications, physicalDRAM bandwidth, or deployment-memory benchmark. J=12ln(I/I_ref)+ln(T/T_ref), with same-seed supervisedMemNet reference; dimensionless preference, not requestvolume amortization. Quality gates precede cost selection.

No architecture-superiority claim follows from merely matching100%, passing this arbitrary competence screen, or three seeds. No significance/noninferiority/equivalence claim. Strong supervised baselines, not only weakquerycontrol, are the relevant comparison. This is a supplied-boundary, knownvocabulary, structured-template sentence adaptation, not unchangedbyteLRC, natural-language modeling, open-domain identityresolution or proof of generalmultihop reasoning. Counterfactualquartets and supportviews are dependent; fresh taskinstances are not unseen semanticclasses. Conventional hardattention is descriptive intervention, not an indexedexecution kernel.
