import json,time,hashlib,random,statistics,platform
from pathlib import Path
from dataclasses import asdict
import torch
from torch.nn import functional as F
from .source import study as vb
from .model import SentenceLRC
from .train import update
P=Path(__file__).parent;OUT=P/'output';LRC=['lrc_answer','lrc_support','lrc_agreement','lrc_shuffled'];ARMS=list(vb.ARMS)+LRC;C=vb.Config()
def build(a):return SentenceLRC() if a in LRC else vb.build(a,C)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def freeze():
 assert not OUT.exists(),'Refusing existing output';OUT.mkdir();files=[f for f in P.rglob('*') if f.is_file() and '__pycache__' not in str(f) and f.suffix in ['.py','.md','.json'] and 'output' not in f.parts];(OUT/'prefit_manifest.json').write_text(json.dumps({str(f.relative_to(P)):sha(f) for f in files},indent=2));train=vb.dataset(C.train_seed,C.train_groups);assert vb.digest_data(train)==json.loads((P/'source/manifest.json').read_text())['train_sha256'];torch.save(train,OUT/'train.pt');(OUT/'manifest.json').write_text(json.dumps(dict(config=asdict(C),arms=ARMS,parameters={a:sum(p.numel() for p in build(a).parameters()) for a in ARMS},torch=torch.__version__,python=platform.python_version(),train_hash=vb.digest_data(train)),indent=2));return train

def fit(a,s,train):
 if a not in LRC:return vb.fit(OUT,C,a,s,train)
 torch.manual_seed(s);m=build(a);opt=torch.optim.AdamW(m.parameters(),lr=C.lr,weight_decay=0.);order=torch.Generator().manual_seed(100000+s);oh=hashlib.sha256();logs=[];start=time.perf_counter()
 for step in range(1,C.steps+1):
  idx=torch.randint(len(train['answer']),(C.batch,),generator=order);oh.update(idx.numpy().tobytes());r=update(m,opt,vb.take(train,idx),a,2300000+s*10000+step)
  if step==1 or step%100==0:logs.append(dict(step=step,**r))
 receipt=dict(arm=a,seed=s,steps=C.steps,train_seconds=time.perf_counter()-start,batch_order_sha256=oh.hexdigest(),trace=logs,forwards=2*C.steps,examples=C.steps*C.batch)
 torch.save(dict(model=m.state_dict(),optimizer=opt.state_dict(),torch_rng=torch.get_rng_state(),order_rng=order.get_state(),receipt=receipt),OUT/f'{a}_{s}.pt');(OUT/f'{a}_{s}.json').write_text(json.dumps(receipt,indent=2));print('FIT',a,s,receipt['train_seconds'],flush=True)

@torch.inference_mode()
def evaluate(m,d):
 ps=[];losses=[];selected=[];trace=[]
 for start in range(0,len(d['answer']),128):
  b=vb.take(d,slice(start,start+128));o=m(b['records'],b['query']);ps.append(o.logits[:,-1].argmax(-1));losses.append(F.cross_entropy(o.logits[:,-1],b['answer'],reduction='none'));selected.append(o.operands[0][:,-1]);trace.append({str(k):v[:,-1].cpu() if not k[1].startswith('write') else v[:,:16].cpu() for k,v in o.decisions.items()})
 pred=torch.cat(ps);loss=torch.cat(losses);sel=torch.cat(selected);correct=pred==d['answer'];matched=sel==d['support'];r=dict(accuracy=float(correct.float().mean()),nll=float(loss.mean()),n=len(pred),quartet_accuracy=float(correct.reshape(-1,4).all(-1).float().mean()),old_accuracy=float(correct[d['era']==0].float().mean()),latest_accuracy=float(correct[d['era']==1].float().mean()),hop1=float(matched[:,0].float().mean()),hop2=float(matched[:,1].float().mean()),both_supports=float(matched.all(-1).float().mean()))
 return r,dict(pred=pred,loss=loss,selected=sel,trace=trace)

def signatures(d):return {tuple(torch.cat([r.flatten(),q]).tolist()) for r,q in zip(d['records'],d['query'])}
def main():
 # Train requires gradients; this wrapper only handles sequencing.
 torch.set_num_threads(1);torch.use_deterministic_algorithms(True)
 with torch.enable_grad():
  train=freeze()
  for s in C.seeds:
   for a in ARMS:fit(a,s,train)
 # All27 fits close before any test construction or scoring.
 receipts={};hashes={}
 for s in C.seeds:
  orders=set()
  for a in ARMS:
   r=json.loads((OUT/f'{a}_{s}.json').read_text());assert r['steps']==2000;orders.add(r['batch_order_sha256']);receipts[a,s]=r;hashes[f'{a}_{s}.pt']=sha(OUT/f'{a}_{s}.pt')
  assert len(orders)==1
  assert orders=={json.loads((P/f'source/memnet_support_{s}.json').read_text())['batch_order_sha256']}
 (OUT/'checkpoint_hashes.json').write_text(json.dumps(hashes,indent=2))
 for n,h in json.loads((OUT/'prefit_manifest.json').read_text()).items():assert sha(P/n)==h,n
 print('ALL_27_FITS_CLOSED_HASHES_VERIFIED',flush=True)
 # Label isolation and fast/reference parity use a TRAIN sample, not test tuning.
 parities=[]
 for s in C.seeds:
  for a in LRC:
   m=build(a).eval().requires_grad_(False);m.load_state_dict(torch.load(OUT/f'{a}_{s}.pt',weights_only=True)['model']);b=vb.take(train,slice(0,4));fast=m(b['records'],b['query']);ref=m.forward_reference(b['records'],b['query']);err=float((fast.logits[:,-1]-ref.logits[:,-1]).abs().max());assert torch.allclose(fast.logits[:,-1],ref.logits[:,-1],atol=1e-5,rtol=1e-5) and torch.equal(fast.logits[:,-1].argmax(-1),ref.logits[:,-1].argmax(-1));assert torch.equal(fast.operands[0][:,-1],ref.operands[0][:,-1]);parities.append(dict(arm=a,seed=s,error=err))
 (OUT/'parity.json').write_text(json.dumps(parities,indent=2));print('PARITY_CLOSED',flush=True)
 ds=dict(iid=vb.dataset(71002,256),heldout_pairs=vb.dataset(71003,256,True),fresh_iid=vb.dataset(72002,256),fresh_heldout_pairs=vb.dataset(72003,256,True));ss=signatures(train)
 assert all(not ss&signatures(d) for d in ds.values());torch.save(ds,OUT/'evaluation_data.pt');published=json.loads((P/'source/results.json').read_text())['evaluation_sha256'];assert all(vb.digest_data(ds[k])==v for k,v in published.items())
 (OUT/'data_hashes.json').write_text(json.dumps({k:vb.digest_data(v) for k,v in ds.items()},indent=2));results=[];preds={};models={}
 for s in C.seeds:
  for a in ARMS:
   m=build(a).eval().requires_grad_(False);m.load_state_dict(torch.load(OUT/f'{a}_{s}.pt',weights_only=True)['model']);models[a,s]=m;row=dict(arm=a,seed=s)
   for name,d in ds.items():
    if a in LRC:
     row[name],preds[f'{a}/{s}/{name}']=evaluate(m,d);zero=dict(d,records=torch.zeros_like(d['records']));row[name+'_memory_off'],_=evaluate(m,zero)
    else:
     row[name],preds[f'{a}/{s}/{name}']=vb.evaluate(m,d);row[name+'_memory_off'],_=vb.evaluate(m,d,ablation='zero');row[name+'_hard'],_=vb.evaluate(m,d,hard=True)
    assert row[name+'_memory_off']['accuracy']==.25
   results.append(row);print('RESULT',a,s,row['heldout_pairs']['accuracy'],row['fresh_heldout_pairs']['accuracy'],flush=True)
 (OUT/'results.json').write_text(json.dumps(results,indent=2));torch.save(preds,OUT/'predictions.pt')
 # Same complete batch1 task, including sentence encoding and indexing for LRC.
 panel_indices=random.Random(8192).sample(range(len(train['answer'])),32);panel=[vb.take(train,slice(i,i+1)) for i in panel_indices];(OUT/'timing_panel.json').write_text(json.dumps(panel_indices));jobs=list(models);rng=random.Random(8191);timings=[]
 for a,s in jobs:
  for sample in panel:models[a,s](sample['records'],sample['query'])
 for rep in range(30):
  rng.shuffle(jobs)
  for a,s in jobs:
   start=time.perf_counter()
   for sample in panel:models[a,s](sample['records'],sample['query'])
   timings.append(dict(arm=a,seed=s,repeat=rep,seconds_per_call=(time.perf_counter()-start)/32))
 (OUT/'timings.json').write_text(json.dumps(timings,indent=2));print('COMPLETE',flush=True)
if __name__=='__main__':main()
