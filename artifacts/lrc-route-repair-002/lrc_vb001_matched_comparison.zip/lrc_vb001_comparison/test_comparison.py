import unittest,torch,copy,random,hashlib
from pathlib import Path
from .source import study as vb
from .model import SentenceLRC
from .train import auxiliaries,update
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):torch.set_num_threads(1)
 def batch(self):return vb.dataset(91234,2)
 def test_source(self):self.assertEqual(hashlib.sha256(Path(vb.__file__).read_bytes()).hexdigest(),'3abbbe86ceeefb6ff0a0b7cdd734cf23da4b5e3ad73be2ab94b6dd7a58e82be4')
 def test_parity(self):
  for seed in [1,2,3]:
   torch.manual_seed(seed);m=SentenceLRC();b=self.batch()
   for sample in [False,True]:
    torch.manual_seed(91);a=m(b['records'],b['query'],sample=sample);torch.manual_seed(91);r=m.forward_reference(b['records'],b['query'],sample=sample)
    torch.testing.assert_close(a.logits[:,-1],r.logits[:,-1],atol=1e-6,rtol=1e-6);self.assertTrue(torch.equal(a.operands[0][:,-1],r.operands[0][:,-1]))
    for k in a.policies:torch.testing.assert_close(a.policies[k][:,-1],r.policies[k][:,-1])
 def test_counterfactual_reference(self):
  m=SentenceLRC();b=self.batch();a=m(b['records'],b['query'],sample=True)
  for key in a.decisions:
   if key[1]=='continuation':continue
   changed=a.decisions[key].clone();coord=(0,0) if key[1].startswith('write') else ((0,16,0) if changed.ndim==3 else (0,16));changed[coord]=(changed[coord]+1)%a.policies[key].shape[-1];kw=dict(sample=True,noise=a.noise,overrides={key:changed});x=m(b['records'],b['query'],**kw);y=m.forward_reference(b['records'],b['query'],**kw);torch.testing.assert_close(x.logits[:,-1],y.logits[:,-1],atol=1e-6,rtol=1e-6)
 def test_gradients(self):
  m=SentenceLRC();r=copy.deepcopy(m);b=self.batch();a=m(b['records'],b['query'],sample=True);z=r.forward_reference(b['records'],b['query'],sample=True,noise=a.noise);a.logits[:,-1].square().sum().backward();z.logits[:,-1].square().sum().backward()
  for (k,p),(j,q) in zip(m.named_parameters(),r.named_parameters()):
   self.assertEqual(k,j)
   if p.grad is not None:torch.testing.assert_close(p.grad,q.grad,atol=2e-6,rtol=1e-5)
 def test_aux_writer_credit_and_no_label_inputs(self):
  m=SentenceLRC();b=self.batch();a=m(b['records'],b['query']);loss,_,_=auxiliaries(a,b['support'],True);loss.backward();self.assertGreater(float(m.core.layers[0].write_address.weight.grad.abs().sum()),0);b['support']=b['support'].flip(0);b['answer']=b['answer'].roll(1);z=m(b['records'],b['query']);self.assertTrue(torch.equal(a.logits,z.logits))
 def test_counterfactual_update(self):
  for arm in ['lrc_answer','lrc_support','lrc_agreement','lrc_shuffled']:
   m=SentenceLRC();r=update(m,torch.optim.AdamW(m.parameters(),lr=.002),self.batch(),arm,89);self.assertEqual(r['forwards'],2)
 def test_strictpast_and_capped(self):
  m=SentenceLRC();b=self.batch();a=m(b['records'],b['query']);self.assertTrue((a.operands[0][:,-1]<16).all());self.assertLessEqual(a.metrics['candidates'],len(b['answer'])*4);self.assertEqual(a.metrics['reads'],len(b['answer'])*2)
 def test_memory_off_chance(self):
  m=SentenceLRC();b=self.batch();a=m(torch.zeros_like(b['records']),b['query']);self.assertEqual(float((a.logits[:,-1].argmax(-1)==b['answer']).float().mean()),.25)
 def test_fullcapacity_collision(self):
  from .base.hierarchical_index import PagedCausalIndex
  ix=PagedCausalIndex(2)
  for j in range(16):ix.append(j,0,0)
  for rank in range(16):self.assertEqual(ix.lookup_page(0,0,16,rank//2).candidates[rank%2],15-rank)
if __name__=='__main__':unittest.main()
