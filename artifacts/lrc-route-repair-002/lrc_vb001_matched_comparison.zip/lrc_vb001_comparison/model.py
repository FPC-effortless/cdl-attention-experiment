import torch
from torch import nn
from .source.study import SentenceEncoder,N_RECORDS
from .base.model import Config
from .base.hierarchical_model import PagedMultiHopLM,PagedOutput
from .base.model import dereference
from .base.hierarchical_index import PagedCausalIndex
from torch.nn import functional as F

class SentenceLRC(nn.Module):
 """Sentence-vector input/output adapter; hard V4 program core unchanged.

 One two-hop layer, pointwise local kernel. No semantic parsing or labels.
 """
 def __init__(self,width=29):
  super().__init__();self.encoder=SentenceEncoder(width)
  self.core=PagedMultiHopLM(Config(vocab=4,width=width,layers=1,relations=2,addresses=8,candidates=2,local_kernel=1),page_bits=3)
  self.core.embedding=nn.Identity() # unused token embedding replaced by sentence vectors
 def forward_reference(self,records,query,**kwargs):
  encoded=torch.cat((self.encoder(records),self.encoder(query)[:,None]),1)
  tokens=torch.ones(encoded.shape[:2],dtype=torch.long,device=encoded.device)
  return self.core(tokens,encoded=encoded,**kwargs)

 def forward(self, records, query, *, sample=False, replay=None, overrides=None, noise=None, memory="normal"):
     """Query-only outputs; full-shaped noise/policies retain RNG compatibility.

     Record read-policy entries are placeholders, not supervised predictions.
     Writer policies/decisions stay real at all17positions. Use forward_reference for
     full reference. This path requires one layer and local_kernel1.
     """
     encoded=torch.cat((self.encoder(records),self.encoder(query)[:,None]),1)
     tokens=torch.ones(encoded.shape[:2],dtype=torch.long,device=encoded.device)
     core=self.core
     assert core.config.layers==1 and core.config.local_kernel==1
     if tokens.ndim != 2 or tokens.shape[1] < 1:
         raise ValueError('expected nonempty [batch, time] tokens')
     if (tokens < 0).any() or (tokens >= core.config.vocab).any():
         raise ValueError('out-of-vocabulary token')
     if memory not in ('normal','disabled'):
         raise ValueError('unsupported memory mode')
     valid = tokens != 0
     if ((~valid[:,:-1]) & valid[:,1:]).any():
         raise ValueError('padding must be a suffix')
     batch, n = tokens.shape
     cfg = core.config
     overrides = overrides or {}
     policies, decisions, used_noise = {}, {}, {}
     active_bits = {}
     metrics = dict(writes=0, reads=0, candidates=0, omitted=0,
                    null_reads=0, reference_dereferences=0, operator_executions=0,
                    older_page_reads=0, invalid_page_reads=0,
                    active_page_bit_decisions=0)
     refs_history, operand_history = [], []

     def choose(ell, name, logits):
         key = ell, name
         policies[key] = logits
         if key in overrides:
             action = overrides[key].to(tokens.device)
         elif replay is not None and key in replay:
             action = replay[key].to(tokens.device)
         elif sample:
             g = noise.get(key) if noise is not None else None
             if g is None:
                 u = torch.rand_like(logits).clamp_(1e-7,1-1e-7)
                 g = -(-u.log()).log()
             if g.shape != logits.shape:
                 raise ValueError('Gumbel noise shape mismatch')
             used_noise[key] = g
             action = (logits + g).argmax(-1)
         else:
             action = logits.argmax(-1)
         if (action.shape != logits.shape[:-1] or (action < 0).any()
                 or (action >= logits.shape[-1]).any()):
             raise ValueError(f'invalid action {key}')
         decisions[key] = action.detach().clone()
         return action

     def read_postings(indexes, rel, addr, rank, page_word, *, key):
         result = torch.full((batch,n), -1,device=tokens.device,dtype=torch.long)
         bits_mask = torch.zeros((batch,n,core.page_bits),device=tokens.device,dtype=torch.bool)
         relations, addresses, ranks, words = [v.detach().cpu().tolist()
                                 for v in (rel,addr,rank,page_word)]
         for row in range(batch):
             ix = indexes[row]
             for t in range(n):
                 if t != n-1 or not bool(valid[row,t]):
                     continue
                 pages = ix.page_count(relations[row][t],addresses[row][t],t)
                 width = min(core.page_bits, (pages-1).bit_length()) if pages else 0
                 bits_mask[row,t,:width] = True
                 metrics['active_page_bit_decisions'] += width
                 # Low bits define page; inactive high bits are ignored.
                 code = sum(int(v)<<bit for bit,v in enumerate(words[row][t][:width]))
                 hit = ix.lookup_page(relations[row][t],addresses[row][t],t,code)
                 metrics['reads'] += 1
                 metrics['candidates'] += len(hit.candidates)
                 metrics['omitted'] += hit.omitted
                 if hit.pages and hit.chosen_page is None:
                     metrics['invalid_page_reads'] += 1
                 if hit.chosen_page is not None and hit.chosen_page > 0:
                     metrics['older_page_reads'] += 1
                 if memory != 'disabled' and ranks[row][t] < len(hit.candidates):
                     result[row,t] = hit.candidates[ranks[row][t]]
                 else:
                     metrics['null_reads'] += 1
         active_bits[key] = bits_mask
         return result

     def query_head(module,x):
         q=module(x[:,-1:])
         return torch.cat((q.new_zeros((batch,n-1,q.shape[-1])),q),1)

     h = encoded
     h = core.local_norm(h + F.gelu(core.local(F.pad(
         h.transpose(1,2), (cfg.local_kernel-1,0))).transpose(1,2)))
     h = h * valid.unsqueeze(-1)
     refs = torch.full_like(tokens,-1)
     for ell,layer in enumerate(core.layers):
         anchor = dereference(h,refs)
         metrics['reference_dereferences'] += int((refs>=0).sum())
         wr = choose(ell,'write_relation',layer.write_relation(h))
         wa = choose(ell,'write_address',layer.write_address(h))
         routes = choose(ell,'routes',query_head(layer.route,torch.cat((h,anchor),-1))
                         .reshape(batch,n,3,cfg.relations))
         r1,r2,ro = [routes[:,:,k] for k in range(3)]
         ef,es,op = [layer.relation(x) for x in (r1,r2,ro)]
         first = torch.cat((h,anchor,ef),-1)
         a1 = choose(ell,'query_first',query_head(layer.query_first,first))
         k1 = choose(ell,'rank_first',query_head(layer.rank_first,first))
         p1 = choose(ell,'page_first',query_head(layer.page_first,first).reshape(
             batch,n,core.page_bits,2))
         wr_cpu,wa_cpu = wr.detach().cpu().tolist(),wa.detach().cpu().tolist()
         indexes = [PagedCausalIndex(cfg.candidates) for _ in range(batch)]
         for row in range(batch):
             for t in range(n):
                 if bool(valid[row,t]):
                     indexes[row].append(t,wr_cpu[row][t],wa_cpu[row][t])
                     metrics['writes'] += 1
         j1 = read_postings(indexes,r1,a1,k1,p1,key=(ell,'page_first'))
         left = dereference(h,j1)
         second = torch.cat((h,anchor,left,es),-1)
         a2 = choose(ell,'query_second',query_head(layer.query_second,second))
         k2 = choose(ell,'rank_second',query_head(layer.rank_second,second))
         p2 = choose(ell,'page_second',query_head(layer.page_second,second).reshape(
             batch,n,core.page_bits,2))
         j2 = read_postings(indexes,r2,a2,k2,p2,key=(ell,'page_second'))
         right = dereference(h,j2)
         continuation = choose(ell,'continuation',query_head(layer.continue_ref,
             torch.cat((h,left,right,op),-1)))
         opts = torch.stack((torch.full_like(refs,-1),refs,j1,j2),-1)
         refs = opts.gather(-1,continuation.unsqueeze(-1)).squeeze(-1)
         if cfg.variant == 'no_reference' or memory == 'disabled':
             refs = torch.full_like(refs,-1)
         refs = torch.where(valid, refs,-1)
         features = torch.cat((h,left,right,ef,es,op,
                      (torch.stack((j1,j2),-1)>=0).to(h.dtype)),-1)
         q = layer.norm(h[:,-1:]+layer.compose(features[:,-1:]))
         h = torch.cat((q.new_zeros((batch,n-1,q.shape[-1])),q),1)
         metrics['operator_executions'] += batch
         refs_history.append(refs)
         operand_history.append(torch.stack((j1,j2),-1))
     return PagedOutput(core.lm_head(h),decisions,policies,used_noise,
                        refs_history,operand_history,metrics,active_bits)
